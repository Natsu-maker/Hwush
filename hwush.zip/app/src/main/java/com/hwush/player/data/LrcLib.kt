package com.hwush.player.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** One result from the lyrics search: the lyrics themselves come with it, timed when the contributor made them so. */
data class LyricHit(
    val title: String,
    val artist: String,
    val album: String,
    val durationSec: Int,
    val synced: String?,
    val plain: String?,
    val instrumental: Boolean,
)

/**
 * Looks lyrics up on LRCLIB (lrclib.net), a free community library made for apps like this one. Nothing about the user
 * is sent except the words typed into the search. Hwush only goes online when the Find online button is used.
 */
object LrcLib {
    class Failure(val msg: String) : Exception(msg)

    suspend fun search(title: String, artist: String): List<LyricHit> = withContext(Dispatchers.IO) {
        val primary = "track_name=" + enc(title) + if (artist.isNotBlank()) "&artist_name=" + enc(artist) else ""
        var hits = fetch(primary)
        if (hits.isEmpty()) hits = fetch("q=" + enc((artist + " " + title).trim()))
        hits
    }

    private fun enc(s: String) = URLEncoder.encode(s.trim(), "UTF-8")

    private fun fetch(query: String): List<LyricHit> {
        val c = URL("https://lrclib.net/api/search?$query").openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 15_000
            c.setRequestProperty("User-Agent", "Hwush (offline music player for Android)")
            val code = c.responseCode
            if (code == 404) return emptyList()
            if (code !in 200..299) throw Failure("The lyrics service answered with error $code.")
            val arr = JSONArray(c.inputStream.bufferedReader().use { it.readText() })
            val out = ArrayList<LyricHit>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val synced = o.optString("syncedLyrics", "").takeIf { it.isNotBlank() && it != "null" }
                val plain = o.optString("plainLyrics", "").takeIf { it.isNotBlank() && it != "null" }
                val instrumental = o.optBoolean("instrumental", false)
                if (synced == null && plain == null && !instrumental) continue
                out.add(
                    LyricHit(
                        o.optString("trackName", o.optString("name", "")),
                        o.optString("artistName", ""),
                        o.optString("albumName", ""),
                        o.optDouble("duration", 0.0).toInt(),
                        synced,
                        plain,
                        instrumental,
                    ),
                )
            }
            // Timed lyrics first, then the ones closest in length can be found by the user from the duration shown.
            return out.sortedByDescending { it.synced != null }
        } catch (e: Failure) {
            throw e
        } catch (e: Exception) {
            throw Failure("Could not reach the lyrics service. Check your connection.")
        } finally {
            c.disconnect()
        }
    }
}
