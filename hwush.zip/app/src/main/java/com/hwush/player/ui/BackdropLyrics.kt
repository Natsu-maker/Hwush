package com.hwush.player.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hwush.player.data.Lyrics
import kotlinx.coroutines.delay

/**
 * While a song with timed lyrics plays and the full player is closed, one line at a time drifts in behind the app,
 * in a different spot each time, and fades out before the next arrives. It never takes touches.
 */
@Composable
fun BackdropLyrics(ui: UiController, modifier: Modifier = Modifier) {
    val app = ui.app
    val sd by app.store.data.collectAsState()
    val pui by app.player.ui.collectAsState()
    if (!sd.bgLyrics || ui.nowPlayingOpen || ui.carMode) return
    val track = pui.path?.let { app.library.find(it) } ?: return
    val rev = app.lyricsRev.intValue
    var lyrics by remember(track.path) { mutableStateOf<Lyrics?>(null) }
    LaunchedEffect(track.path, rev, sd.lyricsTree, sd.songLyrics[track.path]) {
        lyrics = try { app.lyrics.find(track) } catch (_: Exception) { null }
    }
    val l = lyrics
    if (l == null || !l.synced || l.lines.isEmpty() || !pui.isPlaying) return
    val offset = sd.lyricOffsets[track.path] ?: 0L
    val pos by produceState(0L, track.path) {
        while (true) {
            value = app.player.position()
            delay(40L)
        }
    }
    val p = pos - offset
    var active = -1
    for (k in l.lines.indices) {
        if (l.lines[k].timeMs <= p + 120L) active = k else break
    }
    // Show the line from when it starts until the next one, but not for more than a few seconds.
    var shown = -1
    if (active >= 0) {
        val line = l.lines[active]
        val next = l.lines.getOrNull(active + 1)?.timeMs ?: (line.timeMs + 6000L)
        val span = minOf(next - line.timeMs, 7000L)
        if (line.text.isNotBlank() && p - line.timeMs < span) shown = active
    }
    val ease = FastOutSlowInEasing
    AnimatedContent(
        targetState = shown,
        modifier = modifier.fillMaxSize(),
        transitionSpec = {
            (fadeIn(tween(650, delayMillis = 120, easing = ease)) +
                scaleIn(tween(900, easing = ease), initialScale = 0.9f) +
                slideInVertically(tween(900, easing = ease)) { it / 10 })
                .togetherWith(
                    fadeOut(tween(520, easing = ease)) +
                        scaleOut(tween(700, easing = ease), targetScale = 1.06f) +
                        slideOutVertically(tween(700, easing = ease)) { -it / 12 },
                )
        },
        label = "bgLyrics",
    ) { idx ->
        if (idx < 0) {
            Box(Modifier.fillMaxSize())
        } else {
            val r = remember(idx, track.path) { java.util.Random(idx * 7919L + track.path.hashCode()) }
            val bx = remember(idx) { -0.7f + 1.4f * r.nextFloat() }
            val by = remember(idx) { -0.55f + 1.05f * r.nextFloat() }
            val glow = MaterialTheme.colorScheme.primary
            Box(
                Modifier.fillMaxSize().padding(horizontal = 36.dp, vertical = 96.dp),
                contentAlignment = BiasAlignment(bx, by),
            ) {
                Text(
                    l.lines[idx].text,
                    modifier = Modifier.widthIn(max = 460.dp),
                    textAlign = if (bx < -0.25f) TextAlign.Start else if (bx > 0.25f) TextAlign.End else TextAlign.Center,
                    style = TextStyle(
                        fontSize = (30f * sd.bgLyricsSize).sp,
                        lineHeight = (36f * sd.bgLyricsSize).sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.42f),
                        shadow = Shadow(glow.copy(alpha = 0.55f), blurRadius = 28f),
                    ),
                )
            }
        }
    }
}
