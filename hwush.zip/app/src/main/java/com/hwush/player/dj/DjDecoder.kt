package com.hwush.player.dj

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import com.hwush.player.data.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteOrder

/** A piece of a song turned into raw stereo sound, so a deck can play it at any speed, forward or backward. */
class DjClip(val data: ShortArray, val sampleRate: Int) {
    val frames: Int get() = data.size / 2
}

object DjDecoder {
    /** Decodes up to [maxSeconds] of [t], starting [startMs] in. Returns null when the song cannot be read. */
    suspend fun decode(ctx: Context, t: Track, startMs: Long, maxSeconds: Int = 150): DjClip? = withContext(Dispatchers.IO) {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, t.uri, null)
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                    idx = i
                    fmt = f
                    break
                }
            }
            if (idx < 0 || fmt == null) return@withContext null
            ex.selectTrack(idx)
            if (startMs > 0L) ex.seekTo(startMs * 1000L, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return@withContext null
            var rate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var channels = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(fmt, null, null, 0)
            codec.start()
            val info = MediaCodec.BufferInfo()
            var out = ShortArray(44100 * 2 * 10)
            var used = 0
            val limitFrames = maxSeconds * 48000
            var inputDone = false
            var outputDone = false
            val deadline = System.nanoTime() + 45_000_000_000L
            while (!outputDone && System.nanoTime() < deadline) {
                if (!inputDone) {
                    val i = codec.dequeueInputBuffer(5_000L)
                    if (i >= 0) {
                        val buf = codec.getInputBuffer(i)
                        val n = if (buf != null) ex.readSampleData(buf, 0) else -1
                        if (n < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 5_000L)
                if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                } else if (o >= 0) {
                    val buf = codec.getOutputBuffer(o)
                    if (buf != null && info.size > 0) {
                        val sb = buf.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val ch = maxOf(1, channels)
                        val frames = (sb.limit() - sb.position()) / ch
                        val base = sb.position()
                        if (used + frames * 2 > out.size) out = out.copyOf(maxOf(out.size * 2, used + frames * 2))
                        for (f in 0 until frames) {
                            val l = sb.get(base + f * ch)
                            val r = if (ch > 1) sb.get(base + f * ch + 1) else l
                            out[used++] = l
                            out[used++] = r
                        }
                        if (used / 2 >= rate * maxSeconds || used / 2 >= limitFrames) outputDone = true
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                }
            }
            if (used < 4410) return@withContext null
            DjClip(out.copyOf(used), rate)
        } catch (_: Exception) {
            null
        } catch (_: OutOfMemoryError) {
            null
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { ex.release() } catch (_: Exception) {}
        }
    }
}
