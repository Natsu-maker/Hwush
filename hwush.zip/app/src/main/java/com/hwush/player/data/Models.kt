package com.hwush.player.data

import android.net.Uri

data class Track(
    val id: Long,
    val uri: Uri,
    val path: String,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val folder: String,
    val dateAdded: Long,
    val size: Long,
    val trackNo: Int,
    val genre: String = "",
    val year: Int = 0,
)

data class Playlist(val id: Long, val name: String, val paths: List<String>, val cover: String? = null)

/** Sound settings remembered for a single song. */
data class SongFx(val speed: Float, val pitch: Float, val eq: List<Int>?, val bass: Int?)

/** Edits made inside Hwush. The audio file itself is never modified. */
data class TagOverride(
    val title: String? = null,
    val artist: String? = null,
    val album: String? = null,
    val cover: String? = null,
)

data class AlbumInfo(val key: String, val name: String, val artist: String, val tracks: List<Track>)
data class ArtistInfo(val name: String, val tracks: List<Track>)
data class FolderInfo(val path: String, val tracks: List<Track>)

data class LyricLine(val timeMs: Long, val text: String)
data class Lyrics(val lines: List<LyricLine>, val synced: Boolean)
