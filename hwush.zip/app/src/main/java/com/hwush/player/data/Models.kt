package com.hwush.player.data

import android.net.Uri

data class Track(
    val id: Long,
    val uri: Uri,
    val path: String,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val folder: String,
    val dateAdded: Long,
    val size: Long,
    val trackNo: Int,
    val genre: String = "",
    val year: Int = 0,
)

data class Playlist(val id: Long, val name: String, val paths: List<String>, val cover: String? = null)

/** Sound settings remembered for a single song. */
data class SongFx(val speed: Float, val pitch: Float, val eq: List<Int>?, val bass: Int?)

/** Edits made inside Hwush. The audio file itself is never modified. */
data class TagOverride(
    val title: String? = null,
    val artist: String? = null,
    val album: String? = null,
    val cover: String? = null,
)

data class AlbumInfo(val key: String, val name: String, val artist: String, val tracks: List<Track>)
data class ArtistInfo(val name: String, val tracks: List<Track>)
data class FolderInfo(val path: String, val tracks: List<Track>)

data class LyricLine(val timeMs: Long, val text: String)
data class Lyrics(val lines: List<LyricLine>, val synced: Boolean)


/** A playlist that fills itself from rules the user set. Every rule left empty is ignored. */
data class SmartRule(
    val id: Long,
    val name: String,
    val minRating: Int = 0,
    val minPlays: Int = 0,
    val genre: String = "",
    val artist: String = "",
    val favoritesOnly: Boolean = false,
    val addedDays: Int = 0,
    val playedDays: Int = 0,
    val notPlayedDays: Int = 0,
) {
    fun pick(
        all: List<Track>,
        favorites: Set<String>,
        ratings: Map<String, Int>,
        plays: Map<String, Int>,
        lastPlayed: Map<String, Long>,
        now: Long = System.currentTimeMillis(),
    ): List<Track> {
        val day = 86_400_000L
        return all.filter { t ->
            (minRating <= 0 || (ratings[t.path] ?: 0) >= minRating) &&
                (minPlays <= 0 || (plays[t.path] ?: 0) >= minPlays) &&
                (genre.isBlank() || t.genre.contains(genre.trim(), ignoreCase = true)) &&
                (artist.isBlank() || t.artist.contains(artist.trim(), ignoreCase = true)) &&
                (!favoritesOnly || t.path in favorites) &&
                (addedDays <= 0 || t.dateAdded * 1000L >= now - addedDays * day) &&
                (playedDays <= 0 || (lastPlayed[t.path] ?: 0L) >= now - playedDays * day) &&
                (notPlayedDays <= 0 || (lastPlayed[t.path] ?: 0L) < now - notPlayedDays * day)
        }.sortedBy { it.title.lowercase() }
    }
}


/** A search with filters the user saved. [spec] is the filters written as JSON. */
data class SavedSearch(val id: Long, val name: String, val spec: String)

/** Equalizer levels saved under a name, for example one per pair of headphones. */
data class EqProfile(val name: String, val levels: List<Int>, val bass: Int, val loudness: Int)
