@file:OptIn(ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Alarm
import androidx.compose.material.icons.rounded.Widgets
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.ArtistInfo
import com.hwush.player.data.Track

// ---------------------------------------------------------------- Home

private data class BrowseItem(val label: String, val note: String, val icon: ImageVector, val dest: Dest)

private val browseItems = listOf(
    BrowseItem("Recycle bin and health", "Restore things, find messy spots", Icons.Rounded.Delete, Dest(Kind.HEALTH)),
    BrowseItem("Theme builder", "Your colours, fonts and text size", Icons.Rounded.Edit, Dest(Kind.THEME)),
    BrowseItem("Widgets", "Design and add home screen widgets", Icons.Rounded.Widgets, Dest(Kind.WIDGETS)),
    BrowseItem("Alarm clock", "Wake up to your music, rising slowly", Icons.Rounded.Alarm, Dest(Kind.ALARMS)),
    BrowseItem("Mixes", "Daily, morning, night, workout and more", Icons.Rounded.AutoAwesome, Dest(Kind.MIXES)),
    BrowseItem("Smart search", "Filter by year, genre, rating, length", Icons.Rounded.Search, Dest(Kind.FILTER)),
    BrowseItem("Audiobooks and podcasts", "Pick up where you left off", Icons.Rounded.LibraryMusic, Dest(Kind.BOOKS)),
    BrowseItem("Goals and weekly report", "Daily listening goal and your week", Icons.Rounded.BarChart, Dest(Kind.GOALS)),
    BrowseItem("Achievements", "Badges for how you listen", Icons.Rounded.EmojiEvents, Dest(Kind.BADGES)),
    BrowseItem("Favorites", "Songs you loved", Icons.Rounded.Favorite, Dest(Kind.PLAYLIST, "s:fav")),
    BrowseItem("Top rated", "Four stars and up", Icons.Rounded.Star, Dest(Kind.PLAYLIST, "s:rated")),
    BrowseItem("Folders", "Browse by where songs are stored", Icons.Rounded.Folder, Dest(Kind.FOLDERS)),
    BrowseItem("Genres", "Rock, pop, hip hop and more", Icons.Rounded.LibraryMusic, Dest(Kind.GENRES)),
    BrowseItem("Years", "Songs by release year", Icons.Rounded.Event, Dest(Kind.YEARS)),
    BrowseItem("History", "Everything you played, day by day", Icons.Rounded.History, Dest(Kind.HISTORY)),
    BrowseItem("Your Hwush wrapped", "A story of what you play most", Icons.Rounded.AutoAwesome, Dest(Kind.WRAPPED)),
    BrowseItem("Listening stats", "Your top songs, artists and albums", Icons.Rounded.BarChart, Dest(Kind.STATS)),
    BrowseItem("Duplicate finder", "Find extra copies of the same song", Icons.Rounded.ContentCopy, Dest(Kind.DUPES)),
    BrowseItem("Fix messy files", "Names like 19283728492.flac", Icons.Rounded.Edit, Dest(Kind.FIXFILES)),
    BrowseItem("Music quiz", "Guess the song from a short clip", Icons.Rounded.EmojiEvents, Dest(Kind.QUIZ)),
)

@Composable
private fun HomeRow(title: String, tracks: List<Track>, ui: UiController, preview: HoldPreview, rowIndex: Int) {
    if (tracks.isEmpty()) return
    val pui by ui.app.player.ui.collectAsState()
    Text(
        title,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp).popIn(rowIndex),
    )
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        itemsIndexed(tracks, key = { i, t -> "$i-${t.id}" }) { i, t ->
            HomeCard(t, i, preview, pui.path == t.path) { ui.play(tracks, i) }
        }
    }
}

@Composable
fun HomeScreen(ui: UiController) {
    val app = ui.app
    val all by app.library.tracks.collectAsState()
    val loaded by app.library.loaded.collectAsState()
    val lastPlayed by app.store.select { it.lastPlayed }
    val plays by app.store.select { it.plays }
    val homeOrder by app.store.select { it.homeOrder }
    val homeHidden by app.store.select { it.homeHidden }
    if (loaded && all.isEmpty()) {
        EmptyLibrary(ui)
        return
    }
    val recent = remember(all, lastPlayed) {
        all.filter { lastPlayed.containsKey(it.path) }.sortedByDescending { lastPlayed[it.path] ?: 0L }.take(15)
    }
    val top = remember(all, plays) {
        all.filter { (plays[it.path] ?: 0) > 0 }.sortedByDescending { plays[it.path] ?: 0 }.take(15)
    }
    val added = remember(all) { all.sortedByDescending { it.dateAdded }.take(15) }
    val preview = rememberHoldPreview()
    val hello = remember { greeting() }
    val homePrimary = MaterialTheme.colorScheme.primary
    val homePal = remember(homePrimary) { listOf(homePrimary, homePrimary, homePrimary, homePrimary, homePrimary) }
    Box(Modifier.fillMaxSize()) {
    PlayerEffects(null, homePal, true, Modifier.fillMaxSize(), ambient = true)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item(key = "header") {
          Column {
            ListHeader("Hwush", plural(all.size, "song"), ui, all, showSettings = true)
            Text(
                hello,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp).popIn(0),
            )
            Text(
                "Hold a cover to hear a preview",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp).popIn(1),
            )
            GoalBanner(ui)
          }
        }
        if (java.util.Calendar.getInstance().get(java.util.Calendar.MONTH) == java.util.Calendar.DECEMBER) {
            item(key = "wrapped-banner") {
                androidx.compose.foundation.layout.Box(
                    Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth()
                        .clip(RoundedCornerShape(20.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF693668), Color(0xFF3F7CFF))))
                        .clickable { ui.open(Dest(Kind.WRAPPED, "YEAR")) }
                        .padding(20.dp),
                ) {
                    Column {
                        Text("Your year in music is ready", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Tap to see your Hwush wrapped", color = Color.White.copy(alpha = 0.8f))
                    }
                }
            }
        }
        val order = homeOrder.filter { it !in homeHidden }
        order.forEach { id ->
            when (id) {
                "recent" -> item(key = "recent") { HomeRow("Jump back in", recent, ui, preview, 0) }
                "top" -> item(key = "top") { HomeRow("Most played", top, ui, preview, 1) }
                "added" -> item(key = "added") { HomeRow("Recently added", added, ui, preview, 2) }
                "browse" -> {
                    item(key = "browse") {
                        Text(
                            "Browse",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(start = 16.dp, top = 20.dp, bottom = 4.dp),
                        )
                    }
                    itemsIndexed(browseItems, key = { _, b -> b.label }) { bi, b ->
                        ListItem(
                            modifier = Modifier.staggerIn(bi).clickable { ui.open(b.dest) },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            leadingContent = { Icon(b.icon, null, tint = MaterialTheme.colorScheme.primary) },
                            headlineContent = { Text(b.label) },
                            supportingContent = { Text(b.note) },
                        )
                    }
                }
            }
        }
    }
    }
}

// ---------------------------------------------------------------- Genres and years

@Composable
private fun GroupList(
    ui: UiController,
    title: String,
    unit: String,
    groups: List<ArtistInfo>,
    detail: Kind,
    icon: ImageVector,
    emptyBody: String,
) {
    Column(Modifier.fillMaxSize()) {
        ListHeader(title, plural(groups.size, unit), ui, emptyList(), back = ui.stack.size > 1)
        if (groups.isEmpty()) {
            EmptyState("Nothing here yet", emptyBody)
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(groups, key = { it.name }) { g ->
                    ListItem(
                        modifier = Modifier.clickable { ui.open(Dest(detail, g.name)) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        leadingContent = { Icon(icon, null, tint = MaterialTheme.colorScheme.primary) },
                        headlineContent = { Text(g.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        supportingContent = { Text(plural(g.tracks.size, "song")) },
                    )
                }
            }
        }
    }
}

@Composable
private fun GroupDetail(ui: UiController, name: String, groups: List<ArtistInfo>, notFound: String) {
    val g = groups.firstOrNull { it.name == name }
    if (g == null) {
        EmptyState(notFound, "It may have been removed from your library.")
        return
    }
    val sorted = remember(g) { sortTracks(g.tracks, 1, false) }
    TrackList(ui, sorted, header = {
        ListHeader(
            title = g.name,
            subtitle = plural(sorted.size, "song"),
            ui = ui,
            tracks = sorted,
            back = true,
            cover = sorted.first(),
        )
    })
}

@Composable
fun GenresScreen(ui: UiController) {
    val groups by ui.app.library.genres.collectAsState()
    GroupList(
        ui, "Genres", "genre", groups, Kind.GENRE, Icons.Rounded.LibraryMusic,
        "Genres come from the tags inside your songs. None of your songs have a genre tag yet.",
    )
}

@Composable
fun GenreDetail(ui: UiController, name: String) {
    val groups by ui.app.library.genres.collectAsState()
    GroupDetail(ui, name, groups, "Genre not found")
}

@Composable
fun YearsScreen(ui: UiController) {
    val groups by ui.app.library.years.collectAsState()
    GroupList(
        ui, "Years", "year", groups, Kind.YEAR, Icons.Rounded.Event,
        "Years come from the tags inside your songs. None of your songs have a year tag yet.",
    )
}

@Composable
fun YearDetail(ui: UiController, name: String) {
    val groups by ui.app.library.years.collectAsState()
    GroupDetail(ui, name, groups, "Year not found")
}

// ---------------------------------------------------------------- Duplicate finder

@Composable
fun DupesScreen(ui: UiController) {
    val groups by ui.app.library.duplicates.collectAsState()
    val pui by ui.app.player.ui.collectAsState()
    Column(Modifier.fillMaxSize()) {
        ListHeader("Duplicates", plural(groups.size, "set"), ui, emptyList(), back = ui.stack.size > 1)
        if (groups.isEmpty()) {
            EmptyState("No duplicates found", "Songs that look like copies of each other will show up here.")
        } else {
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                item(key = "info") {
                    Text(
                        "Hide the extra copies to tidy your library. Your files are never deleted.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }
                groups.forEachIndexed { gi, g ->
                    item(key = "h$gi") {
                        Text(
                            "${g.first().title} · ${g.size} copies",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(start = 16.dp, top = 14.dp, bottom = 2.dp),
                        )
                    }
                    items(g, key = { "$gi-${it.id}" }) { t ->
                        SongRow(
                            t = t,
                            ui = ui,
                            playing = pui.path == t.path,
                            onClick = { ui.play(g, g.indexOf(t)) },
                            showMenu = false,
                            trailing = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        fmtBytes(t.size),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                    TextButton(onClick = {
                                        ui.app.store.hide(t.path)
                                        ui.say("Copy hidden")
                                    }) { Text("Hide") }
                                }
                            },
                        )
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Ratings

@Composable
fun RatingRow(ui: UiController, t: Track) {
    val r by ui.app.store.select(t.path) { it.ratings[t.path] ?: 0 }
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.Center) {
        for (n in 1..5) {
            IconButton(onClick = { ui.app.store.setRating(t.path, if (r == n) 0 else n) }) {
                Icon(
                    if (n <= r) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                    "Rate $n stars",
                    tint = if (n <= r) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

// ---------------------------------------------------------------- Multi-select bar

@Composable
fun SelectionBar(ui: UiController, modifier: Modifier = Modifier) {
    val picked = ui.selection.toList()
    if (picked.isEmpty()) return
    Surface(
        modifier = modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 4.dp),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
        shadowElevation = 6.dp,
    ) {
        Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { ui.selection.clear() }) { Icon(Icons.Rounded.Close, "Cancel selection") }
            Text(
                "${picked.size} selected",
                modifier = Modifier.weight(1f),
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            IconButton(onClick = { ui.playNext(picked); ui.selection.clear(); ui.say("Playing next") }) {
                Icon(Icons.Rounded.SkipNext, "Play next")
            }
            IconButton(onClick = { ui.enqueue(picked); ui.selection.clear(); ui.say("Added to queue") }) {
                Icon(Icons.Rounded.QueueMusic, "Add to queue")
            }
            IconButton(onClick = {
                val paths = picked.map { it.path }
                ui.app.store.update { it.copy(favorites = it.favorites + paths) }
                ui.selection.clear()
                ui.say("Added to favorites")
            }) { Icon(Icons.Rounded.Favorite, "Add to favorites") }
            IconButton(onClick = { ui.pickPlaylistFor = picked; ui.selection.clear() }) {
                Icon(Icons.Rounded.Add, "Add to playlist")
            }
            val ctx = androidx.compose.ui.platform.LocalContext.current
            IconButton(onClick = { shareTracks(ctx, picked); ui.selection.clear() }) {
                Icon(Icons.Rounded.Share, "Share")
            }
            // Inside one of your own playlists the songs can be taken out in one go, with an undo.
            val here = ui.current
            val plId = if (here.kind == Kind.PLAYLIST) here.arg.toLongOrNull() else null
            if (plId != null) {
                IconButton(onClick = {
                    val before = ui.app.store.data.value.playlists.firstOrNull { it.id == plId }?.paths
                    val gone = picked.map { it.path }.toSet()
                    if (before != null) {
                        ui.app.store.setPlaylistPaths(plId, before.filter { it !in gone })
                        ui.sayAction("Removed ${plural(gone.size, "song")}", "Undo") { ui.app.store.setPlaylistPaths(plId, before) }
                    }
                    ui.selection.clear()
                }) { Icon(Icons.Rounded.Delete, "Remove from this playlist") }
            }
        }
    }
}
