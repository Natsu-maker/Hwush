@file:OptIn(ExperimentalLayoutApi::class)

package com.hwush.player.ui

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.StoreData
import com.hwush.player.widget.HwushWidget
import com.hwush.player.widget.HwushWidgetBig
import com.hwush.player.widget.HwushWidgetCard
import com.hwush.player.widget.HwushWidgetMini
import kotlin.math.roundToInt

private fun pinWidget(ctx: Context, cls: Class<*>): Boolean {
    val mgr = AppWidgetManager.getInstance(ctx)
    if (!mgr.isRequestPinAppWidgetSupported) return false
    return try {
        mgr.requestPinAppWidget(ComponentName(ctx, cls), null, null)
    } catch (_: Exception) {
        false
    }
}

/** Shape the home screen widgets: a live preview on top and every choice below it. Changes reach the widgets at once. */
@Composable
fun WidgetsScreen(ui: UiController) {
    val app = ui.app
    val ctx = LocalContext.current
    val sd by app.store.data.collectAsState()
    val pui by app.player.ui.collectAsState()
    val track = pui.path?.let { app.library.find(it) } ?: app.library.tracks.value.firstOrNull()
    val change: ((StoreData) -> StoreData) -> Unit = { f ->
        app.store.update(f)
        HwushWidget.update(ctx)
    }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        ListHeader("Widgets", "Make them yours", ui, emptyList(), back = ui.stack.size > 1)
        // A pretend wallpaper behind the preview, so see-through styles can be judged.
        Box(
            Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(Color(0xFFE0457B), Color(0xFF4B5BD8), Color(0xFF16B3A6))))
                .padding(20.dp),
            contentAlignment = Alignment.Center,
        ) {
            WidgetPreview(track, sd)
        }
        Spacer(Modifier.height(12.dp))
        Heading("Add to home screen")
        FlowRow(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(
                "Card" to HwushWidgetCard::class.java,
                "Bar" to HwushWidget::class.java,
                "Big cover" to HwushWidgetBig::class.java,
                "Mini" to HwushWidgetMini::class.java,
            ).forEach { (label, cls) ->
                AssistChip(onClick = {
                    if (!pinWidget(ctx, cls)) ui.say("Hold an empty spot on your home screen, choose Widgets, then Hwush")
                }, label = { Text(label) })
            }
        }
        Heading("Background")
        Choices(
            listOf("Solid" to 0, "Cover tint" to 1, "Cover colours" to 2, "Glass" to 3),
            sd.widgetBg,
        ) { v -> change { it.copy(widgetBg = v) } }
        Heading("Opacity  ${sd.widgetOpacity}%")
        Slider(
            value = sd.widgetOpacity.toFloat(),
            onValueChange = { v -> change { it.copy(widgetOpacity = ((v / 5f).roundToInt() * 5).coerceIn(10, 100)) } },
            valueRange = 10f..100f,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        Heading("Corners  ${sd.widgetCorner} dp")
        Slider(
            value = sd.widgetCorner.toFloat(),
            onValueChange = { v -> change { it.copy(widgetCorner = v.roundToInt()) } },
            valueRange = 0f..40f,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        Heading("Cover shape")
        Choices(listOf("Rounded" to 0, "Circle" to 1, "Square" to 2), sd.widgetCover) { v -> change { it.copy(widgetCover = v) } }
        Heading("Accent")
        Choices(listOf("From the cover" to 0, "App colour" to 1, "Plain" to 2), sd.widgetAccent) { v -> change { it.copy(widgetAccent = v) } }
        Heading("Text")
        Choices(listOf("Light on dark" to false, "Dark on light" to true), sd.widgetDarkText) { v -> change { it.copy(widgetDarkText = v) } }
        SwitchRow("Heart button", sd.widgetHeart) { v -> change { it.copy(widgetHeart = v) } }
        SwitchRow("Progress bar", sd.widgetProgress) { v -> change { it.copy(widgetProgress = v) } }
        Text(
            "The heart and progress bar show on the card and big widgets. The progress bar moves about every 15 seconds.",
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun Heading(text: String) {
    Text(
        text,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 6.dp),
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** What the card widget will look like, drawn with the same choices the real one uses. */
@Composable
private fun WidgetPreview(track: com.hwush.player.data.Track?, sd: StoreData) {
    val primary = MaterialTheme.colorScheme.primary
    val tint = rememberArtColor(track, primary)
    val light = sd.widgetDarkText
    val ink = if (light) Color(0xFF14161C) else Color(0xFFF2F4FF)
    val sub = if (light) Color(0xFF4A4F60) else Color(0xFFB4B9CC)
    val base = if (light) Color(0xFFF4F5FA) else Color(0xFF101218)
    val accent = when (sd.widgetAccent) {
        1 -> Color(sd.accentColor)
        2 -> ink
        else -> tint
    }
    val a = sd.widgetOpacity / 100f
    val shape = RoundedCornerShape(sd.widgetCorner.dp)
    val bg = when (sd.widgetBg) {
        0 -> Brush.linearGradient(listOf(base.copy(alpha = a), base.copy(alpha = a)))
        1 -> Brush.linearGradient(
            listOf(
                lerp(base, tint, if (light) 0.32f else 0.62f).copy(alpha = a),
                lerp(base, tint, if (light) 0.08f else 0.14f).copy(alpha = a),
            ),
        )
        2 -> Brush.linearGradient(
            listOf(
                lerp(base, tint, if (light) 0.5f else 0.8f).copy(alpha = a),
                lerp(base, MaterialTheme.colorScheme.tertiary, if (light) 0.25f else 0.4f).copy(alpha = a),
            ),
        )
        else -> Brush.linearGradient(listOf(Color.White.copy(alpha = a * 0.22f), Color.White.copy(alpha = a * 0.1f)))
    }
    val coverShape = when (sd.widgetCover) {
        1 -> CircleShape
        2 -> RoundedCornerShape(0.dp)
        else -> RoundedCornerShape(14.dp)
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(bg)
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Cover(track, Modifier.size(64.dp), 96.dp, coverShape)
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(track?.title ?: "Hwush", color = ink, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(track?.artist ?: "Tap to open", color = sub, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (sd.widgetHeart) Icon(Icons.Rounded.Favorite, null, tint = accent, modifier = Modifier.size(24.dp))
        }
        if (sd.widgetProgress) {
            Spacer(Modifier.height(10.dp))
            Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(ink.copy(alpha = 0.2f))) {
                Box(Modifier.fillMaxWidth(0.42f).height(4.dp).clip(CircleShape).background(accent))
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.SkipPrevious, null, tint = ink, modifier = Modifier.size(36.dp))
            Spacer(Modifier.width(12.dp))
            Icon(Icons.Rounded.PlayArrow, null, tint = ink, modifier = Modifier.size(44.dp))
            Spacer(Modifier.width(12.dp))
            Icon(Icons.Rounded.SkipNext, null, tint = ink, modifier = Modifier.size(36.dp))
        }
    }
}
