@file:OptIn(UnstableApi::class)

package com.hwush.player.player

import android.app.PendingIntent
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.media3.common.util.BitmapLoader
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.hwush.player.HwushApp
import com.hwush.player.MainActivity
import com.hwush.player.R
import com.hwush.player.data.Art
import com.hwush.player.data.Library
import java.util.concurrent.Callable
import java.util.concurrent.Executors

/** Keeps music playing with the screen off and shows the notification and lock screen controls. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        val app = application as HwushApp
        setMediaNotificationProvider(
            DefaultMediaNotificationProvider(this).apply { setSmallIcon(R.drawable.ic_stat_hwush) },
        )
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        session = MediaSession.Builder(this, app.player.player)
            .setSessionActivity(open)
            .setBitmapLoader(ArtBitmapLoader(app.art, app.library))
            .build()
        // Register the session with the service so the notification and lock screen player appear.
        addSession(session!!)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        session?.release()
        session = null
        super.onDestroy()
    }
}

/** Gives the notification and lock screen the same cover art the app shows. */
class ArtBitmapLoader(private val art: Art, private val library: Library) : BitmapLoader {
    private val exec = MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor())

    override fun supportsMimeType(mimeType: String): Boolean = mimeType.startsWith("image/")

    override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> = exec.submit(
        Callable<Bitmap> {
            BitmapFactory.decodeByteArray(data, 0, data.size)
                ?: throw IllegalStateException("Could not decode image")
        },
    )

    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> = exec.submit(
        Callable<Bitmap> {
            val path = uri.getQueryParameter("p") ?: throw IllegalArgumentException("No song in uri")
            val track = library.find(path) ?: throw IllegalStateException("Unknown song")
            art.loadBlocking(track, 512) ?: throw IllegalStateException("No cover")
        },
    )
}
