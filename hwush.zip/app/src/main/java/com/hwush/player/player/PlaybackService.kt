@file:OptIn(UnstableApi::class)

package com.hwush.player.player

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.util.BitmapLoader
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.CommandButton
import androidx.media3.session.DefaultMediaNotificationProvider
import androidx.media3.session.MediaNotification
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.hwush.player.HwushApp
import com.hwush.player.LockScreenActivity
import com.hwush.player.MainActivity
import com.hwush.player.R
import com.hwush.player.data.Art
import com.hwush.player.data.Library
import com.hwush.player.data.dominantColor
import java.util.concurrent.Callable
import java.util.concurrent.Executors

/** Keeps music playing with the screen off and shows the notification and lock screen controls. */
class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null

    /** Shows the full screen player when the screen turns off while music is playing. */
    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val app = application as HwushApp
            if (!app.store.data.value.lockPlayer) return
            if (!app.player.player.isPlaying) return
            if (Build.VERSION.SDK_INT >= 29 && !Settings.canDrawOverlays(context)) return
            try {
                startActivity(
                    Intent(context, LockScreenActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                )
            } catch (_: Exception) {
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        val app = application as HwushApp
        setMediaNotificationProvider(HwushNotificationProvider(app))
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        session = MediaSession.Builder(this, app.player.player)
            .setSessionActivity(open)
            .setBitmapLoader(ArtBitmapLoader(app.art, app.library))
            .build()
        // Register the session with the service so the notification and lock screen player appear.
        addSession(session!!)
        ContextCompat.registerReceiver(
            this,
            screenOff,
            IntentFilter(Intent.ACTION_SCREEN_OFF),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    /** Redraws the notification, for example after the heart was tapped. */
    fun refreshNotification() {
        val s = session ?: return
        try {
            onUpdateNotification(s, s.player.isPlaying)
        } catch (_: Exception) {
        }
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        instance = null
        try {
            unregisterReceiver(screenOff)
        } catch (_: Exception) {
        }
        session?.release()
        session = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: PlaybackService? = null
    }
}

/** Handles the buttons on the expanded notification. */
class NotifActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as HwushApp
        val player = app.player
        when (intent.action) {
            ACT_PLAY -> player.togglePlay()
            ACT_NEXT -> player.next()
            ACT_PREV -> player.previous()
            ACT_REW -> player.seekBy(-10_000L)
            ACT_FWD -> player.seekBy(10_000L)
            ACT_FAV -> {
                val path = player.currentPath()
                if (path != null) {
                    app.store.toggleFavorite(path)
                    PlaybackService.instance?.refreshNotification()
                }
            }
        }
    }

    companion object {
        const val ACT_PLAY = "com.hwush.player.N_PLAY"
        const val ACT_NEXT = "com.hwush.player.N_NEXT"
        const val ACT_PREV = "com.hwush.player.N_PREV"
        const val ACT_REW = "com.hwush.player.N_REW"
        const val ACT_FWD = "com.hwush.player.N_FWD"
        const val ACT_FAV = "com.hwush.player.N_FAV"
    }
}

/**
 * The standard media notification with a bigger expanded view: cover, title, artist, album,
 * heart, previous, rewind, play, forward, next, add to playlist, and the next songs in the queue.
 */
class HwushNotificationProvider(private val app: HwushApp) : DefaultMediaNotificationProvider(app) {

    init {
        setSmallIcon(R.drawable.ic_stat_hwush)
    }

    override fun addNotificationActions(
        mediaSession: MediaSession,
        mediaButtons: ImmutableList<CommandButton>,
        builder: NotificationCompat.Builder,
        actionFactory: MediaNotification.ActionFactory,
    ): IntArray {
        val compact = super.addNotificationActions(mediaSession, mediaButtons, builder, actionFactory)
        try {
            builder.setCustomBigContentView(buildBig())
        } catch (_: Exception) {
        }
        return compact
    }

    private fun broadcast(code: Int, action: String): PendingIntent = PendingIntent.getBroadcast(
        app,
        code,
        Intent(app, NotifActionReceiver::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun background(color: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hsv[1] = hsv[1].coerceAtMost(0.7f)
        hsv[2] = hsv[2].coerceIn(0.28f, 0.5f)
        return Color.HSVToColor(hsv)
    }

    private fun buildBig(): RemoteViews {
        val exo = app.player.player
        val track = app.player.currentTrack()
        val rv = RemoteViews(app.packageName, R.layout.notification_big)
        rv.setTextViewText(R.id.n_title, track?.title ?: "Hwush")
        rv.setTextViewText(R.id.n_artist, track?.artist ?: "")
        rv.setTextViewText(R.id.n_album, track?.album ?: "")

        var bg = 0xFF2B3550.toInt()
        val bmp = if (track != null) app.art.loadBlocking(track, 256) else null
        if (bmp != null) {
            rv.setImageViewBitmap(R.id.n_art, bmp)
            bg = background(dominantColor(bmp))
        } else {
            rv.setImageViewResource(R.id.n_art, R.drawable.ic_stat_hwush)
        }
        rv.setInt(R.id.n_root, "setBackgroundColor", bg)

        val fav = track != null && track.path in app.store.data.value.favorites
        rv.setImageViewResource(R.id.n_fav, if (fav) R.drawable.ic_heart_filled else R.drawable.ic_heart)
        rv.setImageViewResource(R.id.n_prev, R.drawable.ic_prev)
        rv.setImageViewResource(R.id.n_rew, R.drawable.ic_rewind)
        rv.setImageViewResource(R.id.n_play, if (exo.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        rv.setImageViewResource(R.id.n_fwd, R.drawable.ic_forward)
        rv.setImageViewResource(R.id.n_next, R.drawable.ic_next)
        rv.setImageViewResource(R.id.n_add, R.drawable.ic_queue_add)
        rv.setOnClickPendingIntent(R.id.n_fav, broadcast(1, NotifActionReceiver.ACT_FAV))
        rv.setOnClickPendingIntent(R.id.n_prev, broadcast(2, NotifActionReceiver.ACT_PREV))
        rv.setOnClickPendingIntent(R.id.n_rew, broadcast(3, NotifActionReceiver.ACT_REW))
        rv.setOnClickPendingIntent(R.id.n_play, broadcast(4, NotifActionReceiver.ACT_PLAY))
        rv.setOnClickPendingIntent(R.id.n_fwd, broadcast(5, NotifActionReceiver.ACT_FWD))
        rv.setOnClickPendingIntent(R.id.n_next, broadcast(6, NotifActionReceiver.ACT_NEXT))
        rv.setOnClickPendingIntent(
            R.id.n_add,
            PendingIntent.getActivity(
                app,
                7,
                Intent(app, MainActivity::class.java)
                    .setAction(MainActivity.ACTION_ADD_PLAYLIST)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            ),
        )

        val upcoming = ArrayList<String>()
        var i = exo.currentMediaItemIndex + 1
        while (i < exo.mediaItemCount && upcoming.size < 2) {
            val m = exo.getMediaItemAt(i).mediaMetadata
            upcoming.add("${m.title ?: ""} - ${m.artist ?: ""}")
            i++
        }
        if (upcoming.isEmpty()) {
            rv.setTextViewText(R.id.n_up_label, "End of queue")
            rv.setTextViewText(R.id.n_up1, "")
            rv.setTextViewText(R.id.n_up2, "")
        } else {
            rv.setTextViewText(R.id.n_up_label, "Upcoming songs")
            rv.setTextViewText(R.id.n_up1, upcoming[0])
            rv.setTextViewText(R.id.n_up2, upcoming.getOrElse(1) { "" })
        }
        return rv
    }
}

/** Gives the notification and lock screen the same cover art the app shows. */
class ArtBitmapLoader(private val art: Art, private val library: Library) : BitmapLoader {
    private val exec = MoreExecutors.listeningDecorator(Executors.newSingleThreadExecutor())

    override fun supportsMimeType(mimeType: String): Boolean = mimeType.startsWith("image/")

    override fun decodeBitmap(data: ByteArray): ListenableFuture<Bitmap> = exec.submit(
        Callable<Bitmap> {
            BitmapFactory.decodeByteArray(data, 0, data.size)
                ?: throw IllegalStateException("Could not decode image")
        },
    )

    override fun loadBitmap(uri: Uri): ListenableFuture<Bitmap> = exec.submit(
        Callable<Bitmap> {
            val path = uri.getQueryParameter("p") ?: throw IllegalArgumentException("No song in uri")
            val track = library.find(path) ?: throw IllegalStateException("Unknown song")
            art.loadBlocking(track, 512) ?: throw IllegalStateException("No cover")
        },
    )
}
