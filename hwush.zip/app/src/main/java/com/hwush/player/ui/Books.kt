package com.hwush.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Track

private data class BookEntry(
    val key: String,
    val title: String,
    val folder: Boolean,
    val tracks: List<Track>,
)

private fun bkLeft(ms: Long): String {
    val m = ms / 60_000L
    return if (m >= 60L) "${m / 60} h ${m % 60} min left" else "$m min left"
}

private val bkSpeeds = listOf(1f, 1.25f, 1.5f, 1.75f, 2f)

/** Audiobooks and podcasts: they remember where you stopped and keep their own speed. */
@Composable
fun BooksScreen(ui: UiController) {
    val app = ui.app
    val all by app.library.tracks.collectAsState()
    val sd by app.store.data.collectAsState()
    val pui by app.player.ui.collectAsState()
    var picking by remember { mutableStateOf(false) }

    val entries = remember(all, sd.books, sd.bookFolders) {
        val list = ArrayList<BookEntry>()
        for (f in sd.bookFolders) {
            val ts = all.filter { it.folder == f }.sortedWith(compareBy({ it.trackNo }, { it.title.lowercase() }))
            if (ts.isNotEmpty()) list.add(BookEntry(f, lastSegment(f), true, ts))
        }
        for (p in sd.books) {
            val t = all.firstOrNull { it.path == p }
            if (t != null && t.folder !in sd.bookFolders) list.add(BookEntry(p, t.title, false, listOf(t)))
        }
        list.sortedBy { it.title.lowercase() }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        ListHeader("Audiobooks and podcasts", plural(entries.size, "title"), ui, emptyList(), back = ui.stack.size > 1)
        Text(
            "Mark a folder or a single file as a book. Hwush then remembers where you stopped, starts a few seconds early, and keeps the speed you chose for that book. It never changes speed for your music.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        )
        OutlinedButton(onClick = { picking = true }, modifier = Modifier.padding(horizontal = 16.dp)) { Text("Add a folder") }
        Text(
            "To mark a single file, open its menu and choose Mark as audiobook or podcast.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        )
        entries.forEachIndexed { i, e ->
            val total = e.tracks.size
            val doneCount = e.tracks.count { it.path in sd.bookDone }
            val frac = e.tracks.sumOf { t ->
                when {
                    t.path in sd.bookDone -> 1.0
                    t.durationMs > 0L -> ((sd.positions[t.path] ?: 0L).toDouble() / t.durationMs).coerceIn(0.0, 1.0)
                    else -> 0.0
                }
            }.toFloat() / total
            val nextIdx = e.tracks.indexOfFirst { it.path !in sd.bookDone }.let { if (it < 0) 0 else it }
            val next = e.tracks[nextIdx]
            val left = e.tracks.filter { it.path !in sd.bookDone }.sumOf { t -> (t.durationMs - (sd.positions[t.path] ?: 0L)).coerceAtLeast(0L) }
            val speed = sd.bookSpeeds[e.key] ?: 1f
            val playingThis = pui.path != null && e.tracks.any { it.path == pui.path }
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).popIn(i).glass().padding(14.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Cover(next, Modifier.size(64.dp), 64.dp, RoundedCornerShape(12.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(e.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (e.folder) "File ${nextIdx + 1} of $total" else next.artist,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                        )
                        Text(
                            if (doneCount == total) "Finished" else bkLeft(left),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                        )
                    }
                    IconButton(onClick = {
                        app.store.update { d ->
                            if (e.folder) d.copy(bookFolders = d.bookFolders - e.key) else d.copy(books = d.books - e.key)
                        }
                        ui.say("Removed from audiobooks")
                    }) { Icon(Icons.Rounded.Close, "Remove from audiobooks") }
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { frac.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(6.dp))
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = {
                        if (doneCount == total) {
                            app.store.update { d -> d.copy(bookDone = d.bookDone - e.tracks.map { it.path }.toSet()) }
                            ui.play(e.tracks, 0)
                        } else {
                            ui.play(e.tracks, nextIdx)
                        }
                    }) { Text(if (doneCount == total) "Listen again" else if (sd.positions.containsKey(next.path) || nextIdx > 0) "Continue" else "Start") }
                    AssistChip(
                        onClick = {
                            val n = bkSpeeds[(bkSpeeds.indexOfFirst { kotlin.math.abs(it - speed) < 0.01f } + 1).mod(bkSpeeds.size)]
                            app.store.update { d -> d.copy(bookSpeeds = d.bookSpeeds + (e.key to n)) }
                            if (playingThis) app.player.setSpeed(n)
                        },
                        label = { Text(fmtSpeed(speed)) },
                    )
                    if (playingThis) AssistChip(onClick = { ui.bookmarksOpen = true }, label = { Text("Chapter marks") })
                }
            }
        }
    }

    if (picking) {
        val folders = remember(all) {
            all.groupBy { it.folder }.filter { it.key.isNotEmpty() }.map { it.key to it.value.size }.sortedBy { lastSegment(it.first).lowercase() }
        }
        AlertDialog(
            onDismissRequest = { picking = false },
            title = { Text("Choose a folder") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    folders.forEach { (f, n) ->
                        Column(
                            Modifier.fillMaxWidth().clickable {
                                picking = false
                                app.store.update { d -> d.copy(bookFolders = d.bookFolders + f) }
                                ui.say("Added ${lastSegment(f)}")
                            }.padding(vertical = 8.dp),
                        ) {
                            Text(lastSegment(f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(plural(n, "file"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { picking = false }) { Text("Cancel") } },
        )
    }
}
