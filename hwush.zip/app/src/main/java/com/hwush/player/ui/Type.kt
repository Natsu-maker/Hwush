package com.hwush.player.ui

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.hwush.player.R

/** Poppins, bundled inside the app so it looks the same on every phone. */
val PoppinsFamily = FontFamily(
    Font(R.font.poppins_regular, FontWeight.Normal),
    Font(R.font.poppins_medium, FontWeight.Medium),
    Font(R.font.poppins_medium, FontWeight.SemiBold),
    Font(R.font.poppins_bold, FontWeight.Bold),
)

/** The fonts to choose from. All but the first come with the phone, so they cost nothing in size. */
val fontChoices = listOf("Poppins", "Phone font", "Serif", "Mono")

private fun familyFor(style: Int): FontFamily = when (style) {
    1 -> FontFamily.SansSerif
    2 -> FontFamily.Serif
    3 -> FontFamily.Monospace
    else -> PoppinsFamily
}

fun hwushTypography(fontStyle: Int = 0, scalePct: Int = 100): Typography {
    val base = Typography()
    val fam = familyFor(fontStyle)
    val k = scalePct.coerceIn(80, 140) / 100f
    fun TextStyle.f(): TextStyle = copy(
        fontFamily = fam,
        fontSize = fontSize * k,
        lineHeight = lineHeight * k,
    )
    return Typography(
        displayLarge = base.displayLarge.f(),
        displayMedium = base.displayMedium.f(),
        displaySmall = base.displaySmall.f(),
        headlineLarge = base.headlineLarge.f(),
        headlineMedium = base.headlineMedium.f(),
        headlineSmall = base.headlineSmall.f(),
        titleLarge = base.titleLarge.f(),
        titleMedium = base.titleMedium.f(),
        titleSmall = base.titleSmall.f(),
        bodyLarge = base.bodyLarge.f(),
        bodyMedium = base.bodyMedium.f(),
        bodySmall = base.bodySmall.f(),
        labelLarge = base.labelLarge.f(),
        labelMedium = base.labelMedium.f(),
        labelSmall = base.labelSmall.f(),
    )
}
