package com.hwush.player.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** One listen with its date and time. A skip is a song you left before it counted as a play. */
data class PlayEvent(val ts: Long, val path: String, val durMs: Long, val skipped: Boolean)

/**
 * The dated listening history behind Wrapped. It lives in its own file so the main settings file stays small,
 * and it is stored locally only. Song paths are stored once and events point at them.
 */
class History(ctx: Context) {
    private val file = File(ctx.filesDir, "history.json")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var saveJob: Job? = null

    val events = MutableStateFlow(load())

    private fun load(): List<PlayEvent> = try {
        if (file.exists()) decode(JSONObject(file.readText())) else emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    fun add(e: PlayEvent) {
        events.update { old ->
            val l = old + e
            if (l.size > MAX_EVENTS) l.subList(l.size - MAX_EVENTS, l.size).toList() else l
        }
        scheduleSave()
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(3_000)
            writeNow()
        }
    }

    @Synchronized
    private fun writeNow() {
        try {
            val tmp = File(file.path + ".tmp")
            tmp.writeText(encode(events.value).toString())
            tmp.renameTo(file)
        } catch (_: Exception) {
        }
    }

    fun flush() {
        saveJob?.cancel()
        writeNow()
    }

    /** Adds the history to a settings backup so a restore brings the wrapped back too. */
    fun withHistory(storeJson: String): String = try {
        JSONObject(storeJson).put("history", encode(events.value)).toString()
    } catch (e: Exception) {
        storeJson
    }

    /** Reads the history out of a backup, if it has one. */
    fun restore(backup: String) {
        try {
            val h = JSONObject(backup).optJSONObject("history") ?: return
            events.value = decode(h)
            scheduleSave()
        } catch (_: Exception) {
        }
    }

    companion object {
        const val MAX_EVENTS = 60_000

        fun encode(list: List<PlayEvent>): JSONObject {
            val idx = LinkedHashMap<String, Int>()
            val ev = JSONArray()
            for (e in list) {
                val i = idx.getOrPut(e.path) { idx.size }
                ev.put(JSONArray().put(e.ts).put(i).put(e.durMs).put(if (e.skipped) 1 else 0))
            }
            return JSONObject().put("v", 1).put("paths", JSONArray(idx.keys.toList())).put("events", ev)
        }

        fun decode(o: JSONObject): List<PlayEvent> {
            val pa = o.optJSONArray("paths") ?: return emptyList()
            val paths = List(pa.length()) { pa.getString(it) }
            val ea = o.optJSONArray("events") ?: return emptyList()
            val out = ArrayList<PlayEvent>(ea.length())
            for (i in 0 until ea.length()) {
                val a = ea.getJSONArray(i)
                val p = paths.getOrNull(a.getInt(1)) ?: continue
                out.add(PlayEvent(a.getLong(0), p, a.getLong(2), a.optInt(3, 0) == 1))
            }
            return out
        }
    }
}
