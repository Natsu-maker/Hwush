package com.hwush.player.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaPlayer
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.*
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.hwush.player.data.SongCount
import com.hwush.player.data.Track
import com.hwush.player.data.WPeriod
import com.hwush.player.data.WStats
import com.hwush.player.data.computeWrapped
import com.hwush.player.data.dateLabel
import com.hwush.player.data.dayLabel
import com.hwush.player.data.weekdayNames
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

private const val PAGE_MS = 7000
private const val MIN_DATED = 5

private val W80 = Color.White.copy(alpha = 0.8f)
private val W70 = Color.White.copy(alpha = 0.7f)

private val PALETTES = listOf(
    Color(0xFF1B1B3A) to Color(0xFF693668),
    Color(0xFF0F3D3E) to Color(0xFF2E8B57),
    Color(0xFF3D1C00) to Color(0xFFE07A1F),
    Color(0xFF2B0A3D) to Color(0xFFC2185B),
    Color(0xFF0A1F44) to Color(0xFF3F7CFF),
    Color(0xFF13262F) to Color(0xFF4E9F9B),
    Color(0xFF3A0F1C) to Color(0xFFD1495B),
    Color(0xFF1C1C1C) to Color(0xFF6B5B95),
)

private val FULL_DAYS = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")

// ---------------------------------------------------------------- small pieces

@Composable
private fun WRise(delayMs: Int = 0, content: @Composable () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(600, delayMillis = delayMs, easing = FastOutSlowInEasing)) }
    Box(Modifier.alpha(a.value).graphicsLayer { translationY = (1f - a.value) * 60f }) { content() }
}

@Composable
private fun WCount(target: Long, delayMs: Int = 0, style: TextStyle? = null) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(1200, delayMillis = delayMs, easing = FastOutSlowInEasing)) }
    Text(
        NumberFormat.getIntegerInstance().format((target * a.value).toLong()),
        style = style ?: MaterialTheme.typography.displayLarge,
        fontWeight = FontWeight.Bold,
        color = Color.White,
    )
}

@Composable
private fun WLbl(text: String, delayMs: Int = 0) {
    WRise(delayMs) {
        Text(text, color = W80, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
    }
}

@Composable
private fun WHero(text: String, delayMs: Int = 0, maxLines: Int = 3, style: TextStyle? = null) {
    WRise(delayMs) {
        Text(
            text,
            color = Color.White,
            style = style ?: MaterialTheme.typography.displaySmall,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            maxLines = maxLines,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun WSub(text: String, delayMs: Int = 0) {
    WRise(delayMs) {
        Text(
            text,
            color = W70,
            style = MaterialTheme.typography.bodyLarge,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 3.dp),
        )
    }
}

@Composable
private fun WGap(dp: Int) = Spacer(Modifier.height(dp.dp))

@Composable
private fun WDelta(pct: Int?, period: WPeriod, delayMs: Int) {
    if (pct == null || period == WPeriod.ALL) return
    val word = when (period) {
        WPeriod.WEEK -> "last week"
        WPeriod.MONTH -> "last month"
        else -> "last year"
    }
    val text = when {
        pct > 0 -> "▲ $pct% vs $word"
        pct < 0 -> "▼ ${-pct}% vs $word"
        else -> "Same as $word"
    }
    WRise(delayMs) {
        Text(
            text,
            color = Color.White,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.padding(top = 6.dp).background(Color.White.copy(alpha = 0.18f), RoundedCornerShape(50))
                .padding(horizontal = 12.dp, vertical = 4.dp),
        )
    }
}

@Composable
private fun WSongRow(rank: Int?, sc: SongCount, delayMs: Int, right: String) {
    WRise(delayMs) {
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            if (rank != null) {
                Text(
                    "$rank",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.width(34.dp),
                )
            }
            Cover(sc.track, Modifier.size(44.dp), 44.dp, RoundedCornerShape(10.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(sc.track.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                Text(sc.track.artist, color = W70, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.width(8.dp))
            Text(right, color = W80)
        }
    }
}

@Composable
private fun WNameRow(rank: Int, name: String, sub: String?, right: String, delayMs: Int) {
    WRise(delayMs) {
        Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "$rank",
                color = Color.White,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.width(34.dp),
            )
            Column(Modifier.weight(1f)) {
                Text(name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                if (sub != null) Text(sub, color = W70, style = MaterialTheme.typography.bodySmall)
            }
            Spacer(Modifier.width(8.dp))
            Text(right, color = W80)
        }
    }
}

@Composable
private fun WTile(value: String, label: String, modifier: Modifier) {
    Column(
        modifier.background(Color.White.copy(alpha = 0.14f), RoundedCornerShape(20.dp)).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(label, color = W70, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
    }
}

@Composable
private fun WTileRow(a: Pair<String, String>, b: Pair<String, String>, delayMs: Int) {
    WRise(delayMs) {
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            WTile(a.first, a.second, Modifier.weight(1f))
            WTile(b.first, b.second, Modifier.weight(1f))
        }
    }
}

@Composable
private fun WBars(values: List<Long>, labels: List<String>, highlight: Int, height: Dp = 180.dp, gap: Dp = 5.dp) {
    val max = (values.maxOrNull() ?: 0L).coerceAtLeast(1L)
    val prog = remember { Animatable(0f) }
    LaunchedEffect(Unit) { prog.animateTo(1f, tween(900, delayMillis = 200, easing = FastOutSlowInEasing)) }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().height(height), horizontalArrangement = Arrangement.spacedBy(gap), verticalAlignment = Alignment.Bottom) {
            values.forEachIndexed { i, v ->
                val f = (v.toFloat() / max * prog.value).coerceIn(0.015f, 1f)
                Box(
                    Modifier.weight(1f).height((height.value * f).dp)
                        .background(if (i == highlight) Color.White else Color.White.copy(alpha = 0.42f), RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp)),
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(gap)) {
            labels.forEach {
                Text(it, Modifier.weight(1f), color = W70, fontSize = 10.sp, maxLines = 1, softWrap = false, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun WHBars(items: List<Pair<String, Int>>, total: Int) {
    val max = (items.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)
    val prog = remember { Animatable(0f) }
    LaunchedEffect(Unit) { prog.animateTo(1f, tween(900, delayMillis = 250, easing = FastOutSlowInEasing)) }
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items.forEach { (name, n) ->
            Column(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth()) {
                    Text(name, Modifier.weight(1f), color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text("${n * 100 / total.coerceAtLeast(1)}%", color = W70)
                }
                Spacer(Modifier.height(4.dp))
                Box(Modifier.fillMaxWidth().height(8.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f))) {
                    Box(
                        Modifier.fillMaxWidth((n.toFloat() / max * prog.value).coerceIn(0.01f, 1f)).fillMaxHeight()
                            .background(Color.White, CircleShape),
                    )
                }
            }
        }
    }
}

@Composable
private fun WClock(hours: List<Long>, peak: Int) {
    val prog = remember { Animatable(0f) }
    LaunchedEffect(Unit) { prog.animateTo(1f, tween(1000, delayMillis = 200, easing = FastOutSlowInEasing)) }
    val max = (hours.maxOrNull() ?: 0L).coerceAtLeast(1L)
    Canvas(Modifier.size(270.dp)) {
        val r = size.minDimension / 2f
        val inner = r * 0.36f
        for (h in 0 until 24) {
            val ang = Math.toRadians((h * 15 - 90).toDouble())
            val f = hours[h].toFloat() / max * prog.value
            val outer = inner + (r - inner) * (0.08f + 0.92f * f)
            val dx = cos(ang).toFloat()
            val dy = sin(ang).toFloat()
            drawLine(
                color = if (h == peak) Color.White else Color.White.copy(alpha = 0.42f),
                start = Offset(center.x + dx * inner, center.y + dy * inner),
                end = Offset(center.x + dx * outer, center.y + dy * outer),
                strokeWidth = 8.dp.toPx(),
                cap = StrokeCap.Round,
            )
        }
    }
}

@Composable
private fun WChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) Color.White else Color.White.copy(alpha = 0.18f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp),
    ) {
        Text(
            text,
            color = if (selected) Color.Black else Color.White,
            fontWeight = FontWeight.SemiBold,
            style = MaterialTheme.typography.labelLarge,
        )
    }
}

@Composable
private fun WBigButton(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
        modifier = Modifier.fillMaxWidth(),
    ) { Text(text, fontWeight = FontWeight.SemiBold) }
}

@Composable
private fun WCollecting(s: WStats) {
    WLbl("Still collecting")
    WGap(12)
    WSub("Hwush only started keeping dated history with this update, so this page needs a few more days of listening.", 200)
    if (s.trackingSince > 0L) {
        WGap(8)
        WSub("Tracking since ${dateLabel(s.trackingSince)}", 400)
    }
}

// ---------------------------------------------------------------- helpers

private fun fmtMin(m: Long): String = if (m >= 60L) "${m / 60} h ${m % 60} min" else "$m min"

private fun fmtSize(b: Long): String =
    if (b >= 1_000_000_000L) String.format(Locale.US, "%.1f GB", b / 1e9) else "${b / 1_000_000L} MB"

private fun fmtDur(ms: Long): String {
    val sec = ms / 1000
    return "${sec / 60}:${(sec % 60).toString().padStart(2, '0')}"
}

private fun hourLabel(h: Int): String = when {
    h == 0 -> "12 AM"
    h < 12 -> "$h AM"
    h == 12 -> "12 PM"
    else -> "${h - 12} PM"
}

private fun fmtTime(ts: Long): String = SimpleDateFormat("d MMM 'at' h:mm a", Locale.getDefault()).format(Date(ts))

private fun savePng(ctx: Context, bmp: Bitmap): File {
    val dir = File(ctx.cacheDir, "cards").apply { mkdirs() }
    dir.listFiles()?.forEach { it.delete() }
    val f = File(dir, "wrapped.png")
    f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    return f
}

private class WPage(val dates: Boolean = false, val body: @Composable () -> Unit)

// ---------------------------------------------------------------- the 25 pages

private fun buildPages(s: WStats, ui: UiController): List<WPage> {
    val p = s.period
    val top = s.songs.first()
    fun topFifty() {
        val paths = s.songs.take(50).map { it.track.path }
        ui.app.store.createPlaylist("Hwush top 50 · ${p.label}", paths)
        ui.say("Saved as a playlist")
    }
    fun playTop() {
        ui.play(s.songs.take(50).map { it.track }, 0)
    }
    val artistTop = s.artists.firstOrNull()

    return listOf(
        // 1 intro
        WPage {
            WLbl("Your")
            WHero("Hwush wrapped", 150, 2, MaterialTheme.typography.displayMedium)
            WGap(14)
            WSub(
                when (p) {
                    WPeriod.WEEK -> "The last 7 days"
                    WPeriod.MONTH -> "The last 30 days"
                    WPeriod.YEAR -> "The last 12 months"
                    WPeriod.ALL -> "Everything you have played"
                },
                400,
            )
            WGap(24)
            WSub("Tap to go on. Hold to pause.", 700)
        },
        // 2 the big numbers
        WPage {
            WLbl("You listened for")
            WCount(s.minutes, 100)
            WSub("minutes", 200)
            WDelta(s.vsMinutes, p, 500)
            WGap(18)
            WRise(300) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    WCount(s.plays.toLong(), 300, MaterialTheme.typography.displayMedium)
                    Text("plays", color = W70, style = MaterialTheme.typography.bodyLarge)
                    WDelta(s.vsPlays, p, 0)
                }
            }
            if (s.days > 0) {
                WGap(18)
                WRise(500) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        WCount(s.days.toLong(), 500, MaterialTheme.typography.displayMedium)
                        Text("days with music", color = W70, style = MaterialTheme.typography.bodyLarge)
                        WDelta(s.vsDays, p, 0)
                    }
                }
            }
        },
        // 3 longest streak
        WPage(dates = true) {
            WLbl("Your longest streak")
            WCount(s.streak.toLong(), 100)
            WSub(if (s.streak == 1) "day in a row" else "days in a row", 200)
            WGap(12)
            if (s.streak > 1) {
                WSub("It ended on ${dayLabel(s.streakEndKey)}. Music every single day.", 500)
            } else {
                WSub("Play something on back to back days to start a streak.", 500)
            }
        },
        // 4 bars over time
        WPage(dates = true) {
            WLbl(if (s.dailyBuckets) "Day by day" else "Month by month")
            WGap(18)
            val n = s.buckets.size
            val labels = s.buckets.mapIndexed { i, b ->
                when {
                    p == WPeriod.MONTH -> if (i % 5 == 0) b.label else ""
                    n > 12 -> if (i % 2 == 0) b.label else ""
                    else -> b.label
                }
            }
            val hi = s.buckets.indexOfFirst { it === s.busiest }
            WBars(s.buckets.map { it.minutes }, labels, hi, gap = if (n > 14) 2.dp else 5.dp)
            WGap(16)
            s.busiest?.let { WSub("Busiest: ${it.label} · ${fmtMin(it.minutes)}", 900) }
            s.quietest?.let { WSub("Quietest: ${it.label} · ${fmtMin(it.minutes)}", 1000) }
        },
        // 5 favourite weekday
        WPage(dates = true) {
            val max = s.weekdayMin.maxOrNull() ?: 0L
            val fav = s.weekdayMin.indexOf(max).coerceAtLeast(0)
            val total = s.weekdayMin.sum().coerceAtLeast(1L)
            val weekend = ((s.weekdayMin[5] + s.weekdayMin[6]) * 100 / total).toInt()
            WLbl("Your favourite day")
            WHero(FULL_DAYS[fav], 150)
            WGap(18)
            WBars(s.weekdayMin, weekdayNames, fav, 140.dp, 8.dp)
            WGap(16)
            WSub(
                if (weekend >= 40) "Weekend person: $weekend% of your listening is on Saturday and Sunday."
                else "Weekday person: only $weekend% of your listening lands on the weekend.",
                900,
            )
        },
        // 6 peak hour
        WPage(dates = true) {
            val max = s.hourMin.maxOrNull() ?: 0L
            val peak = s.hourMin.indexOf(max).coerceAtLeast(0)
            WLbl("You peak at")
            WHero(hourLabel(peak), 150)
            WGap(14)
            WClock(s.hourMin, peak)
            WGap(10)
            WSub("Each bar is an hour of the day. The bright one is your busiest.", 800)
        },
        // 7 listener type
        WPage(dates = true) {
            WLbl("You are a")
            WGap(10)
            WHero(s.typeName, 200, 2, MaterialTheme.typography.displayMedium)
            WGap(10)
            WSub(s.typeBlurb, 500)
        },
        // 8 number one song
        WPage {
            WLbl("Your number one song")
            WGap(16)
            WRise(150) { Cover(top.track, Modifier.size(220.dp), 220.dp, RoundedCornerShape(28.dp)) }
            WGap(16)
            WHero(top.track.title, 300, 2, MaterialTheme.typography.headlineMedium)
            WSub(top.track.artist, 400)
            WSub("${top.n} plays · ${fmtMin(top.track.durationMs * top.n / 60_000L)}", 500)
        },
        // 9 top five songs
        WPage {
            WLbl("Your top five")
            WGap(10)
            s.songs.take(5).forEachIndexed { i, sc -> WSongRow(i + 1, sc, 150 + i * 110, "${sc.n}×") }
            WGap(14)
            WRise(800) { WBigButton("Make a playlist of my top ${s.songs.size.coerceAtMost(50)}") { topFifty() } }
        },
        // 10 song of each month or day
        WPage(dates = true) {
            val items = s.buckets.filter { it.top != null }
            WLbl(if (s.dailyBuckets) "Song of each day" else "Song of each month")
            WGap(14)
            val cols = if (items.size > 12) 6 else 4
            val sz = if (cols == 6) 46.dp else 72.dp
            items.chunked(cols).forEachIndexed { r, row ->
                WRise(100 + r * 120) {
                    Row(Modifier.padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { b ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Cover(b.top, Modifier.size(sz), sz, RoundedCornerShape(10.dp))
                                Text(b.label, color = W70, fontSize = 10.sp, maxLines = 1)
                            }
                        }
                    }
                }
            }
        },
        // 11 most replayed in one day
        WPage(dates = true) {
            val r = s.replay
            WLbl("On repeat")
            WGap(14)
            if (r == null) {
                WSub("No song has been played twice in one day yet. Put a favourite on repeat and it will show up here.", 200)
            } else {
                WRise(150) { Cover(r.track, Modifier.size(200.dp), 200.dp, RoundedCornerShape(26.dp)) }
                WGap(14)
                WHero(r.track.title, 300, 2, MaterialTheme.typography.headlineMedium)
                WSub(r.track.artist, 400)
                WSub("${r.times} times on ${dayLabel(r.dayKey)}", 500)
            }
        },
        // 12 never skipped and most skipped
        WPage(dates = true) {
            WLbl("Skips")
            WGap(10)
            if (s.neverSkipped.isEmpty() && s.skipped.isEmpty()) {
                WSub("Nothing skipped yet. Hwush began counting skips with this update.", 200)
            } else {
                if (s.neverSkipped.isNotEmpty()) {
                    WSub("Never skipped", 200)
                    s.neverSkipped.take(3).forEachIndexed { i, sc -> WSongRow(null, sc, 300 + i * 100, "${sc.n}×") }
                }
                if (s.skipped.isNotEmpty()) {
                    WGap(14)
                    WSub("Skipped the most", 700)
                    s.skipped.take(3).forEachIndexed { i, sc -> WSongRow(null, sc, 800 + i * 100, "${sc.n} skips") }
                }
            }
        },
        // 13 top artist
        WPage {
            WLbl("Your top artist")
            WGap(16)
            if (artistTop == null) {
                WSub("Your songs have no artist names yet.", 200)
            } else {
                WHero(artistTop.first, 200, 3)
                WGap(8)
                WSub("${artistTop.second} plays", 350)
                WSub("That is ${artistTop.second * 100 / s.plays.coerceAtLeast(1)}% of everything you played.", 500)
            }
        },
        // 14 top five artists
        WPage {
            WLbl("Your top five artists")
            WGap(10)
            if (s.artists.isEmpty()) {
                WSub("Your songs have no artist names yet.", 200)
            } else {
                s.artists.take(5).forEachIndexed { i, a -> WNameRow(i + 1, a.first, null, "${a.second}×", 150 + i * 110) }
            }
        },
        // 15 top album
        WPage {
            WLbl("Your top album")
            WGap(16)
            val al = s.album
            if (al == null) {
                WSub("Your songs have no album names yet.", 200)
            } else {
                WRise(150) { Cover(al.track, Modifier.size(220.dp), 220.dp, RoundedCornerShape(28.dp)) }
                WGap(16)
                WHero(al.name, 300, 2, MaterialTheme.typography.headlineMedium)
                WSub(al.artist, 400)
                WSub("${al.plays} plays", 500)
            }
        },
        // 16 artists you stuck with
        WPage(dates = true) {
            WLbl("Artists you stuck with")
            WGap(10)
            if (s.stuck.isEmpty()) {
                WSub("Come back on a few different days with the same artist and they will appear here.", 200)
            } else {
                s.stuck.forEachIndexed { i, a ->
                    WNameRow(i + 1, a.artist, "over ${a.spanDays} days", "${a.days} days", 150 + i * 150)
                }
            }
        },
        // 17 top genre
        WPage {
            WLbl("Your top genre")
            WGap(16)
            val g = s.genres.firstOrNull()
            if (g == null) {
                WSub("Your songs have no genre tags yet. Add some and this page comes alive.", 200)
            } else {
                WHero(g.first, 200, 2, MaterialTheme.typography.displayMedium)
                WGap(8)
                WSub("${g.second * 100 / s.genres.sumOf { it.second }.coerceAtLeast(1)}% of your listening", 400)
            }
        },
        // 18 genre breakdown
        WPage {
            WLbl("Your genres")
            WGap(16)
            if (s.genres.isEmpty()) {
                WSub("No genre tags yet.", 200)
            } else {
                WHBars(s.genres.take(6), s.genres.sumOf { it.second })
            }
        },
        // 19 listening age
        WPage {
            if (s.avgYear == 0) {
                WLbl("Your listening age")
                WGap(12)
                WSub("Your songs have no release years yet. Add years in the tag editor and this page will work.", 200)
            } else {
                val now = Calendar.getInstance().get(Calendar.YEAR)
                WLbl("Your music is mostly from")
                WHero("${s.avgYear}", 150, 1, MaterialTheme.typography.displayLarge)
                WGap(6)
                WSub("That gives you a listening age of ${(now - s.avgYear).coerceAtLeast(0)}.", 400)
                WGap(14)
                s.oldest?.let { WSub("Oldest: ${it.title} (${it.year})", 700) }
                s.newest?.let { WSub("Newest: ${it.title} (${it.year})", 800) }
            }
        },
        // 20 decades
        WPage {
            WLbl("Your decades")
            WGap(16)
            if (s.decades.isEmpty()) {
                WSub("No release years yet.", 200)
            } else {
                WHBars(s.decades.map { "${it.first}s" to it.second }, s.decades.sumOf { it.second })
            }
        },
        // 21 discoveries (or coverage for all time)
        WPage(dates = p != WPeriod.ALL) {
            if (p == WPeriod.ALL) {
                WLbl("You have played")
                WCount(s.playedCount.toLong(), 100)
                WSub("of ${s.libraryCount} songs", 200)
                WGap(12)
                val never = (s.libraryCount - s.playedCount).coerceAtLeast(0)
                WSub(if (never == 0) "Every song in your library has had a turn." else "$never songs have never been played. Time to shuffle?", 500)
            } else {
                WLbl("Discoveries")
                WCount(s.newSongs.toLong(), 100)
                WSub("songs you played for the first time", 200)
                WGap(14)
                WSub("${s.replaySongs} songs you came back to", 500)
                WSub("${s.newPlays * 100 / s.dated.coerceAtLeast(1)}% of your plays were brand new to you.", 650)
            }
        },
        // 22 longest session
        WPage(dates = true) {
            val se = s.session
            WLbl("Your longest session")
            WGap(10)
            if (se == null) {
                WSub("Nothing yet.", 200)
            } else {
                WHero(fmtMin(se.minutes), 150, 1, MaterialTheme.typography.displayMedium)
                WGap(6)
                WSub("${se.songs} songs in a row", 400)
                WSub("Started ${fmtTime(se.start)}", 550)
            }
        },
        // 23 library stats
        WPage {
            WLbl("Your library")
            WGap(10)
            WTileRow(s.lib.songs.toString() to "songs", "${s.lib.hours} h" to "of music", 100)
            WTileRow(fmtSize(s.lib.sizeBytes) to "on your phone", "${s.lib.flacPct}%" to "FLAC", 220)
            WTileRow(fmtDur(s.lib.avgSec * 1000L) to "average song", "${s.libraryCount}" to "total tracks", 340)
            s.lib.longest?.let { WSub("Longest: ${it.title} (${fmtDur(it.durationMs)})", 700) }
            s.lib.shortest?.let { WSub("Shortest: ${it.title} (${fmtDur(it.durationMs)})", 800) }
        },
        // 24 stars and favourites
        WPage {
            WLbl("Stars and hearts")
            WGap(10)
            WTileRow(s.fiveStar.size.toString() to "5-star songs", s.favCount.toString() to "favourites", 100)
            WGap(8)
            val list = if (s.fiveStar.isNotEmpty()) s.fiveStar else s.favTop
            if (list.isEmpty()) {
                WSub("Rate songs with stars and heart your favourites to fill this page.", 300)
            } else {
                WSub(if (s.fiveStar.isNotEmpty()) "Your most played 5 stars" else "Your most played favourites", 300)
                list.take(3).forEachIndexed { i, sc -> WSongRow(null, sc, 400 + i * 110, "${sc.n}×") }
            }
        },
        // 25 closing
        WPage {
            WLbl("That was your Hwush")
            WGap(10)
            WHero(if (s.dated >= MIN_DATED) s.typeName else top.track.title, 200, 2, MaterialTheme.typography.displayMedium)
            WGap(8)
            WSub("${fmtMin(s.minutes)} · ${s.plays} plays", 400)
            artistTop?.let { WSub("Top artist: ${it.first}", 500) }
            WGap(18)
            WRise(700) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    WBigButton("Make my top 50 a playlist") { topFifty() }
                    WBigButton("Play my top songs") { playTop() }
                }
            }
            WGap(10)
            WSub("Tap the share icon to send any page.", 900)
        },
    )
}

// ---------------------------------------------------------------- the screen

/** A tap-through story of your listening: 25 pages, for the week, the month, the year or all time. */
@Composable
fun WrappedScreen(ui: UiController) {
    val app = ui.app
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val data by app.store.data.collectAsState()
    val tracks by app.library.tracks.collectAsState()
    val events by app.history.events.collectAsState()

    var periodName by rememberSaveable { mutableStateOf(WPeriod.ALL.name) }
    val period = WPeriod.valueOf(periodName)
    var stats by remember { mutableStateOf<WStats?>(null) }
    LaunchedEffect(period, events, data.plays, data.ratings, data.favorites, tracks) {
        stats = withContext(Dispatchers.Default) { computeWrapped(period, events, data, tracks) }
    }
    val s = stats

    val pages = remember(s) { if (s != null && s.hasAny) buildPages(s, ui) else emptyList() }
    var page by remember(period) { mutableIntStateOf(0) }
    var paused by remember { mutableStateOf(false) }
    var sound by rememberSaveable { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    val layer = rememberGraphicsLayer()

    val progress = remember(period, page) { Animatable(0f) }
    LaunchedEffect(period, page, paused, pages.size) {
        if (pages.isNotEmpty() && !paused) {
            progress.animateTo(1f, tween(((1f - progress.value) * PAGE_MS).toInt().coerceAtLeast(1), easing = LinearEasing))
            if (page < pages.lastIndex) page++
        }
    }

    // A quiet loop of your top song behind the story, only when nothing else is playing.
    val backdrop = s?.songs?.firstOrNull()?.track
    DisposableEffect(backdrop?.path, sound) {
        var mp: MediaPlayer? = null
        if (sound && backdrop != null && !app.player.player.isPlaying) {
            try {
                mp = MediaPlayer().apply {
                    setDataSource(ctx, backdrop.uri)
                    setAudioAttributes(
                        android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build(),
                    )
                    isLooping = true
                    setVolume(0.22f, 0.22f)
                    setOnPreparedListener { m ->
                        try {
                            val dur = m.duration
                            if (dur > 60_000) m.seekTo(dur / 4)
                            m.start()
                        } catch (_: Exception) {
                        }
                    }
                    prepareAsync()
                }
            } catch (_: Exception) {
                try {
                    mp?.release()
                } catch (_: Exception) {
                }
                mp = null
            }
        }
        onDispose {
            try {
                mp?.release()
            } catch (_: Exception) {
            }
        }
    }

    val share: () -> Unit = {
        if (!busy) {
            busy = true
            scope.launch {
                try {
                    val img = layer.toImageBitmap().asAndroidBitmap()
                    val soft = img.copy(Bitmap.Config.ARGB_8888, false) ?: img
                    val file = withContext(Dispatchers.IO) { savePng(ctx, soft) }
                    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
                    val send = Intent(Intent.ACTION_SEND).setType("image/png")
                        .putExtra(Intent.EXTRA_STREAM, uri)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {
                    ui.say("Could not make the picture")
                }
                busy = false
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (s != null && pages.isNotEmpty()) {
            Box(
                Modifier.fillMaxSize().pointerInput(pages.size) {
                    detectTapGestures(
                        onPress = {
                            paused = true
                            tryAwaitRelease()
                            paused = false
                        },
                        onTap = { off ->
                            if (off.x < size.width * 0.33f) {
                                if (page > 0) page--
                            } else if (page < pages.lastIndex) {
                                page++
                            }
                        },
                    )
                },
            ) {
                Crossfade(targetState = page, animationSpec = tween(300), label = "wrapped") { pi ->
                    val i = pi.coerceIn(0, pages.lastIndex)
                    val pal = PALETTES[i % PALETTES.size]
                    val pg = pages[i]
                    Box(
                        Modifier.fillMaxSize()
                            .drawWithContent {
                                layer.record { this@drawWithContent.drawContent() }
                                drawLayer(layer)
                            }
                            .background(Brush.verticalGradient(listOf(pal.first, pal.second))),
                    ) {
                        Column(
                            Modifier.fillMaxSize().statusBarsPadding().padding(top = 128.dp, bottom = 56.dp, start = 28.dp, end = 28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                        ) {
                            if (pg.dates && s.dated < MIN_DATED) WCollecting(s) else pg.body()
                        }
                        Text(
                            "Hwush · ${s.period.label}",
                            color = Color.White.copy(alpha = 0.45f),
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 22.dp),
                        )
                    }
                }
            }
        } else if (s != null) {
            Box(
                Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(PALETTES[0].first, PALETTES[0].second)))
                    .statusBarsPadding().padding(top = 128.dp, start = 28.dp, end = 28.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    WLbl("Nothing here yet")
                    WGap(10)
                    WSub(
                        if (period == WPeriod.ALL) "Listen to a few songs and your story will be waiting here."
                        else "No listening ${period.phrase} yet. Play something, or try All time.",
                        200,
                    )
                }
            }
        }

        // top controls: progress bars, back, sound, share, period switch
        Column(Modifier.fillMaxWidth().statusBarsPadding()) {
            if (pages.isNotEmpty()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    for (i in pages.indices) {
                        val frac = when {
                            i < page -> 1f
                            i == page -> progress.value
                            else -> 0f
                        }
                        Box(Modifier.weight(1f).height(3.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.3f))) {
                            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(Color.White))
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { ui.back() }) { Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White) }
                Spacer(Modifier.weight(1f))
                if (pages.isNotEmpty()) {
                    IconButton(onClick = { sound = !sound }) {
                        Icon(if (sound) Icons.Rounded.VolumeUp else Icons.Rounded.VolumeOff, "Sound", tint = Color.White)
                    }
                    IconButton(onClick = share) { Icon(Icons.Rounded.Share, "Share this page", tint = Color.White) }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
            ) {
                WPeriod.values().forEach { pr -> WChip(pr.label, pr == period) { periodName = pr.name } }
            }
        }
    }
}
