package com.hwush.player.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Track

@Composable
private fun Rise(active: Boolean, delayMs: Int = 0, content: @Composable () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(active) {
        if (active) a.animateTo(1f, tween(600, delayMillis = delayMs, easing = FastOutSlowInEasing)) else a.snapTo(0f)
    }
    Box(Modifier.alpha(a.value).graphicsLayer { translationY = (1f - a.value) * 60f }) { content() }
}

@Composable
private fun CountText(active: Boolean, target: Long, suffix: String = "") {
    val a = remember { Animatable(0f) }
    LaunchedEffect(active) {
        if (active) a.animateTo(1f, tween(1200, easing = FastOutSlowInEasing)) else a.snapTo(0f)
    }
    Text(
        "${(target * a.value).toLong()}$suffix",
        style = MaterialTheme.typography.displayLarge,
        fontWeight = FontWeight.Bold,
        color = Color.White,
    )
}

/** A swipeable story of what you play most. It only knows play counts, so it covers all time. */
@Composable
fun WrappedScreen(ui: UiController) {
    val data by ui.app.store.data.collectAsState()
    val tracks by ui.app.library.tracks.collectAsState()
    val byPath = remember(tracks) { tracks.associateBy { it.path } }
    val played: List<Pair<Track, Int>> = remember(data.plays, byPath) {
        data.plays.mapNotNull { (p, n) -> byPath[p]?.let { it to n } }.filter { it.second > 0 }.sortedByDescending { it.second }
    }
    if (played.size < 3) {
        Column(Modifier.fillMaxSize()) {
            ListHeader("Your Hwush wrapped", null, ui, emptyList(), back = ui.stack.size > 1)
            EmptyState("Not enough plays yet", "Listen to a few more songs and come back. Your story will be waiting here.")
        }
        return
    }
    val plays = played.sumOf { it.second }.toLong()
    val minutes = played.sumOf { it.first.durationMs / 1000L * it.second } / 60L
    val topSong = played.first()
    val topArtist = played.groupBy { it.first.artist }.map { (a, l) -> a to l.sumOf { it.second } }.maxByOrNull { it.second }!!
    val top5 = played.take(5)
    val palette = listOf(
        listOf(Color(0xFF1B1B3A), Color(0xFF693668)),
        listOf(Color(0xFF0F3D3E), Color(0xFF2E8B57)),
        listOf(Color(0xFF3D1C00), Color(0xFFE07A1F)),
        listOf(Color(0xFF2B0A3D), Color(0xFFC2185B)),
        listOf(Color(0xFF0A1F44), Color(0xFF3F7CFF)),
    )
    val pager = rememberPagerState(pageCount = { 5 })
    Box(Modifier.fillMaxSize()) {
        HorizontalPager(pager, Modifier.fillMaxSize()) { page ->
            val active = pager.currentPage == page
            Box(
                Modifier.fillMaxSize().background(Brush.verticalGradient(palette[page])).statusBarsPadding().padding(28.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    when (page) {
                        0 -> {
                            Rise(active) { Text("Your", color = Color.White.copy(0.8f), style = MaterialTheme.typography.headlineSmall) }
                            Rise(active, 150) {
                                Text("Hwush wrapped", color = Color.White, style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                            }
                            Spacer(Modifier.height(16.dp))
                            Rise(active, 400) { Text("Swipe to see what you played the most", color = Color.White.copy(0.7f), textAlign = TextAlign.Center) }
                        }
                        1 -> {
                            Rise(active) { Text("You listened to songs", color = Color.White.copy(0.8f), style = MaterialTheme.typography.titleLarge) }
                            CountText(active, plays, " times")
                            Spacer(Modifier.height(20.dp))
                            Rise(active, 300) { Text("That is about", color = Color.White.copy(0.8f), style = MaterialTheme.typography.titleLarge) }
                            CountText(active, minutes, " minutes")
                        }
                        2 -> {
                            Rise(active) { Text("Your number one song", color = Color.White.copy(0.8f), style = MaterialTheme.typography.titleLarge) }
                            Spacer(Modifier.height(16.dp))
                            Rise(active, 150) { Cover(topSong.first, Modifier.size(220.dp), 220.dp, RoundedCornerShape(28.dp)) }
                            Spacer(Modifier.height(16.dp))
                            Rise(active, 300) {
                                Text(topSong.first.title, color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                            Rise(active, 400) { Text("${topSong.second} plays", color = Color.White.copy(0.8f)) }
                        }
                        3 -> {
                            Rise(active) { Text("Your top artist", color = Color.White.copy(0.8f), style = MaterialTheme.typography.titleLarge) }
                            Spacer(Modifier.height(16.dp))
                            Rise(active, 200) {
                                Text(topArtist.first, color = Color.White, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis)
                            }
                            Spacer(Modifier.height(8.dp))
                            Rise(active, 350) { Text("${topArtist.second} plays", color = Color.White.copy(0.8f)) }
                        }
                        else -> {
                            Rise(active) { Text("Your top five", color = Color.White.copy(0.8f), style = MaterialTheme.typography.titleLarge) }
                            Spacer(Modifier.height(16.dp))
                            top5.forEachIndexed { i, (t, n) ->
                                Rise(active, 150 + i * 120) {
                                    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Text("${i + 1}", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 14.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(t.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                                            Text(t.artist, color = Color.White.copy(0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                                        }
                                        Text("$n×", color = Color.White.copy(0.8f))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        IconButton(onClick = { ui.back() }, Modifier.statusBarsPadding().padding(4.dp)) {
            Icon(Icons.Rounded.ArrowBack, "Back", tint = Color.White)
        }
        Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(5) { i ->
                Box(Modifier.size(if (i == pager.currentPage) 10.dp else 7.dp).background(Color.White.copy(if (i == pager.currentPage) 1f else 0.4f), CircleShape))
            }
        }
    }
}
