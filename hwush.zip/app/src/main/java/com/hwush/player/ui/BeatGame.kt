package com.hwush.player.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.changedToDown
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hwush.player.data.BeatChart
import com.hwush.player.data.BeatNote
import com.hwush.player.data.Track
import kotlin.math.abs
import kotlin.math.roundToInt

private val laneColors = listOf(Color(0xFFC24B99), Color(0xFF00E5FF), Color(0xFF12FA05), Color(0xFFF9393F))
private val laneTurn = floatArrayOf(-90f, 180f, 0f, 90f)
private val diffNames = listOf("Easy", "Normal", "Hard")
private val approachMs = longArrayOf(1750L, 1500L, 1250L)

private class BeatResult(
    val score: Int,
    val maxCombo: Int,
    val sick: Int,
    val good: Int,
    val bad: Int,
    val shit: Int,
    val miss: Int,
    val total: Int,
) {
    val accuracy: Float
        get() = if (total == 0) 0f else (sick + good * 0.75f + bad * 0.5f + shit * 0.25f) / total * 100f
    val grade: String
        get() = when {
            miss == 0 && bad == 0 && shit == 0 && good == 0 -> "S+"
            accuracy >= 92f -> "S"
            accuracy >= 82f -> "A"
            accuracy >= 68f -> "B"
            accuracy >= 50f -> "C"
            else -> "D"
        }
}

/** Songs to play the beat game on, with your best score for the chosen difficulty next to each. */
@Composable
fun BeatListScreen(ui: UiController) {
    val app = ui.app
    val all by app.library.tracks.collectAsState()
    val scores by app.store.select { it.beatScores }
    val diff by app.store.select { it.beatDifficulty }
    val q = ui.query
    val list = remember(all, q) {
        all.filter { q.isBlank() || it.title.contains(q, true) || it.artist.contains(q, true) }.sortedBy { it.title.lowercase() }
    }
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Column {
                ListHeader("Beat game", "Hit the arrows in time with your music", ui, emptyList(), back = ui.stack.size > 1)
                Choices(diffNames.mapIndexed { i, n -> n to i }, diff) { v -> app.store.update { d -> d.copy(beatDifficulty = v) } }
                SearchField(q, { ui.query = it }, "Pick a song")
            }
        }
        items(list, key = { it.id }) { t ->
            val best = scores["${t.path}|$diff"] ?: 0
            Row(
                Modifier.fillMaxWidth().clickable { ui.open(Dest(Kind.BEAT, t.path)) }.padding(horizontal = 16.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Cover(t, Modifier.size(46.dp), 64.dp, RoundedCornerShape(10.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (best > 0) Text("$best", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

/** The beat game for one song: choose a difficulty, then hit the arrows as they reach the top. */
@Composable
fun BeatGameScreen(ui: UiController, path: String) {
    val app = ui.app
    val ctx = LocalContext.current
    val track = remember(path) { app.library.find(path) }
    if (track == null) {
        EmptyState("Song not found", "It may have been removed from this phone.")
        return
    }
    val diff by app.store.select { it.beatDifficulty }
    val offset by app.store.select { it.beatOffsetMs }
    val best by app.store.select(path) { (it.beatScores["$path|${it.beatDifficulty}"] ?: 0) }
    // 0 menu, 1 working out the arrows, 2 playing, 3 result, 4 could not read the song
    var phase by remember(path) { mutableIntStateOf(0) }
    var token by remember(path) { mutableIntStateOf(0) }
    var notes by remember(path) { mutableStateOf<List<BeatNote>>(emptyList()) }
    var result by remember(path) { mutableStateOf<BeatResult?>(null) }

    LaunchedEffect(token) {
        if (token > 0) {
            phase = 1
            val chart = BeatChart.build(ctx, track, diff)
            if (chart == null || chart.size < 8) {
                phase = 4
            } else {
                notes = chart
                app.player.playList(listOf(track), 0)
                phase = 2
            }
        }
    }

    when (phase) {
        2 -> BeatPlay(ui, track, notes, offset, diff) { r ->
            result = r
            app.store.setBeatScore(path, diff, r.score)
            phase = 3
        }
        3 -> BeatResultView(ui, result, best, onRetry = { token++ }, onBack = { phase = 0 })
        else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            ListHeader("Beat game", track.title, ui, emptyList(), back = ui.stack.size > 1)
            Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                Cover(track, Modifier.size(180.dp), 320.dp, RoundedCornerShape(24.dp))
            }
            Text(track.artist, Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(12.dp))
            when (phase) {
                1 -> Text(
                    "Listening to the song to place the arrows…",
                    Modifier.fillMaxWidth().padding(24.dp),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                4 -> Text(
                    "This song could not be read, or it is too long (over 12 minutes). Try another one.",
                    Modifier.fillMaxWidth().padding(24.dp),
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.error,
                )
            }
            if (phase != 1) {
                Text("Difficulty", Modifier.padding(horizontal = 16.dp, vertical = 6.dp), fontWeight = FontWeight.Medium)
                Choices(diffNames.mapIndexed { i, n -> n to i }, diff) { v -> app.store.update { d -> d.copy(beatDifficulty = v) } }
                Text(
                    "Audio delay  $offset ms",
                    Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp),
                    fontWeight = FontWeight.Medium,
                )
                Slider(
                    value = offset.toFloat(),
                    onValueChange = { v -> app.store.update { d -> d.copy(beatOffsetMs = ((v / 10f).roundToInt() * 10)) } },
                    valueRange = -100f..500f,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                Text(
                    "Bluetooth headphones delay the sound. If you always seem to hit late, raise this.",
                    Modifier.padding(horizontal = 16.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                if (best > 0) {
                    Text("Best on ${diffNames[diff.coerceIn(0, 2)]}: $best", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                }
                Button(onClick = { token++ }, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth()) { Text("Play") }
                Text(
                    "Tap the lane when an arrow reaches the arrows at the top. Use both thumbs.",
                    Modifier.padding(horizontal = 16.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

private fun arrowPath(): Path = Path().apply {
    moveTo(0f, -0.5f)
    lineTo(0.5f, 0.05f)
    lineTo(0.22f, 0.05f)
    lineTo(0.22f, 0.5f)
    lineTo(-0.22f, 0.5f)
    lineTo(-0.22f, 0.05f)
    lineTo(-0.5f, 0.05f)
    close()
}

@Composable
private fun BeatPlay(ui: UiController, track: Track, notes: List<BeatNote>, offsetMs: Int, difficulty: Int, onFinish: (BeatResult) -> Unit) {
    val app = ui.app
    val holder = app.player
    val bgStyle by app.store.select { it.bgStyle }
    val primary = MaterialTheme.colorScheme.primary
    val artColor = rememberArtColor(track, primary)
    val state = remember(notes) { IntArray(notes.size) } // 0 waiting, 1 hit, 2 missed
    val cursor = remember(notes) { intArrayOf(0) }
    val flash = remember { LongArray(4) }
    val now = remember(notes) { mutableLongStateOf(0L) }
    var score by remember(notes) { mutableIntStateOf(0) }
    var combo by remember(notes) { mutableIntStateOf(0) }
    var maxCombo by remember(notes) { mutableIntStateOf(0) }
    var sick by remember(notes) { mutableIntStateOf(0) }
    var good by remember(notes) { mutableIntStateOf(0) }
    var bad by remember(notes) { mutableIntStateOf(0) }
    var shit by remember(notes) { mutableIntStateOf(0) }
    var miss by remember(notes) { mutableIntStateOf(0) }
    var popup by remember(notes) { mutableStateOf("") }
    var popupColor by remember(notes) { mutableStateOf(Color.White) }
    val popupAt = remember(notes) { mutableLongStateOf(0L) }
    val arrow = remember { arrowPath() }
    val approach = approachMs[difficulty.coerceIn(0, 2)]
    val window = 160L

    fun show(text: String, color: Color) {
        popup = text
        popupColor = color
        popupAt.longValue = System.currentTimeMillis()
    }

    fun judge(lane: Int) {
        val t = holder.position() - offsetMs
        var pick = -1
        var i = cursor[0]
        while (i < notes.size && notes[i].timeMs <= t + window) {
            if (state[i] == 0 && notes[i].lane == lane && abs(notes[i].timeMs - t) <= window) {
                pick = i
                break
            }
            i++
        }
        flash[lane] = System.currentTimeMillis()
        if (pick < 0) return
        state[pick] = 1
        val d = abs(notes[pick].timeMs - t)
        when {
            d <= 45L -> { sick++; score += 350; combo++; show("SICK!!", Color(0xFF7DF9FF)) }
            d <= 90L -> { good++; score += 200; combo++; show("Good", Color(0xFF7CFC00)) }
            d <= 130L -> { bad++; score += 100; combo++; show("Bad", Color(0xFFFFB347)) }
            else -> { shit++; score += 50; combo = 0; show("Shit", Color(0xFFFF6B6B)) }
        }
        if (combo > maxCombo) maxCombo = combo
    }

    LaunchedEffect(notes) {
        val last = notes.last().timeMs
        while (true) {
            withFrameNanos { }
            val t = holder.position() - offsetMs
            now.longValue = t
            while (cursor[0] < notes.size && notes[cursor[0]].timeMs + window < t) {
                val k = cursor[0]
                if (state[k] == 0) {
                    state[k] = 2
                    miss++
                    combo = 0
                    show("MISS", Color(0xFFFF4D4D))
                }
                cursor[0] = k + 1
            }
            if (holder.currentPath() != track.path || t > last + 1500L) break
        }
        onFinish(BeatResult(score, maxCombo, sick, good, bad, shit, miss, notes.size))
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        PlayerBackdrop(track, artColor, true, bgStyle, Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f)))
        Canvas(
            Modifier
                .fillMaxSize()
                .pointerInput(notes) {
                    awaitPointerEventScope {
                        while (true) {
                            val ev = awaitPointerEvent()
                            for (c in ev.changes) {
                                if (c.changedToDown()) {
                                    c.consume()
                                    judge((c.position.x / size.width * 4f).toInt().coerceIn(0, 3))
                                }
                            }
                        }
                    }
                },
        ) {
            val w = size.width
            val h = size.height
            val laneW = w / 4f
            val recvY = h * 0.15f
            val travel = h * 0.8f
            val s = laneW * 0.62f
            val t = now.longValue
            val wall = System.currentTimeMillis()
            for (l in 0 until 4) {
                drawRect(Color.White.copy(alpha = if (l % 2 == 0) 0.05f else 0.02f), Offset(l * laneW, 0f), androidx.compose.ui.geometry.Size(laneW, h))
            }
            for (l in 0 until 4) {
                val cx = l * laneW + laneW / 2f
                val hot = wall - flash[l] < 130L
                withTransform({
                    translate(cx, recvY)
                    rotate(laneTurn[l], Offset.Zero)
                    scale(s, s, Offset.Zero)
                }) {
                    if (hot) drawPath(arrow, laneColors[l].copy(alpha = 0.55f))
                    drawPath(arrow, laneColors[l].copy(alpha = 0.85f), style = Stroke(0.07f))
                }
            }
            var i = cursor[0]
            while (i < notes.size) {
                val n = notes[i]
                val dt = n.timeMs - t
                if (dt > approach) break
                if (state[i] != 1) {
                    val y = recvY + dt.toFloat() / approach * travel
                    if (y > -s) {
                        val cx = n.lane * laneW + laneW / 2f
                        val c = laneColors[n.lane]
                        withTransform({
                            translate(cx, y)
                            rotate(laneTurn[n.lane], Offset.Zero)
                            scale(s, s, Offset.Zero)
                        }) {
                            drawPath(arrow, c.copy(alpha = if (state[i] == 2) 0.3f else 1f))
                            drawPath(arrow, Color.White.copy(alpha = if (state[i] == 2) 0.1f else 0.8f), style = Stroke(0.05f))
                        }
                    }
                }
                i++
            }
        }
        Column(Modifier.align(Alignment.TopStart).padding(12.dp)) {
            Text("$score", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
            Text(track.title, color = Color.White.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
        }
        Column(
            Modifier.align(Alignment.Center).graphicsLayer {
                val age = System.currentTimeMillis() - popupAt.longValue
                val read = now.longValue // keeps this fading while the game runs
                alpha = if (read < 0L) 0f else (1f - age / 650f).coerceIn(0f, 1f)
                val k = 1f + (1f - (age / 180f).coerceIn(0f, 1f)) * 0.25f
                scaleX = k
                scaleY = k
            },
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(popup, color = popupColor, fontWeight = FontWeight.ExtraBold, fontSize = 34.sp)
            if (combo >= 5) Text("$combo combo", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
private fun BeatResultView(ui: UiController, r: BeatResult?, best: Int, onRetry: () -> Unit, onBack: () -> Unit) {
    if (r == null) return
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(r.grade, fontSize = 88.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
        Text("${r.score}", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("%.1f%% accuracy · max combo ${r.maxCombo}".format(r.accuracy), color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (r.score >= best && r.score > 0) Text("New best!", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(18.dp))
        listOf("Sick" to r.sick, "Good" to r.good, "Bad" to r.bad, "Shit" to r.shit, "Miss" to r.miss).forEach { (n, v) ->
            Row(Modifier.fillMaxWidth(0.7f).padding(vertical = 2.dp)) {
                Text(n, Modifier.weight(1f))
                Text("$v", fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(20.dp))
        Button(onClick = onRetry, modifier = Modifier.fillMaxWidth(0.7f)) { Text("Play again") }
        OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth(0.7f)) { Text("Change difficulty") }
        OutlinedButton(onClick = { ui.back() }, modifier = Modifier.fillMaxWidth(0.7f)) { Text("Done") }
    }
}
