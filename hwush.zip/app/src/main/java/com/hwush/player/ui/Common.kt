@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import android.graphics.Bitmap
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Store
import com.hwush.player.data.StoreData
import com.hwush.player.data.Track
import com.hwush.player.hwush
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

// ---------------------------------------------------------------- small helpers

fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

fun fmtBytes(b: Long): String = when {
    b >= 1_000_000_000L -> "%.1f GB".format(b / 1e9)
    b >= 1_000_000L -> "%.1f MB".format(b / 1e6)
    else -> "%d KB".format(b / 1000)
}

fun plural(n: Int, word: String): String = if (n == 1) "1 $word" else "$n ${word}s"

fun hueOf(s: String): Float {
    var h = 0
    for (c in s) h = (h * 31 + c.code) % 360
    return h.toFloat()
}

fun lastSegment(path: String): String = path.trimEnd('/').substringAfterLast('/').ifEmpty { path }

fun filterTracks(list: List<Track>, q: String): List<Track> {
    val s = q.trim()
    if (s.isEmpty()) return list
    return list.filter {
        it.title.contains(s, ignoreCase = true) || it.artist.contains(s, ignoreCase = true) ||
            it.album.contains(s, ignoreCase = true)
    }
}

fun sortTracks(list: List<Track>, key: Int, desc: Boolean): List<Track> {
    val cmp: Comparator<Track> = when (key) {
        1 -> compareBy<Track>({ it.artist.lowercase() }, { it.title.lowercase() })
        2 -> compareBy<Track>({ it.album.lowercase() }, { it.trackNo }, { it.title.lowercase() })
        3 -> compareBy<Track> { it.dateAdded }.thenBy { it.title.lowercase() }
        4 -> compareBy<Track> { it.durationMs }.thenBy { it.title.lowercase() }
        else -> compareBy<Track> { it.title.lowercase() }
    }
    return if (desc) list.sortedWith(cmp.reversed()) else list.sortedWith(cmp)
}

/** Watches one slice of the saved data, so a screen only redraws when its own slice changes. */
@Composable
fun <T> Store.select(key: Any? = null, f: (StoreData) -> T): State<T> {
    val store = this
    val flow = remember(store, key) { store.data.map { f(it) }.distinctUntilChanged() }
    return flow.collectAsState(initial = f(store.data.value))
}

// ---------------------------------------------------------------- cover art

@Composable
fun Cover(
    track: Track?,
    modifier: Modifier = Modifier,
    loadSize: Dp = 160.dp,
    shape: Shape = RoundedCornerShape(10.dp),
) {
    val app = LocalContext.current.hwush
    val rev = app.coverRev.intValue
    val px = with(LocalDensity.current) { loadSize.roundToPx() }
    val bmp by produceState<Bitmap?>(track?.let { app.art.peek(it, px) }, track?.path, rev, px) {
        value = if (track == null) null else app.art.load(track, px)
    }
    val b = bmp
    Box(modifier.clip(shape)) {
        if (b != null) {
            Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            val h = hueOf((track?.album ?: "") + (track?.artist ?: ""))
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            listOf(Color.hsv(h, 0.55f, 0.5f), Color.hsv((h + 40f) % 360f, 0.6f, 0.24f)),
                        ),
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Rounded.MusicNote,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.fillMaxSize(0.45f),
                )
            }
        }
    }
}

/** A playlist's own picture if one was chosen, otherwise the first song's cover. */
@Composable
fun PlaylistCover(
    cover: String?,
    first: Track?,
    modifier: Modifier = Modifier,
    loadSize: Dp = 160.dp,
    shape: Shape = RoundedCornerShape(10.dp),
    mosaic: List<Track> = emptyList(),
) {
    if (cover == null) {
        if (mosaic.size >= 4) {
            // No picture chosen: four different covers side by side.
            val half = loadSize / 2
            val flat = androidx.compose.ui.graphics.RectangleShape
            Box(modifier.clip(shape)) {
                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.weight(1f).fillMaxWidth()) {
                        Cover(mosaic[0], Modifier.weight(1f).fillMaxSize(), half, flat)
                        Cover(mosaic[1], Modifier.weight(1f).fillMaxSize(), half, flat)
                    }
                    Row(Modifier.weight(1f).fillMaxWidth()) {
                        Cover(mosaic[2], Modifier.weight(1f).fillMaxSize(), half, flat)
                        Cover(mosaic[3], Modifier.weight(1f).fillMaxSize(), half, flat)
                    }
                }
            }
        } else {
            Cover(first, modifier, loadSize, shape)
        }
        return
    }
    val app = LocalContext.current.hwush
    val rev = app.coverRev.intValue
    val bmp by produceState<Bitmap?>(null, cover, rev) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                android.graphics.BitmapFactory.decodeFile(java.io.File(app.filesDir, "covers/$cover").path)
            } catch (e: Exception) {
                null
            }
        }
    }
    val b = bmp
    if (b == null) {
        Cover(first, modifier, loadSize, shape)
    } else {
        Box(modifier.clip(shape)) {
            Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
    }
}

// ---------------------------------------------------------------- rows and lists

@Composable
private fun SongRowBody(
    t: Track,
    ui: UiController,
    playing: Boolean,
    onClick: () -> Unit,
    showMenu: Boolean = true,
    trailing: (@Composable () -> Unit)? = null,
    selected: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    index: Int = 0,
) {
    val src = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    Row(
        Modifier
            .fillMaxWidth()
            .staggerIn(index)
            .pressScale(src)
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f) else Color.Transparent)
            .combinedClickable(
                interactionSource = src,
                indication = androidx.compose.foundation.LocalIndication.current,
                onClick = onClick,
                onLongClick = onLongClick,
            )
            .padding(start = 16.dp, end = if (showMenu) 4.dp else 8.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Cover(t, Modifier.size(48.dp), 48.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                t.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = if (playing) FontWeight.SemiBold else FontWeight.Normal,
                color = if (playing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
            Text(
                "${t.artist} · ${fmtTime(t.durationMs)}",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (selected) {
            Icon(Icons.Rounded.CheckCircle, "Selected", Modifier.padding(horizontal = 8.dp), tint = MaterialTheme.colorScheme.primary)
        } else if (playing) {
            PlayingBars(Modifier.padding(horizontal = 8.dp))
        }
        if (trailing != null) trailing()
        if (showMenu) {
            IconButton(onClick = { ui.menuTrack = t }) { Icon(Icons.Rounded.MoreVert, "More") }
        }
    }
}

/** A song row you can swipe right to add to the queue, or left to play next. */
@Composable
fun SongRow(
    t: Track,
    ui: UiController,
    playing: Boolean,
    onClick: () -> Unit,
    showMenu: Boolean = true,
    trailing: (@Composable () -> Unit)? = null,
    selected: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    index: Int = 0,
) {
    val swipeOn = showMenu && ui.selection.isEmpty()
    val state = androidx.compose.material3.rememberSwipeToDismissBoxState(
        confirmValueChange = { v ->
            when (v) {
                androidx.compose.material3.SwipeToDismissBoxValue.StartToEnd -> {
                    ui.enqueue(listOf(t))
                    ui.say("Added to queue")
                }
                androidx.compose.material3.SwipeToDismissBoxValue.EndToStart -> {
                    ui.playNext(listOf(t))
                    ui.say("Playing next")
                }
                else -> {}
            }
            false
        },
    )
    androidx.compose.material3.SwipeToDismissBox(
        state = state,
        enableDismissFromStartToEnd = swipeOn,
        enableDismissFromEndToStart = swipeOn,
        backgroundContent = {
            val dir = state.dismissDirection
            if (dir != androidx.compose.material3.SwipeToDismissBoxValue.Settled) {
                val toQueue = dir == androidx.compose.material3.SwipeToDismissBoxValue.StartToEnd
                Row(
                    Modifier.fillMaxSize().background(MaterialTheme.colorScheme.primaryContainer).padding(horizontal = 24.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = if (toQueue) Arrangement.Start else Arrangement.End,
                ) {
                    Text(
                        if (toQueue) "Add to queue" else "Play next",
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontWeight = FontWeight.SemiBold,
                    )
                }
            }
        },
    ) {
        Box(Modifier.background(MaterialTheme.colorScheme.background)) {
            SongRowBody(t, ui, playing, onClick, showMenu, trailing, selected, onLongClick, index)
        }
    }
}

@Composable
fun TrackList(
    ui: UiController,
    tracks: List<Track>,
    modifier: Modifier = Modifier,
    header: (@Composable () -> Unit)? = null,
    showMenu: Boolean = true,
    trailing: (@Composable (Int, Track) -> Unit)? = null,
) {
    val pui by ui.app.player.ui.collectAsState()
    val playing = pui.path
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        if (header != null) {
            item(key = "header") { header() }
        }
        itemsIndexed(tracks, key = { i, t -> "$i-${t.id}" }) { i, t ->
            SongRow(
                t = t,
                ui = ui,
                playing = playing == t.path,
                onClick = { if (ui.selection.isNotEmpty()) ui.toggleSelect(t) else ui.play(tracks, i) },
                showMenu = showMenu,
                trailing = if (trailing != null) ({ trailing(i, t) }) else null,
                selected = ui.selection.any { it.path == t.path },
                onLongClick = { ui.toggleSelect(t) },
                index = i,
            )
        }
    }
}

@Composable
fun SearchField(value: String, onChange: (String) -> Unit, hint: String = "Search") {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        placeholder = { Text(hint) },
        leadingIcon = { Icon(Icons.Rounded.Search, null) },
        trailingIcon = if (value.isNotEmpty()) ({
            IconButton(onClick = { onChange("") }) { Icon(Icons.Rounded.Close, "Clear") }
        }) else null,
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
    )
}

@Composable
fun ListHeader(
    title: String,
    subtitle: String?,
    ui: UiController,
    tracks: List<Track>,
    back: Boolean = false,
    cover: Track? = null,
    coverContent: (@Composable () -> Unit)? = null,
    showSettings: Boolean = false,
    menuExtra: (@Composable (close: () -> Unit) -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(start = if (back) 4.dp else 16.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (back) {
                IconButton(onClick = { ui.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") }
            }
            if (coverContent != null) {
                coverContent()
                Spacer(Modifier.width(12.dp))
            } else if (cover != null) {
                Cover(cover, Modifier.size(64.dp), 64.dp, RoundedCornerShape(12.dp))
                Spacer(Modifier.width(12.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                if (subtitle != null) {
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            actions()
            if (showSettings) {
                IconButton(onClick = { ui.open(Dest(Kind.SETTINGS)) }) { Icon(Icons.Rounded.Settings, "Settings") }
            }
        }
        if (tracks.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Button(onClick = { ui.play(tracks, 0) }) {
                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Play")
                }
                FilledTonalButton(onClick = { ui.shuffle(tracks) }) {
                    Icon(Icons.Rounded.Shuffle, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Shuffle")
                }
                Spacer(Modifier.weight(1f))
                var menu by remember { mutableStateOf(false) }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "More") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Play next") },
                            onClick = { menu = false; ui.playNext(tracks) },
                        )
                        DropdownMenuItem(
                            text = { Text("Add to queue") },
                            onClick = { menu = false; ui.enqueue(tracks) },
                        )
                        DropdownMenuItem(
                            text = { Text("Add to playlist") },
                            onClick = { menu = false; ui.pickPlaylistFor = tracks },
                        )
                        if (menuExtra != null) menuExtra { menu = false }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyState(title: String, body: String, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    Column(
        modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            Icons.Rounded.MusicNote,
            null,
            Modifier.size(48.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(
            body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        if (action != null) {
            Spacer(Modifier.height(16.dp))
            action()
        }
    }
}

@Composable
fun <T> Choices(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { (label, value) ->
            FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) })
        }
    }
}

@Composable
fun roundShape(): Shape = CircleShape

/** Three little bars that bounce next to the song that is playing. */
@Composable
fun PlayingBars(modifier: Modifier = Modifier) {
    val t = androidx.compose.animation.core.rememberInfiniteTransition(label = "bars")
    val color = MaterialTheme.colorScheme.primary
    val heights = listOf(420, 560, 700).mapIndexed { i, ms ->
        t.animateFloat(
            initialValue = 0.25f,
            targetValue = 1f,
            animationSpec = androidx.compose.animation.core.infiniteRepeatable(
                androidx.compose.animation.core.tween(ms, easing = androidx.compose.animation.core.LinearEasing),
                androidx.compose.animation.core.RepeatMode.Reverse,
                androidx.compose.animation.core.StartOffset(i * 120),
            ),
            label = "bar$i",
        )
    }
    Row(modifier.height(16.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        heights.forEach { h ->
            Box(Modifier.width(3.dp).fillMaxHeight(h.value).background(color, RoundedCornerShape(1.dp)))
        }
    }
}

/** Up to four songs with different albums, for the picture of a playlist that has none of its own. */
fun playlistMosaic(app: com.hwush.player.HwushApp, p: com.hwush.player.data.Playlist): List<Track> =
    p.paths.asSequence().mapNotNull { app.library.find(it) }.distinctBy { it.album }.take(4).toList()
