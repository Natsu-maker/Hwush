@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import android.graphics.Bitmap
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Store
import com.hwush.player.data.StoreData
import com.hwush.player.data.Track
import com.hwush.player.hwush
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map

// ---------------------------------------------------------------- small helpers

fun fmtTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

fun fmtBytes(b: Long): String = when {
    b >= 1_000_000_000L -> "%.1f GB".format(b / 1e9)
    b >= 1_000_000L -> "%.1f MB".format(b / 1e6)
    else -> "%d KB".format(b / 1000)
}

fun plural(n: Int, word: String): String = if (n == 1) "1 $word" else "$n ${word}s"

fun hueOf(s: String): Float {
    var h = 0
    for (c in s) h = (h * 31 + c.code) % 360
    return h.toFloat()
}

fun lastSegment(path: String): String = path.trimEnd('/').substringAfterLast('/').ifEmpty { path }

fun filterTracks(list: List<Track>, q: String): List<Track> {
    val s = q.trim()
    if (s.isEmpty()) return list
    return list.filter {
        it.title.contains(s, ignoreCase = true) || it.artist.contains(s, ignoreCase = true) ||
            it.album.contains(s, ignoreCase = true)
    }
}

fun sortTracks(list: List<Track>, key: Int, desc: Boolean): List<Track> {
    val cmp: Comparator<Track> = when (key) {
        1 -> compareBy<Track>({ it.artist.lowercase() }, { it.title.lowercase() })
        2 -> compareBy<Track>({ it.album.lowercase() }, { it.trackNo }, { it.title.lowercase() })
        3 -> compareBy<Track> { it.dateAdded }.thenBy { it.title.lowercase() }
        4 -> compareBy<Track> { it.durationMs }.thenBy { it.title.lowercase() }
        else -> compareBy<Track> { it.title.lowercase() }
    }
    return if (desc) list.sortedWith(cmp.reversed()) else list.sortedWith(cmp)
}

/** Watches one slice of the saved data, so a screen only redraws when its own slice changes. */
@Composable
fun <T> Store.select(key: Any? = null, f: (StoreData) -> T): State<T> {
    val store = this
    val flow = remember(store, key) { store.data.map { f(it) }.distinctUntilChanged() }
    return flow.collectAsState(initial = f(store.data.value))
}

// ---------------------------------------------------------------- cover art

@Composable
fun Cover(
    track: Track?,
    modifier: Modifier = Modifier,
    loadSize: Dp = 160.dp,
    shape: Shape = RoundedCornerShape(10.dp),
) {
    val app = LocalContext.current.hwush
    val rev = app.coverRev.intValue
    val px = with(LocalDensity.current) { loadSize.roundToPx() }
    val bmp by produceState<Bitmap?>(track?.let { app.art.peek(it, px) }, track?.path, rev, px) {
        value = if (track == null) null else app.art.load(track, px)
    }
    val b = bmp
    Box(modifier.clip(shape)) {
        if (b != null) {
            Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            val h = hueOf((track?.album ?: "") + (track?.artist ?: ""))
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            listOf(Color.hsv(h, 0.55f, 0.5f), Color.hsv((h + 40f) % 360f, 0.6f, 0.24f)),
                        ),
                    ),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Rounded.MusicNote,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.fillMaxSize(0.45f),
                )
            }
        }
    }
}

// ---------------------------------------------------------------- rows and lists

@Composable
fun SongRow(
    t: Track,
    ui: UiController,
    playing: Boolean,
    onClick: () -> Unit,
    showMenu: Boolean = true,
    trailing: (@Composable () -> Unit)? = null,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = if (showMenu) 4.dp else 8.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Cover(t, Modifier.size(48.dp), 48.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                t.title,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = if (playing) FontWeight.SemiBold else FontWeight.Normal,
                color = if (playing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
            Text(
                "${t.artist} · ${fmtTime(t.durationMs)}",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (trailing != null) trailing()
        if (showMenu) {
            IconButton(onClick = { ui.menuTrack = t }) { Icon(Icons.Rounded.MoreVert, "More") }
        }
    }
}

@Composable
fun TrackList(
    ui: UiController,
    tracks: List<Track>,
    modifier: Modifier = Modifier,
    header: (@Composable () -> Unit)? = null,
    showMenu: Boolean = true,
    trailing: (@Composable (Int, Track) -> Unit)? = null,
) {
    val pui by ui.app.player.ui.collectAsState()
    val playing = pui.path
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        if (header != null) {
            item(key = "header") { header() }
        }
        itemsIndexed(tracks, key = { i, t -> "$i-${t.id}" }) { i, t ->
            SongRow(
                t = t,
                ui = ui,
                playing = playing == t.path,
                onClick = { ui.play(tracks, i) },
                showMenu = showMenu,
                trailing = if (trailing != null) ({ trailing(i, t) }) else null,
            )
        }
    }
}

@Composable
fun SearchField(value: String, onChange: (String) -> Unit, hint: String = "Search") {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        singleLine = true,
        placeholder = { Text(hint) },
        leadingIcon = { Icon(Icons.Rounded.Search, null) },
        trailingIcon = if (value.isNotEmpty()) ({
            IconButton(onClick = { onChange("") }) { Icon(Icons.Rounded.Close, "Clear") }
        }) else null,
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
    )
}

@Composable
fun ListHeader(
    title: String,
    subtitle: String?,
    ui: UiController,
    tracks: List<Track>,
    back: Boolean = false,
    cover: Track? = null,
    showSettings: Boolean = false,
    menuExtra: (@Composable (close: () -> Unit) -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(start = if (back) 4.dp else 16.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (back) {
                IconButton(onClick = { ui.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") }
            }
            if (cover != null) {
                Cover(cover, Modifier.size(64.dp), 64.dp, RoundedCornerShape(12.dp))
                Spacer(Modifier.width(12.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                if (subtitle != null) {
                    Text(
                        subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }
            actions()
            if (showSettings) {
                IconButton(onClick = { ui.open(Dest(Kind.SETTINGS)) }) { Icon(Icons.Rounded.Settings, "Settings") }
            }
        }
        if (tracks.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Button(onClick = { ui.play(tracks, 0) }) {
                    Icon(Icons.Rounded.PlayArrow, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Play")
                }
                FilledTonalButton(onClick = { ui.shuffle(tracks) }) {
                    Icon(Icons.Rounded.Shuffle, null, Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Shuffle")
                }
                Spacer(Modifier.weight(1f))
                var menu by remember { mutableStateOf(false) }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, "More") }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Play next") },
                            onClick = { menu = false; ui.playNext(tracks) },
                        )
                        DropdownMenuItem(
                            text = { Text("Add to queue") },
                            onClick = { menu = false; ui.enqueue(tracks) },
                        )
                        DropdownMenuItem(
                            text = { Text("Add to playlist") },
                            onClick = { menu = false; ui.pickPlaylistFor = tracks },
                        )
                        if (menuExtra != null) menuExtra { menu = false }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyState(title: String, body: String, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    Column(
        modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            Icons.Rounded.MusicNote,
            null,
            Modifier.size(48.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(
            body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
        if (action != null) {
            Spacer(Modifier.height(16.dp))
            action()
        }
    }
}

@Composable
fun <T> Choices(options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { (label, value) ->
            FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) })
        }
    }
}

@Composable
fun roundShape(): Shape = CircleShape
