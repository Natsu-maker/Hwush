@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Lyrics
import com.hwush.player.data.Track
import com.hwush.player.player.PlayerUi
import kotlinx.coroutines.delay
import kotlin.math.max

fun fmtSpeed(v: Float): String = "%.2f×".format(v).replace(Regex("0+×$"), "×").replace(".×", "×")

// ---------------------------------------------------------------- mini player (phone)

@Composable
fun MiniPlayer(ui: UiController) {
    val app = ui.app
    val holder = app.player
    val pui by holder.ui.collectAsState()
    val track = pui.path?.let { app.library.find(it) }
    if (track != null) {
        val pos by produceState(0L, pui.path, pui.isPlaying) {
            while (true) {
                value = holder.position()
                delay(if (pui.isPlaying) 500L else 1500L)
            }
        }
        val dur = max(1L, holder.duration())
        Surface(
            onClick = { ui.nowPlayingOpen = true },
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
        ) {
            Column {
                LinearProgressIndicator(
                    progress = { (pos.toFloat() / dur).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(2.dp),
                )
                Row(
                    Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Cover(track, Modifier.size(44.dp), 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        Text(
                            track.artist,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { holder.togglePlay() }) {
                        Icon(if (pui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (pui.isPlaying) "Pause" else "Play")
                    }
                    IconButton(onClick = { holder.next() }) { Icon(Icons.Rounded.SkipNext, "Next") }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- player pane (phone full screen and tablet side panel)

@Composable
fun PlayerPane(ui: UiController, modifier: Modifier = Modifier, onClose: (() -> Unit)? = null) {
    val app = ui.app
    val pui by app.player.ui.collectAsState()
    val track = pui.path?.let { app.library.find(it) }
    var tab by remember { mutableIntStateOf(0) }
    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            if (onClose != null) {
                IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Close") }
            }
            Spacer(Modifier.weight(1f))
            listOf("Player", "Lyrics", "Up next").forEachIndexed { i, label ->
                FilterChip(
                    selected = tab == i,
                    onClick = { tab = i },
                    label = { Text(label) },
                    modifier = Modifier.padding(horizontal = 3.dp),
                )
            }
            Spacer(Modifier.weight(1f))
            if (onClose != null) Spacer(Modifier.width(48.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> NowTab(ui, pui, track)
                1 -> LyricsTab(ui, pui, track)
                else -> QueueTab(ui, pui)
            }
        }
    }
}

@Composable
private fun NowTab(ui: UiController, pui: PlayerUi, track: Track?) {
    val app = ui.app
    val holder = app.player
    val fav by app.store.select(track?.path) { track != null && track.path in it.favorites }
    val primary = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Cover(
            track,
            Modifier.fillMaxWidth(0.86f).widthIn(max = 380.dp).aspectRatio(1f),
            380.dp,
            RoundedCornerShape(26.dp),
        )
        Spacer(Modifier.height(20.dp))
        Text(
            track?.title ?: "Nothing playing",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Text(
            if (track == null) "Pick a song from your library" else "${track.artist} · ${track.album}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(8.dp))
        SeekBar(ui, pui)
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { holder.toggleShuffle() }) {
                Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (pui.shuffle) primary else dim)
            }
            IconButton(onClick = { holder.previous() }, Modifier.size(56.dp)) {
                Icon(Icons.Rounded.SkipPrevious, "Previous", Modifier.size(34.dp))
            }
            FilledIconButton(onClick = { holder.togglePlay() }, Modifier.size(72.dp)) {
                Icon(
                    if (pui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    if (pui.isPlaying) "Pause" else "Play",
                    Modifier.size(40.dp),
                )
            }
            IconButton(onClick = { holder.next() }, Modifier.size(56.dp)) {
                Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(34.dp))
            }
            IconButton(onClick = { holder.cycleRepeat() }) {
                Icon(
                    if (pui.repeat == 2) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    "Repeat",
                    tint = if (pui.repeat != 0) primary else dim,
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { track?.let { app.store.toggleFavorite(it.path) } }) {
                Icon(if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, "Favorite", tint = if (fav) primary else dim)
            }
            val speedText = if (pui.speed != 1f || pui.pitch != 1f) "Sound · ${fmtSpeed(pui.speed)}" else "Sound"
            AssistChip(onClick = { ui.soundOpen = true }, label = { Text(speedText) })
            val sleepOn = pui.sleepEndsAt > 0L || pui.sleepAfterSong
            AssistChip(onClick = { ui.sleepOpen = true }, label = { Text(if (sleepOn) "Sleep on" else "Sleep") })
            IconButton(onClick = { track?.let { ui.menuTrack = it } }) { Icon(Icons.Rounded.MoreVert, "More") }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun SeekBar(ui: UiController, pui: PlayerUi) {
    val holder = ui.app.player
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val pos by produceState(0L, pui.path, pui.isPlaying) {
        while (true) {
            value = holder.position()
            delay(if (pui.isPlaying) 250L else 700L)
        }
    }
    val dur = max(1L, holder.duration())
    val shown = if (dragging) dragValue else pos.toFloat().coerceIn(0f, dur.toFloat())
    Column(Modifier.fillMaxWidth()) {
        Slider(
            value = shown,
            onValueChange = { dragging = true; dragValue = it },
            onValueChangeFinished = { holder.seekTo(dragValue.toLong()); dragging = false },
            valueRange = 0f..dur.toFloat(),
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
            Text(fmtTime(shown.toLong()), style = MaterialTheme.typography.labelMedium, fontFamily = FontFamily.Monospace)
            Spacer(Modifier.weight(1f))
            Text(fmtTime(dur), style = MaterialTheme.typography.labelMedium, fontFamily = FontFamily.Monospace)
        }
    }
}

// ---------------------------------------------------------------- lyrics

@Composable
private fun LyricsTab(ui: UiController, pui: PlayerUi, track: Track?) {
    val app = ui.app
    val holder = app.player
    val tree by app.store.select { it.lyricsTree }
    val chosen by app.store.select { d -> track?.let { d.songLyrics[it.path] } }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null && track != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            app.store.setSongLyrics(track.path, uri.toString())
        }
    }
    var lyrics by remember(track?.path) { mutableStateOf<Lyrics?>(null) }
    var loading by remember(track?.path) { mutableStateOf(true) }
    LaunchedEffect(track?.path, tree, chosen) {
        loading = true
        lyrics = if (track == null) null else app.lyrics.find(track)
        loading = false
    }
    if (track == null) {
        EmptyState("Nothing playing", "Start a song to see its lyrics.")
        return
    }
    val l = lyrics
    if (l == null) {
        EmptyState(
            title = if (loading) "Looking for lyrics" else "No lyrics found",
            body = if (loading) "Checking next to the song and in your lyrics folder." else
                "Put a .lrc file with the same name next to the song, or pick a lyrics folder in Settings.",
            action = if (loading) null else ({
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Button(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Choose .lrc file for this song") }
                    TextButton(onClick = { ui.nowPlayingOpen = false; ui.open(Dest(Kind.SETTINGS)) }) { Text("Pick a lyrics folder instead") }
                }
            }),
        )
        return
    }
    val pos by produceState(0L, pui.path, pui.isPlaying) {
        while (true) {
            value = holder.position()
            delay(if (pui.isPlaying) 200L else 600L)
        }
    }
    var active = -1
    if (l.synced) {
        for (k in l.lines.indices) {
            if (l.lines[k].timeMs <= pos + 150L) active = k else break
        }
    }
    val state = rememberLazyListState()
    LaunchedEffect(active) {
        if (active >= 0) state.animateScrollToItem((active - 2).coerceAtLeast(0))
    }
    LazyColumn(Modifier.fillMaxSize(), state = state, contentPadding = PaddingValues(horizontal = 24.dp, vertical = 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text(if (chosen != null) "Change lyrics file" else "Use another file") }
                if (chosen != null) TextButton(onClick = { app.store.setSongLyrics(track.path, null) }) { Text("Remove") }
            }
        }
        itemsIndexed(l.lines) { i, line ->
            val current = i == active
            Text(
                line.text.ifEmpty { "♪" },
                style = MaterialTheme.typography.titleLarge,
                fontWeight = if (current) FontWeight.Bold else FontWeight.Medium,
                color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier
                    .fillMaxWidth()
                    .alpha(if (current || !l.synced) 1f else 0.5f)
                    .then(if (l.synced) Modifier.clickable { holder.seekTo(line.timeMs) } else Modifier)
                    .padding(vertical = 8.dp),
            )
        }
    }
}

// ---------------------------------------------------------------- queue

@Composable
private fun QueueTab(ui: UiController, pui: PlayerUi) {
    val app = ui.app
    val holder = app.player
    val paths = pui.queue
    if (paths.isEmpty()) {
        EmptyState("Queue is empty", "Play a song, or add songs with Play next and Add to queue.")
        return
    }
    val state = rememberLazyListState()
    LaunchedEffect(Unit) { state.scrollToItem((pui.index - 1).coerceAtLeast(0)) }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "${plural(paths.size, "song")} in queue",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { holder.clearUpcoming() }) { Text("Clear upcoming") }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = state) {
            itemsIndexed(paths, key = { i, p -> "$i$p" }) { i, path ->
                val t = app.library.find(path)
                val current = i == pui.index
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { holder.skipTo(i) }
                        .padding(start = 16.dp, end = 0.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Cover(t, Modifier.size(40.dp), 48.dp, RoundedCornerShape(8.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            t?.title ?: lastSegment(path),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontWeight = if (current) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            t?.artist ?: "",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { holder.moveInQueue(i, i - 1) }, enabled = i > 0, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Rounded.KeyboardArrowUp, "Move up")
                    }
                    IconButton(onClick = { holder.moveInQueue(i, i + 1) }, enabled = i < paths.lastIndex, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Rounded.KeyboardArrowDown, "Move down")
                    }
                    IconButton(onClick = { holder.removeAt(i) }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Rounded.Close, "Remove")
                    }
                }
            }
        }
    }
}
