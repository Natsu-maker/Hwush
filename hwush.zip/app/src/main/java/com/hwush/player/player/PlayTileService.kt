package com.hwush.player.player

import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.hwush.player.HwushApp

/** A tile for the quick settings panel that plays and pauses, so music is one swipe away on any screen. */
class PlayTileService : TileService() {
    override fun onStartListening() {
        refresh()
    }

    override fun onClick() {
        val app = application as HwushApp
        app.player.togglePlay()
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        val app = application as HwushApp
        val playing = app.player.player.isPlaying
        val title = app.player.currentTrack()?.title
        tile.state = if (playing) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = title ?: "Hwush"
        if (Build.VERSION.SDK_INT >= 29) tile.subtitle = if (playing) "Playing" else "Paused"
        tile.updateTile()
    }
}
