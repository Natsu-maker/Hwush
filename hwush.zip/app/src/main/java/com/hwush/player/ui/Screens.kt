@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import com.hwush.player.data.Playlist
import androidx.compose.foundation.combinedClickable
import androidx.compose.material.icons.rounded.PushPin
import com.hwush.player.data.SmartRule
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.material.icons.rounded.ViewList
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Track

// ---------------------------------------------------------------- Songs

@Composable
fun SortMenu(ui: UiController, sortKey: Int, desc: Boolean) {
    var open by remember { mutableStateOf(false) }
    val labels = listOf("Title", "Artist", "Album", "Date added", "Length")
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Rounded.Sort, "Sort") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            labels.forEachIndexed { i, label ->
                DropdownMenuItem(
                    text = { Text(label) },
                    leadingIcon = if (i == sortKey) ({ Icon(Icons.Rounded.Check, null) }) else null,
                    onClick = {
                        open = false
                        ui.app.store.update { it.copy(sortKey = i) }
                    },
                )
            }
            DropdownMenuItem(
                text = { Text(if (desc) "Descending" else "Ascending") },
                onClick = { open = false; ui.app.store.update { it.copy(sortDesc = !desc) } },
            )
        }
    }
}

@Composable
fun SongsScreen(ui: UiController) {
    val app = ui.app
    val all by app.library.tracks.collectAsState()
    val loaded by app.library.loaded.collectAsState()
    val sortKey by app.store.select { it.sortKey }
    val desc by app.store.select { it.sortDesc }
    val q = ui.query
    val list = remember(all, sortKey, desc, q) { sortTracks(filterTracks(all, q), sortKey, desc) }
    if (loaded && all.isEmpty()) {
        EmptyLibrary(ui)
    } else {
        TrackList(ui, list, header = {
            Column {
                ListHeader(
                    title = "Songs",
                    subtitle = plural(all.size, "song"),
                    ui = ui,
                    tracks = list,
                    showSettings = true,
                    actions = { SortMenu(ui, sortKey, desc) },
                )
                SearchField(q, { ui.query = it }, "Search songs, artists, albums")
            }
        })
    }
}

@Composable
fun EmptyLibrary(ui: UiController) {
    EmptyState(
        title = "No songs found",
        body = "Hwush looks for music on this device. Songs shorter than the minimum length in Settings are hidden.",
        action = {
            Button(onClick = { ui.app.library.refresh() }) { Text("Scan again") }
        },
    )
}

// ---------------------------------------------------------------- Albums

@Composable
fun AlbumsScreen(ui: UiController) {
    val albums by ui.app.library.albums.collectAsState()
    val q = ui.query.trim()
    val shown = remember(albums, q) {
        if (q.isEmpty()) albums
        else albums.filter { it.name.contains(q, true) || it.artist.contains(q, true) }
    }
    Column(Modifier.fillMaxSize()) {
        ListHeader("Albums", plural(albums.size, "album"), ui, emptyList(), showSettings = true)
        SearchField(ui.query, { ui.query = it }, "Search albums")
        LazyVerticalGrid(
            columns = GridCells.Adaptive(150.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            items(shown, key = { it.key }) { a ->
                Column(Modifier.clickable { ui.open(Dest(Kind.ALBUM, a.key)) }) {
                    Cover(a.tracks.first(), Modifier.fillMaxWidth().aspectRatio(1f), 160.dp, RoundedCornerShape(14.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(
                        a.name,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodyLarge,
                    )
                    Text(
                        "${a.artist} · ${a.tracks.size}",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
fun AlbumDetail(ui: UiController, key: String) {
    val albums by ui.app.library.albums.collectAsState()
    val album = albums.firstOrNull { it.key == key }
    if (album == null) {
        EmptyState("Album not found", "It may have been removed from your library.")
        return
    }
    TrackList(ui, album.tracks, header = {
        ListHeader(
            title = album.name,
            subtitle = "${album.artist} · ${plural(album.tracks.size, "song")}",
            ui = ui,
            tracks = album.tracks,
            back = true,
            cover = album.tracks.first(),
        )
    })
}

// ---------------------------------------------------------------- Artists

@Composable
fun ArtistsScreen(ui: UiController) {
    val artists by ui.app.library.artists.collectAsState()
    val q = ui.query.trim()
    val shown = remember(artists, q) { if (q.isEmpty()) artists else artists.filter { it.name.contains(q, true) } }
    Column(Modifier.fillMaxSize()) {
        ListHeader("Artists", plural(artists.size, "artist"), ui, emptyList(), showSettings = true)
        SearchField(ui.query, { ui.query = it }, "Search artists")
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(shown, key = { it.name }) { a ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { ui.open(Dest(Kind.ARTIST, a.name)) }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Cover(a.tracks.first(), Modifier.size(52.dp), 52.dp, CircleShape)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            plural(a.tracks.size, "song"),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ArtistDetail(ui: UiController, name: String) {
    val artists by ui.app.library.artists.collectAsState()
    val artist = artists.firstOrNull { it.name == name }
    if (artist == null) {
        EmptyState("Artist not found", "It may have been removed from your library.")
        return
    }
    val sorted = remember(artist) { sortTracks(artist.tracks, 2, false) }
    TrackList(ui, sorted, header = {
        ListHeader(
            title = artist.name,
            subtitle = plural(artist.tracks.size, "song"),
            ui = ui,
            tracks = sorted,
            back = true,
            cover = sorted.first(),
        )
    })
}

// ---------------------------------------------------------------- Folders

@Composable
fun FoldersScreen(ui: UiController) {
    val folders by ui.app.library.folders.collectAsState()
    val pui by ui.app.player.ui.collectAsState()
    val q = ui.query.trim()
    val root = remember(folders) {
        val parts = folders.map { it.path.split('/') }
        if (parts.isEmpty()) "" else {
            var n = parts.minOf { it.size }
            val first = parts.first()
            while (n > 0 && !parts.all { it.take(n) == first.take(n) }) n--
            first.take(n).joinToString("/")
        }
    }
    var dir by remember(root) { mutableStateOf(root) }
    androidx.activity.compose.BackHandler(enabled = q.isEmpty() && dir.length > root.length) {
        val up = dir.substringBeforeLast('/')
        dir = if (up.length < root.length) root else up
    }
    Column(Modifier.fillMaxSize()) {
        ListHeader("Folders", plural(folders.size, "folder"), ui, emptyList(), back = ui.stack.size > 1, showSettings = true)
        SearchField(ui.query, { ui.query = it }, "Search folders")
        if (q.isNotEmpty()) {
            val shown = folders.filter { it.path.contains(q, true) }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                items(shown, key = { it.path }) { f ->
                    ListItem(
                        modifier = Modifier.clickable { ui.open(Dest(Kind.FOLDER, f.path)) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        leadingContent = { Icon(Icons.Rounded.Folder, null, tint = MaterialTheme.colorScheme.primary) },
                        headlineContent = { Text(lastSegment(f.path).ifEmpty { "Unknown" }, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        supportingContent = { Text("${plural(f.tracks.size, "song")} · ${f.path}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        trailingContent = {
                            IconButton(onClick = {
                                ui.app.store.update { it.copy(excludedFolders = it.excludedFolders + f.path) }
                                ui.say("Folder hidden. You can show it again in Settings.")
                            }) { Icon(Icons.Rounded.VisibilityOff, "Hide folder") }
                        },
                    )
                }
            }
            return@Column
        }
        val prefix = "$dir/"
        val kids = remember(folders, dir) {
            folders.filter { it.path.startsWith(prefix) }
                .groupBy { it.path.removePrefix(prefix).substringBefore('/') }
                .map { (name, l) -> Triple(name, l.sumOf { it.tracks.size }, l.size) }
                .sortedBy { it.first.lowercase() }
        }
        val here = remember(folders, dir) {
            folders.firstOrNull { it.path == dir }?.let { sortTracks(it.tracks, 0, false) } ?: emptyList()
        }
        if (dir.length > root.length) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = {
                    val up = dir.substringBeforeLast('/')
                    dir = if (up.length < root.length) root else up
                }) { Icon(Icons.Rounded.ArrowBack, "Up one folder") }
                Text(
                    dir.removePrefix(root).trimStart('/'),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleSmall,
                )
            }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(kids, key = { "d" + it.first }) { (name, songs, _) ->
                ListItem(
                    modifier = Modifier.clickable { dir = prefix + name },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    leadingContent = { Icon(Icons.Rounded.Folder, null, tint = MaterialTheme.colorScheme.primary) },
                    headlineContent = { Text(name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text(plural(songs, "song")) },
                )
            }
            itemsIndexed(here, key = { i, t -> "t$i-${t.id}" }) { i, t ->
                SongRow(
                    t = t,
                    ui = ui,
                    playing = pui.path == t.path,
                    onClick = { if (ui.selection.isNotEmpty()) ui.toggleSelect(t) else ui.play(here, i) },
                    selected = ui.selection.any { it.path == t.path },
                    onLongClick = { ui.toggleSelect(t) },
                    index = i,
                )
            }
        }
    }
}

@Composable
fun FolderDetail(ui: UiController, path: String) {
    val folders by ui.app.library.folders.collectAsState()
    val folder = folders.firstOrNull { it.path == path }
    if (folder == null) {
        EmptyState("Folder not found", "It may be empty or hidden.")
        return
    }
    val sorted = remember(folder) { sortTracks(folder.tracks, 0, false) }
    TrackList(ui, sorted, header = {
        ListHeader(
            title = lastSegment(folder.path),
            subtitle = "${plural(sorted.size, "song")} · ${folder.path}",
            ui = ui,
            tracks = sorted,
            back = true,
        )
    })
}

// ---------------------------------------------------------------- Playlists

private data class Smart(val id: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val smartLists = listOf(
    Smart("s:fav", "Favorites", Icons.Rounded.Favorite),
    Smart("s:recent", "Recently played", Icons.Rounded.History),
    Smart("s:top", "Most played", Icons.Rounded.MusicNote),
    Smart("s:added", "Recently added", Icons.Rounded.Add),
    Smart("s:rated", "Top rated", Icons.Rounded.Star),
)

@Composable
fun PlaylistsScreen(ui: UiController) {
    val app = ui.app
    val playlists by app.store.select { it.playlists }
    val grid by app.store.select { it.playlistGrid }
    val rules by app.store.select { it.smartRules }
    val pinned by app.store.select { it.pinned }
    val sort by app.store.select { it.playlistSort }
    val folders by app.store.select { it.playlistFolders }
    val bin by app.store.select { it.deletedPlaylists }
    val all by app.library.tracks.collectAsState()
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var openFolder by remember { mutableStateOf<String?>(null) }
    var sortMenu by remember { mutableStateOf(false) }
    var newFolder by remember { mutableStateOf(false) }
    var moveOpen by remember { mutableStateOf(false) }
    var moveNew by remember { mutableStateOf(false) }
    var mergeOpen by remember { mutableStateOf(false) }
    var binOpen by remember { mutableStateOf(false) }
    var folderToRemove by remember { mutableStateOf<String?>(null) }
    val inSelect = selected.isNotEmpty()
    val atTop = openFolder == null
    androidx.activity.compose.BackHandler(enabled = inSelect || openFolder != null) {
        if (inSelect) selected = emptySet() else openFolder = null
    }
    val folderNames = remember(folders, playlists) { (folders + playlists.map { it.folder }.filter { it.isNotEmpty() }).sorted() }
    val sortedPl = remember(playlists, sort, openFolder) {
        val inside = playlists.filter { it.folder == (openFolder ?: "") }
        when (sort) {
            1 -> inside.sortedBy { it.name.lowercase() }
            2 -> inside.sortedByDescending { it.paths.size }
            3 -> inside.sortedByDescending { it.opened }
            4 -> inside.sortedByDescending { it.id }
            else -> inside
        }
    }
    // Every playlist kind in one shape, so pinned ones can be pulled to the top together.
    val entries = remember(playlists, rules, sortedPl, folderNames, atTop) {
        val smart: List<PlEntry> = if (atTop) {
            smartLists.map { PlEntry("s:" + it.id.removePrefix("s:"), it.title, "Smart list", it.id, it.icon, null, null) } +
                rules.map { PlEntry("c:${it.id}", it.name, "Smart playlist", "c:${it.id}", Icons.Rounded.AutoAwesome, null, it) }
        } else {
            emptyList()
        }
        val dirs: List<PlEntry> = if (atTop) {
            folderNames.map { PlEntry("f:$it", it, "", "", Icons.Rounded.Folder, null, null, it) }
        } else {
            emptyList()
        }
        smart + dirs + sortedPl.map { PlEntry(it.id.toString(), it.name, "", it.id.toString(), null, it, null) }
    }
    val top = if (atTop) entries.filter { it.key in pinned } else emptyList()
    val builtIn = entries.filter { it.key !in pinned && it.playlist == null && it.rule == null && it.folder == null }
    val dirEntries = entries.filter { it.folder != null }
    val mine = entries.filter { (!atTop || it.key !in pinned) && (it.playlist != null || it.rule != null) }
    val countOf: (Playlist) -> Int = { p -> p.paths.count { app.library.find(it) != null } }

    val openEntry: (PlEntry) -> Unit = { e ->
        val pl = e.playlist
        if (e.folder != null) {
            openFolder = e.folder
        } else if (inSelect && pl != null) {
            selected = if (pl.id in selected) selected - pl.id else selected + pl.id
        } else if (!inSelect) {
            ui.open(Dest(Kind.PLAYLIST, e.dest))
        }
    }
    val longEntry: (PlEntry) -> Unit = { e ->
        val pl = e.playlist
        if (pl != null) {
            selected = selected + pl.id
        } else if (e.folder != null) {
            folderToRemove = e.folder
        } else {
            app.store.togglePin(e.key)
        }
    }

    val header: @Composable () -> Unit = {
        if (inSelect) {
            PlSelectionBar(
                count = selected.size,
                onClose = { selected = emptySet() },
                onAll = { selected = sortedPl.map { it.id }.toSet() },
                onMove = { moveOpen = true },
                onMerge = { mergeOpen = true },
                onDelete = {
                    val ids = selected
                    app.store.deletePlaylists(ids)
                    selected = emptySet()
                    ui.sayAction("Deleted ${plural(ids.size, "playlist")}", "Undo") { app.store.restorePlaylists(ids) }
                },
            )
        } else {
            ListHeader(
                openFolder ?: "Playlists",
                if (atTop) plural(playlists.size, "playlist") else plural(sortedPl.size, "playlist"),
                ui,
                emptyList(),
                showSettings = atTop,
                actions = {
                    if (!atTop) IconButton(onClick = { openFolder = null }) { Icon(Icons.Rounded.ArrowBack, "Back to all playlists") }
                    if (bin.isNotEmpty()) IconButton(onClick = { binOpen = true }) { Icon(Icons.Rounded.Delete, "Recycle bin") }
                    Box {
                        IconButton(onClick = { sortMenu = true }) { Icon(Icons.Rounded.Sort, "Sort playlists") }
                        DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                            listOf("As made", "Name", "Most songs", "Recently opened", "Newest").forEachIndexed { i, label ->
                                DropdownMenuItem(
                                    text = { Text(label) },
                                    onClick = { sortMenu = false; app.store.update { d -> d.copy(playlistSort = i) } },
                                    trailingIcon = if (sort == i) ({ Icon(Icons.Rounded.Check, null) }) else null,
                                )
                            }
                        }
                    }
                    IconButton(onClick = { app.store.update { d -> d.copy(playlistGrid = !d.playlistGrid) } }) {
                        Icon(
                            if (grid) Icons.Rounded.ViewList else Icons.Rounded.GridView,
                            if (grid) "Show as list" else "Show as grid",
                        )
                    }
                },
            )
        }
    }

    if (grid) {
        Column(Modifier.fillMaxSize()) {
        header()
        LazyVerticalGrid(
            columns = GridCells.Adaptive(150.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            val tile: @Composable (PlEntry) -> Unit = { e ->
                val isPinned = e.key in pinned
                val first = e.playlist?.paths?.firstNotNullOfOrNull { app.library.find(it) }
                val sel = e.playlist != null && e.playlist.id in selected
                GridCard(
                    title = e.title,
                    subtitle = when {
                        e.playlist != null -> plural(remember(e.playlist, all) { countOf(e.playlist) }, "song")
                        e.folder != null -> plural(playlists.count { it.folder == e.folder }, "playlist")
                        else -> e.sub
                    },
                    pinned = isPinned,
                    selected = sel,
                    onLongClick = { longEntry(e) },
                    onClick = { openEntry(e) },
                ) {
                    if (e.playlist != null) {
                        PlaylistCover(e.playlist.cover, first, Modifier.fillMaxSize(), 200.dp, mosaic = remember(e.playlist, all) { playlistMosaic(app, e.playlist) })
                    } else {
                        Box(
                            Modifier.fillMaxSize().background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(e.icon ?: Icons.Rounded.AutoAwesome, null, Modifier.size(44.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    }
                }
            }
            items(top, key = { "p" + it.key }) { tile(it) }
            items(builtIn, key = { "b" + it.key }) { tile(it) }
            items(dirEntries, key = { "d" + it.key }) { tile(it) }
            if (atTop) {
                item(key = "new") {
                    GridCard(title = "New playlist", subtitle = "Create one", onClick = { ui.newPlaylistFor = emptyList() }) {
                        Box(
                            Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceContainerHigh),
                            contentAlignment = Alignment.Center,
                        ) { Icon(Icons.Rounded.Add, null, Modifier.size(44.dp), tint = MaterialTheme.colorScheme.primary) }
                    }
                }
                item(key = "newfolder") {
                    GridCard(title = "New folder", subtitle = "Group playlists", onClick = { newFolder = true }) {
                        Box(
                            Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceContainerHigh),
                            contentAlignment = Alignment.Center,
                        ) { Icon(Icons.Rounded.Folder, null, Modifier.size(44.dp), tint = MaterialTheme.colorScheme.primary) }
                    }
                }
                item(key = "newsmart") {
                    GridCard(title = "New smart playlist", subtitle = "From rules", onClick = { ui.smartEdit = SmartRule(System.currentTimeMillis(), "") }) {
                        Box(
                            Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceContainerHigh),
                            contentAlignment = Alignment.Center,
                        ) { Icon(Icons.Rounded.AutoAwesome, null, Modifier.size(44.dp), tint = MaterialTheme.colorScheme.primary) }
                    }
                }
            }
            items(mine, key = { "m" + it.key }) { tile(it) }
        }
        }
    } else {
        val row: @Composable (PlEntry) -> Unit = { e ->
            val isPinned = e.key in pinned
            val first = e.playlist?.paths?.firstNotNullOfOrNull { app.library.find(it) }
            val sel = e.playlist != null && e.playlist.id in selected
            ListItem(
                modifier = Modifier
                    .background(if (sel) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f) else Color.Transparent)
                    .combinedClickable(onClick = { openEntry(e) }, onLongClick = { longEntry(e) }),
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                leadingContent = {
                    if (e.playlist != null) PlaylistCover(e.playlist.cover, first, Modifier.size(48.dp), 48.dp, mosaic = remember(e.playlist, all) { playlistMosaic(app, e.playlist) })
                    else Icon(e.icon ?: Icons.Rounded.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary)
                },
                headlineContent = { Text(e.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = if (e.playlist != null || e.folder != null || e.sub.isNotEmpty()) ({
                    val line = when {
                        e.playlist != null -> plural(remember(e.playlist, all) { countOf(e.playlist) }, "song") +
                            (if (e.playlist.note.isNotBlank()) " · " + e.playlist.note.lineSequence().first() else "")
                        e.folder != null -> plural(playlists.count { it.folder == e.folder }, "playlist")
                        else -> e.sub
                    }
                    Text(line, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }) else null,
                trailingContent = if (e.folder != null || inSelect) null else ({
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (e.rule != null) {
                            IconButton(onClick = { ui.smartEdit = e.rule }) { Icon(Icons.Rounded.Edit, "Edit rules") }
                        }
                        IconButton(onClick = { app.store.togglePin(e.key) }) {
                            Icon(
                                Icons.Rounded.PushPin,
                                if (isPinned) "Unpin" else "Pin to top",
                                tint = if (isPinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            )
                        }
                    }
                }),
            )
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            item(key = "header") { header() }
            if (top.isNotEmpty()) {
                item(key = "pinHead") {
                    Text(
                        "Pinned",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(start = 16.dp, top = 8.dp),
                    )
                }
                items(top, key = { "p" + it.key }) { row(it) }
                item(key = "pinDivider") { Spacer(Modifier.height(8.dp)) }
            }
            items(builtIn, key = { "b" + it.key }) { row(it) }
            items(dirEntries, key = { "d" + it.key }) { row(it) }
            if (atTop) {
                item(key = "new") {
                    ListItem(
                        modifier = Modifier.clickable { ui.newPlaylistFor = emptyList() },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        leadingContent = { Icon(Icons.Rounded.Add, null, tint = MaterialTheme.colorScheme.primary) },
                        headlineContent = { Text("New playlist", color = MaterialTheme.colorScheme.primary) },
                    )
                }
                item(key = "newfolder") {
                    ListItem(
                        modifier = Modifier.clickable { newFolder = true },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        leadingContent = { Icon(Icons.Rounded.Folder, null, tint = MaterialTheme.colorScheme.primary) },
                        headlineContent = { Text("New folder", color = MaterialTheme.colorScheme.primary) },
                        supportingContent = { Text("Group playlists together. Hold a playlist to move it in.") },
                    )
                }
                item(key = "newsmart") {
                    ListItem(
                        modifier = Modifier.clickable { ui.smartEdit = SmartRule(System.currentTimeMillis(), "") },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        leadingContent = { Icon(Icons.Rounded.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary) },
                        headlineContent = { Text("New smart playlist", color = MaterialTheme.colorScheme.primary) },
                        supportingContent = { Text("Fills itself from rules you choose") },
                    )
                }
            }
            if (!atTop && mine.isEmpty()) {
                item(key = "emptyFolder") {
                    Text(
                        "This folder is empty. Hold a playlist and choose Folder to put it here.",
                        modifier = Modifier.padding(24.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            items(mine, key = { "m" + it.key }) { row(it) }
        }
    }

    if (newFolder) {
        NameDialog("New folder", "", "Create", { newFolder = false }) { name ->
            app.store.addPlaylistFolder(name)
            newFolder = false
        }
    }
    if (moveOpen) {
        AlertDialog(
            onDismissRequest = { moveOpen = false },
            title = { Text("Move to folder") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    TextButton(onClick = {
                        app.store.setPlaylistFolder(selected, "")
                        moveOpen = false
                        selected = emptySet()
                    }) { Text("No folder (top level)") }
                    folderNames.forEach { f ->
                        TextButton(onClick = {
                            app.store.setPlaylistFolder(selected, f)
                            moveOpen = false
                            selected = emptySet()
                        }) { Text(f) }
                    }
                    TextButton(onClick = { moveOpen = false; moveNew = true }) { Text("New folder…") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { moveOpen = false }) { Text("Cancel") } },
        )
    }
    if (moveNew) {
        NameDialog("New folder", "", "Move", { moveNew = false }) { name ->
            app.store.setPlaylistFolder(selected, name)
            moveNew = false
            selected = emptySet()
        }
    }
    if (mergeOpen) {
        NameDialog("Merge into a new playlist", "Merged", "Merge", { mergeOpen = false }) { name ->
            val joined = playlists.filter { it.id in selected }.flatMap { it.paths }.distinct()
            app.store.createPlaylist(name, joined)
            mergeOpen = false
            selected = emptySet()
            ui.say("Merged into ${name.trim()} · ${plural(joined.size, "song")}. The originals are kept.")
        }
    }
    folderToRemove?.let { f ->
        AlertDialog(
            onDismissRequest = { folderToRemove = null },
            title = { Text("Remove folder?") },
            text = { Text("$f is removed. The playlists inside move back to the top level.") },
            confirmButton = {
                TextButton(onClick = {
                    app.store.deletePlaylistFolder(f)
                    folderToRemove = null
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { folderToRemove = null }) { Text("Cancel") } },
        )
    }
    if (binOpen) {
        AlertDialog(
            onDismissRequest = { binOpen = false },
            title = { Text("Recycle bin") },
            text = {
                if (bin.isEmpty()) {
                    Text("Nothing here.")
                } else {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        bin.forEach { p ->
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(plural(p.paths.size, "song"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                TextButton(onClick = { app.store.restorePlaylists(setOf(p.id)) }) { Text("Restore") }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (bin.isNotEmpty()) TextButton(onClick = { app.store.emptyPlaylistBin() }) { Text("Empty bin") }
            },
            dismissButton = { TextButton(onClick = { binOpen = false }) { Text("Close") } },
        )
    }
}

/** Replaces the page header while playlists are selected. */
@Composable
private fun PlSelectionBar(count: Int, onClose: () -> Unit, onAll: () -> Unit, onMove: () -> Unit, onMerge: () -> Unit, onDelete: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Cancel selection") }
            Text("$count selected", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            TextButton(onClick = onAll) { Text("All") }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            TextButton(onClick = onMove) { Text("Folder") }
            if (count >= 2) TextButton(onClick = onMerge) { Text("Merge") }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onDelete) { Text("Delete", color = MaterialTheme.colorScheme.error) }
        }
    }
}

private data class PlEntry(
    val key: String,
    val title: String,
    val sub: String,
    val dest: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector?,
    val playlist: Playlist?,
    val rule: SmartRule?,
    val folder: String? = null,
)

/** A square tile with a cover on top and a title under it, used in grid view. */
@Composable
private fun GridCard(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    pinned: Boolean = false,
    selected: Boolean = false,
    onLongClick: (() -> Unit)? = null,
    cover: @Composable () -> Unit,
) {
    val src = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    Column(
        Modifier
            .pressScale(src)
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f) else Color.Transparent)
            .combinedClickable(
                interactionSource = src,
                indication = androidx.compose.foundation.LocalIndication.current,
                onClick = onClick,
                onLongClick = onLongClick,
            ),
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp))) {
            cover()
            if (pinned) {
                Icon(
                    Icons.Rounded.PushPin,
                    "Pinned",
                    Modifier.align(Alignment.TopEnd).padding(8.dp).size(22.dp)
                        .background(MaterialTheme.colorScheme.primary, CircleShape).padding(4.dp),
                    tint = MaterialTheme.colorScheme.onPrimary,
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
        Text(subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun PlaylistDetail(ui: UiController, id: String) {
    val app = ui.app
    val all by app.library.tracks.collectAsState()
    val playlists by app.store.select { it.playlists }
    val favorites by app.store.select { it.favorites }
    val plays by app.store.select { it.plays }
    val lastPlayed by app.store.select { it.lastPlayed }
    val ratings by app.store.select { it.ratings }

    val rules by app.store.select { it.smartRules }
    val rule = if (id.startsWith("c:")) rules.firstOrNull { "c:${it.id}" == id } else null
    val smart = smartLists.firstOrNull { it.id == id }
        ?: rule?.let { Smart(id, it.name.ifBlank { "Smart playlist" }, Icons.Rounded.AutoAwesome) }
    val playlist = if (smart == null) playlists.firstOrNull { it.id.toString() == id } else null

    val tracks: List<Track> = remember(id, all, playlists, favorites, plays, lastPlayed, ratings, rule) {
        if (rule != null) return@remember rule.pick(all, favorites, ratings, plays, lastPlayed)
        when (id) {
            "s:fav" -> all.filter { it.path in favorites }.sortedBy { it.title.lowercase() }
            "s:recent" -> all.filter { lastPlayed.containsKey(it.path) }
                .sortedByDescending { lastPlayed[it.path] ?: 0L }.take(100)
            "s:top" -> all.filter { (plays[it.path] ?: 0) > 0 }
                .sortedByDescending { plays[it.path] ?: 0 }.take(100)
            "s:added" -> all.sortedByDescending { it.dateAdded }.take(100)
            "s:rated" -> all.filter { (ratings[it.path] ?: 0) >= 4 }
                .sortedByDescending { ratings[it.path] ?: 0 }
            else -> playlist?.paths?.mapNotNull { app.library.find(it) } ?: emptyList()
        }
    }

    if (smart == null && playlist == null) {
        EmptyState("Playlist not found", "It may have been deleted.")
        return
    }

    androidx.compose.runtime.LaunchedEffect(id) {
        if (playlist != null) app.store.touchPlaylist(playlist.id)
    }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val m3uSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-mpegurl")) { uri ->
        if (uri != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(com.hwush.player.data.M3u.export(tracks).toByteArray()) }
                ui.say("Saved the playlist file")
            } catch (e: Exception) {
                ui.say("Could not save the file")
            }
        }
    }
    var noting by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var sorting by remember { mutableStateOf(false) }
    var merging by remember { mutableStateOf(false) }
    val title = smart?.title ?: playlist!!.name
    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && playlist != null) {
            val saved = app.art.saveCover(uri)
            if (saved != null) {
                app.store.setPlaylistCover(playlist.id, saved)
                app.coverRev.intValue++
            } else ui.say("Could not use that image")
        }
    }

    val headerContent: @Composable () -> Unit = {
        Column {

            ListHeader(
                title = title,
                subtitle = plural(tracks.size, "song"),
                ui = ui,
                tracks = tracks,
                back = true,
                cover = tracks.firstOrNull(),
                coverContent = if (playlist != null) ({
                    Box(Modifier.clickable { coverPicker.launch("image/*") }) {
                        PlaylistCover(playlist.cover, tracks.firstOrNull(), Modifier.size(64.dp), 64.dp, RoundedCornerShape(12.dp), mosaic = remember(playlist, all) { playlistMosaic(app, playlist) })
                    }
                }) else null,
                actions = {
                    val key = if (playlist != null) playlist.id.toString() else id
                    val isPinned by app.store.select(key) { key in it.pinned }
                    IconButton(onClick = { app.store.togglePin(key) }) {
                        Icon(
                            Icons.Rounded.PushPin,
                            if (isPinned) "Unpin" else "Pin to top",
                            tint = if (isPinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                menuExtra = if (playlist != null) ({ close ->
                    DropdownMenuItem(text = { Text("Change image") }, onClick = { close(); coverPicker.launch("image/*") })
                    if (playlist.cover != null) {
                        DropdownMenuItem(text = { Text("Remove image") }, onClick = { close(); app.store.setPlaylistCover(playlist.id, null) })
                    }
                    DropdownMenuItem(text = { Text(if (editing) "Done editing" else "Reorder or remove songs") }, onClick = { close(); editing = !editing })
                    DropdownMenuItem(text = { Text(if (playlist.note.isBlank()) "Add a note…" else "Edit note…") }, onClick = { close(); noting = true })
                    DropdownMenuItem(text = { Text("Duplicate playlist") }, onClick = {
                        close()
                        val nid = app.store.duplicatePlaylist(playlist.id)
                        if (nid != 0L) ui.say("Made ${playlist.name} copy")
                    })
                    DropdownMenuItem(text = { Text("Save as .m3u file") }, onClick = { close(); m3uSaver.launch(playlist.name + ".m3u") })
                    DropdownMenuItem(text = { Text("Sort songs…") }, onClick = { close(); sorting = true })
                    DropdownMenuItem(text = { Text("Remove duplicates") }, onClick = {
                        close()
                        val seen = HashSet<String>()
                        val kept = playlist.paths.filter { seen.add(it) }
                        val removed = playlist.paths.size - kept.size
                        if (removed > 0) app.store.setPlaylistPaths(playlist.id, kept)
                        ui.say(if (removed > 0) "Removed ${plural(removed, "duplicate")}" else "No duplicates")
                    })
                    DropdownMenuItem(text = { Text("Remove missing songs") }, onClick = {
                        close()
                        val kept = playlist.paths.filter { app.library.find(it) != null }
                        val removed = playlist.paths.size - kept.size
                        if (removed > 0) app.store.setPlaylistPaths(playlist.id, kept)
                        ui.say(if (removed > 0) "Removed ${plural(removed, "missing song")}" else "Every song is still on this phone")
                    })
                    DropdownMenuItem(text = { Text("Merge another into this…") }, onClick = { close(); merging = true })
                    DropdownMenuItem(text = { Text("Rename") }, onClick = { close(); renaming = true })
                    DropdownMenuItem(text = { Text("Delete playlist") }, onClick = { close(); deleting = true })
                }) else null,
            )
            if (playlist != null && playlist.note.isNotBlank()) {
                Text(
                    playlist.note,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp).clickable { noting = true },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
    if (editing && playlist != null) {
        PlaylistEditList(ui, playlist, onDone = { editing = false }, header = headerContent)
    } else {
        TrackList(ui, tracks, showMenu = true, header = headerContent)
    }

    if (sorting && playlist != null) {
        AlertDialog(
            onDismissRequest = { sorting = false },
            title = { Text("Sort songs by") },
            text = {
                Column {
                    listOf("Title", "Artist", "Album", "Newest added", "Most played", "Shortest first").forEachIndexed { k, label ->
                        TextButton(onClick = {
                            sorting = false
                            val list = playlist.paths.mapNotNull { app.library.find(it) }
                            val sorted = when (k) {
                                0 -> list.sortedBy { it.title.lowercase() }
                                1 -> list.sortedWith(compareBy({ it.artist.lowercase() }, { it.album.lowercase() }, { it.trackNo }))
                                2 -> list.sortedWith(compareBy({ it.album.lowercase() }, { it.trackNo }))
                                3 -> list.sortedByDescending { it.dateAdded }
                                4 -> list.sortedByDescending { plays[it.path] ?: 0 }
                                else -> list.sortedBy { it.durationMs }
                            }
                            app.store.setPlaylistPaths(playlist.id, sorted.map { it.path })
                            ui.say("Sorted by ${label.lowercase()}")
                        }) { Text(label) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { sorting = false }) { Text("Cancel") } },
        )
    }
    if (merging && playlist != null) {
        val others = playlists.filter { it.id != playlist.id }
        AlertDialog(
            onDismissRequest = { merging = false },
            title = { Text("Add songs from") },
            text = {
                if (others.isEmpty()) {
                    Text("You have no other playlists.")
                } else {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        others.forEach { o ->
                            TextButton(onClick = {
                                merging = false
                                app.store.mergePlaylists(playlist.id, o.id)
                                ui.say("Added songs from ${o.name}")
                            }) { Text("${o.name} · ${plural(o.paths.size, "song")}") }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { merging = false }) { Text("Cancel") } },
        )
    }

    if (noting && playlist != null) {
        var text by remember { mutableStateOf(playlist.note) }
        AlertDialog(
            onDismissRequest = { noting = false },
            title = { Text("Playlist note") },
            text = {
                androidx.compose.material3.OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Note") },
                    minLines = 2,
                    maxLines = 6,
                )
            },
            confirmButton = { TextButton(onClick = { app.store.setPlaylistNote(playlist.id, text); noting = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { noting = false }) { Text("Cancel") } },
        )
    }
    if (renaming && playlist != null) {
        NameDialog(
            title = "Rename playlist",
            initial = playlist.name,
            confirm = "Save",
            onDismiss = { renaming = false },
            onConfirm = { app.store.renamePlaylist(playlist.id, it); renaming = false },
        )
    }
    if (deleting && playlist != null) {
        AlertDialog(
            onDismissRequest = { deleting = false },
            title = { Text("Delete playlist?") },
            text = { Text("${playlist.name} moves to the recycle bin on the Playlists page. Your songs are not touched.") },
            confirmButton = {
                TextButton(onClick = {
                    deleting = false
                    val gone = playlist.id
                    val label = playlist.name
                    app.store.deletePlaylist(gone)
                    ui.back()
                    ui.sayAction("Deleted $label", "Undo") { app.store.restorePlaylists(setOf(gone)) }
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = false }) { Text("Cancel") } },
        )
    }
}
