@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Track

// ---------------------------------------------------------------- Songs

@Composable
fun SortMenu(ui: UiController, sortKey: Int, desc: Boolean) {
    var open by remember { mutableStateOf(false) }
    val labels = listOf("Title", "Artist", "Album", "Date added", "Length")
    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Rounded.Sort, "Sort") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            labels.forEachIndexed { i, label ->
                DropdownMenuItem(
                    text = { Text(label) },
                    leadingIcon = if (i == sortKey) ({ Icon(Icons.Rounded.Check, null) }) else null,
                    onClick = {
                        open = false
                        ui.app.store.update { it.copy(sortKey = i) }
                    },
                )
            }
            DropdownMenuItem(
                text = { Text(if (desc) "Descending" else "Ascending") },
                onClick = { open = false; ui.app.store.update { it.copy(sortDesc = !desc) } },
            )
        }
    }
}

@Composable
fun SongsScreen(ui: UiController) {
    val app = ui.app
    val all by app.library.tracks.collectAsState()
    val loaded by app.library.loaded.collectAsState()
    val sortKey by app.store.select { it.sortKey }
    val desc by app.store.select { it.sortDesc }
    val q = ui.query
    val list = remember(all, sortKey, desc, q) { sortTracks(filterTracks(all, q), sortKey, desc) }
    if (loaded && all.isEmpty()) {
        EmptyLibrary(ui)
    } else {
        TrackList(ui, list, header = {
            Column {
                ListHeader(
                    title = "Songs",
                    subtitle = plural(all.size, "song"),
                    ui = ui,
                    tracks = list,
                    showSettings = true,
                    actions = { SortMenu(ui, sortKey, desc) },
                )
                SearchField(q, { ui.query = it }, "Search songs, artists, albums")
            }
        })
    }
}

@Composable
fun EmptyLibrary(ui: UiController) {
    EmptyState(
        title = "No songs found",
        body = "Hwush looks for music on this device. Songs shorter than the minimum length in Settings are hidden.",
        action = {
            Button(onClick = { ui.app.library.refresh() }) { Text("Scan again") }
        },
    )
}

// ---------------------------------------------------------------- Albums

@Composable
fun AlbumsScreen(ui: UiController) {
    val albums by ui.app.library.albums.collectAsState()
    val q = ui.query.trim()
    val shown = remember(albums, q) {
        if (q.isEmpty()) albums
        else albums.filter { it.name.contains(q, true) || it.artist.contains(q, true) }
    }
    Column(Modifier.fillMaxSize()) {
        ListHeader("Albums", plural(albums.size, "album"), ui, emptyList(), showSettings = true)
        SearchField(ui.query, { ui.query = it }, "Search albums")
        LazyVerticalGrid(
            columns = GridCells.Adaptive(150.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            items(shown, key = { it.key }) { a ->
                Column(Modifier.clickable { ui.open(Dest(Kind.ALBUM, a.key)) }) {
                    Cover(a.tracks.first(), Modifier.fillMaxWidth().aspectRatio(1f), 160.dp, RoundedCornerShape(14.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(
                        a.name,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodyLarge,
                    )
                    Text(
                        "${a.artist} · ${a.tracks.size}",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
fun AlbumDetail(ui: UiController, key: String) {
    val albums by ui.app.library.albums.collectAsState()
    val album = albums.firstOrNull { it.key == key }
    if (album == null) {
        EmptyState("Album not found", "It may have been removed from your library.")
        return
    }
    TrackList(ui, album.tracks, header = {
        ListHeader(
            title = album.name,
            subtitle = "${album.artist} · ${plural(album.tracks.size, "song")}",
            ui = ui,
            tracks = album.tracks,
            back = true,
            cover = album.tracks.first(),
        )
    })
}

// ---------------------------------------------------------------- Artists

@Composable
fun ArtistsScreen(ui: UiController) {
    val artists by ui.app.library.artists.collectAsState()
    val q = ui.query.trim()
    val shown = remember(artists, q) { if (q.isEmpty()) artists else artists.filter { it.name.contains(q, true) } }
    Column(Modifier.fillMaxSize()) {
        ListHeader("Artists", plural(artists.size, "artist"), ui, emptyList(), showSettings = true)
        SearchField(ui.query, { ui.query = it }, "Search artists")
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(shown, key = { it.name }) { a ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { ui.open(Dest(Kind.ARTIST, a.name)) }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Cover(a.tracks.first(), Modifier.size(52.dp), 52.dp, CircleShape)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(a.name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyLarge)
                        Text(
                            plural(a.tracks.size, "song"),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ArtistDetail(ui: UiController, name: String) {
    val artists by ui.app.library.artists.collectAsState()
    val artist = artists.firstOrNull { it.name == name }
    if (artist == null) {
        EmptyState("Artist not found", "It may have been removed from your library.")
        return
    }
    val sorted = remember(artist) { sortTracks(artist.tracks, 2, false) }
    TrackList(ui, sorted, header = {
        ListHeader(
            title = artist.name,
            subtitle = plural(artist.tracks.size, "song"),
            ui = ui,
            tracks = sorted,
            back = true,
            cover = sorted.first(),
        )
    })
}

// ---------------------------------------------------------------- Folders

@Composable
fun FoldersScreen(ui: UiController) {
    val folders by ui.app.library.folders.collectAsState()
    val q = ui.query.trim()
    val shown = remember(folders, q) {
        if (q.isEmpty()) folders else folders.filter { it.path.contains(q, true) }
    }
    Column(Modifier.fillMaxSize()) {
        ListHeader("Folders", plural(folders.size, "folder"), ui, emptyList(), showSettings = true)
        SearchField(ui.query, { ui.query = it }, "Search folders")
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(shown, key = { it.path }) { f ->
                ListItem(
                    modifier = Modifier.clickable { ui.open(Dest(Kind.FOLDER, f.path)) },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    leadingContent = { Icon(Icons.Rounded.Folder, null, tint = MaterialTheme.colorScheme.primary) },
                    headlineContent = { Text(lastSegment(f.path).ifEmpty { "Unknown" }, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text("${plural(f.tracks.size, "song")} · ${f.path}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    trailingContent = {
                        IconButton(onClick = {
                            ui.app.store.update { it.copy(excludedFolders = it.excludedFolders + f.path) }
                            ui.say("Folder hidden. You can show it again in Settings.")
                        }) { Icon(Icons.Rounded.VisibilityOff, "Hide folder") }
                    },
                )
            }
        }
    }
}

@Composable
fun FolderDetail(ui: UiController, path: String) {
    val folders by ui.app.library.folders.collectAsState()
    val folder = folders.firstOrNull { it.path == path }
    if (folder == null) {
        EmptyState("Folder not found", "It may be empty or hidden.")
        return
    }
    val sorted = remember(folder) { sortTracks(folder.tracks, 0, false) }
    TrackList(ui, sorted, header = {
        ListHeader(
            title = lastSegment(folder.path),
            subtitle = "${plural(sorted.size, "song")} · ${folder.path}",
            ui = ui,
            tracks = sorted,
            back = true,
        )
    })
}

// ---------------------------------------------------------------- Playlists

private data class Smart(val id: String, val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val smartLists = listOf(
    Smart("s:fav", "Favorites", Icons.Rounded.Favorite),
    Smart("s:recent", "Recently played", Icons.Rounded.History),
    Smart("s:top", "Most played", Icons.Rounded.MusicNote),
    Smart("s:added", "Recently added", Icons.Rounded.Add),
)

@Composable
fun PlaylistsScreen(ui: UiController) {
    val app = ui.app
    val playlists by app.store.select { it.playlists }
    val all by app.library.tracks.collectAsState()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item {
            ListHeader("Playlists", plural(playlists.size, "playlist"), ui, emptyList(), showSettings = true)
        }
        items(smartLists, key = { it.id }) { s ->
            ListItem(
                modifier = Modifier.clickable { ui.open(Dest(Kind.PLAYLIST, s.id)) },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                leadingContent = { Icon(s.icon, null, tint = MaterialTheme.colorScheme.primary) },
                headlineContent = { Text(s.title) },
            )
        }
        item {
            ListItem(
                modifier = Modifier.clickable { ui.newPlaylistFor = emptyList() },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                leadingContent = { Icon(Icons.Rounded.Add, null, tint = MaterialTheme.colorScheme.primary) },
                headlineContent = { Text("New playlist", color = MaterialTheme.colorScheme.primary) },
            )
        }
        items(playlists, key = { it.id }) { p ->
            val first = p.paths.firstNotNullOfOrNull { app.library.find(it) }
            val count = remember(p, all) { p.paths.count { app.library.find(it) != null } }
            ListItem(
                modifier = Modifier.clickable { ui.open(Dest(Kind.PLAYLIST, p.id.toString())) },
                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                leadingContent = { PlaylistCover(p.cover, first, Modifier.size(48.dp), 48.dp) },
                headlineContent = { Text(p.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                supportingContent = { Text(plural(count, "song")) },
            )
        }
    }
}

@Composable
fun PlaylistDetail(ui: UiController, id: String) {
    val app = ui.app
    val all by app.library.tracks.collectAsState()
    val playlists by app.store.select { it.playlists }
    val favorites by app.store.select { it.favorites }
    val plays by app.store.select { it.plays }
    val lastPlayed by app.store.select { it.lastPlayed }

    val smart = smartLists.firstOrNull { it.id == id }
    val playlist = if (smart == null) playlists.firstOrNull { it.id.toString() == id } else null

    val tracks: List<Track> = remember(id, all, playlists, favorites, plays, lastPlayed) {
        when (id) {
            "s:fav" -> all.filter { it.path in favorites }.sortedBy { it.title.lowercase() }
            "s:recent" -> all.filter { lastPlayed.containsKey(it.path) }
                .sortedByDescending { lastPlayed[it.path] ?: 0L }.take(100)
            "s:top" -> all.filter { (plays[it.path] ?: 0) > 0 }
                .sortedByDescending { plays[it.path] ?: 0 }.take(100)
            "s:added" -> all.sortedByDescending { it.dateAdded }.take(100)
            else -> playlist?.paths?.mapNotNull { app.library.find(it) } ?: emptyList()
        }
    }

    if (smart == null && playlist == null) {
        EmptyState("Playlist not found", "It may have been deleted.")
        return
    }

    var editing by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    val title = smart?.title ?: playlist!!.name
    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && playlist != null) {
            val saved = app.art.saveCover(uri)
            if (saved != null) {
                app.store.setPlaylistCover(playlist.id, saved)
                app.coverRev.intValue++
            } else ui.say("Could not use that image")
        }
    }

    TrackList(
        ui,
        tracks,
        showMenu = !editing,
        header = {
            ListHeader(
                title = title,
                subtitle = plural(tracks.size, "song"),
                ui = ui,
                tracks = tracks,
                back = true,
                cover = tracks.firstOrNull(),
                coverContent = if (playlist != null) ({
                    Box(Modifier.clickable { coverPicker.launch("image/*") }) {
                        PlaylistCover(playlist.cover, tracks.firstOrNull(), Modifier.size(64.dp), 64.dp, RoundedCornerShape(12.dp))
                    }
                }) else null,
                menuExtra = if (playlist != null) ({ close ->
                    DropdownMenuItem(text = { Text("Change image") }, onClick = { close(); coverPicker.launch("image/*") })
                    if (playlist.cover != null) {
                        DropdownMenuItem(text = { Text("Remove image") }, onClick = { close(); app.store.setPlaylistCover(playlist.id, null) })
                    }
                    DropdownMenuItem(text = { Text(if (editing) "Done editing" else "Reorder or remove songs") }, onClick = { close(); editing = !editing })
                    DropdownMenuItem(text = { Text("Rename") }, onClick = { close(); renaming = true })
                    DropdownMenuItem(text = { Text("Delete playlist") }, onClick = { close(); deleting = true })
                }) else null,
            )
        },
        trailing = if (editing && playlist != null) ({ index, t ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { app.store.moveInPlaylist(playlist.id, index, index - 1) }, enabled = index > 0) {
                    Icon(Icons.Rounded.KeyboardArrowUp, "Move up")
                }
                IconButton(onClick = { app.store.moveInPlaylist(playlist.id, index, index + 1) }, enabled = index < tracks.lastIndex) {
                    Icon(Icons.Rounded.KeyboardArrowDown, "Move down")
                }
                IconButton(onClick = { app.store.removeFromPlaylist(playlist.id, t.path) }) {
                    Icon(Icons.Rounded.Close, "Remove")
                }
            }
        }) else null,
    )

    if (renaming && playlist != null) {
        NameDialog(
            title = "Rename playlist",
            initial = playlist.name,
            confirm = "Save",
            onDismiss = { renaming = false },
            onConfirm = { app.store.renamePlaylist(playlist.id, it); renaming = false },
        )
    }
    if (deleting && playlist != null) {
        AlertDialog(
            onDismissRequest = { deleting = false },
            title = { Text("Delete playlist?") },
            text = { Text("${playlist.name} will be deleted. Your songs are not touched.") },
            confirmButton = {
                TextButton(onClick = {
                    deleting = false
                    app.store.deletePlaylist(playlist.id)
                    ui.back()
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = false }) { Text("Cancel") } },
        )
    }
}
