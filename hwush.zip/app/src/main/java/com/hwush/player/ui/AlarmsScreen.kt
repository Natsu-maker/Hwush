@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.hwush.player.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Alarm
import com.hwush.player.player.Alarms
import kotlin.math.roundToInt

private val dayNames = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")

private fun daysText(days: Int): String = when (days) {
    0 -> "Once"
    127 -> "Every day"
    31 -> "Weekdays"
    96 -> "Weekends"
    else -> dayNames.filterIndexed { i, _ -> (days shr i) and 1 == 1 }.joinToString(" ")
}

private fun timeText(h: Int, m: Int): String = "%02d:%02d".format(h, m)

/** Wake up to your own music. The volume starts silent and rises over the time you choose. */
@Composable
fun AlarmsScreen(ui: UiController) {
    val app = ui.app
    val ctx = LocalContext.current
    val alarms by app.store.select { it.alarms }
    val playlists by app.store.select { it.playlists }
    var editing by remember { mutableStateOf<Alarm?>(null) }
    val sorted = remember(alarms) { alarms.sortedWith(compareBy({ it.hour }, { it.minute })) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            ListHeader(
                "Alarm clock",
                if (alarms.isEmpty()) "Nothing set" else plural(alarms.count { it.enabled }, "alarm") + " on",
                ui,
                emptyList(),
                back = ui.stack.size > 1,
                actions = {
                    IconButton(onClick = { editing = Alarm(System.currentTimeMillis(), 7, 0) }) { Icon(Icons.Rounded.Add, "New alarm") }
                },
            )
        }
        if (alarms.isEmpty()) {
            item {
                Column(Modifier.fillMaxWidth().padding(24.dp)) {
                    Text("Wake up to music", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Pick a time, choose a playlist or your favorites, and the music fades in slowly. " +
                            "It works with the screen off. If your phone stops background apps, set Hwush to unrestricted in battery settings.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(14.dp))
                    Button(onClick = { editing = Alarm(System.currentTimeMillis(), 7, 0) }) { Text("New alarm") }
                }
            }
        }
        items(sorted, key = { it.id }) { a ->
            Surface(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clickable { editing = a },
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
            ) {
                Row(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            timeText(a.hour, a.minute),
                            style = MaterialTheme.typography.displaySmall,
                            fontWeight = FontWeight.Light,
                            color = if (a.enabled) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Text(
                            daysText(a.days) + (if (a.label.isNotBlank()) " · " + a.label else ""),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        val what = when (a.sourceKind) {
                            1 -> playlists.firstOrNull { it.id.toString() == a.sourceArg }?.name ?: "A playlist"
                            2 -> app.library.find(a.sourceArg)?.title ?: "One song"
                            3 -> "Favorites"
                            else -> "Everything, shuffled"
                        }
                        Text(
                            what + if (a.rampSeconds > 0) " · rises over ${a.rampSeconds}s" else "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = a.enabled, onCheckedChange = {
                        val next = a.copy(enabled = it)
                        app.store.saveAlarm(next)
                        Alarms.schedule(ctx, next)
                        if (it) {
                            val at = Alarms.nextTime(next)
                            ui.say("Rings " + java.text.SimpleDateFormat("EEE HH:mm", java.util.Locale.getDefault()).format(java.util.Date(at)))
                        }
                    })
                }
            }
        }
    }

    editing?.let { a -> AlarmEditor(ui, a, onClose = { editing = null }) }
}

@Composable
private fun AlarmEditor(ui: UiController, start: Alarm, onClose: () -> Unit) {
    val app = ui.app
    val ctx = LocalContext.current
    val playlists by app.store.select { it.playlists }
    val exists = app.store.data.value.alarms.any { it.id == start.id }
    val time = rememberTimePickerState(start.hour, start.minute, true)
    var days by remember { mutableIntStateOf(start.days) }
    var kind by remember { mutableIntStateOf(start.sourceKind) }
    var arg by remember { mutableStateOf(start.sourceArg) }
    var ramp by remember { mutableFloatStateOf(start.rampSeconds.toFloat()) }
    var label by remember { mutableStateOf(start.label) }
    val playingPath = ui.app.player.currentPath()

    fun build(): Alarm = Alarm(start.id, time.hour, time.minute, days, true, kind, arg, ramp.roundToInt(), label.trim())

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (exists) "Edit alarm" else "New alarm") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                TimePicker(time)
                Text("Repeat", fontWeight = FontWeight.Medium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    dayNames.forEachIndexed { i, n ->
                        FilterChip(
                            selected = (days shr i) and 1 == 1,
                            onClick = { days = days xor (1 shl i) },
                            label = { Text(n) },
                        )
                    }
                }
                Text(
                    daysText(days) + if (days == 0) " (rings the next time this time comes)" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text("Wake me with", fontWeight = FontWeight.Medium)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = kind == 0, onClick = { kind = 0; arg = "" }, label = { Text("Everything") })
                    FilterChip(selected = kind == 3, onClick = { kind = 3; arg = "" }, label = { Text("Favorites") })
                    if (playingPath != null) {
                        FilterChip(
                            selected = kind == 2,
                            onClick = { kind = 2; arg = playingPath },
                            label = { Text(if (kind == 2) (app.library.find(arg)?.title ?: "This song") else "Song playing now") },
                        )
                    }
                    playlists.forEach { p ->
                        FilterChip(
                            selected = kind == 1 && arg == p.id.toString(),
                            onClick = { kind = 1; arg = p.id.toString() },
                            label = { Text(p.name) },
                        )
                    }
                }
                Text(
                    if (ramp.roundToInt() == 0) "Volume: starts at full" else "Volume rises over ${ramp.roundToInt()} seconds",
                    fontWeight = FontWeight.Medium,
                )
                Slider(value = ramp, onValueChange = { ramp = (it / 10f).roundToInt() * 10f }, valueRange = 0f..300f)
                androidx.compose.material3.OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    singleLine = true,
                    label = { Text("Label (optional)") },
                    modifier = Modifier.fillMaxWidth(),
                )
                TextButton(onClick = { app.player.startAlarm(build()); ui.say("Playing the alarm now") }) { Text("Try it now") }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val saved = build()
                app.store.saveAlarm(saved)
                Alarms.schedule(ctx, saved)
                val at = Alarms.nextTime(saved)
                ui.say("Rings " + java.text.SimpleDateFormat("EEE HH:mm", java.util.Locale.getDefault()).format(java.util.Date(at)))
                onClose()
            }) { Text("Save") }
        },
        dismissButton = {
            Row {
                if (exists) {
                    TextButton(onClick = {
                        Alarms.cancel(ctx, start.id)
                        app.store.deleteAlarm(start.id)
                        onClose()
                    }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                }
                TextButton(onClick = onClose) { Text("Cancel") }
            }
        },
    )
}
