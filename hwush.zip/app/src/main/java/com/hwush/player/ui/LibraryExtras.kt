package com.hwush.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.ArtistInfo
import com.hwush.player.data.TagOverride
import com.hwush.player.data.TempoMath
import com.hwush.player.data.Track

// ---------------------------------------------------------------- composers and album artists

@Composable
private fun TagScanBar(ui: UiController, all: List<Track>) {
    val a = ui.app.analysis
    val tags by a.tags.collectAsState()
    val prog by a.tagProgress.collectAsState()
    val left = all.count { !tags.containsKey(it.path) }
    val p = prog
    if (p != null) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
            Text("Reading tags: ${p.first} of ${p.second}", style = MaterialTheme.typography.bodySmall)
            LinearProgressIndicator(progress = { if (p.second == 0) 0f else p.first.toFloat() / p.second }, Modifier.fillMaxWidth().padding(top = 4.dp))
            TextButton(onClick = { a.stopTags() }) { Text("Stop") }
        }
    } else if (left > 0) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("$left songs not read yet. This is done once and takes a while for a big library.", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = { a.scanTags(all) }) { Text("Read tags") }
        }
    }
}

@Composable
private fun tagGroups(composer: Boolean): List<ArtistInfo> {
    val app = androidx.compose.ui.platform.LocalContext.current.hwushApp()
    val all by app.library.tracks.collectAsState()
    val tags by app.analysis.tags.collectAsState()
    return remember(all, tags, composer) {
        all.groupBy { t -> tags[t.path]?.let { if (composer) it.composer else it.albumArtist }.orEmpty() }
            .filterKeys { it.isNotBlank() }
            .map { ArtistInfo(it.key, it.value) }
            .sortedBy { it.name.lowercase() }
    }
}

private fun android.content.Context.hwushApp() = (applicationContext as com.hwush.player.HwushApp)

@Composable
fun ComposersScreen(ui: UiController) {
    val all by ui.app.library.tracks.collectAsState()
    val groups = tagGroups(true)
    Column(Modifier.fillMaxSize()) {
        TagScanBar(ui, all)
        Box(Modifier.weight(1f)) {
            GroupList(ui, "Composers", "composer", groups, Kind.COMPOSER, Icons.Rounded.Person, "Composers come from the tags inside your songs. Tap Read tags above to look for them.")
        }
    }
}

@Composable
fun ComposerDetail(ui: UiController, name: String) = GroupDetail(ui, name, tagGroups(true), "Composer not found")

@Composable
fun AlbumArtistsScreen(ui: UiController) {
    val all by ui.app.library.tracks.collectAsState()
    val groups = tagGroups(false)
    Column(Modifier.fillMaxSize()) {
        TagScanBar(ui, all)
        Box(Modifier.weight(1f)) {
            GroupList(ui, "Album artists", "album artist", groups, Kind.ALBUMARTIST, Icons.Rounded.Person, "Album artists come from the tags inside your songs. Tap Read tags above to look for them.")
        }
    }
}

@Composable
fun AlbumArtistDetail(ui: UiController, name: String) = GroupDetail(ui, name, tagGroups(false), "Album artist not found")

// ---------------------------------------------------------------- change tags of many songs at once

@Composable
fun BatchTagDialog(ui: UiController, tracks: List<Track>, onClose: () -> Unit) {
    var artist by remember { mutableStateOf("") }
    var album by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Edit ${tracks.size} songs") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Leave a box empty to keep each song's own value. Saved inside Hwush, the files are not changed.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(artist, { artist = it }, label = { Text("Artist") }, singleLine = true)
                OutlinedTextField(album, { album = it }, label = { Text("Album") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val st = ui.app.store
                for (t in tracks) {
                    val old = st.data.value.tags[t.path] ?: TagOverride()
                    st.setTag(
                        t.path,
                        old.copy(artist = artist.trim().ifBlank { old.artist }, album = album.trim().ifBlank { old.album }),
                    )
                }
                ui.selection.clear()
                ui.say("Updated ${tracks.size} songs")
                onClose()
            }, enabled = artist.isNotBlank() || album.isNotBlank()) { Text("Apply") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } },
    )
}

// ---------------------------------------------------------------- Auto DJ

@Composable
fun AutoDjScreen(ui: UiController) {
    val app = ui.app
    val all by app.library.tracks.collectAsState()
    val tempo by app.analysis.tempo.collectAsState()
    val prog by app.analysis.tempoProgress.collectAsState()
    val pui by app.player.ui.collectAsState()
    var lo by remember { mutableFloatStateOf(60f) }
    var hi by remember { mutableFloatStateOf(200f) }
    val analysed = remember(all, tempo) {
        all.mapNotNull { t -> tempo[t.path]?.takeIf { it.bpm > 0 }?.let { t to it } }
    }
    val shown = remember(analysed, lo, hi) {
        analysed.filter { it.second.bpm.toFloat() in lo..hi }.sortedBy { it.second.bpm }
    }
    val pending = all.count { !tempo.containsKey(it.path) && it.durationMs in 30_000L..(12 * 60_000L) }
    val p = prog

    fun start(mode: Int) {
        val cur = pui.path?.let { path -> analysed.firstOrNull { it.first.path == path }?.first }
        val first = cur ?: shown.firstOrNull()?.first
        if (first == null) {
            ui.say("Analyse your songs first")
            return
        }
        val list = TempoMath.set(first, analysed, mode)
        ui.play(list, 0)
        ui.say("Playing a set of ${list.size} songs")
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 16.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { ui.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") }
                Column {
                    Text("Auto DJ", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                    Text("Sets that flow by speed and mood", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                if (p != null) {
                    Text("Listening to your songs: ${p.first} of ${p.second}", style = MaterialTheme.typography.bodyMedium)
                    LinearProgressIndicator(progress = { if (p.second == 0) 0f else p.first.toFloat() / p.second }, Modifier.fillMaxWidth().padding(vertical = 6.dp))
                    OutlinedButton(onClick = { app.analysis.stopTempo() }) { Text("Stop") }
                } else {
                    Text(
                        "${analysed.size} songs analysed" + if (pending > 0) ", $pending to go" else "",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        "Hwush listens to each song once on your phone to find its speed and energy. It runs in the background while the app is open, and nothing leaves the phone.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 4.dp),
                    )
                    if (pending > 0) Button(onClick = { app.analysis.scanTempo(all) }) { Text(if (analysed.isEmpty()) "Analyse my songs" else "Analyse the rest") }
                }
            }
        }
        if (analysed.isNotEmpty()) {
            item {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    Text("Start a set from the song playing", style = MaterialTheme.typography.titleSmall)
                    Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { start(0) }) { Text("Blend") }
                        OutlinedButton(onClick = { start(1) }) { Text("Build up") }
                        OutlinedButton(onClick = { start(2) }) { Text("Wind down") }
                    }
                    Text("Tempo range: ${lo.toInt()} to ${hi.toInt()} BPM", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
                    Slider(value = lo, onValueChange = { lo = it.coerceAtMost(hi - 5f) }, valueRange = 60f..200f)
                    Slider(value = hi, onValueChange = { hi = it.coerceAtLeast(lo + 5f) }, valueRange = 60f..200f)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { if (shown.isNotEmpty()) ui.play(shown.map { it.first }, 0) }, enabled = shown.isNotEmpty()) { Text("Play ${shown.size}") }
                        OutlinedButton(onClick = { if (shown.isNotEmpty()) ui.shuffle(shown.map { it.first }) }, enabled = shown.isNotEmpty()) { Text("Shuffle") }
                        OutlinedButton(onClick = {
                            val n = "${lo.toInt()}-${hi.toInt()} BPM"
                            app.store.createPlaylist(n, shown.map { it.first.path })
                            ui.say("Saved as a playlist: \"$n\"")
                        }, enabled = shown.isNotEmpty()) { Text("Save") }
                    }
                }
            }
            items(shown.size, key = { shown[it].first.path }) { i ->
                val (t, info) = shown[i]
                ListItem(
                    modifier = Modifier.clickable { ui.play(shown.map { it.first }, i) },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    headlineContent = { Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text("${t.artist} · energy ${info.energy}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                    trailingContent = { Text("${info.bpm} BPM", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold) },
                )
            }
        }
    }
}
