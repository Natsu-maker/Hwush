package com.hwush.player.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class StoreData(
    val favorites: Set<String> = emptySet(),
    val playlists: List<Playlist> = emptyList(),
    val plays: Map<String, Int> = emptyMap(),
    val lastPlayed: Map<String, Long> = emptyMap(),
    val positions: Map<String, Long> = emptyMap(),
    val songFx: Map<String, SongFx> = emptyMap(),
    val tags: Map<String, TagOverride> = emptyMap(),
    val hidden: Set<String> = emptySet(),
    val excludedFolders: Set<String> = emptySet(),
    val queue: List<String> = emptyList(),
    val queueIndex: Int = 0,
    val queuePos: Long = 0L,
    // settings
    val themeMode: Int = 0, // 0 auto, 1 light, 2 dark
    val amoled: Boolean = false,
    val accentMode: Int = 0, // 0 wallpaper, 1 album art, 2 custom, 3 Hwush blue
    val accentColor: Int = 0xFF5B8CFF.toInt(),
    val minSeconds: Int = 30,
    val rememberMinutes: Int = 10,
    val fadeSeconds: Int = 0,
    val skipSilence: Boolean = false,
    val lyricsTree: String? = null,
    val songLyrics: Map<String, String> = emptyMap(),
    // sound
    val eqEnabled: Boolean = false,
    val eqLevels: List<Int> = emptyList(),
    val eqPreset: String = "Flat",
    val bass: Int = 0,
    val loudness: Int = 0,
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val linkSpeedPitch: Boolean = false,
    // list sorting
    val sortKey: Int = 0, // 0 title, 1 artist, 2 album, 3 date added, 4 duration
    val sortDesc: Boolean = false,
    // playback toggles
    val shuffle: Boolean = false,
    val repeat: Int = 0, // 0 off, 1 all, 2 one
)

private fun JSONObject.strings(k: String): List<String> {
    val a = optJSONArray(k) ?: return emptyList()
    return List(a.length()) { a.getString(it) }
}

private fun JSONObject.intMap(k: String): Map<String, Int> {
    val m = optJSONObject(k) ?: return emptyMap()
    val out = HashMap<String, Int>()
    for (key in m.keys()) out[key] = m.getInt(key)
    return out
}

private fun JSONObject.longMap(k: String): Map<String, Long> {
    val m = optJSONObject(k) ?: return emptyMap()
    val out = HashMap<String, Long>()
    for (key in m.keys()) out[key] = m.getLong(key)
    return out
}

private fun JSONObject.optStr(k: String): String? =
    if (has(k) && !isNull(k)) getString(k).ifEmpty { null } else null

object StoreJson {
    fun encode(d: StoreData): String {
        val o = JSONObject()
        o.put("v", 1)
        o.put("favorites", JSONArray(d.favorites.toList()))
        val pls = JSONArray()
        for (p in d.playlists) {
            val po = JSONObject().put("id", p.id).put("name", p.name).put("paths", JSONArray(p.paths))
            if (p.cover != null) po.put("cover", p.cover)
            pls.put(po)
        }
        o.put("playlists", pls)
        o.put("plays", JSONObject(d.plays))
        o.put("lastPlayed", JSONObject(d.lastPlayed))
        o.put("positions", JSONObject(d.positions))
        val fx = JSONObject()
        for ((k, v) in d.songFx) {
            val s = JSONObject().put("s", v.speed.toDouble()).put("p", v.pitch.toDouble())
            if (v.eq != null) s.put("eq", JSONArray(v.eq))
            if (v.bass != null) s.put("bass", v.bass)
            fx.put(k, s)
        }
        o.put("songFx", fx)
        val tg = JSONObject()
        for ((k, v) in d.tags) {
            val s = JSONObject()
            if (v.title != null) s.put("title", v.title)
            if (v.artist != null) s.put("artist", v.artist)
            if (v.album != null) s.put("album", v.album)
            if (v.cover != null) s.put("cover", v.cover)
            tg.put(k, s)
        }
        o.put("tags", tg)
        o.put("hidden", JSONArray(d.hidden.toList()))
        o.put("excludedFolders", JSONArray(d.excludedFolders.toList()))
        o.put("queue", JSONArray(d.queue))
        o.put("queueIndex", d.queueIndex)
        o.put("queuePos", d.queuePos)
        o.put("themeMode", d.themeMode)
        o.put("amoled", d.amoled)
        o.put("accentMode", d.accentMode)
        o.put("accentColor", d.accentColor)
        o.put("minSeconds", d.minSeconds)
        o.put("rememberMinutes", d.rememberMinutes)
        o.put("fadeSeconds", d.fadeSeconds)
        o.put("skipSilence", d.skipSilence)
        if (d.lyricsTree != null) o.put("lyricsTree", d.lyricsTree)
        o.put("songLyrics", JSONObject(d.songLyrics))
        o.put("eqEnabled", d.eqEnabled)
        o.put("eqLevels", JSONArray(d.eqLevels))
        o.put("eqPreset", d.eqPreset)
        o.put("bass", d.bass)
        o.put("loudness", d.loudness)
        o.put("speed", d.speed.toDouble())
        o.put("pitch", d.pitch.toDouble())
        o.put("linkSpeedPitch", d.linkSpeedPitch)
        o.put("sortKey", d.sortKey)
        o.put("sortDesc", d.sortDesc)
        o.put("shuffle", d.shuffle)
        o.put("repeat", d.repeat)
        return o.toString()
    }

    fun decode(text: String): StoreData {
        val o = JSONObject(text)
        val b = StoreData()
        val playlists = ArrayList<Playlist>()
        o.optJSONArray("playlists")?.let { a ->
            for (i in 0 until a.length()) {
                val p = a.getJSONObject(i)
                playlists.add(Playlist(p.getLong("id"), p.getString("name"), p.strings("paths"), p.optStr("cover")))
            }
        }
        val fx = HashMap<String, SongFx>()
        o.optJSONObject("songFx")?.let { m ->
            for (k in m.keys()) {
                val s = m.getJSONObject(k)
                val eq = s.optJSONArray("eq")?.let { a -> List(a.length()) { a.getInt(it) } }
                fx[k] = SongFx(
                    s.optDouble("s", 1.0).toFloat(),
                    s.optDouble("p", 1.0).toFloat(),
                    eq,
                    if (s.has("bass")) s.getInt("bass") else null,
                )
            }
        }
        val tags = HashMap<String, TagOverride>()
        o.optJSONObject("tags")?.let { m ->
            for (k in m.keys()) {
                val s = m.getJSONObject(k)
                tags[k] = TagOverride(s.optStr("title"), s.optStr("artist"), s.optStr("album"), s.optStr("cover"))
            }
        }
        val songLyrics = HashMap<String, String>()
        o.optJSONObject("songLyrics")?.let { m ->
            for (k in m.keys()) songLyrics[k] = m.getString(k)
        }
        val eqLevels = o.optJSONArray("eqLevels")?.let { a -> List(a.length()) { a.getInt(it) } } ?: emptyList()
        return StoreData(
            favorites = o.strings("favorites").toSet(),
            playlists = playlists,
            plays = o.intMap("plays"),
            lastPlayed = o.longMap("lastPlayed"),
            positions = o.longMap("positions"),
            songFx = fx,
            tags = tags,
            hidden = o.strings("hidden").toSet(),
            excludedFolders = o.strings("excludedFolders").toSet(),
            queue = o.strings("queue"),
            queueIndex = o.optInt("queueIndex", 0),
            queuePos = o.optLong("queuePos", 0L),
            themeMode = o.optInt("themeMode", b.themeMode),
            amoled = o.optBoolean("amoled", b.amoled),
            accentMode = o.optInt("accentMode", b.accentMode),
            accentColor = o.optInt("accentColor", b.accentColor),
            minSeconds = o.optInt("minSeconds", b.minSeconds),
            rememberMinutes = o.optInt("rememberMinutes", b.rememberMinutes),
            fadeSeconds = o.optInt("fadeSeconds", b.fadeSeconds),
            skipSilence = o.optBoolean("skipSilence", b.skipSilence),
            lyricsTree = o.optStr("lyricsTree"),
            songLyrics = songLyrics,
            eqEnabled = o.optBoolean("eqEnabled", b.eqEnabled),
            eqLevels = eqLevels,
            eqPreset = o.optString("eqPreset", b.eqPreset),
            bass = o.optInt("bass", b.bass),
            loudness = o.optInt("loudness", b.loudness),
            speed = o.optDouble("speed", b.speed.toDouble()).toFloat(),
            pitch = o.optDouble("pitch", b.pitch.toDouble()).toFloat(),
            linkSpeedPitch = o.optBoolean("linkSpeedPitch", b.linkSpeedPitch),
            sortKey = o.optInt("sortKey", b.sortKey),
            sortDesc = o.optBoolean("sortDesc", b.sortDesc),
            shuffle = o.optBoolean("shuffle", b.shuffle),
            repeat = o.optInt("repeat", b.repeat),
        )
    }
}

/** Everything Hwush remembers: playlists, favorites, play counts, per-song sound, edits and settings. */
class Store(ctx: Context) {
    private val file = File(ctx.filesDir, "hwush.json")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var saveJob: Job? = null

    val data = MutableStateFlow(load())

    private fun load(): StoreData = try {
        if (file.exists()) StoreJson.decode(file.readText()) else StoreData()
    } catch (e: Exception) {
        StoreData()
    }

    fun update(block: (StoreData) -> StoreData) {
        data.update(block)
        scheduleSave()
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(500)
            writeNow()
        }
    }

    @Synchronized
    private fun writeNow() {
        try {
            val tmp = File(file.path + ".tmp")
            tmp.writeText(StoreJson.encode(data.value))
            tmp.renameTo(file)
        } catch (_: Exception) {
        }
    }

    fun flush() {
        saveJob?.cancel()
        writeNow()
    }

    fun exportJson(): String = StoreJson.encode(data.value)

    fun importJson(text: String): Boolean = try {
        val d = StoreJson.decode(text)
        update { d }
        true
    } catch (e: Exception) {
        false
    }

    // ---- favorites ----
    fun toggleFavorite(path: String) = update {
        it.copy(favorites = if (path in it.favorites) it.favorites - path else it.favorites + path)
    }

    // ---- playlists ----
    fun createPlaylist(name: String, paths: List<String> = emptyList()): Long {
        val id = System.currentTimeMillis()
        update { it.copy(playlists = it.playlists + Playlist(id, name.trim().ifEmpty { "Playlist" }, paths.distinct())) }
        return id
    }

    fun renamePlaylist(id: Long, name: String) = update { d ->
        d.copy(playlists = d.playlists.map { if (it.id == id) it.copy(name = name.trim().ifEmpty { it.name }) else it })
    }

    fun setPlaylistCover(id: Long, file: String?) = update { d ->
        d.copy(playlists = d.playlists.map { if (it.id == id) it.copy(cover = file) else it })
    }

    fun setSongLyrics(path: String, uri: String?) = update { d ->
        d.copy(songLyrics = if (uri == null) d.songLyrics - path else d.songLyrics + (path to uri))
    }

    fun deletePlaylist(id: Long) = update { d -> d.copy(playlists = d.playlists.filter { it.id != id }) }

    fun addToPlaylist(id: Long, paths: List<String>) = update { d ->
        d.copy(playlists = d.playlists.map { p ->
            if (p.id == id) p.copy(paths = p.paths + paths.filter { it !in p.paths }) else p
        })
    }

    fun removeFromPlaylist(id: Long, path: String) = update { d ->
        d.copy(playlists = d.playlists.map { p -> if (p.id == id) p.copy(paths = p.paths - path) else p })
    }

    fun moveInPlaylist(id: Long, from: Int, to: Int) = update { d ->
        d.copy(playlists = d.playlists.map { p ->
            if (p.id != id || from !in p.paths.indices || to !in p.paths.indices) p
            else {
                val l = p.paths.toMutableList()
                l.add(to, l.removeAt(from))
                p.copy(paths = l)
            }
        })
    }

    // ---- edits ----
    fun setTag(path: String, o: TagOverride?) = update { d ->
        d.copy(tags = if (o == null) d.tags - path else d.tags + (path to o))
    }

    fun hide(path: String) = update { it.copy(hidden = it.hidden + path) }
    fun unhideAll() = update { it.copy(hidden = emptySet()) }
}
