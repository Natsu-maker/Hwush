package com.hwush.player.data

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

private const val HWUSH_ACCENT: Int = 0xFF5B8CFF.toInt()

data class StoreData(
    val favorites: Set<String> = emptySet(),
    val playlists: List<Playlist> = emptyList(),
    val plays: Map<String, Int> = emptyMap(),
    val lastPlayed: Map<String, Long> = emptyMap(),
    val positions: Map<String, Long> = emptyMap(),
    val songFx: Map<String, SongFx> = emptyMap(),
    val tags: Map<String, TagOverride> = emptyMap(),
    val hidden: Set<String> = emptySet(),
    val excludedFolders: Set<String> = emptySet(),
    val queue: List<String> = emptyList(),
    val queueIndex: Int = 0,
    val queuePos: Long = 0L,
    // settings
    val themeMode: Int = 0, // 0 auto, 1 light, 2 dark
    val amoled: Boolean = false,
    val accentMode: Int = 0, // 0 wallpaper, 1 album art, 2 custom, 3 Hwush blue
    val accentColor: Int = 0xFF5B8CFF.toInt(),
    val minSeconds: Int = 30,
    val rememberMinutes: Int = 10,
    val fadeSeconds: Int = 0,
    val skipSilence: Boolean = false,
    val lockPlayer: Boolean = true,
    val shakeSkip: Boolean = false,
    val btResume: Boolean = false,
    val visualizer: Boolean = false,
    val blurBackdrop: Boolean = true,
    val playlistGrid: Boolean = false,
    val pinned: Set<String> = emptySet(),
    val glassLevel: Float = 0.5f,
    val themeStyle: Int = 0, // 0 classic, 1 rich, 2 mono
    val coverStyle: Int = 0, // 0 square, 1 spinning disc
    val overlapFade: Boolean = false,
    val smartRules: List<SmartRule> = emptyList(),
    val homeOrder: List<String> = listOf("recent", "top", "added", "browse"),
    val homeHidden: Set<String> = emptySet(),
    val tabOrder: List<String> = listOf("HOME", "SONGS", "ALBUMS", "ARTISTS", "PLAYLISTS"),
    val tabHidden: Set<String> = emptySet(),
    val replayGain: Int = 0, // 0 off, 1 track, 2 album
    val bookmarks: Map<String, List<Long>> = emptyMap(),
    val lyricsTree: String? = null,
    val songLyrics: Map<String, String> = emptyMap(),
    val ratings: Map<String, Int> = emptyMap(),
    // sound
    val eqEnabled: Boolean = false,
    val eqLevels: List<Int> = emptyList(),
    val eqPreset: String = "Flat",
    val bass: Int = 0,
    val loudness: Int = 0,
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val linkSpeedPitch: Boolean = false,
    // list sorting
    val sortKey: Int = 0, // 0 title, 1 artist, 2 album, 3 date added, 4 duration
    val sortDesc: Boolean = false,
    // playback toggles
    val shuffle: Boolean = false,
    val repeat: Int = 0, // 0 off, 1 all, 2 one
    // automatic backup
    val autoBackup: Boolean = false,
    val backupTree: String? = null,
    val lastBackup: Long = 0L,
    // v1.9
    val bgStyle: Int = 0, // 0 Apple fluid, 1 lava lamp, 2 liquid marble
    val swipeStyle: Int = 0, // 0 streak and slide, 1 whole slab slides, 2 card stack
    val autoResetSpeed: Boolean = true,
    val endless: Boolean = false,
    val sleepFadeSeconds: Int = 8,
    val shakeExtend: Boolean = true,
    val firstOpen: Long = 0L,
    // v2.0
    val dailyGoalMin: Int = 0,
    val savedSearches: List<SavedSearch> = emptyList(),
    val books: Set<String> = emptySet(),
    val bookFolders: Set<String> = emptySet(),
    val bookSpeeds: Map<String, Float> = emptyMap(),
    val bookDone: Set<String> = emptySet(),
    val eqProfiles: List<EqProfile> = emptyList(),
    val deviceProfiles: Map<String, String> = emptyMap(),
    val waveSeek: Boolean = true,
    // v2.1
    val deletedPlaylists: List<Playlist> = emptyList(),
    val playlistSort: Int = 0, // 0 as made, 1 name, 2 most songs, 3 recently opened, 4 newest
    val playlistFolders: Set<String> = emptySet(),
    val balance: Int = 0, // -100 left .. 100 right
    val mono: Boolean = false,
    val spatial: Int = 0, // 0..1000
    val songTrim: Map<String, Int> = emptyMap(), // dB per song
    val lyricOffsets: Map<String, Long> = emptyMap(), // ms, positive shows lines later
    val alarms: List<Alarm> = emptyList(),
    val savedQueues: List<SavedQueue> = emptyList(),
    val fontStyle: Int = 0, // 0 Poppins, 1 system, 2 serif, 3 mono
    val fontScale: Int = 100, // percent
    val customThemes: List<SavedTheme> = emptyList(),
    // widget look
    val widgetBg: Int = 1, // 0 solid, 1 tinted by the cover, 2 blurred cover, 3 glass
    val widgetOpacity: Int = 92, // percent
    val widgetCorner: Int = 24, // dp
    val widgetAccent: Int = 0, // 0 cover colour, 1 app accent, 2 white
    val widgetDarkText: Boolean = false,
    val widgetCover: Int = 0, // 0 rounded, 1 circle, 2 square
    val widgetHeart: Boolean = true,
    val widgetProgress: Boolean = true,
)

private fun JSONObject.strings(k: String): List<String> {
    val a = optJSONArray(k) ?: return emptyList()
    return List(a.length()) { a.getString(it) }
}

private fun JSONObject.intMap(k: String): Map<String, Int> {
    val m = optJSONObject(k) ?: return emptyMap()
    val out = HashMap<String, Int>()
    for (key in m.keys()) out[key] = m.getInt(key)
    return out
}

private fun JSONObject.longMap(k: String): Map<String, Long> {
    val m = optJSONObject(k) ?: return emptyMap()
    val out = HashMap<String, Long>()
    for (key in m.keys()) out[key] = m.getLong(key)
    return out
}

private fun JSONObject.optStr(k: String): String? =
    if (has(k) && !isNull(k)) getString(k).ifEmpty { null } else null

object StoreJson {
    fun encode(d: StoreData): String {
        val o = JSONObject()
        o.put("v", 1)
        o.put("favorites", JSONArray(d.favorites.toList()))
        val pls = JSONArray()
        for (p in d.playlists) pls.put(playlistJson(p))
        o.put("playlists", pls)
        val bin = JSONArray()
        for (p in d.deletedPlaylists) bin.put(playlistJson(p))
        o.put("deletedPlaylists", bin)
        o.put("playlistSort", d.playlistSort)
        o.put("playlistFolders", JSONArray(d.playlistFolders.toList()))
        o.put("fontStyle", d.fontStyle)
        o.put("fontScale", d.fontScale)
        val th = JSONArray()
        for (x in d.customThemes) {
            th.put(
                JSONObject().put("name", x.name).put("accent", x.accent).put("style", x.style)
                    .put("amoled", x.amoled).put("mode", x.mode).put("font", x.font).put("scale", x.scale),
            )
        }
        o.put("customThemes", th)
        o.put("widgetBg", d.widgetBg)
        o.put("widgetOpacity", d.widgetOpacity)
        o.put("widgetCorner", d.widgetCorner)
        o.put("widgetAccent", d.widgetAccent)
        o.put("widgetDarkText", d.widgetDarkText)
        o.put("widgetCover", d.widgetCover)
        o.put("widgetHeart", d.widgetHeart)
        o.put("widgetProgress", d.widgetProgress)
        o.put("balance", d.balance)
        o.put("mono", d.mono)
        o.put("spatial", d.spatial)
        o.put("songTrim", JSONObject(d.songTrim))
        o.put("lyricOffsets", JSONObject(d.lyricOffsets))
        val al = JSONArray()
        for (x in d.alarms) {
            al.put(
                JSONObject().put("id", x.id).put("hour", x.hour).put("minute", x.minute).put("days", x.days)
                    .put("enabled", x.enabled).put("kind", x.sourceKind).put("arg", x.sourceArg)
                    .put("ramp", x.rampSeconds).put("label", x.label),
            )
        }
        o.put("alarms", al)
        val sq = JSONArray()
        for (x in d.savedQueues) sq.put(JSONObject().put("id", x.id).put("name", x.name).put("paths", JSONArray(x.paths)).put("index", x.index))
        o.put("savedQueues", sq)
        o.put("plays", JSONObject(d.plays))
        o.put("lastPlayed", JSONObject(d.lastPlayed))
        o.put("positions", JSONObject(d.positions))
        val fx = JSONObject()
        for ((k, v) in d.songFx) {
            val s = JSONObject().put("s", v.speed.toDouble()).put("p", v.pitch.toDouble())
            if (v.eq != null) s.put("eq", JSONArray(v.eq))
            if (v.bass != null) s.put("bass", v.bass)
            fx.put(k, s)
        }
        o.put("songFx", fx)
        val tg = JSONObject()
        for ((k, v) in d.tags) {
            val s = JSONObject()
            if (v.title != null) s.put("title", v.title)
            if (v.artist != null) s.put("artist", v.artist)
            if (v.album != null) s.put("album", v.album)
            if (v.cover != null) s.put("cover", v.cover)
            tg.put(k, s)
        }
        o.put("tags", tg)
        o.put("hidden", JSONArray(d.hidden.toList()))
        o.put("excludedFolders", JSONArray(d.excludedFolders.toList()))
        o.put("queue", JSONArray(d.queue))
        o.put("queueIndex", d.queueIndex)
        o.put("queuePos", d.queuePos)
        o.put("themeMode", d.themeMode)
        o.put("amoled", d.amoled)
        o.put("accentMode", d.accentMode)
        o.put("accentColor", d.accentColor)
        o.put("minSeconds", d.minSeconds)
        o.put("rememberMinutes", d.rememberMinutes)
        o.put("fadeSeconds", d.fadeSeconds)
        o.put("skipSilence", d.skipSilence)
        o.put("lockPlayer", d.lockPlayer)
        o.put("shakeSkip", d.shakeSkip)
        o.put("btResume", d.btResume)
        o.put("visualizer", d.visualizer)
        o.put("blurBackdrop", d.blurBackdrop)
        o.put("playlistGrid", d.playlistGrid)
        o.put("pinned", JSONArray(d.pinned.toList()))
        o.put("glassLevel", d.glassLevel.toDouble())
        o.put("themeStyle", d.themeStyle)
        o.put("coverStyle", d.coverStyle)
        o.put("overlapFade", d.overlapFade)
        val sr = JSONArray()
        for (r in d.smartRules) {
            sr.put(
                JSONObject().put("id", r.id).put("name", r.name).put("minRating", r.minRating).put("minPlays", r.minPlays)
                    .put("genre", r.genre).put("artist", r.artist).put("fav", r.favoritesOnly)
                    .put("added", r.addedDays).put("played", r.playedDays).put("notPlayed", r.notPlayedDays),
            )
        }
        o.put("smartRules", sr)
        o.put("homeOrder", JSONArray(d.homeOrder))
        o.put("homeHidden", JSONArray(d.homeHidden.toList()))
        o.put("tabOrder", JSONArray(d.tabOrder))
        o.put("tabHidden", JSONArray(d.tabHidden.toList()))
        o.put("replayGain", d.replayGain)
        val bm = JSONObject()
        for ((k, v) in d.bookmarks) bm.put(k, JSONArray(v))
        o.put("bookmarks", bm)
        if (d.lyricsTree != null) o.put("lyricsTree", d.lyricsTree)
        o.put("songLyrics", JSONObject(d.songLyrics))
        o.put("ratings", JSONObject(d.ratings))
        o.put("eqEnabled", d.eqEnabled)
        o.put("eqLevels", JSONArray(d.eqLevels))
        o.put("eqPreset", d.eqPreset)
        o.put("bass", d.bass)
        o.put("loudness", d.loudness)
        o.put("speed", d.speed.toDouble())
        o.put("pitch", d.pitch.toDouble())
        o.put("linkSpeedPitch", d.linkSpeedPitch)
        o.put("sortKey", d.sortKey)
        o.put("sortDesc", d.sortDesc)
        o.put("shuffle", d.shuffle)
        o.put("repeat", d.repeat)
        o.put("autoBackup", d.autoBackup)
        if (d.backupTree != null) o.put("backupTree", d.backupTree)
        o.put("lastBackup", d.lastBackup)
        o.put("bgStyle", d.bgStyle)
        o.put("swipeStyle", d.swipeStyle)
        o.put("autoResetSpeed", d.autoResetSpeed)
        o.put("endless", d.endless)
        o.put("sleepFadeSeconds", d.sleepFadeSeconds)
        o.put("shakeExtend", d.shakeExtend)
        o.put("firstOpen", d.firstOpen)
        o.put("dailyGoalMin", d.dailyGoalMin)
        o.put("waveSeek", d.waveSeek)
        val ss = JSONArray()
        for (x in d.savedSearches) ss.put(JSONObject().put("id", x.id).put("name", x.name).put("spec", x.spec))
        o.put("savedSearches", ss)
        o.put("books", JSONArray(d.books.toList()))
        o.put("bookFolders", JSONArray(d.bookFolders.toList()))
        o.put("bookDone", JSONArray(d.bookDone.toList()))
        val bs = JSONObject()
        for ((k, v) in d.bookSpeeds) bs.put(k, v.toDouble())
        o.put("bookSpeeds", bs)
        val ep = JSONArray()
        for (x in d.eqProfiles) {
            ep.put(JSONObject().put("name", x.name).put("levels", JSONArray(x.levels)).put("bass", x.bass).put("loudness", x.loudness))
        }
        o.put("eqProfiles", ep)
        o.put("deviceProfiles", JSONObject(d.deviceProfiles))
        return o.toString()
    }

    private fun playlistJson(p: Playlist): JSONObject {
        val po = JSONObject().put("id", p.id).put("name", p.name).put("paths", JSONArray(p.paths))
        if (p.cover != null) po.put("cover", p.cover)
        if (p.folder.isNotEmpty()) po.put("folder", p.folder)
        if (p.note.isNotEmpty()) po.put("note", p.note)
        if (p.opened != 0L) po.put("opened", p.opened)
        if (p.deletedAt != 0L) po.put("deletedAt", p.deletedAt)
        return po
    }

    private fun playlistFrom(p: JSONObject): Playlist = Playlist(
        p.getLong("id"),
        p.getString("name"),
        p.strings("paths"),
        p.optStr("cover"),
        p.optString("folder", ""),
        p.optString("note", ""),
        p.optLong("opened", 0L),
        p.optLong("deletedAt", 0L),
    )

    fun decode(text: String): StoreData {
        val o = JSONObject(text)
        val b = StoreData()
        val playlists = ArrayList<Playlist>()
        o.optJSONArray("playlists")?.let { a ->
            for (i in 0 until a.length()) {
                playlists.add(playlistFrom(a.getJSONObject(i)))
            }
        }
        val binned = ArrayList<Playlist>()
        o.optJSONArray("deletedPlaylists")?.let { a ->
            for (i in 0 until a.length()) binned.add(playlistFrom(a.getJSONObject(i)))
        }
        val fx = HashMap<String, SongFx>()
        o.optJSONObject("songFx")?.let { m ->
            for (k in m.keys()) {
                val s = m.getJSONObject(k)
                val eq = s.optJSONArray("eq")?.let { a -> List(a.length()) { a.getInt(it) } }
                fx[k] = SongFx(
                    s.optDouble("s", 1.0).toFloat(),
                    s.optDouble("p", 1.0).toFloat(),
                    eq,
                    if (s.has("bass")) s.getInt("bass") else null,
                )
            }
        }
        val tags = HashMap<String, TagOverride>()
        o.optJSONObject("tags")?.let { m ->
            for (k in m.keys()) {
                val s = m.getJSONObject(k)
                tags[k] = TagOverride(s.optStr("title"), s.optStr("artist"), s.optStr("album"), s.optStr("cover"))
            }
        }
        val songLyrics = HashMap<String, String>()
        o.optJSONObject("songLyrics")?.let { m ->
            for (k in m.keys()) songLyrics[k] = m.getString(k)
        }
        val bookmarks = HashMap<String, List<Long>>()
        o.optJSONObject("bookmarks")?.let { m ->
            for (k in m.keys()) {
                val a = m.getJSONArray(k)
                bookmarks[k] = List(a.length()) { a.getLong(it) }
            }
        }
        val smartRules = ArrayList<SmartRule>()
        o.optJSONArray("smartRules")?.let { a ->
            for (i in 0 until a.length()) {
                val r = a.getJSONObject(i)
                smartRules.add(
                    SmartRule(
                        r.getLong("id"), r.optString("name", "Smart playlist"), r.optInt("minRating"), r.optInt("minPlays"),
                        r.optString("genre"), r.optString("artist"), r.optBoolean("fav"),
                        r.optInt("added"), r.optInt("played"), r.optInt("notPlayed"),
                    ),
                )
            }
        }
        val eqLevels = o.optJSONArray("eqLevels")?.let { a -> List(a.length()) { a.getInt(it) } } ?: emptyList()
        return StoreData(
            favorites = o.strings("favorites").toSet(),
            playlists = playlists,
            deletedPlaylists = binned,
            playlistSort = o.optInt("playlistSort", 0),
            playlistFolders = o.strings("playlistFolders").toSet(),
            fontStyle = o.optInt("fontStyle", 0),
            fontScale = o.optInt("fontScale", 100),
            customThemes = o.optJSONArray("customThemes")?.let { a ->
                List(a.length()) { i ->
                    val x = a.getJSONObject(i)
                    SavedTheme(
                        x.optString("name", "Theme"), x.optInt("accent", HWUSH_ACCENT), x.optInt("style", 0),
                        x.optBoolean("amoled", false), x.optInt("mode", 0), x.optInt("font", 0), x.optInt("scale", 100),
                    )
                }
            } ?: emptyList(),
            widgetBg = o.optInt("widgetBg", b.widgetBg),
            widgetOpacity = o.optInt("widgetOpacity", b.widgetOpacity),
            widgetCorner = o.optInt("widgetCorner", b.widgetCorner),
            widgetAccent = o.optInt("widgetAccent", b.widgetAccent),
            widgetDarkText = o.optBoolean("widgetDarkText", b.widgetDarkText),
            widgetCover = o.optInt("widgetCover", b.widgetCover),
            widgetHeart = o.optBoolean("widgetHeart", b.widgetHeart),
            widgetProgress = o.optBoolean("widgetProgress", b.widgetProgress),
            balance = o.optInt("balance", 0),
            mono = o.optBoolean("mono", false),
            spatial = o.optInt("spatial", 0),
            songTrim = o.intMap("songTrim"),
            lyricOffsets = o.longMap("lyricOffsets"),
            alarms = o.optJSONArray("alarms")?.let { a ->
                List(a.length()) { i ->
                    val x = a.getJSONObject(i)
                    Alarm(
                        x.getLong("id"), x.optInt("hour", 7), x.optInt("minute", 0), x.optInt("days", 0),
                        x.optBoolean("enabled", true), x.optInt("kind", 0), x.optString("arg", ""),
                        x.optInt("ramp", 60), x.optString("label", ""),
                    )
                }
            } ?: emptyList(),
            savedQueues = o.optJSONArray("savedQueues")?.let { a ->
                List(a.length()) { i ->
                    val x = a.getJSONObject(i)
                    SavedQueue(x.getLong("id"), x.optString("name", "Queue"), x.strings("paths"), x.optInt("index", 0))
                }
            } ?: emptyList(),
            plays = o.intMap("plays"),
            lastPlayed = o.longMap("lastPlayed"),
            positions = o.longMap("positions"),
            songFx = fx,
            tags = tags,
            hidden = o.strings("hidden").toSet(),
            excludedFolders = o.strings("excludedFolders").toSet(),
            queue = o.strings("queue"),
            queueIndex = o.optInt("queueIndex", 0),
            queuePos = o.optLong("queuePos", 0L),
            themeMode = o.optInt("themeMode", b.themeMode),
            amoled = o.optBoolean("amoled", b.amoled),
            accentMode = o.optInt("accentMode", b.accentMode),
            accentColor = o.optInt("accentColor", b.accentColor),
            minSeconds = o.optInt("minSeconds", b.minSeconds),
            rememberMinutes = o.optInt("rememberMinutes", b.rememberMinutes),
            fadeSeconds = o.optInt("fadeSeconds", b.fadeSeconds),
            skipSilence = o.optBoolean("skipSilence", b.skipSilence),
            lockPlayer = o.optBoolean("lockPlayer", b.lockPlayer),
            shakeSkip = o.optBoolean("shakeSkip", b.shakeSkip),
            btResume = o.optBoolean("btResume", b.btResume),
            visualizer = o.optBoolean("visualizer", b.visualizer),
            blurBackdrop = o.optBoolean("blurBackdrop", b.blurBackdrop),
            playlistGrid = o.optBoolean("playlistGrid", b.playlistGrid),
            pinned = o.strings("pinned").toSet(),
            homeOrder = o.strings("homeOrder").ifEmpty { b.homeOrder },
            homeHidden = o.strings("homeHidden").toSet(),
            tabOrder = o.strings("tabOrder").ifEmpty { b.tabOrder },
            tabHidden = o.strings("tabHidden").toSet(),
            themeStyle = o.optInt("themeStyle", b.themeStyle),
            coverStyle = o.optInt("coverStyle", b.coverStyle),
            overlapFade = o.optBoolean("overlapFade", b.overlapFade),
            smartRules = smartRules,
            glassLevel = o.optDouble("glassLevel", b.glassLevel.toDouble()).toFloat().coerceIn(0f, 1f),
            replayGain = o.optInt("replayGain", b.replayGain),
            bookmarks = bookmarks,
            lyricsTree = o.optStr("lyricsTree"),
            songLyrics = songLyrics,
            ratings = o.intMap("ratings"),
            eqEnabled = o.optBoolean("eqEnabled", b.eqEnabled),
            eqLevels = eqLevels,
            eqPreset = o.optString("eqPreset", b.eqPreset),
            bass = o.optInt("bass", b.bass),
            loudness = o.optInt("loudness", b.loudness),
            speed = o.optDouble("speed", b.speed.toDouble()).toFloat(),
            pitch = o.optDouble("pitch", b.pitch.toDouble()).toFloat(),
            linkSpeedPitch = o.optBoolean("linkSpeedPitch", b.linkSpeedPitch),
            sortKey = o.optInt("sortKey", b.sortKey),
            sortDesc = o.optBoolean("sortDesc", b.sortDesc),
            shuffle = o.optBoolean("shuffle", b.shuffle),
            repeat = o.optInt("repeat", b.repeat),
            autoBackup = o.optBoolean("autoBackup", b.autoBackup),
            backupTree = o.optStr("backupTree"),
            lastBackup = o.optLong("lastBackup", 0L),
            bgStyle = o.optInt("bgStyle", b.bgStyle),
            swipeStyle = o.optInt("swipeStyle", b.swipeStyle),
            autoResetSpeed = o.optBoolean("autoResetSpeed", b.autoResetSpeed),
            endless = o.optBoolean("endless", b.endless),
            sleepFadeSeconds = o.optInt("sleepFadeSeconds", b.sleepFadeSeconds),
            shakeExtend = o.optBoolean("shakeExtend", b.shakeExtend),
            firstOpen = o.optLong("firstOpen", 0L),
            dailyGoalMin = o.optInt("dailyGoalMin", 0),
            waveSeek = o.optBoolean("waveSeek", b.waveSeek),
            savedSearches = o.optJSONArray("savedSearches")?.let { a ->
                List(a.length()) { i ->
                    val x = a.getJSONObject(i)
                    SavedSearch(x.getLong("id"), x.getString("name"), x.getString("spec"))
                }
            } ?: emptyList(),
            books = o.strings("books").toSet(),
            bookFolders = o.strings("bookFolders").toSet(),
            bookDone = o.strings("bookDone").toSet(),
            bookSpeeds = o.optJSONObject("bookSpeeds")?.let { m ->
                val out = HashMap<String, Float>()
                for (key in m.keys()) out[key] = m.getDouble(key).toFloat()
                out
            } ?: emptyMap(),
            eqProfiles = o.optJSONArray("eqProfiles")?.let { a ->
                List(a.length()) { i ->
                    val x = a.getJSONObject(i)
                    val lv = x.optJSONArray("levels")
                    EqProfile(
                        x.getString("name"),
                        if (lv == null) emptyList() else List(lv.length()) { k -> lv.getInt(k) },
                        x.optInt("bass", 0),
                        x.optInt("loudness", 0),
                    )
                }
            } ?: emptyList(),
            deviceProfiles = o.optJSONObject("deviceProfiles")?.let { m ->
                val out = HashMap<String, String>()
                for (key in m.keys()) out[key] = m.getString(key)
                out
            } ?: emptyMap(),
        )
    }
}

/** Everything Hwush remembers: playlists, favorites, play counts, per-song sound, edits and settings. */
class Store(ctx: Context) {
    private val file = File(ctx.filesDir, "hwush.json")
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var saveJob: Job? = null

    val data = MutableStateFlow(load())

    private fun load(): StoreData = try {
        if (file.exists()) StoreJson.decode(file.readText()) else StoreData()
    } catch (e: Exception) {
        StoreData()
    }

    fun update(block: (StoreData) -> StoreData) {
        data.update(block)
        scheduleSave()
    }

    private fun scheduleSave() {
        saveJob?.cancel()
        saveJob = scope.launch {
            delay(500)
            writeNow()
        }
    }

    @Synchronized
    private fun writeNow() {
        try {
            val tmp = File(file.path + ".tmp")
            tmp.writeText(StoreJson.encode(data.value))
            tmp.renameTo(file)
        } catch (_: Exception) {
        }
    }

    fun flush() {
        saveJob?.cancel()
        writeNow()
    }

    fun exportJson(): String = StoreJson.encode(data.value)

    fun importJson(text: String): Boolean = try {
        val d = StoreJson.decode(text)
        update { d }
        true
    } catch (e: Exception) {
        false
    }

    // ---- favorites ----
    fun toggleFavorite(path: String) = update {
        it.copy(favorites = if (path in it.favorites) it.favorites - path else it.favorites + path)
    }

    // ---- playlists ----
    fun createPlaylist(name: String, paths: List<String> = emptyList()): Long {
        val id = System.currentTimeMillis()
        update { it.copy(playlists = it.playlists + Playlist(id, name.trim().ifEmpty { "Playlist" }, paths.distinct())) }
        return id
    }

    fun renamePlaylist(id: Long, name: String) = update { d ->
        d.copy(playlists = d.playlists.map { if (it.id == id) it.copy(name = name.trim().ifEmpty { it.name }) else it })
    }

    fun setPlaylistCover(id: Long, file: String?) = update { d ->
        d.copy(playlists = d.playlists.map { if (it.id == id) it.copy(cover = file) else it })
    }

    fun addBookmark(path: String, ms: Long) = update { d ->
        val list = ((d.bookmarks[path] ?: emptyList()) + ms).distinct().sorted()
        d.copy(bookmarks = d.bookmarks + (path to list))
    }

    fun removeBookmark(path: String, ms: Long) = update { d ->
        val list = (d.bookmarks[path] ?: emptyList()) - ms
        d.copy(bookmarks = if (list.isEmpty()) d.bookmarks - path else d.bookmarks + (path to list))
    }

    fun setRating(path: String, stars: Int) = update { d ->
        d.copy(ratings = if (stars <= 0) d.ratings - path else d.ratings + (path to stars.coerceAtMost(5)))
    }

    fun setSongLyrics(path: String, uri: String?) = update { d ->
        d.copy(songLyrics = if (uri == null) d.songLyrics - path else d.songLyrics + (path to uri))
    }

    fun togglePin(key: String) = update { d -> d.copy(pinned = if (key in d.pinned) d.pinned - key else d.pinned + key) }

    fun saveSmartRule(r: SmartRule) = update { d ->
        val exists = d.smartRules.any { it.id == r.id }
        d.copy(smartRules = if (exists) d.smartRules.map { if (it.id == r.id) r else it } else d.smartRules + r)
    }

    fun deleteSmartRule(id: Long) = update { d -> d.copy(smartRules = d.smartRules.filter { it.id != id }) }

    /** Moves playlists to the recycle bin so they can be brought back. */
    fun deletePlaylist(id: Long) = deletePlaylists(setOf(id))

    fun deletePlaylists(ids: Set<Long>) = update { d ->
        val now = System.currentTimeMillis()
        val gone = d.playlists.filter { it.id in ids }.map { it.copy(deletedAt = now) }
        d.copy(
            playlists = d.playlists.filter { it.id !in ids },
            deletedPlaylists = (gone + d.deletedPlaylists).take(50),
        )
    }

    fun restorePlaylists(ids: Set<Long>) = update { d ->
        val back = d.deletedPlaylists.filter { it.id in ids }.map { it.copy(deletedAt = 0L) }
        d.copy(
            playlists = d.playlists + back.filter { b -> d.playlists.none { it.id == b.id } },
            deletedPlaylists = d.deletedPlaylists.filter { it.id !in ids },
        )
    }

    fun emptyPlaylistBin() = update { d -> d.copy(deletedPlaylists = emptyList()) }

    fun duplicatePlaylist(id: Long): Long {
        val src = data.value.playlists.firstOrNull { it.id == id } ?: return 0L
        var nid = System.currentTimeMillis()
        while (data.value.playlists.any { it.id == nid }) nid++
        update { d -> d.copy(playlists = d.playlists + src.copy(id = nid, name = src.name + " copy", opened = 0L)) }
        return nid
    }

    fun touchPlaylist(id: Long) = update { d ->
        d.copy(playlists = d.playlists.map { if (it.id == id) it.copy(opened = System.currentTimeMillis()) else it })
    }

    fun setPlaylistNote(id: Long, note: String) = update { d ->
        d.copy(playlists = d.playlists.map { if (it.id == id) it.copy(note = note.trim()) else it })
    }

    fun setPlaylistFolder(ids: Set<Long>, folder: String) = update { d ->
        val f = folder.trim()
        d.copy(
            playlists = d.playlists.map { if (it.id in ids) it.copy(folder = f) else it },
            playlistFolders = if (f.isEmpty()) d.playlistFolders else d.playlistFolders + f,
        )
    }

    fun addPlaylistFolder(name: String) = update { d ->
        val f = name.trim()
        if (f.isEmpty()) d else d.copy(playlistFolders = d.playlistFolders + f)
    }

    fun deletePlaylistFolder(name: String) = update { d ->
        d.copy(
            playlists = d.playlists.map { if (it.folder == name) it.copy(folder = "") else it },
            playlistFolders = d.playlistFolders - name,
        )
    }

    // ---- sound extras, lyric timing, alarms, saved queues ----
    fun saveTheme(t: SavedTheme) = update { d ->
        d.copy(customThemes = d.customThemes.filter { it.name != t.name } + t)
    }

    fun deleteTheme(name: String) = update { d -> d.copy(customThemes = d.customThemes.filter { it.name != name }) }

    fun setBalance(v: Int) = update { it.copy(balance = v.coerceIn(-100, 100)) }
    fun setMono(v: Boolean) = update { it.copy(mono = v) }
    fun setSpatial(v: Int) = update { it.copy(spatial = v.coerceIn(0, 1000)) }

    fun setSongTrim(path: String, db: Int) = update { d ->
        d.copy(songTrim = if (db == 0) d.songTrim - path else d.songTrim + (path to db.coerceIn(-12, 6)))
    }

    fun setLyricOffset(path: String, ms: Long) = update { d ->
        d.copy(lyricOffsets = if (ms == 0L) d.lyricOffsets - path else d.lyricOffsets + (path to ms.coerceIn(-30_000L, 30_000L)))
    }

    fun saveAlarm(a: Alarm) = update { d ->
        d.copy(alarms = if (d.alarms.any { it.id == a.id }) d.alarms.map { if (it.id == a.id) a else it } else d.alarms + a)
    }

    fun deleteAlarm(id: Long) = update { d -> d.copy(alarms = d.alarms.filter { it.id != id }) }

    fun saveQueue(name: String, paths: List<String>, index: Int) = update { d ->
        d.copy(savedQueues = (listOf(SavedQueue(System.currentTimeMillis(), name.trim().ifEmpty { "Queue" }, paths, index)) + d.savedQueues).take(30))
    }

    fun deleteSavedQueue(id: Long) = update { d -> d.copy(savedQueues = d.savedQueues.filter { it.id != id }) }

    fun mergeMany(into: Long, from: Set<Long>) {
        for (f in from) if (f != into) mergePlaylists(into, f)
    }

    fun addToPlaylist(id: Long, paths: List<String>) = update { d ->
        d.copy(playlists = d.playlists.map { p ->
            if (p.id == id) p.copy(paths = p.paths + paths.filter { it !in p.paths }) else p
        })
    }

    fun setPlaylistPaths(id: Long, paths: List<String>) = update { d ->
        d.copy(playlists = d.playlists.map { if (it.id == id) it.copy(paths = paths) else it })
    }

    /** Puts the songs of [from] at the end of [into], skipping ones already there. */
    fun mergePlaylists(into: Long, from: Long) = update { d ->
        val src = d.playlists.firstOrNull { it.id == from } ?: return@update d
        d.copy(playlists = d.playlists.map {
            if (it.id == into) it.copy(paths = it.paths + src.paths.filter { p -> p !in it.paths }) else it
        })
    }

    fun removeFromPlaylist(id: Long, path: String) = update { d ->
        d.copy(playlists = d.playlists.map { p -> if (p.id == id) p.copy(paths = p.paths - path) else p })
    }

    fun moveInPlaylist(id: Long, from: Int, to: Int) = update { d ->
        d.copy(playlists = d.playlists.map { p ->
            if (p.id != id || from !in p.paths.indices || to !in p.paths.indices) p
            else {
                val l = p.paths.toMutableList()
                l.add(to, l.removeAt(from))
                p.copy(paths = l)
            }
        })
    }

    /** After files are renamed, moves everything remembered about them to the new paths. */
    fun migratePaths(m: Map<String, String>) {
        if (m.isEmpty()) return
        update { d ->
            d.copy(
                favorites = d.favorites.map { m[it] ?: it }.toSet(),
                playlists = d.playlists.map { pl -> pl.copy(paths = pl.paths.map { m[it] ?: it }) },
                plays = remap(d.plays, m),
                lastPlayed = remap(d.lastPlayed, m),
                positions = remap(d.positions, m),
                songFx = remap(d.songFx, m),
                tags = remap(d.tags, m),
                hidden = d.hidden.map { m[it] ?: it }.toSet(),
                queue = d.queue.map { m[it] ?: it },
                bookmarks = remap(d.bookmarks, m),
                songLyrics = remap(d.songLyrics, m),
                ratings = remap(d.ratings, m),
            )
        }
    }

    private fun <V> remap(src: Map<String, V>, m: Map<String, String>): Map<String, V> {
        val out = HashMap<String, V>()
        for ((k, v) in src) out[m[k] ?: k] = v
        return out
    }

    // ---- edits ----
    fun setTag(path: String, o: TagOverride?) = update { d ->
        d.copy(tags = if (o == null) d.tags - path else d.tags + (path to o))
    }

    fun hide(path: String) = update { it.copy(hidden = it.hidden + path) }
    fun unhide(path: String) = update { it.copy(hidden = it.hidden - path) }
    fun unhideAll() = update { it.copy(hidden = emptySet()) }
}
