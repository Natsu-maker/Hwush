@file:OptIn(UnstableApi::class)

package com.hwush.player.player

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer

/**
 * Sits in the audio path to shift the sound towards the left or right ear and to fold stereo into mono.
 * It only touches ordinary 16-bit stereo; anything else passes through untouched.
 */
class BalanceProcessor : BaseAudioProcessor() {
    @Volatile var left = 1f
    @Volatile var right = 1f
    @Volatile var mono = false

    /** -100 is all left, 0 is the middle and 100 is all right. */
    fun setBalance(v: Int) {
        val b = v.coerceIn(-100, 100) / 100f
        left = if (b > 0f) 1f - b else 1f
        right = if (b < 0f) 1f + b else 1f
    }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT || inputAudioFormat.channelCount != 2) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val out = replaceOutputBuffer(size)
        val l = left
        val r = right
        val m = mono
        if (!m && l >= 0.999f && r >= 0.999f) {
            out.put(inputBuffer)
        } else {
            while (inputBuffer.remaining() >= 4) {
                var a = inputBuffer.short.toInt()
                var b = inputBuffer.short.toInt()
                if (m) {
                    val avg = (a + b) / 2
                    a = avg
                    b = avg
                }
                out.putShort((a * l).toInt().coerceIn(-32768, 32767).toShort())
                out.putShort((b * r).toInt().coerceIn(-32768, 32767).toShort())
            }
            inputBuffer.position(inputBuffer.limit())
        }
        out.flip()
    }
}
