package com.hwush.player.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.hwush.player.dj.DjDecoder
import com.hwush.player.studio.Note
import com.hwush.player.studio.ST_RATE
import com.hwush.player.studio.StudioEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

private val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
private fun isBlack(p: Int) = (p % 12) in intArrayOf(1, 3, 6, 8, 10)

/**
 * Studio mode: a separate part of Hwush for making beats and loops. Drum lanes, a lead and a bass you play on a
 * piano roll, a lane for a piece of one of your songs, a mixer, and export to wav. The player stays untouched.
 */
@Composable
fun StudioShell(ui: UiController) {
    val app = ui.app
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { StudioEngine() }
    val file = remember { File(ctx.filesDir, "studio").also { it.mkdirs() }.let { File(it, "project.json") } }
    var rev by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    var noteLen by remember { mutableIntStateOf(1) }
    var pickSample by remember { mutableStateOf(false) }
    var exportOpen by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf("") }
    var playStep by remember { mutableIntStateOf(-1) }
    var isPlaying by remember { mutableStateOf(false) }
    val tracks by app.library.tracks.collectAsState()

    fun touch() { engine.dirty = true; rev++ }

    DisposableEffect(Unit) {
        try { app.player.player.pause() } catch (_: Exception) {}
        try {
            if (file.exists()) engine.fromJson(JSONObject(file.readText()))
        } catch (_: Exception) {}
        engine.start()
        rev++
        onDispose {
            try { file.writeText(engine.toJson().toString()) } catch (_: Exception) {}
            engine.playing = false
            engine.release()
        }
    }
    LaunchedEffect(Unit) {
        // Bring the saved sample back
        val path = engine.sample.path
        if (path.isNotEmpty()) {
            val t = app.library.find(path)
            if (t != null) loadSample(ctx, engine, t, (engine.sample.startSec * 1000f).toLong())
            rev++
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            androidx.compose.runtime.withFrameNanos { }
            val s = if (engine.playing) engine.step else -1
            if (s != playStep) playStep = s
            if (isPlaying != engine.playing) isPlaying = engine.playing
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(2500)
            if (engine.dirty) {
                engine.dirty = false
                withContext(Dispatchers.IO) { try { file.writeText(engine.toJson().toString()) } catch (_: Exception) {} }
            }
        }
    }

    var pending by remember { mutableStateOf<File?>(null) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-wav")) { uri ->
        val f = pending
        if (uri != null && f != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        ctx.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                        true
                    } catch (_: Exception) { false }
                }
                Toast.makeText(ctx, if (ok) "Saved your beat" else "Could not save", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @Suppress("UNUSED_VARIABLE") val r = rev
    val primary = MaterialTheme.colorScheme.primary
    val bg = MaterialTheme.colorScheme.background

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(primary.copy(alpha = 0.22f).compositeOver(bg), bg, MaterialTheme.colorScheme.tertiary.copy(alpha = 0.12f).compositeOver(bg))))
            .systemBarsPadding(),
    ) {
        Column(Modifier.fillMaxSize()) {
            // Top bar
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { ui.studio = false }) { Icon(Icons.Rounded.ArrowBack, "Back to the player") }
                Column(Modifier.weight(1f)) {
                    Text("Studio", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("Beats and loops", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledTonalButton(onClick = { exportOpen = true }) { Text("Export") }
                Spacer(Modifier.width(6.dp))
                Button(onClick = {
                    if (engine.playing) engine.stop() else engine.play()
                }) { Text(if (isPlaying) "Stop" else "Play") }
            }
            // Tempo strip
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${engine.bpm} BPM", fontWeight = FontWeight.Bold, modifier = Modifier.width(78.dp))
                Slider(
                    value = engine.bpm.toFloat(),
                    onValueChange = { engine.bpm = it.toInt(); touch() },
                    valueRange = 50f..200f,
                    modifier = Modifier.weight(1f),
                )
            }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Beat", "Lead", "Bass", "Sample", "Mixer").forEachIndexed { i, n ->
                    FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(n) })
                }
            }
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(top = 8.dp, bottom = 24.dp)) {
                when (tab) {
                    0 -> {
                        val cols = engine.totalSteps
                        StepGrid(
                            rows = engine.drums.size, cols = cols, rowHeight = 40.dp,
                            labels = engine.drums.map { it.name },
                            state = { rr, c -> if (engine.drums[rr].steps[c]) 1 else 0 },
                            playStep = playStep, accent = primary, rev = rev,
                            onLabel = { engine.audition(it) },
                            onSet = { rr, c, on ->
                                engine.drums[rr].steps[c] = on
                                if (on) engine.audition(rr)
                                touch()
                            },
                        )
                        Text(
                            "Tap or swipe across squares to place hits. Tap a name to hear it.",
                            Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    1, 2 -> {
                        val lane = engine.synths[tab - 1]
                        val rowsN = 24
                        val high = lane.low + rowsN - 1
                        StepGrid(
                            rows = rowsN, cols = engine.totalSteps, rowHeight = 24.dp,
                            labels = (0 until rowsN).map { val p = high - it; noteNames[p % 12] + (p / 12 - 1) },
                            blackRow = { (high - it).let { p -> isBlack(p) } },
                            state = { rr, c ->
                                val p = high - rr
                                var st = 0
                                for (n in lane.notes) if (n.pitch == p) {
                                    if (n.step == c) st = 1 else if (c > n.step && c < n.step + n.len && st == 0) st = 2
                                }
                                st
                            },
                            playStep = playStep, accent = MaterialTheme.colorScheme.tertiary, rev = rev,
                            onLabel = { engine.auditionNote(tab - 1, high - it) },
                            onSet = { rr, c, on ->
                                val p = high - rr
                                val hit = lane.notes.filter { it.pitch == p && c >= it.step && c < it.step + it.len }
                                if (on) {
                                    if (hit.isEmpty()) {
                                        lane.notes.add(Note(c, noteLen.coerceAtMost(engine.totalSteps - c), p))
                                        engine.auditionNote(tab - 1, p, noteLen)
                                    }
                                } else {
                                    for (n in hit) lane.notes.remove(n)
                                }
                                touch()
                            },
                        )
                        Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                            Text("Note length", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                for (n in listOf(1, 2, 4, 8)) FilterChip(selected = noteLen == n, onClick = { noteLen = n }, label = { Text("$n") })
                            }
                            Text("Sound", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("Sine", "Square", "Saw", "Pluck").forEachIndexed { i, n ->
                                    FilterChip(selected = lane.wave == i, onClick = { lane.wave = i; touch() }, label = { Text(n) })
                                }
                            }
                            Text("Brightness", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Slider(value = lane.cutoff, onValueChange = { lane.cutoff = it; touch() })
                            Text("Fade out", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Slider(value = lane.release, onValueChange = { lane.release = it; touch() })
                        }
                    }
                    3 -> {
                        val sm = engine.sample
                        Column(Modifier.padding(horizontal = 16.dp)) {
                            Text(
                                if (sm.title.isBlank() && sm.clip == null) "No song cut yet" else sm.title.ifBlank { "Your cut" },
                                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold,
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                                FilledTonalButton(onClick = { pickSample = true }) { Text("Pick a song") }
                                FilledTonalButton(onClick = { engine.auditionSample() }) { Text("Hear it") }
                            }
                            Text("Pitch ${if (sm.semis >= 0) "+" else ""}${sm.semis} semitones", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Slider(value = sm.semis.toFloat(), onValueChange = { sm.semis = it.toInt(); touch() }, valueRange = -12f..12f)
                        }
                        StepGrid(
                            rows = 1, cols = engine.totalSteps, rowHeight = 48.dp, labels = listOf("Cut"),
                            state = { _, c -> if (sm.steps[c]) 1 else 0 },
                            playStep = playStep, accent = MaterialTheme.colorScheme.secondary, rev = rev,
                            onLabel = { engine.auditionSample() },
                            onSet = { _, c, on -> sm.steps[c] = on; if (on) engine.auditionSample(); touch() },
                        )
                        Text(
                            "Picks up to 12 seconds from the song you choose and plays it from the start on every square you tap.",
                            Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    else -> MixerTab(engine) { touch() }
                }
            }
        }
        if (busy.isNotEmpty()) {
            AlertDialog(onDismissRequest = {}, confirmButton = {}, title = { Text("Please wait") }, text = { Text(busy) })
        }
    }

    if (pickSample) {
        ChooseSongDialog(
            tracks = tracks,
            onClose = { pickSample = false },
            onPick = { t, startMs ->
                pickSample = false
                busy = "Cutting from ${t.title}"
                scope.launch {
                    val ok = loadSample(ctx, engine, t, startMs)
                    busy = ""
                    if (!ok) Toast.makeText(ctx, "Could not read that song", Toast.LENGTH_SHORT).show()
                    touch()
                }
            },
        )
    }

    if (exportOpen) {
        AlertDialog(
            onDismissRequest = { exportOpen = false },
            title = { Text("Export as wav") },
            text = { Text("How many times should the pattern play in the file?") },
            confirmButton = {
                Row {
                    for (n in listOf(1, 2, 4, 8)) {
                        TextButton(onClick = {
                            exportOpen = false
                            engine.stop()
                            busy = "Making your wav"
                            scope.launch {
                                val out = File(ctx.cacheDir, "studio-export.wav")
                                val ok = withContext(Dispatchers.IO) { engine.export(out, n) }
                                busy = ""
                                if (ok) {
                                    pending = out
                                    saver.launch("hwush-beat-${System.currentTimeMillis() / 1000}.wav")
                                } else {
                                    Toast.makeText(ctx, "Could not make the file", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }) { Text("${n}x") }
                    }
                }
            },
            dismissButton = { TextButton(onClick = { exportOpen = false }) { Text("Cancel") } },
        )
    }
}

private suspend fun loadSample(ctx: android.content.Context, engine: StudioEngine, t: com.hwush.player.data.Track, startMs: Long): Boolean {
    val clip = DjDecoder.decode(ctx, t, startMs, 12) ?: return false
    val frames = clip.frames
    val ratio = clip.sampleRate.toDouble() / ST_RATE
    val n = (frames / ratio).toInt().coerceAtLeast(1)
    val out = ShortArray(n)
    for (i in 0 until n) {
        val p = i * ratio
        val k = p.toInt().coerceAtMost(frames - 2)
        val f = (p - k).toFloat()
        val a = (clip.data[k * 2] + clip.data[k * 2 + 1]) / 2f
        val b = (clip.data[(k + 1) * 2] + clip.data[(k + 1) * 2 + 1]) / 2f
        out[i] = (a + (b - a) * f).toInt().coerceIn(-32768, 32767).toShort()
    }
    val s = engine.sample
    s.clip = out
    s.title = t.title
    s.path = t.path
    s.startSec = startMs / 1000f
    return true
}

/** A grid of squares you tap or swipe across. Draws everything on one canvas so it stays fast. */
@Composable
private fun StepGrid(
    rows: Int,
    cols: Int,
    rowHeight: Dp,
    labels: List<String>,
    state: (Int, Int) -> Int,
    playStep: Int,
    accent: Color,
    rev: Int,
    onLabel: (Int) -> Unit,
    onSet: (Int, Int, Boolean) -> Unit,
    blackRow: (Int) -> Boolean = { false },
) {
    @Suppress("UNUSED_VARIABLE") val r = rev
    val labelW = 58.dp
    BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
        val fit = (maxWidth - labelW) / minOf(cols, 16)
        val cell = if (fit < 26.dp) 26.dp else fit
        val gridW = cell * cols
        val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f)
        val dimmer = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f)
        val black = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.14f)
        val barLine = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.28f)
        Row {
            Column(Modifier.width(labelW)) {
                for (i in 0 until rows) {
                    Box(Modifier.height(rowHeight).fillMaxWidth().clickable { onLabel(i) }.padding(end = 4.dp), contentAlignment = Alignment.CenterStart) {
                        Text(labels.getOrElse(i) { "" }, style = MaterialTheme.typography.labelSmall, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Box(Modifier.horizontalScroll(rememberScrollState())) {
                var paint by remember { mutableStateOf(true) }
                Canvas(
                    Modifier.width(gridW).height(rowHeight * rows)
                        .pointerInput(rows, cols, cell, rowHeight) {
                            detectTapGestures { p ->
                                val c = (p.x / (cell.toPx())).toInt().coerceIn(0, cols - 1)
                                val rr = (p.y / (rowHeight.toPx())).toInt().coerceIn(0, rows - 1)
                                onSet(rr, c, state(rr, c) == 0)
                            }
                        }
                        .pointerInput(rows, cols, cell, rowHeight) {
                            detectHorizontalDragGestures(
                                onDragStart = { p ->
                                    val c = (p.x / (cell.toPx())).toInt().coerceIn(0, cols - 1)
                                    val rr = (p.y / (rowHeight.toPx())).toInt().coerceIn(0, rows - 1)
                                    paint = state(rr, c) == 0
                                    if ((state(rr, c) == 0) == paint) onSet(rr, c, paint)
                                },
                                onHorizontalDrag = { ch, _ ->
                                    val c = (ch.position.x / (cell.toPx())).toInt().coerceIn(0, cols - 1)
                                    val rr = (ch.position.y / (rowHeight.toPx())).toInt().coerceIn(0, rows - 1)
                                    if ((state(rr, c) == 0) == paint) onSet(rr, c, paint)
                                },
                            )
                        },
                ) {
                    val cw = cell.toPx()
                    val rh = rowHeight.toPx()
                    val gap = 2.dp.toPx()
                    if (playStep in 0 until cols) {
                        drawRect(accent.copy(alpha = 0.16f), Offset(playStep * cw, 0f), Size(cw, rh * rows))
                    }
                    for (rr in 0 until rows) {
                        for (c in 0 until cols) {
                            val s = state(rr, c)
                            val x = c * cw + gap / 2f
                            val y = rr * rh + gap / 2f
                            val base = if (blackRow(rr)) black else if ((c / 4) % 2 == 0) dim else dimmer
                            val col = when (s) {
                                1 -> accent
                                2 -> accent.copy(alpha = 0.5f)
                                else -> base
                            }
                            drawRoundRect(col, Offset(x, y), Size(cw - gap, rh - gap), CornerRadius(5.dp.toPx()))
                        }
                    }
                    var b = 16
                    while (b < cols) {
                        drawLine(barLine, Offset(b * cw, 0f), Offset(b * cw, rh * rows), 2f)
                        b += 16
                    }
                }
            }
        }
    }
}

@Composable
private fun MixerTab(engine: StudioEngine, changed: () -> Unit) {
    Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        @Composable
        fun strip(name: String, vol: Float, pan: Float, mute: Boolean, solo: Boolean, onVol: (Float) -> Unit, onPan: (Float) -> Unit, onMute: () -> Unit, onSolo: () -> Unit) {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.7f)).padding(horizontal = 12.dp, vertical = 6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(name, Modifier.weight(1f), fontWeight = FontWeight.Medium)
                    FilterChip(selected = mute, onClick = { onMute(); changed() }, label = { Text("Mute") })
                    Spacer(Modifier.width(6.dp))
                    FilterChip(selected = solo, onClick = { onSolo(); changed() }, label = { Text("Solo") })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Vol", Modifier.width(32.dp), style = MaterialTheme.typography.labelSmall)
                    Slider(value = vol, onValueChange = { onVol(it); changed() }, modifier = Modifier.weight(1f))
                    Text("Pan", Modifier.width(32.dp), style = MaterialTheme.typography.labelSmall)
                    Slider(value = pan, onValueChange = { onPan(it); changed() }, valueRange = -1f..1f, modifier = Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(6.dp))
        }
        for (d in engine.drums) strip(d.name, d.vol, d.pan, d.mute, d.solo, { d.vol = it }, { d.pan = it }, { d.mute = !d.mute }, { d.solo = !d.solo })
        for (s in engine.synths) strip(s.name, s.vol, s.pan, s.mute, s.solo, { s.vol = it }, { s.pan = it }, { s.mute = !s.mute }, { s.solo = !s.solo })
        val sm = engine.sample
        strip("Sample", sm.vol, sm.pan, sm.mute, sm.solo, { sm.vol = it }, { sm.pan = it }, { sm.mute = !sm.mute }, { sm.solo = !sm.solo })
        Text("Master", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
        Slider(value = engine.master, onValueChange = { engine.master = it; changed() }, valueRange = 0f..1f)
        Text("Echo", style = MaterialTheme.typography.labelMedium)
        Slider(value = engine.echoMix, onValueChange = { engine.echoMix = it; changed() }, valueRange = 0f..0.6f)
        Text("Swing", style = MaterialTheme.typography.labelMedium)
        Slider(value = engine.swing, onValueChange = { engine.swing = it; changed() }, valueRange = 0f..1f)
        Text("Length in bars", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (b in 1..4) FilterChip(selected = engine.bars == b, onClick = { engine.bars = b; changed() }, label = { Text("$b") })
        }
        TextButton(onClick = { engine.clearAll(); changed() }) { Text("Clear everything") }
    }
}
