@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.hwush.player.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hwush.player.dj.DjDecoder
import com.hwush.player.studio.BAR
import com.hwush.player.studio.Channel
import com.hwush.player.studio.Clip
import com.hwush.player.studio.FxSlot
import com.hwush.player.studio.INSERTS
import com.hwush.player.studio.MAXPAT
import com.hwush.player.studio.Note
import com.hwush.player.studio.ST_RATE
import com.hwush.player.studio.STEP
import com.hwush.player.studio.StudioEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

private val FlBg = Color(0xFF14171B)
private val FlPanel = Color(0xFF22272E)
private val FlPanel2 = Color(0xFF2C323A)
private val FlLine = Color(0xFF3A414B)
private val FlOrange = Color(0xFFFF8A2B)
private val FlGreen = Color(0xFF9BE564)
private val FlText = Color(0xFFE6E9ED)
private val FlDim = Color(0xFF8E98A3)

private val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
private fun isBlack(p: Int) = (p % 12) in intArrayOf(1, 3, 6, 8, 10)
private fun pitchName(p: Int) = noteNames[p % 12] + (p / 12 - 1)
private val majorScale = setOf(0, 2, 4, 5, 7, 9, 11)
private val minorScale = setOf(0, 2, 3, 5, 7, 8, 10)
private val fxNames = listOf("None", "Filter", "Delay", "Reverb", "Drive", "Crush")
private val fxLabels = listOf(
    listOf("", "", ""),
    listOf("Cutoff", "Low or high pass", "Mix"),
    listOf("Time", "Feedback", "Mix"),
    listOf("Size", "Damping", "Mix"),
    listOf("Drive", "Tone", "Mix"),
    listOf("Bits", "Rate", "Mix"),
)

/**
 * Studio mode, laid out like a loop based music maker: a channel rack of instruments, a piano roll, a playlist that
 * arranges patterns along a timeline, and a mixer with effect slots. It is its own part of Hwush, away from the player.
 */
@Composable
fun StudioShell(ui: UiController) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = FlOrange, onPrimary = Color.Black, secondary = FlGreen, tertiary = Color(0xFF5BC0EB),
            background = FlBg, surface = FlPanel, surfaceContainer = FlPanel, surfaceContainerHigh = FlPanel2,
            surfaceVariant = FlPanel2, onSurface = FlText, onBackground = FlText, onSurfaceVariant = FlDim,
            outline = FlLine, secondaryContainer = Color(0xFF4A3420), onSecondaryContainer = FlText,
        ),
        typography = MaterialTheme.typography,
        shapes = MaterialTheme.shapes,
    ) { StudioBody(ui) }
}

@Composable
private fun StudioBody(ui: UiController) {
    val app = ui.app
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { StudioEngine() }
    val file = remember { File(ctx.filesDir, "studio").also { it.mkdirs() }.let { File(it, "project.json") } }
    var rev by remember { mutableIntStateOf(0) }
    var view by remember { mutableIntStateOf(0) }
    var sel by remember { mutableIntStateOf(0) }
    var snap by remember { mutableIntStateOf(STEP) }
    var vel by remember { mutableFloatStateOf(0.85f) }
    var chord by remember { mutableIntStateOf(0) }
    var scale by remember { mutableIntStateOf(0) }
    var rollLow by remember { mutableIntStateOf(48) }
    var chDialog by remember { mutableStateOf<Channel?>(null) }
    var addOpen by remember { mutableStateOf(false) }
    var patOpen by remember { mutableStateOf(false) }
    var fxEdit by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var samplePick by remember { mutableStateOf(false) }
    var sampleTarget by remember { mutableStateOf<Channel?>(null) }
    var exportOpen by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf("") }
    var isPlaying by remember { mutableStateOf(false) }
    val clock = remember { mutableIntStateOf(0) }
    val tracks by app.library.tracks.collectAsState()

    fun touch() { engine.dirty = true; rev++ }

    DisposableEffect(Unit) {
        try { app.player.player.pause() } catch (_: Exception) {}
        try { if (file.exists()) engine.fromJson(JSONObject(file.readText())) } catch (_: Exception) {}
        engine.start()
        rev++
        onDispose {
            try { file.writeText(engine.toJson().toString()) } catch (_: Exception) {}
            engine.playing = false
            engine.release()
        }
    }
    LaunchedEffect(Unit) {
        for (ch in engine.channels) {
            if (ch.type == 2 && ch.path.isNotEmpty()) {
                val t = app.library.find(ch.path)
                if (t != null) loadSampleInto(ctx, ch, t, (ch.startSec * 1000f).toLong())
            }
        }
        rev++
    }
    LaunchedEffect(Unit) {
        while (true) {
            androidx.compose.runtime.withFrameNanos { }
            clock.intValue++
            if (isPlaying != engine.playing) isPlaying = engine.playing
        }
    }
    LaunchedEffect(Unit) {
        while (true) {
            delay(2500)
            if (engine.dirty) {
                engine.dirty = false
                withContext(Dispatchers.IO) { try { file.writeText(engine.toJson().toString()) } catch (_: Exception) {} }
            }
        }
    }

    var pending by remember { mutableStateOf<File?>(null) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-wav")) { uri ->
        val f = pending
        if (uri != null && f != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        ctx.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                        true
                    } catch (_: Exception) { false }
                }
                Toast.makeText(ctx, if (ok) "Saved your track" else "Could not save", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @Suppress("UNUSED_VARIABLE") val r = rev
    val pat = engine.patterns.getOrNull(engine.curPattern) ?: engine.patterns[0]
    val chans = engine.channels.toList()
    if (sel >= chans.size) sel = max(0, chans.size - 1)

    Column(Modifier.fillMaxSize().background(FlBg).systemBarsPadding()) {
        // ---------------------------------------------------- toolbar
        Row(
            Modifier.fillMaxWidth().background(FlPanel).padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { ui.studio = false }) { Icon(Icons.Rounded.ArrowBack, "Back to the player", tint = FlText) }
            Box(
                Modifier.clip(RoundedCornerShape(8.dp)).background(FlPanel2).clickable { patOpen = true }.padding(horizontal = 10.dp, vertical = 7.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(Color(pat.color)))
                    Spacer(Modifier.width(6.dp))
                    Text(pat.name, color = FlText, fontSize = 13.sp, maxLines = 1)
                }
            }
            Spacer(Modifier.width(8.dp))
            Row(
                Modifier.clip(RoundedCornerShape(8.dp)).background(FlPanel2),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("−", Modifier.clickable { engine.bpm = max(50, engine.bpm - 1); touch() }.padding(horizontal = 10.dp, vertical = 7.dp), color = FlOrange, fontWeight = FontWeight.Bold)
                Text("${engine.bpm}", color = FlGreen, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text("+", Modifier.clickable { engine.bpm = min(220, engine.bpm + 1); touch() }.padding(horizontal = 10.dp, vertical = 7.dp), color = FlOrange, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
            Row(Modifier.clip(RoundedCornerShape(8.dp)).background(FlPanel2)) {
                for ((i, n) in listOf("PAT", "SONG").withIndex()) {
                    val on = (i == 1) == engine.songMode
                    Text(
                        n, Modifier.background(if (on) FlOrange else Color.Transparent).clickable { engine.songMode = i == 1; if (engine.playing) engine.play(); touch() }
                            .padding(horizontal = 10.dp, vertical = 7.dp),
                        color = if (on) Color.Black else FlDim, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                    )
                }
            }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(if (isPlaying) FlOrange else FlGreen)
                    .clickable { if (engine.playing) engine.stop() else engine.play() },
                contentAlignment = Alignment.Center,
            ) { Icon(if (isPlaying) Icons.Rounded.Stop else Icons.Rounded.PlayArrow, "Play or stop", tint = Color.Black) }
            Spacer(Modifier.width(6.dp))
        }
        Row(Modifier.fillMaxWidth().background(FlPanel).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((i, n) in listOf("Channel rack", "Piano roll", "Playlist", "Mixer").withIndex()) {
                FilterChip(selected = view == i, onClick = { view = i }, label = { Text(n, fontSize = 12.sp) })
            }
            FilterChip(selected = false, onClick = { exportOpen = true }, label = { Text("Export", fontSize = 12.sp) })
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (view) {
                0 -> RackView(
                    engine, chans, pat.bars, sel, clock, rev,
                    onSelect = { sel = it },
                    onSettings = { chDialog = it },
                    onRoll = { sel = it; rollLow = if (chans[it].defPitch < 48) 24 else 48; view = 1 },
                    onAdd = { addOpen = true },
                    changed = { touch() },
                )
                1 -> RollView(
                    engine, chans, sel, pat.bars, snap, vel, chord, scale, rollLow, clock, rev,
                    onSel = { sel = it; rollLow = if (chans[it].defPitch < 48) 24 else 48 },
                    onSnap = { snap = it }, onVel = { vel = it }, onChord = { chord = it }, onScale = { scale = it },
                    onLow = { rollLow = it }, changed = { touch() },
                )
                2 -> PlaylistView(engine, rev, clock, changed = { touch() })
                else -> MixerView(engine, clock, rev, onFx = { i, s -> fxEdit = i to s }, changed = { touch() })
            }
        }
    }

    if (busy.isNotEmpty()) {
        AlertDialog(onDismissRequest = {}, confirmButton = {}, title = { Text("Please wait") }, text = { Text(busy) }, containerColor = FlPanel)
    }

    // ---------------------------------------------------- dialogs
    if (addOpen) {
        AlertDialog(
            onDismissRequest = { addOpen = false },
            containerColor = FlPanel,
            title = { Text("Add a channel") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Drum sounds", color = FlDim, fontSize = 12.sp)
                    val names = engine.kitNames
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (rowStart in names.indices step 3) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                for (k in rowStart until min(rowStart + 3, names.size)) {
                                    FilterChip(selected = false, onClick = {
                                        val ch = engine.addChannel(names[k], 0, k)
                                        ch.insert = 0
                                        addOpen = false; sel = engine.channels.size - 1; touch()
                                    }, label = { Text(names[k], fontSize = 12.sp) })
                                }
                            }
                        }
                    }
                    Text("Instruments", color = FlDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = false, onClick = {
                            engine.addChannel("Synth", 1, 0); addOpen = false; sel = engine.channels.size - 1; touch()
                        }, label = { Text("Synth") })
                        FilterChip(selected = false, onClick = {
                            sampleTarget = null; addOpen = false; samplePick = true
                        }, label = { Text("Piece of a song") })
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { addOpen = false }) { Text("Close") } },
        )
    }

    chDialog?.let { ch ->
        ChannelDialog(
            engine, ch, onClose = { chDialog = null }, changed = { touch() },
            onPickSong = { sampleTarget = ch; chDialog = null; samplePick = true },
            onDelete = { engine.removeChannel(ch); chDialog = null; touch() },
        )
    }

    if (patOpen) {
        AlertDialog(
            onDismissRequest = { patOpen = false },
            containerColor = FlPanel,
            title = { Text("Patterns") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.verticalScroll(rememberScrollState()).height(150.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        for ((i, p) in engine.patterns.withIndex()) {
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                                    .background(if (i == engine.curPattern) FlPanel2 else Color.Transparent)
                                    .clickable { engine.curPattern = i; if (engine.playing && !engine.songMode) engine.play(); touch() }
                                    .padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Box(Modifier.size(12.dp).clip(CircleShape).background(Color(p.color)))
                                Spacer(Modifier.width(10.dp))
                                Text(p.name, Modifier.weight(1f), color = FlText)
                                Text("${p.bars} bar${if (p.bars > 1) "s" else ""}", color = FlDim, fontSize = 12.sp)
                            }
                        }
                    }
                    Text("Length of this pattern", color = FlDim, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (b in 1..4) FilterChip(selected = pat.bars == b, onClick = { pat.bars = b; touch() }, label = { Text("$b") })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { engine.curPattern = engine.addPattern(); touch() }) { Text("New") }
                        TextButton(onClick = { engine.curPattern = engine.duplicatePattern(engine.curPattern); touch() }) { Text("Copy") }
                        TextButton(onClick = { engine.clearPattern(engine.curPattern); touch() }) { Text("Clear") }
                    }
                    TextButton(onClick = { engine.newProject(); sel = 0; touch(); patOpen = false }) { Text("New project", color = Color(0xFFFF6B6B)) }
                }
            },
            confirmButton = { TextButton(onClick = { patOpen = false }) { Text("Done") } },
        )
    }

    fxEdit?.let { (ii, si) ->
        val slot = engine.inserts[ii].slots[si]
        FxDialog(engine, slot, onClose = { fxEdit = null }, changed = { touch() })
    }

    if (samplePick) {
        ChooseSongDialog(
            tracks = tracks,
            onClose = { samplePick = false },
            onPick = { t, startMs ->
                samplePick = false
                busy = "Cutting from ${t.title}"
                val target = sampleTarget
                scope.launch {
                    val ch = target ?: engine.addChannel(t.title.take(14), 2, 0)
                    val ok = loadSampleInto(ctx, ch, t, startMs)
                    busy = ""
                    if (!ok) {
                        Toast.makeText(ctx, "Could not read that song", Toast.LENGTH_SHORT).show()
                        if (target == null) engine.removeChannel(ch)
                    } else if (target == null) {
                        sel = engine.channels.size - 1
                    }
                    touch()
                }
            },
        )
    }

    if (exportOpen) {
        AlertDialog(
            onDismissRequest = { exportOpen = false },
            containerColor = FlPanel,
            title = { Text("Export as wav") },
            text = { Text(if (engine.songMode) "Renders the whole playlist once." else "How many times should this pattern play in the file?") },
            confirmButton = {
                Row {
                    for (n in (if (engine.songMode) listOf(1) else listOf(1, 2, 4, 8))) {
                        TextButton(onClick = {
                            exportOpen = false
                            engine.stop()
                            busy = "Making your wav"
                            scope.launch {
                                val out = File(ctx.cacheDir, "studio-export.wav")
                                val ok = withContext(Dispatchers.IO) { engine.export(out, n) }
                                busy = ""
                                if (ok) {
                                    pending = out
                                    saver.launch("hwush-track-${System.currentTimeMillis() / 1000}.wav")
                                } else {
                                    Toast.makeText(ctx, "Could not make the file", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }) { Text(if (engine.songMode) "Export" else "${n}x") }
                    }
                }
            },
            dismissButton = { TextButton(onClick = { exportOpen = false }) { Text("Cancel") } },
        )
    }
}

private suspend fun loadSampleInto(ctx: android.content.Context, ch: Channel, t: com.hwush.player.data.Track, startMs: Long): Boolean {
    val clip = DjDecoder.decode(ctx, t, startMs, 12) ?: return false
    val frames = clip.frames
    val ratio = clip.sampleRate.toDouble() / ST_RATE
    val n = (frames / ratio).toInt().coerceAtLeast(2)
    val out = ShortArray(n)
    for (i in 0 until n) {
        val p = i * ratio
        val k = p.toInt().coerceAtMost(frames - 2)
        val f = (p - k).toFloat()
        val a = (clip.data[k * 2] + clip.data[k * 2 + 1]) / 2f
        val b = (clip.data[(k + 1) * 2] + clip.data[(k + 1) * 2 + 1]) / 2f
        out[i] = (a + (b - a) * f).toInt().coerceIn(-32768, 32767).toShort()
    }
    ch.clip = out
    ch.title = t.title
    ch.path = t.path
    ch.startSec = startMs / 1000f
    return true
}

// ====================================================================== small controls

/** A round knob you drag up or down. */
@Composable
private fun Knob(value: Float, onChange: (Float) -> Unit, color: Color, modifier: Modifier = Modifier, size: Dp = 28.dp, min: Float = 0f, max: Float = 1f) {
    val v = rememberUpdatedState(value)
    val cb = rememberUpdatedState(onChange)
    Canvas(
        modifier.size(size).pointerInput(min, max) {
            detectVerticalDragGestures { ch, dy ->
                ch.consume()
                cb.value((v.value - dy / 220f * (max - min)).coerceIn(min, max))
            }
        },
    ) {
        val norm = ((value - min) / (max - min)).coerceIn(0f, 1f)
        val w = this.size.minDimension
        val stroke = w * 0.14f
        val tl = Offset(stroke / 2f, stroke / 2f)
        val sz = Size(w - stroke, w - stroke)
        drawArc(Color(0xFF3A414B), 135f, 270f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
        drawArc(color, 135f, 270f * norm, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
        val a = Math.toRadians((135f + 270f * norm).toDouble())
        val c = Offset(w / 2f, w / 2f)
        drawLine(Color.White, c, Offset(c.x + (w * 0.28f * Math.cos(a)).toFloat(), c.y + (w * 0.28f * Math.sin(a)).toFloat()), stroke * 0.7f, StrokeCap.Round)
    }
}

/** A tall fader with a level meter beside it. */
@Composable
private fun Fader(value: Float, onChange: (Float) -> Unit, meter: () -> Float, color: Color, modifier: Modifier = Modifier) {
    val cb = rememberUpdatedState(onChange)
    Canvas(
        modifier.width(46.dp).height(150.dp)
            .pointerInput(Unit) { detectTapGestures { p -> cb.value((1f - p.y / size.height).coerceIn(0f, 1f)) } }
            .pointerInput(Unit) { detectVerticalDragGestures { ch, _ -> ch.consume(); cb.value((1f - ch.position.y / size.height).coerceIn(0f, 1f)) } },
    ) {
        val w = size.width
        val h = size.height
        val slot = w * 0.18f
        drawRoundRect(Color(0xFF0E1013), Offset(w * 0.2f, 0f), Size(slot, h), CornerRadius(slot / 2f))
        val m = meter().coerceIn(0f, 1f)
        val mh = h * m
        drawRoundRect(if (m > 0.9f) Color(0xFFFF4D4D) else FlGreen, Offset(w * 0.2f, h - mh), Size(slot, mh), CornerRadius(slot / 2f))
        drawRoundRect(Color(0xFF0E1013), Offset(w * 0.62f, 0f), Size(slot, h), CornerRadius(slot / 2f))
        val y = h * (1f - value)
        drawRoundRect(color, Offset(w * 0.62f - w * 0.1f, y - h * 0.035f), Size(slot + w * 0.2f, h * 0.07f), CornerRadius(6f))
        drawRoundRect(Color.White.copy(alpha = 0.8f), Offset(w * 0.62f - w * 0.1f, y - 1.5f), Size(slot + w * 0.2f, 3f), CornerRadius(2f))
    }
}

// ====================================================================== channel rack

@Composable
private fun RackView(
    engine: StudioEngine, chans: List<Channel>, bars: Int, sel: Int, clock: androidx.compose.runtime.MutableIntState, rev: Int,
    onSelect: (Int) -> Unit, onSettings: (Channel) -> Unit, onRoll: (Int) -> Unit, onAdd: () -> Unit, changed: () -> Unit,
) {
    @Suppress("UNUSED_VARIABLE") val r = rev
    val cols = bars * 16
    val leftW = 168.dp
    val rowH = 48.dp
    val pi = engine.curPattern
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val fit = (maxWidth - leftW - 12.dp) / 16
        val cell = if (fit < 26.dp) 26.dp else if (fit > 44.dp) 44.dp else fit
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = 6.dp, bottom = 24.dp)) {
            Row(Modifier.padding(horizontal = 6.dp)) {
                Column(Modifier.width(leftW)) {
                    for ((i, ch) in chans.withIndex()) {
                        Row(
                            Modifier.height(rowH).fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(8.dp))
                                .background(if (i == sel) FlPanel2 else FlPanel).padding(horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Box(
                                Modifier.size(14.dp).clip(CircleShape).background(if (ch.mute) Color(0xFF3A2A2A) else FlGreen)
                                    .clickable { ch.mute = !ch.mute; changed() },
                            )
                            Spacer(Modifier.width(6.dp))
                            Column(
                                Modifier.weight(1f).combinedClickable(
                                    onClick = { onSelect(i); engine.audition(ch, ch.defPitch) },
                                    onLongClick = { onSettings(ch) },
                                    onDoubleClick = { onRoll(i) },
                                ),
                            ) {
                                Text(ch.name, color = Color(ch.color), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(if (ch.insert == 0) "Master" else "Track ${ch.insert}", color = FlDim, fontSize = 9.sp)
                            }
                            Knob(ch.vol, { ch.vol = it; changed() }, FlOrange, size = 26.dp)
                            Spacer(Modifier.width(4.dp))
                            Knob((ch.pan + 1f) / 2f, { ch.pan = it * 2f - 1f; changed() }, Color(0xFF5BC0EB), size = 26.dp)
                        }
                    }
                }
                Box(Modifier.horizontalScroll(rememberScrollState())) {
                    val gridW = cell * cols
                    val hh = rowH * chans.size
                    var paint by remember { mutableStateOf(true) }
                    fun isOn(rr: Int, c: Int): Boolean = chans.getOrNull(rr)?.notes?.get(pi)?.any { it.start == c * STEP } == true
                    fun setOn(rr: Int, c: Int, on: Boolean) {
                        val ch = chans.getOrNull(rr) ?: return
                        val list = ch.notes[pi]
                        val ex = list.filter { it.start == c * STEP }
                        if (on) {
                            if (ex.isEmpty()) {
                                list.add(Note(c * STEP, STEP, ch.defPitch, 0.85f))
                                engine.audition(ch, ch.defPitch)
                            }
                        } else {
                            for (n in ex) list.remove(n)
                        }
                        changed()
                    }
                    Canvas(
                        Modifier.width(gridW).height(hh)
                            .pointerInput(chans.size, cols, cell, pi) {
                                detectTapGestures { p ->
                                    val c = (p.x / cell.toPx()).toInt().coerceIn(0, cols - 1)
                                    val rr = (p.y / rowH.toPx()).toInt().coerceIn(0, max(0, chans.size - 1))
                                    setOn(rr, c, !isOn(rr, c))
                                }
                            }
                            .pointerInput(chans.size, cols, cell, pi) {
                                detectHorizontalDragGestures(
                                    onDragStart = { p ->
                                        val c = (p.x / cell.toPx()).toInt().coerceIn(0, cols - 1)
                                        val rr = (p.y / rowH.toPx()).toInt().coerceIn(0, max(0, chans.size - 1))
                                        paint = !isOn(rr, c)
                                        setOn(rr, c, paint)
                                    },
                                    onHorizontalDrag = { ch, _ ->
                                        val c = (ch.position.x / cell.toPx()).toInt().coerceIn(0, cols - 1)
                                        val rr = (ch.position.y / rowH.toPx()).toInt().coerceIn(0, max(0, chans.size - 1))
                                        if (isOn(rr, c) != paint) setOn(rr, c, paint)
                                    },
                                )
                            },
                    ) {
                        val cw = cell.toPx()
                        val rh = rowH.toPx()
                        val gap = 2.5.dp.toPx()
                        val ph = engine.tick + 0 * clock.intValue
                        if (engine.playing && !engine.songMode) {
                            drawRect(Color.White.copy(alpha = 0.10f), Offset((ph / STEP) * cw, 0f), Size(cw, rh * chans.size))
                        }
                        for ((rr, ch) in chans.withIndex()) {
                            val on = HashSet<Int>()
                            for (n in ch.notes[pi]) if (n.start % STEP == 0) on.add(n.start / STEP)
                            for (c in 0 until cols) {
                                val x = c * cw + gap / 2f
                                val y = rr * rh + gap / 2f + 2.dp.toPx()
                                val grp = (c / 4) % 2 == 0
                                val base = if (grp) Color(0xFF39404A) else Color(0xFF2E343C)
                                val col = if (c in on) Color(ch.color) else base
                                drawRoundRect(col, Offset(x, y), Size(cw - gap, rh - gap - 4.dp.toPx()), CornerRadius(6.dp.toPx()))
                            }
                        }
                    }
                }
            }
            Row(Modifier.padding(start = 12.dp, top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "+ Add channel", Modifier.clip(RoundedCornerShape(8.dp)).background(FlOrange).clickable { onAdd() }.padding(horizontal = 14.dp, vertical = 9.dp),
                    color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                )
            }
            Text(
                "Tap a name to hear it, hold it for settings, double tap for the piano roll. Tap or swipe the squares to place hits. Turn the knobs: orange is volume, blue is pan.",
                Modifier.padding(12.dp), color = FlDim, fontSize = 11.sp,
            )
        }
    }
}

@Composable
private fun ChannelDialog(engine: StudioEngine, ch: Channel, onClose: () -> Unit, changed: () -> Unit, onPickSong: () -> Unit, onDelete: () -> Unit) {
    var tick by remember { mutableIntStateOf(0) }
    @Suppress("UNUSED_VARIABLE") val t = tick
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = FlPanel,
        title = { Text(ch.name, color = Color(ch.color)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Goes to mixer track", color = FlDim, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (i in 0 until INSERTS) FilterChip(selected = ch.insert == i, onClick = { ch.insert = i; changed(); tick++ }, label = { Text(if (i == 0) "Master" else "$i") })
                }
                when (ch.type) {
                    0 -> {
                        Text("Sound", color = FlDim, fontSize = 12.sp)
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            engine.kitNames.forEachIndexed { i, n ->
                                FilterChip(selected = ch.kit == i, onClick = { ch.kit = i; ch.name = n; changed(); tick++; engine.audition(ch) }, label = { Text(n) })
                            }
                        }
                    }
                    1 -> {
                        Text("Wave", color = FlDim, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Sine", "Square", "Saw", "Pluck").forEachIndexed { i, n ->
                                FilterChip(selected = ch.wave == i, onClick = { ch.wave = i; changed(); tick++; engine.audition(ch, ch.defPitch) }, label = { Text(n) })
                            }
                        }
                        Text("Brightness", color = FlDim, fontSize = 12.sp)
                        Slider(value = ch.cutoff, onValueChange = { ch.cutoff = it; changed(); tick++ })
                        Text("Attack", color = FlDim, fontSize = 12.sp)
                        Slider(value = ch.attack, onValueChange = { ch.attack = it; changed(); tick++ })
                        Text("Release", color = FlDim, fontSize = 12.sp)
                        Slider(value = ch.release, onValueChange = { ch.release = it; changed(); tick++ })
                    }
                    else -> {
                        Text(ch.title.ifBlank { "No song picked" }, color = FlText)
                        TextButton(onClick = onPickSong) { Text("Pick another piece of a song") }
                    }
                }
                Text("Volume", color = FlDim, fontSize = 12.sp)
                Slider(value = ch.vol, onValueChange = { ch.vol = it; changed(); tick++ })
                Text("Pan", color = FlDim, fontSize = 12.sp)
                Slider(value = ch.pan, onValueChange = { ch.pan = it; changed(); tick++ }, valueRange = -1f..1f)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = ch.solo, onClick = { ch.solo = !ch.solo; changed(); tick++ }, label = { Text("Solo") })
                    FilterChip(selected = ch.mute, onClick = { ch.mute = !ch.mute; changed(); tick++ }, label = { Text("Mute") })
                }
                TextButton(onClick = onDelete) { Text("Delete channel", color = Color(0xFFFF6B6B)) }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Done") } },
    )
}

// ====================================================================== piano roll

@Composable
private fun RollView(
    engine: StudioEngine, chans: List<Channel>, sel: Int, bars: Int, snap: Int, vel: Float, chord: Int, scale: Int, low: Int,
    clock: androidx.compose.runtime.MutableIntState, rev: Int,
    onSel: (Int) -> Unit, onSnap: (Int) -> Unit, onVel: (Float) -> Unit, onChord: (Int) -> Unit, onScale: (Int) -> Unit,
    onLow: (Int) -> Unit, changed: () -> Unit,
) {
    @Suppress("UNUSED_VARIABLE") val r = rev
    val ch = chans.getOrNull(sel)
    if (ch == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Add a channel first", color = FlDim) }
        return
    }
    val pi = engine.curPattern
    val rowsN = 36
    val high = low + rowsN - 1
    val rowH = 22.dp
    val ppt = 1.3.dp
    val ticks = bars * BAR
    val inScale: Set<Int>? = when (scale) { 1 -> majorScale; 2 -> minorScale; else -> null }
    val vScroll = rememberScrollState()
    LaunchedEffect(low) { vScroll.scrollTo(150) }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            chans.forEachIndexed { i, c ->
                FilterChip(selected = i == sel, onClick = { onSel(i) }, label = { Text(c.name, fontSize = 12.sp, color = if (i == sel) FlText else Color(c.color)) })
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Snap", color = FlDim, fontSize = 11.sp)
            for ((n, t) in listOf("1/4" to 96, "1/8" to 48, "1/16" to 24, "1/32" to 12)) FilterChip(selected = snap == t, onClick = { onSnap(t) }, label = { Text(n, fontSize = 11.sp) })
            Text("Chord", color = FlDim, fontSize = 11.sp)
            for ((i, n) in listOf("Off", "Maj", "Min", "7th").withIndex()) FilterChip(selected = chord == i, onClick = { onChord(i) }, label = { Text(n, fontSize = 11.sp) })
            Text("Scale", color = FlDim, fontSize = 11.sp)
            for ((i, n) in listOf("Chromatic", "Major", "Minor").withIndex()) FilterChip(selected = scale == i, onClick = { onScale(i) }, label = { Text(n, fontSize = 11.sp) })
            Text("Octave", color = FlDim, fontSize = 11.sp)
            FilterChip(selected = false, onClick = { onLow(max(12, low - 12)) }, label = { Text("−", fontSize = 11.sp) })
            FilterChip(selected = false, onClick = { onLow(min(72, low + 12)) }, label = { Text("+", fontSize = 11.sp) })
        }
        Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Velocity", color = FlDim, fontSize = 11.sp)
            Slider(value = vel, onValueChange = onVel, modifier = Modifier.weight(1f).height(28.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth().verticalScroll(vScroll)) {
            Row {
                Column(Modifier.width(44.dp)) {
                    for (i in 0 until rowsN) {
                        val p = high - i
                        Box(
                            Modifier.height(rowH).fillMaxWidth().background(if (isBlack(p)) Color(0xFF0E1013) else Color(0xFFD9DDE2))
                                .border(0.5.dp, FlLine).clickable { engine.audition(ch, p) }.padding(end = 3.dp),
                            contentAlignment = Alignment.CenterEnd,
                        ) {
                            if (p % 12 == 0 || isBlack(p).not() && inScale != null && (p % 12) in inScale) {
                                Text(pitchName(p), fontSize = 9.sp, color = if (isBlack(p)) FlText else Color(0xFF30363D))
                            }
                        }
                    }
                }
                Box(Modifier.horizontalScroll(rememberScrollState())) {
                    Canvas(
                        Modifier.width(ppt * ticks).height(rowH * rowsN)
                            .pointerInput(ch.id, pi, snap, chord, vel, low, ticks) {
                                detectTapGestures { p ->
                                    val ptk = ppt.toPx()
                                    val rh = rowH.toPx()
                                    val tk = ((p.x / ptk).toInt() / snap) * snap
                                    val row = (p.y / rh).toInt().coerceIn(0, rowsN - 1)
                                    val pitch = high - row
                                    val list = ch.notes[pi]
                                    val hit = list.filter { it.pitch == pitch && tk >= it.start && tk < it.start + it.len }
                                    if (hit.isNotEmpty()) {
                                        for (n in hit) list.remove(n)
                                    } else if (tk < ticks) {
                                        val len = min(snap, ticks - tk)
                                        val extra = when (chord) { 1 -> listOf(4, 7); 2 -> listOf(3, 7); 3 -> listOf(4, 7, 10); else -> emptyList() }
                                        list.add(Note(tk, len, pitch, vel))
                                        for (e in extra) if (pitch + e <= 108) list.add(Note(tk, len, pitch + e, vel))
                                        ch.defPitch = pitch
                                        engine.audition(ch, pitch, max(len, 24))
                                    }
                                    changed()
                                }
                            },
                    ) {
                        val ptk = ppt.toPx()
                        val rh = rowH.toPx()
                        for (i in 0 until rowsN) {
                            val p = high - i
                            val inKey = inScale == null || (p % 12) in inScale
                            val c = if (isBlack(p)) Color(0xFF1B1F24) else Color(0xFF242A31)
                            drawRect(if (inKey) c else Color(0xFF14171A), Offset(0f, i * rh), Size(ticks * ptk, rh))
                            if (inScale != null && (p % 12 == 0)) drawRect(FlOrange.copy(alpha = 0.10f), Offset(0f, i * rh), Size(ticks * ptk, rh))
                            drawLine(Color(0xFF30363D), Offset(0f, i * rh), Offset(ticks * ptk, i * rh), 1f)
                        }
                        var t = 0
                        while (t <= ticks) {
                            val major = t % BAR == 0
                            val beat = t % 96 == 0
                            drawLine(
                                if (major) Color(0xFF6B7480) else if (beat) Color(0xFF4A525C) else Color(0xFF2E343C),
                                Offset(t * ptk, 0f), Offset(t * ptk, rh * rowsN), if (major) 2.5f else 1f,
                            )
                            t += STEP
                        }
                        for (n in ch.notes[pi]) {
                            val row = high - n.pitch
                            if (row < 0 || row >= rowsN) continue
                            drawRoundRect(
                                Color(ch.color).copy(alpha = 0.45f + 0.55f * n.vel),
                                Offset(n.start * ptk + 1f, row * rh + 1.5f), Size(n.len * ptk - 2f, rh - 3f), CornerRadius(4.dp.toPx()),
                            )
                        }
                        if (engine.playing && !engine.songMode) {
                            val x = (engine.tick + 0 * clock.intValue) * ptk
                            drawLine(Color.White, Offset(x, 0f), Offset(x, rh * rowsN), 3f)
                        }
                    }
                }
            }
        }
    }
}

// ====================================================================== playlist

@Composable
private fun PlaylistView(engine: StudioEngine, rev: Int, clock: androidx.compose.runtime.MutableIntState, changed: () -> Unit) {
    @Suppress("UNUSED_VARIABLE") val r = rev
    val tracksN = 6
    val barsN = 32
    val cw = 46.dp
    val rh = 40.dp
    var brush by remember { mutableIntStateOf(engine.curPattern) }
    if (brush >= engine.patterns.size) brush = 0
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Paint with", color = FlDim, fontSize = 11.sp)
            engine.patterns.forEachIndexed { i, p ->
                FilterChip(selected = brush == i, onClick = { brush = i }, label = { Text(p.name, fontSize = 12.sp, color = Color(p.color)) })
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
            Row(Modifier.padding(horizontal = 6.dp)) {
                Column(Modifier.width(52.dp)) {
                    Spacer(Modifier.height(22.dp))
                    for (i in 0 until tracksN) {
                        Box(Modifier.height(rh).fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(6.dp)).background(FlPanel), contentAlignment = Alignment.Center) {
                            Text("Track ${i + 1}", color = FlDim, fontSize = 10.sp)
                        }
                    }
                }
                Box(Modifier.horizontalScroll(rememberScrollState())) {
                    Column {
                        Canvas(Modifier.width(cw * barsN).height(22.dp)) {
                            for (b in 0 until barsN) {
                                drawLine(FlLine, Offset(b * cw.toPx(), 0f), Offset(b * cw.toPx(), 22.dp.toPx()), 1.5f)
                            }
                        }
                        Box {
                            Canvas(
                                Modifier.width(cw * barsN).height(rh * tracksN)
                                    .pointerInput(brush) {
                                        detectTapGestures { p ->
                                            val bar = (p.x / cw.toPx()).toInt().coerceIn(0, barsN - 1)
                                            val tr = (p.y / rh.toPx()).toInt().coerceIn(0, tracksN - 1)
                                            val hit = engine.clips.firstOrNull { c ->
                                                val len = engine.patterns.getOrNull(c.pattern)?.bars ?: 1
                                                c.track == tr && bar >= c.bar && bar < c.bar + len
                                            }
                                            if (hit != null) {
                                                engine.clips.remove(hit)
                                            } else {
                                                val len = engine.patterns.getOrNull(brush)?.bars ?: 1
                                                val clash = engine.clips.any { c ->
                                                    val l2 = engine.patterns.getOrNull(c.pattern)?.bars ?: 1
                                                    c.track == tr && c.bar < bar + len && bar < c.bar + l2
                                                }
                                                if (!clash) engine.clips.add(Clip(tr, bar, brush))
                                            }
                                            changed()
                                        }
                                    },
                            ) {
                                val w = cw.toPx()
                                val h = rh.toPx()
                                for (tr in 0 until tracksN) {
                                    for (b in 0 until barsN) {
                                        drawRoundRect(
                                            if ((b / 4) % 2 == 0) Color(0xFF262C33) else Color(0xFF20252B),
                                            Offset(b * w + 1f, tr * h + 2f), Size(w - 2f, h - 4f), CornerRadius(4.dp.toPx()),
                                        )
                                    }
                                }
                                for (c in engine.clips) {
                                    val p = engine.patterns.getOrNull(c.pattern) ?: continue
                                    drawRoundRect(
                                        Color(p.color).copy(alpha = 0.9f),
                                        Offset(c.bar * w + 1.5f, c.track * h + 3f), Size(p.bars * w - 3f, h - 6f), CornerRadius(6.dp.toPx()),
                                    )
                                }
                                if (engine.playing && engine.songMode) {
                                    val x = (engine.tick + 0 * clock.intValue) / BAR.toFloat() * w
                                    drawLine(Color.White, Offset(x, 0f), Offset(x, h * tracksN), 3f)
                                }
                            }
                            for (c in engine.clips) {
                                val p = engine.patterns.getOrNull(c.pattern) ?: continue
                                Text(
                                    p.name, Modifier.offset(cw * c.bar + 8.dp, rh * c.track + 11.dp).width(cw * p.bars - 12.dp),
                                    color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
            }
        }
        Text(
            "Pick a pattern, then tap a square to place it. Tap a placed pattern to remove it. Switch to SONG at the top and press play to hear the arrangement.",
            Modifier.padding(10.dp), color = FlDim, fontSize = 11.sp,
        )
    }
}

// ====================================================================== mixer

@Composable
private fun MixerView(engine: StudioEngine, clock: androidx.compose.runtime.MutableIntState, rev: Int, onFx: (Int, Int) -> Unit, changed: () -> Unit) {
    @Suppress("UNUSED_VARIABLE") val r = rev
    Row(Modifier.fillMaxSize().horizontalScroll(rememberScrollState()).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (i in 1 until INSERTS) { MixerStrip(engine, i, clock, onFx, changed) }
        Spacer(Modifier.width(6.dp))
        MixerStrip(engine, 0, clock, onFx, changed)
    }
}

@Composable
private fun MixerStrip(engine: StudioEngine, i: Int, clock: androidx.compose.runtime.MutableIntState, onFx: (Int, Int) -> Unit, changed: () -> Unit) {
    val ins = engine.inserts[i]
    val accent = if (i == 0) FlOrange else Color(0xFF5BC0EB)
    Column(
        Modifier.width(86.dp).fillMaxHeight().clip(RoundedCornerShape(12.dp)).background(FlPanel).padding(6.dp).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(ins.name, color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        for (s in 0 until 3) {
            val slot = ins.slots[s]
            Text(
                if (slot.type == 0) "—" else fxNames[slot.type],
                Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(6.dp))
                    .background(if (slot.type == 0) FlPanel2 else Color(0xFF4A3420)).clickable { onFx(i, s) }.padding(vertical = 5.dp),
                color = if (slot.type == 0) FlDim else FlOrange, fontSize = 10.sp, maxLines = 1,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            )
        }
        Spacer(Modifier.height(6.dp))
        if (i != 0) Knob((ins.pan + 1f) / 2f, { ins.pan = it * 2f - 1f; changed() }, Color(0xFF5BC0EB), size = 30.dp)
        Spacer(Modifier.height(6.dp))
        Fader(ins.vol / 1.2f, { ins.vol = it * 1.2f; changed() }, { engine.inserts[i].peak + 0 * clock.intValue }, accent)
        Spacer(Modifier.height(6.dp))
        if (i != 0) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    "M", Modifier.clip(RoundedCornerShape(5.dp)).background(if (ins.mute) Color(0xFFFF6B6B) else FlPanel2).clickable { ins.mute = !ins.mute; changed() }.padding(horizontal = 9.dp, vertical = 5.dp),
                    color = if (ins.mute) Color.Black else FlDim, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                )
                Text(
                    "S", Modifier.clip(RoundedCornerShape(5.dp)).background(if (ins.solo) FlGreen else FlPanel2).clickable { ins.solo = !ins.solo; changed() }.padding(horizontal = 9.dp, vertical = 5.dp),
                    color = if (ins.solo) Color.Black else FlDim, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                )
            }
        }
    }
}

@Composable
private fun FxDialog(engine: StudioEngine, slot: FxSlot, onClose: () -> Unit, changed: () -> Unit) {
    var tick by remember { mutableIntStateOf(0) }
    @Suppress("UNUSED_VARIABLE") val t = tick
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = FlPanel,
        title = { Text("Effect") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    fxNames.forEachIndexed { i, n ->
                        FilterChip(selected = slot.type == i, onClick = { engine.setFx(slot, i); changed(); tick++ }, label = { Text(n) })
                    }
                }
                if (slot.type != 0) {
                    val labels = fxLabels[slot.type]
                    Text(labels[0], color = FlDim, fontSize = 12.sp)
                    Slider(value = slot.p1, onValueChange = { slot.p1 = it; changed(); tick++ })
                    Text(labels[1], color = FlDim, fontSize = 12.sp)
                    Slider(value = slot.p2, onValueChange = { slot.p2 = it; changed(); tick++ })
                    Text(labels[2], color = FlDim, fontSize = 12.sp)
                    Slider(value = slot.p3, onValueChange = { slot.p3 = it; changed(); tick++ })
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Done") } },
    )
}
