package com.hwush.player.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.platform.LocalHapticFeedback
import com.hwush.player.player.PlayerHolder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.min

/**
 * Shared state for swiping the cover to change song. The cover follows the finger, flies out on release,
 * the song changes, and the new cover slides in. While it moves fast it leaves a blur trail behind it.
 */
class CoverSwipe(private val scope: CoroutineScope, private val holder: PlayerHolder) {
    val off = Animatable(0f)
    var dragging by mutableStateOf(false)
    var dragV by mutableFloatStateOf(0f)

    /** True from the moment a swipe is released until the new cover has settled. */
    var busy by mutableStateOf(false)
    var width = 1000f

    /** Signed speed in pixels per second. */
    fun speed(): Float = if (dragging) dragV else off.velocity

    fun drag(dx: Float, vx: Float) {
        dragV = vx
        scope.launch { off.snapTo(dx) }
    }

    fun settle(dx: Float, vx: Float, onSwitch: () -> Unit) {
        scope.launch {
            val far = abs(dx) > width * 0.22f
            val fling = abs(vx) > 900f
            if (!far && !fling) {
                off.animateTo(0f, spring(dampingRatio = 0.62f, stiffness = 380f))
                return@launch
            }
            val toNext = if (far) dx < 0f else vx < 0f
            val away = if (toNext) -width * 1.2f else width * 1.2f
            busy = true
            off.animateTo(away, tween(170, easing = FastOutLinearInEasing), initialVelocity = vx)
            off.snapTo(-away)
            onSwitch()
            if (toNext) holder.next() else holder.previous()
            off.animateTo(0f, spring(dampingRatio = 0.7f, stiffness = 260f))
            busy = false
        }
    }
}

@Composable
fun rememberCoverSwipe(holder: PlayerHolder): CoverSwipe {
    val scope = rememberCoroutineScope()
    return remember(holder) { CoverSwipe(scope, holder) }
}

/**
 * Moves what it wraps with the swipe and smears it. [style] 0 streaks sideways, 1 is meant to wrap the cover and
 * the title together, 2 tilts like a card and smears as a zoom.
 */
@Composable
fun Modifier.swipeFx(swipe: CoverSwipe, style: Int): Modifier {
    val layer = rememberGraphicsLayer()
    return this
        .graphicsLayer {
            val o = swipe.off.value
            swipe.width = size.width.coerceAtLeast(1f)
            translationX = o
            if (style == 2) {
                rotationZ = o / 26f
                val s = 1f - min(abs(o) / swipe.width, 1f) * 0.2f
                scaleX = s
                scaleY = s
            } else if (style == 0) {
                rotationZ = o / 70f
            }
        }
        .drawWithContent {
            layer.record { this@drawWithContent.drawContent() }
            val v = swipe.speed()
            val reach = if (style == 2) size.width * 0.16f else size.width * 0.5f
            val len = min(abs(v) * (if (style == 2) 0.02f else 0.06f), reach)
            if (len > 5f) {
                val n = 8
                val pivot = Offset(size.width / 2f, size.height / 2f)
                for (i in n downTo 1) {
                    val f = i / n.toFloat()
                    layer.alpha = 0.17f * (1f - f * 0.55f)
                    if (style == 2) {
                        val z = 1f + (len / size.width) * f * 1.4f
                        scale(z, z, pivot) { drawLayer(layer) }
                    } else {
                        // The trail lies behind the motion: a leftward swipe smears to the right of the cover.
                        translate(left = -(if (v > 0f) 1f else -1f) * len * f, top = 0f) { drawLayer(layer) }
                    }
                }
                layer.alpha = 1f
            }
            drawLayer(layer)
        }
}

/** Swipe sideways to change song, up for favorite, down to close. Double tap: edges jump 10 s, middle plays or pauses. */
@Composable
fun Modifier.coverSwipeGestures(
    holder: PlayerHolder,
    swipe: CoverSwipe,
    onFavorite: () -> Unit,
    onClose: (() -> Unit)?,
): Modifier {
    val haptic = LocalHapticFeedback.current
    val favNow by rememberUpdatedState(onFavorite)
    val closeNow by rememberUpdatedState(onClose)
    return this
        .pointerInput(Unit) {
            detectTapGestures(onDoubleTap = { o ->
                val third = size.width / 3f
                when {
                    o.x < third -> holder.seekBy(-10_000L)
                    o.x > third * 2f -> holder.seekBy(10_000L)
                    else -> holder.togglePlay()
                }
            })
        }
        .pointerInput(Unit) {
            var dx = 0f
            var dy = 0f
            var locked = 0 // 0 undecided, 1 horizontal, 2 vertical
            val tracker = VelocityTracker()
            detectDragGestures(
                onDragStart = {
                    dx = 0f
                    dy = 0f
                    locked = 0
                    tracker.resetTracking()
                    swipe.dragging = true
                },
                onDrag = { change, amount ->
                    change.consume()
                    tracker.addPosition(change.uptimeMillis, change.position)
                    dx += amount.x
                    dy += amount.y
                    if (locked == 0 && (abs(dx) > 14f || abs(dy) > 14f)) locked = if (abs(dx) >= abs(dy)) 1 else 2
                    if (locked == 1) swipe.drag(dx, tracker.calculateVelocity().x)
                },
                onDragEnd = {
                    swipe.dragging = false
                    if (locked == 1) {
                        val vx = tracker.calculateVelocity().x
                        swipe.settle(dx, vx) { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove) }
                    } else {
                        if (dy < -150f) favNow() else if (dy > 170f) closeNow?.invoke()
                        swipe.settle(0f, 0f) {}
                    }
                },
                onDragCancel = {
                    swipe.dragging = false
                    swipe.settle(0f, 0f) {}
                },
            )
        }
}
