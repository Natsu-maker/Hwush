package com.hwush.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val LETTERS: List<Char> = listOf('#') + ('A'..'Z').toList()

/** The letter a list is filed under: A to Z, or # for numbers and symbols. */
fun letterOf(text: String): Char {
    val c = text.trimStart().firstOrNull()?.uppercaseChar() ?: return '#'
    return if (c in 'A'..'Z') c else '#'
}

/**
 * A strip of letters on the right edge. Drag a finger along it to jump through a sorted list; a bubble shows
 * the letter. [firstIndex] maps each letter to the first list position that starts with it.
 */
@Composable
fun AlphaScrubber(
    firstIndex: Map<Char, Int>,
    onJump: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    var active by remember { mutableStateOf(false) }
    var current by remember { mutableIntStateOf(0) }
    val primary = MaterialTheme.colorScheme.primary

    Box(modifier.fillMaxHeight().padding(vertical = 8.dp), contentAlignment = Alignment.CenterEnd) {
        AnimatedVisibility(
            visible = active,
            enter = fadeIn() + scaleIn(initialScale = 0.7f),
            exit = fadeOut() + scaleOut(targetScale = 0.7f),
            modifier = Modifier.align(Alignment.Center).padding(end = 48.dp),
        ) {
            Box(
                Modifier.size(72.dp).clip(RoundedCornerShape(24.dp)).background(primary.copy(alpha = 0.92f)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    LETTERS[current].toString(),
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }
        Column(
            Modifier
                .width(26.dp)
                .fillMaxHeight()
                .clip(RoundedCornerShape(13.dp))
                .background(if (active) MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.7f) else Color.Transparent)
                .pointerInput(firstIndex) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        fun pick(y: Float) {
                            val i = (y / size.height * LETTERS.size).toInt().coerceIn(0, LETTERS.size - 1)
                            current = i
                            // A letter with no items jumps to the next one that has some.
                            var j = i
                            while (j < LETTERS.size && firstIndex[LETTERS[j]] == null) j++
                            if (j >= LETTERS.size) {
                                j = i
                                while (j >= 0 && firstIndex[LETTERS[j]] == null) j--
                            }
                            val idx = firstIndex[LETTERS.getOrNull(j)]
                            if (idx != null) onJump(idx)
                        }
                        active = true
                        pick(down.position.y)
                        down.consume()
                        while (true) {
                            val ev = awaitPointerEvent(PointerEventPass.Main)
                            val ch = ev.changes.firstOrNull() ?: break
                            if (!ch.pressed) break
                            pick(ch.position.y)
                            ch.consume()
                        }
                        active = false
                    }
                },
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceEvenly,
        ) {
            for ((i, l) in LETTERS.withIndex()) {
                val has = firstIndex[l] != null
                Text(
                    l.toString(),
                    fontSize = 10.sp,
                    fontWeight = if (active && i == current) FontWeight.Bold else FontWeight.Medium,
                    color = when {
                        active && i == current -> primary
                        has -> MaterialTheme.colorScheme.onSurfaceVariant
                        else -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.3f)
                    },
                )
            }
        }
    }
}

/** Builds the letter to first-position map for a list. [offset] is how many items sit before the first entry. */
fun <T> letterIndex(items: List<T>, offset: Int, text: (T) -> String): Map<Char, Int> {
    val m = LinkedHashMap<Char, Int>()
    for ((i, it) in items.withIndex()) {
        val l = letterOf(text(it))
        if (!m.containsKey(l)) m[l] = i + offset
    }
    return m
}
