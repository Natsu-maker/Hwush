package com.hwush.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.LrcLib
import com.hwush.player.data.LyricHit
import com.hwush.player.data.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Search for lyrics online and keep the one that fits. Timed lyrics make the karaoke view follow the singing. */
@Composable
fun OnlineLyricsDialog(ui: UiController, track: Track, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val app = ui.app
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf(track.title) }
    var artist by remember { mutableStateOf(if (track.artist == "Unknown artist") "" else track.artist) }
    var hits by remember { mutableStateOf<List<LyricHit>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }

    fun search() {
        if (busy || title.isBlank()) return
        busy = true
        msg = null
        scope.launch {
            try {
                hits = LrcLib.search(title, artist)
                if (hits.isEmpty()) msg = "Nothing found. Try a shorter title or no artist."
            } catch (e: LrcLib.Failure) {
                msg = e.msg
            }
            busy = false
        }
    }

    fun use(h: LyricHit) {
        val text = h.synced ?: h.plain ?: return
        scope.launch {
            val uri = withContext(Dispatchers.IO) {
                val dir = File(ctx.filesDir, "lyrics").also { it.mkdirs() }
                val f = File(dir, "${track.path.hashCode().toUInt()}.lrc")
                f.writeText(text)
                android.net.Uri.fromFile(f).toString()
            }
            app.store.setSongLyrics(track.path, uri)
            app.lyricsRev.intValue++
            ui.say(if (h.synced != null) "Timed lyrics saved" else "Lyrics saved, without timing")
            onClose()
        }
    }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Find lyrics online") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Song") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(artist, { artist = it }, label = { Text("Artist (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = { search() }, enabled = !busy && title.isNotBlank()) { Text(if (busy) "Searching…" else "Search") }
                msg?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                if (hits.isNotEmpty()) {
                    Text("Tap one to use it. Timed ones light up word by word.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    LazyColumn(Modifier.heightIn(max = 280.dp)) {
                        items(hits.size) { i ->
                            val h = hits[i]
                            Column(
                                Modifier.fillMaxWidth().clickable(enabled = !h.instrumental) { use(h) }.padding(vertical = 8.dp),
                            ) {
                                Text(h.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${h.artist} · ${h.album}", style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        when {
                                            h.instrumental -> "Instrumental"
                                            h.synced != null -> "Timed"
                                            else -> "Text only"
                                        },
                                        style = MaterialTheme.typography.labelMedium,
                                        color = if (h.synced != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                    if (h.durationSec > 0) {
                                        val diff = h.durationSec - (track.durationMs / 1000L).toInt()
                                        Text(
                                            "${h.durationSec / 60}:%02d".format(h.durationSec % 60) + if (kotlin.math.abs(diff) <= 2) "  matches your song" else "  ${if (diff > 0) "+" else ""}${diff}s",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        )
                                    }
                                }
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onClose) { Text("Close") } },
    )
}
