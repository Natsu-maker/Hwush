package com.hwush.player.data

import android.net.Uri
import com.hwush.player.HwushApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Collections

/**
 * Finds lyrics for songs that have none. It asks LRCLIB with the title, artist and length and keeps the best timed
 * match whose length agrees with the song, so the wrong version of a song is not picked.
 */
object AutoLyrics {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val tried: MutableSet<String> = Collections.synchronizedSet(HashSet())
    private val _status = MutableStateFlow<String?>(null)

    /** Progress text of the bulk run, or null when idle. */
    val status: StateFlow<String?> = _status

    @Volatile private var bulkJob: kotlinx.coroutines.Job? = null

    /** Watches what is playing and looks the lyrics up when there are none. */
    fun watch(app: HwushApp) {
        scope.launch {
            app.player.ui.map { it.path }.distinctUntilChanged().collect { path ->
                if (path == null || !app.store.data.value.autoLyrics) return@collect
                val t = app.library.find(path) ?: return@collect
                delay(2500L) // let the song settle, a quick skip should not cost a request
                if (app.player.ui.value.path != path) return@collect
                try {
                    if (fetchFor(app, t)) app.lyricsRev.intValue++
                } catch (_: Exception) {
                }
            }
        }
    }

    /** Returns true when lyrics were found and saved. Songs that already have lyrics are left alone. */
    suspend fun fetchFor(app: HwushApp, t: Track): Boolean {
        if (!tried.add(t.path)) return false
        if (app.lyrics.find(t) != null) return false
        val artist = if (t.artist == "Unknown artist") "" else t.artist
        val title = cleanTitle(t.title)
        if (title.isBlank()) return false
        val hits = try {
            LrcLib.search(title, artist)
        } catch (_: LrcLib.Failure) {
            tried.remove(t.path) // offline: try again later
            return false
        }
        val secs = (t.durationMs / 1000L).toInt()
        fun close(h: LyricHit) = secs <= 0 || h.durationSec <= 0 || kotlin.math.abs(h.durationSec - secs) <= 3
        val pick = hits.firstOrNull { !it.instrumental && it.synced != null && close(it) }
            ?: hits.firstOrNull { !it.instrumental && it.plain != null && close(it) && it.title.equals(title, true) }
            ?: return false
        val text = pick.synced ?: pick.plain ?: return false
        val uri = withContext(Dispatchers.IO) {
            val dir = File(app.filesDir, "lyrics").also { it.mkdirs() }
            val f = File(dir, "${t.path.hashCode().toUInt()}.lrc")
            f.writeText(text)
            Uri.fromFile(f).toString()
        }
        app.store.setSongLyrics(t.path, uri)
        return true
    }

    /** Goes through the whole library, one song at a time, and fills in the missing lyrics. */
    fun runAll(app: HwushApp) {
        if (bulkJob?.isActive == true) return
        bulkJob = scope.launch {
            val all = app.library.tracks.value
            var done = 0
            var found = 0
            for (t in all) {
                _status.value = "Looking up lyrics… $done of ${all.size}, found $found"
                try {
                    if (fetchFor(app, t)) found++
                } catch (_: Exception) {
                }
                done++
                delay(350L)
            }
            app.lyricsRev.intValue++
            _status.value = "Done: lyrics added to $found of ${all.size} songs"
        }
    }

    fun stopAll() {
        bulkJob?.cancel()
        _status.value = null
    }

    /** "Song (Remastered 2011)" and "Song [Official Video]" search better as just "Song". */
    private fun cleanTitle(s: String): String =
        s.replace(Regex("\\s*[\\[(][^\\])]*(official|video|audio|lyrics?|remaster|remastered|hd|hq|mv)[^\\])]*[\\])]", RegexOption.IGNORE_CASE), "")
            .trim()
}
