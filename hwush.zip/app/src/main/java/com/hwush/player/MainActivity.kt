package com.hwush.player

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import com.hwush.player.ui.HwushRoot
import com.hwush.player.ui.HwushTheme
import com.hwush.player.ui.UiController
import com.hwush.player.ui.hasAudioPermission

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as HwushApp
        setContent {
            val scope = rememberCoroutineScope()
            val ui = remember { UiController(app, scope) }
            HwushTheme(app) { HwushRoot(ui) }
        }
    }

    override fun onStart() {
        super.onStart()
        if (hasAudioPermission(this)) (application as HwushApp).library.refresh()
    }

    override fun onStop() {
        (application as HwushApp).store.flush()
        super.onStop()
    }
}
