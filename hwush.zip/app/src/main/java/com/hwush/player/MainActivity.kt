package com.hwush.player

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import com.hwush.player.ui.HwushRoot
import com.hwush.player.ui.HwushTheme
import com.hwush.player.ui.UiController
import com.hwush.player.ui.hasAudioPermission

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as HwushApp
        handleIntent(intent)
        setContent {
            val scope = rememberCoroutineScope()
            val ui = remember { UiController(app, scope) }
            HwushTheme(app) { HwushRoot(ui) }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == ACTION_ADD_PLAYLIST) {
            (application as HwushApp).addToPlaylistRequest.intValue++
            intent.action = null
        }
    }

    override fun onStart() {
        super.onStart()
        if (hasAudioPermission(this)) (application as HwushApp).library.refresh()
    }

    override fun onStop() {
        (application as HwushApp).store.flush()
        super.onStop()
    }

    companion object {
        const val ACTION_ADD_PLAYLIST = "com.hwush.player.ADD_TO_PLAYLIST"
    }
}
