package com.hwush.player.widget

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.min
import kotlin.math.roundToInt

/** Draws the pictures a home screen widget is made of, since widgets cannot run Compose or blur things themselves. */
object WidgetRender {
    private const val DARK = 0xFF101218.toInt()
    private const val PAPER = 0xFFF4F5FA.toInt()

    private fun mix(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * k).roundToInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * k).roundToInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * k).roundToInt(),
        )
    }

    /** One strong colour that stands for the cover. */
    fun dominant(art: Bitmap?, fallback: Int): Int {
        if (art == null) return fallback
        return try {
            val s = Bitmap.createScaledBitmap(art, 6, 6, true)
            var r = 0f
            var g = 0f
            var b = 0f
            var wsum = 0f
            val hsv = FloatArray(3)
            for (y in 0 until 6) for (x in 0 until 6) {
                val c = s.getPixel(x, y)
                Color.colorToHSV(c, hsv)
                val w = 0.15f + hsv[1] * hsv[2]
                r += Color.red(c) * w
                g += Color.green(c) * w
                b += Color.blue(c) * w
                wsum += w
            }
            if (wsum <= 0f) return fallback
            Color.colorToHSV(Color.rgb((r / wsum).roundToInt(), (g / wsum).roundToInt(), (b / wsum).roundToInt()), hsv)
            hsv[1] = min(1f, hsv[1] * 1.25f + 0.08f)
            hsv[2] = hsv[2].coerceIn(0.55f, 0.95f)
            Color.HSVToColor(hsv)
        } catch (_: Exception) {
            fallback
        }
    }

    /** The widget's backdrop, with rounded corners and the chosen see-through amount already in it. */
    fun background(w: Int, h: Int, cornerPx: Float, style: Int, opacityPct: Int, art: Bitmap?, tint: Int, light: Boolean): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val rect = RectF(0f, 0f, w.toFloat(), h.toFloat())
        val clip = Path().apply { addRoundRect(rect, cornerPx, cornerPx, Path.Direction.CW) }
        c.clipPath(clip)
        val alpha = (opacityPct.coerceIn(10, 100) / 100f * 255f).roundToInt()
        val base = if (light) PAPER else DARK
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        when (style) {
            0 -> {
                paint.color = base
                paint.alpha = alpha
                c.drawRect(rect, paint)
            }
            1 -> {
                val c1 = mix(base, tint, if (light) 0.32f else 0.62f)
                val c2 = mix(base, tint, if (light) 0.08f else 0.14f)
                paint.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), c1, c2, Shader.TileMode.CLAMP)
                paint.alpha = alpha
                c.drawRect(rect, paint)
            }
            2 -> {
                if (art != null) {
                    // Shrinking the cover to a dozen pixels and stretching it back gives a soft wash of its colours.
                    val tiny = Bitmap.createScaledBitmap(art, 12, 12, true)
                    val p2 = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                    p2.alpha = alpha
                    c.drawBitmap(tiny, null, rect, p2)
                    paint.color = if (light) 0xB8F4F5FA.toInt() else 0x99101218.toInt()
                    paint.alpha = (Color.alpha(paint.color) * alpha / 255f).roundToInt()
                    c.drawRect(rect, paint)
                } else {
                    paint.color = base
                    paint.alpha = alpha
                    c.drawRect(rect, paint)
                }
            }
            else -> {
                // Glass: mostly see-through, with a faint tint and a bright edge.
                paint.color = if (light) 0xFFFFFFFF.toInt() else mix(DARK, tint, 0.25f)
                paint.alpha = (alpha * 0.5f).roundToInt()
                c.drawRect(rect, paint)
                val edge = Paint(Paint.ANTI_ALIAS_FLAG)
                edge.style = Paint.Style.STROKE
                edge.strokeWidth = 3f
                edge.color = if (light) 0x55000000 else 0x55FFFFFF
                c.drawRoundRect(RectF(1.5f, 1.5f, w - 1.5f, h - 1.5f), cornerPx, cornerPx, edge)
            }
        }
        return bmp
    }

    /** The cover cut to a rounded square, a circle or a plain square. */
    fun cover(src: Bitmap?, px: Int, shape: Int, tint: Int): Bitmap {
        val out = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        if (src != null) {
            val side = min(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val scaled = Bitmap.createScaledBitmap(sq, px, px, true)
            paint.shader = BitmapShader(scaled, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        } else {
            paint.shader = LinearGradient(0f, 0f, px.toFloat(), px.toFloat(), tint, mix(tint, DARK, 0.7f), Shader.TileMode.CLAMP)
        }
        val rect = RectF(0f, 0f, px.toFloat(), px.toFloat())
        when (shape) {
            1 -> c.drawCircle(px / 2f, px / 2f, px / 2f, paint)
            2 -> c.drawRect(rect, paint)
            else -> c.drawRoundRect(rect, px * 0.2f, px * 0.2f, paint)
        }
        return out
    }

    /** A thin rounded bar that is filled up to [frac]. */
    fun progress(w: Int, h: Int, frac: Float, fill: Int, track: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val r = h / 2f
        paint.color = track
        c.drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), r, r, paint)
        val f = frac.coerceIn(0f, 1f)
        if (f > 0f) {
            paint.color = fill
            c.drawRoundRect(RectF(0f, 0f, maxOf(h.toFloat(), w * f), h.toFloat()), r, r, paint)
        }
        return bmp
    }
}
