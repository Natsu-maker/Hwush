package com.hwush.player.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Writes title, artist, album and a cover into the song file itself. Works for MP3 (ID3v2) and FLAC.
 * Other formats are left alone. The original is kept in the cache and put back if anything goes wrong.
 */
object TagWriter {
    private const val MAX_BYTES = 150L * 1024L * 1024L

    /** Shrinks a picked image to a JPEG small enough to live inside a song file. */
    fun coverBytes(ctx: Context, uri: Uri): ByteArray? = try {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        val bmp = if (bytes == null) null else BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        if (bmp == null) {
            null
        } else {
            val side = 1000
            val scale = minOf(1f, side.toFloat() / maxOf(bmp.width, bmp.height))
            val out = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
            val bos = ByteArrayOutputStream()
            out.compress(Bitmap.CompressFormat.JPEG, 90, bos)
            bos.toByteArray()
        }
    } catch (_: Exception) {
        null
    }

    /** Returns null when it worked, or a short message saying why not. */
    fun write(ctx: Context, uri: Uri, title: String?, artist: String?, album: String?, cover: ByteArray?): String? {
        val original: ByteArray = try {
            ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return "Could not open the file"
        } catch (e: Exception) {
            return "Could not open the file"
        }
        if (original.size > MAX_BYTES) return "This file is too large to edit"
        val isFlac = original.size > 4 && original[0] == 'f'.code.toByte() && original[1] == 'L'.code.toByte() &&
            original[2] == 'a'.code.toByte() && original[3] == 'C'.code.toByte()
        val isMp3 = original.size > 3 && ((original[0] == 'I'.code.toByte() && original[1] == 'D'.code.toByte() && original[2] == '3'.code.toByte()) ||
            (original[0] == 0xFF.toByte() && (original[1].toInt() and 0xE0) == 0xE0))
        val result: ByteArray = try {
            when {
                isFlac -> flac(original, title, artist, album, cover)
                isMp3 -> mp3(original, title, artist, album, cover)
                else -> return "Only MP3 and FLAC files can be edited. The change is saved inside Hwush."
            }
        } catch (e: Exception) {
            return "Could not read the tags in this file"
        }
        val backup = File(ctx.cacheDir, "tag-backup.bin")
        try {
            backup.writeBytes(original)
        } catch (_: Exception) {
        }
        return try {
            ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(result) } ?: return "Android did not allow writing to this file"
            null
        } catch (e: Exception) {
            try {
                ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(original) }
            } catch (_: Exception) {
            }
            "Android did not allow writing to this file"
        }
    }

    // ------------------------------------------------------------------ MP3

    private fun syncsafe(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0x7F) shl 21) or ((b[o + 1].toInt() and 0x7F) shl 14) or ((b[o + 2].toInt() and 0x7F) shl 7) or (b[o + 3].toInt() and 0x7F)

    private fun be32(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xFF) shl 24) or ((b[o + 1].toInt() and 0xFF) shl 16) or ((b[o + 2].toInt() and 0xFF) shl 8) or (b[o + 3].toInt() and 0xFF)

    private fun put32(out: ByteArrayOutputStream, v: Int) {
        out.write((v shr 24) and 0xFF)
        out.write((v shr 16) and 0xFF)
        out.write((v shr 8) and 0xFF)
        out.write(v and 0xFF)
    }

    private fun textFrame(id: String, text: String): ByteArray {
        val body = ByteArrayOutputStream()
        body.write(1) // UTF-16 with a byte order mark
        body.write(0xFF)
        body.write(0xFE)
        body.write(text.toByteArray(Charsets.UTF_16LE))
        return frame(id, body.toByteArray())
    }

    private fun frame(id: String, data: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(id.toByteArray(Charsets.ISO_8859_1))
        put32(out, data.size)
        out.write(0)
        out.write(0)
        out.write(data)
        return out.toByteArray()
    }

    private fun mp3(b: ByteArray, title: String?, artist: String?, album: String?, cover: ByteArray?): ByteArray {
        val replace = HashSet<String>()
        if (!title.isNullOrBlank()) replace.add("TIT2")
        if (!artist.isNullOrBlank()) replace.add("TPE1")
        if (!album.isNullOrBlank()) replace.add("TALB")
        if (cover != null) replace.add("APIC")

        var audioStart = 0
        val kept = ByteArrayOutputStream()
        if (b.size > 10 && b[0] == 'I'.code.toByte() && b[1] == 'D'.code.toByte() && b[2] == '3'.code.toByte()) {
            val ver = b[3].toInt()
            val flags = b[5].toInt() and 0xFF
            val tagSize = syncsafe(b, 6)
            val footer = if (ver == 4 && (flags and 0x10) != 0) 10 else 0
            audioStart = (10 + tagSize + footer).coerceAtMost(b.size)
            val end = (10 + tagSize).coerceAtMost(b.size)
            var pos = 10
            if ((flags and 0x40) != 0 && pos + 4 <= end) {
                pos += if (ver == 4) syncsafe(b, pos) else be32(b, pos) + 4
            }
            // Old frames are carried over unless they are being replaced. Tags that use tricks
            // (whole-tag unsynchronisation, version 2.2) are rebuilt from scratch instead.
            val usable = (ver == 3 || ver == 4) && (flags and 0x80) == 0
            while (usable && pos + 10 <= end) {
                if (b[pos].toInt() == 0) break
                val id = String(b, pos, 4, Charsets.ISO_8859_1)
                val size = if (ver == 4) syncsafe(b, pos + 4) else be32(b, pos + 4)
                val f2 = b[pos + 9].toInt() and 0xFF
                if (size <= 0 || pos + 10 + size > end) break
                val plain = if (ver == 4) (f2 and 0x4F) == 0 else (f2 and 0xE0) == 0
                if (plain && id !in replace) kept.write(frame(id, b.copyOfRange(pos + 10, pos + 10 + size)))
                pos += 10 + size
            }
        }
        val frames = ByteArrayOutputStream()
        if (!title.isNullOrBlank()) frames.write(textFrame("TIT2", title.trim()))
        if (!artist.isNullOrBlank()) frames.write(textFrame("TPE1", artist.trim()))
        if (!album.isNullOrBlank()) frames.write(textFrame("TALB", album.trim()))
        if (cover != null) {
            val pic = ByteArrayOutputStream()
            pic.write(0)
            pic.write("image/jpeg".toByteArray(Charsets.ISO_8859_1))
            pic.write(0)
            pic.write(3)
            pic.write(0)
            pic.write(cover)
            frames.write(frame("APIC", pic.toByteArray()))
        }
        frames.write(kept.toByteArray())
        val body = frames.toByteArray()
        val out = ByteArrayOutputStream()
        out.write("ID3".toByteArray(Charsets.ISO_8859_1))
        out.write(3)
        out.write(0)
        out.write(0)
        out.write((body.size shr 21) and 0x7F)
        out.write((body.size shr 14) and 0x7F)
        out.write((body.size shr 7) and 0x7F)
        out.write(body.size and 0x7F)
        out.write(body)
        out.write(b, audioStart, b.size - audioStart)
        return out.toByteArray()
    }

    // ------------------------------------------------------------------ FLAC

    private fun le32(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)

    private fun putLe32(out: ByteArrayOutputStream, v: Int) {
        out.write(v and 0xFF)
        out.write((v shr 8) and 0xFF)
        out.write((v shr 16) and 0xFF)
        out.write((v shr 24) and 0xFF)
    }

    private fun flac(b: ByteArray, title: String?, artist: String?, album: String?, cover: ByteArray?): ByteArray {
        class Block(val type: Int, val data: ByteArray)
        val blocks = ArrayList<Block>()
        var pos = 4
        while (true) {
            val h = b[pos].toInt() and 0xFF
            val last = (h and 0x80) != 0
            val type = h and 0x7F
            val len = ((b[pos + 1].toInt() and 0xFF) shl 16) or ((b[pos + 2].toInt() and 0xFF) shl 8) or (b[pos + 3].toInt() and 0xFF)
            blocks.add(Block(type, b.copyOfRange(pos + 4, pos + 4 + len)))
            pos += 4 + len
            if (last) break
        }
        val audioStart = pos

        val replace = HashSet<String>()
        if (!title.isNullOrBlank()) replace.add("TITLE")
        if (!artist.isNullOrBlank()) replace.add("ARTIST")
        if (!album.isNullOrBlank()) replace.add("ALBUM")

        var vendor = "Hwush"
        val comments = ArrayList<String>()
        val old = blocks.firstOrNull { it.type == 4 }
        if (old != null) {
            val d = old.data
            var o = 0
            val vl = le32(d, o)
            o += 4
            vendor = String(d, o, vl, Charsets.UTF_8)
            o += vl
            val n = le32(d, o)
            o += 4
            for (i in 0 until n) {
                val l = le32(d, o)
                o += 4
                val c = String(d, o, l, Charsets.UTF_8)
                o += l
                val key = c.substringBefore('=').uppercase()
                if (key !in replace) comments.add(c)
            }
        }
        if (!title.isNullOrBlank()) comments.add("TITLE=${title.trim()}")
        if (!artist.isNullOrBlank()) comments.add("ARTIST=${artist.trim()}")
        if (!album.isNullOrBlank()) comments.add("ALBUM=${album.trim()}")
        val vc = ByteArrayOutputStream()
        val vb = vendor.toByteArray(Charsets.UTF_8)
        putLe32(vc, vb.size)
        vc.write(vb)
        putLe32(vc, comments.size)
        for (c in comments) {
            val cb = c.toByteArray(Charsets.UTF_8)
            putLe32(vc, cb.size)
            vc.write(cb)
        }

        val outBlocks = ArrayList<Block>()
        for (bl in blocks) {
            when {
                bl.type == 1 || bl.type == 4 -> {}
                bl.type == 6 && cover != null -> {}
                else -> outBlocks.add(bl)
            }
        }
        outBlocks.add(1.coerceAtMost(outBlocks.size), Block(4, vc.toByteArray()))
        if (cover != null) {
            val pic = ByteArrayOutputStream()
            put32(pic, 3)
            val mime = "image/jpeg".toByteArray(Charsets.ISO_8859_1)
            put32(pic, mime.size)
            pic.write(mime)
            put32(pic, 0)
            put32(pic, 0)
            put32(pic, 0)
            put32(pic, 24)
            put32(pic, 0)
            put32(pic, cover.size)
            pic.write(cover)
            outBlocks.add(Block(6, pic.toByteArray()))
        }
        val out = ByteArrayOutputStream()
        out.write("fLaC".toByteArray(Charsets.ISO_8859_1))
        for ((i, bl) in outBlocks.withIndex()) {
            val lastFlag = if (i == outBlocks.lastIndex) 0x80 else 0
            out.write(lastFlag or bl.type)
            out.write((bl.data.size shr 16) and 0xFF)
            out.write((bl.data.size shr 8) and 0xFF)
            out.write(bl.data.size and 0xFF)
            out.write(bl.data)
        }
        out.write(b, audioStart, b.size - audioStart)
        return out.toByteArray()
    }
}
