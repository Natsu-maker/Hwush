package com.hwush.player.player

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import com.hwush.player.HwushApp
import com.hwush.player.data.Lyrics
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * The line being sung, in a small bubble over other apps while Hwush itself is not on screen. It can be dragged.
 * Needs "Display over other apps", and only shows for songs with timed lyrics.
 */
class FloatingLyrics(private val app: HwushApp) {
    private val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var view: TextView? = null
    private var params: WindowManager.LayoutParams? = null
    private var lyrics: Lyrics? = null
    private var loadedFor: String? = null

    private val tick = object : Runnable {
        override fun run() {
            try { update() } catch (_: Exception) {}
            handler.postDelayed(this, 300L)
        }
    }

    fun start() {
        handler.post(tick)
    }

    private fun update() {
        val on = app.store.data.value.toolsFloatLyrics && Settings.canDrawOverlays(app)
        if (!on || app.appVisible || !app.player.player.isPlaying) {
            hide()
            return
        }
        val path = app.player.currentPath()
        if (path != loadedFor) {
            loadedFor = path
            lyrics = null
            val t = path?.let { app.library.find(it) }
            if (t != null) scope.launch { lyrics = app.lyrics.find(t) }
        }
        val ly = lyrics
        if (ly == null || !ly.synced || ly.lines.isEmpty()) {
            hide()
            return
        }
        val offset = path?.let { app.store.data.value.lyricOffsets[it] } ?: 0L
        val pos = app.player.position() - offset
        var line = ""
        for (l in ly.lines) {
            if (l.timeMs <= pos) line = l.text else break
        }
        if (line.isBlank()) {
            hide()
            return
        }
        show(line)
    }

    private fun show(text: String) {
        val v = view ?: makeView().also { view = it }
        v.text = text
        if (!v.isAttachedToWindow) {
            try { wm.addView(v, params) } catch (_: Exception) { view = null }
        }
    }

    private fun hide() {
        val v = view ?: return
        if (v.isAttachedToWindow) {
            try { wm.removeView(v) } catch (_: Exception) {}
        }
    }

    private fun makeView(): TextView {
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT,
        )
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = (120 * app.resources.displayMetrics.density).toInt()
        params = p
        val d = app.resources.displayMetrics.density
        val tv = TextView(app)
        tv.setTextColor(Color.WHITE)
        tv.textSize = 17f
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.gravity = Gravity.CENTER
        tv.maxLines = 2
        tv.maxWidth = (app.resources.displayMetrics.widthPixels * 0.9f).toInt()
        tv.setPadding((18 * d).toInt(), (10 * d).toInt(), (18 * d).toInt(), (10 * d).toInt())
        tv.background = GradientDrawable().apply {
            setColor(Color.argb(190, 20, 20, 24))
            cornerRadius = 26 * d
        }
        var startY = 0
        var touchY = 0f
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startY = p.y; touchY = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    p.y = (startY + (e.rawY - touchY)).toInt().coerceAtLeast(0)
                    try { wm.updateViewLayout(tv, p) } catch (_: Exception) {}
                }
            }
            true
        }
        return tv
    }
}
