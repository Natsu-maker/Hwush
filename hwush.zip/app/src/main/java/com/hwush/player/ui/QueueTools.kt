package com.hwush.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.player.PlayerUi

/** Queues kept under a name: save the one that is playing, bring one back, or delete it. */
@Composable
fun SavedQueuesDialog(ui: UiController, pui: PlayerUi, onClose: () -> Unit) {
    val app = ui.app
    val saved by app.store.select { it.savedQueues }
    var naming by remember { mutableStateOf(false) }
    if (naming) {
        val stamp = java.text.SimpleDateFormat("d MMM, HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
        NameDialog("Save this queue", "Queue $stamp", "Save", { naming = false }) { name ->
            app.store.saveQueue(name, pui.queue, pui.index)
            naming = false
            ui.say("Queue saved")
        }
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Saved queues") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                TextButton(onClick = { naming = true }, enabled = pui.queue.isNotEmpty()) { Text("Save the current queue") }
                if (saved.isEmpty()) {
                    Text(
                        "Nothing saved yet. A saved queue keeps the songs and where you were in them.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp),
                    )
                }
                saved.forEach { q ->
                    val tracks = q.paths.mapNotNull { app.library.find(it) }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(
                            Modifier
                                .weight(1f)
                                .clickable(enabled = tracks.isNotEmpty()) {
                                    val at = q.paths.getOrNull(q.index)?.let { p -> tracks.indexOfFirst { it.path == p } }?.coerceAtLeast(0) ?: 0
                                    ui.play(tracks, at)
                                    onClose()
                                }
                                .padding(vertical = 8.dp),
                        ) {
                            Text(q.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                plural(tracks.size, "song"),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        TextButton(onClick = { app.store.deleteSavedQueue(q.id) }) { Text("Delete") }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onClose) { Text("Close") } },
    )
}

/** The songs played most recently, newest first. Tap one to play it, or add it next. */
@Composable
fun QueueHistoryDialog(ui: UiController, onClose: () -> Unit) {
    val app = ui.app
    val events by app.history.events.collectAsState()
    val recent = remember(events) {
        val seen = HashSet<String>()
        events.asReversed().filter { !it.skipped && seen.add(it.path) }.mapNotNull { app.library.find(it.path) }.take(40)
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Played recently") },
        text = {
            if (recent.isEmpty()) {
                Text("Songs you listen to will show up here.")
            } else {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    recent.forEach { t ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Cover(t, Modifier.size(40.dp), 48.dp, RoundedCornerShape(8.dp))
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f).clickable { ui.play(listOf(t), 0); onClose() }.padding(vertical = 6.dp)) {
                                Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    t.artist,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                            TextButton(onClick = { ui.playNext(listOf(t)); ui.say("Playing next") }) { Text("Next") }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onClose) { Text("Close") } },
    )
}
