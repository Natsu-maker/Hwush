package com.hwush.player.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AssistChip
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

/**
 * The player for a tablet held sideways: the cover and song name on the left, lyrics or the queue on the right,
 * and the controls along the bottom right. Everything is visible at once, with the fluid background behind it.
 */
@Composable
fun TabletPlayer(ui: UiController, onClose: () -> Unit) {
    val app = ui.app
    val holder = app.player
    val ctx = LocalContext.current
    val pui by holder.ui.collectAsState()
    val track = pui.path?.let { app.library.find(it) }
    val primary = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
    val bg = MaterialTheme.colorScheme.background
    val artColor = rememberArtColor(track, primary)
    val blur by app.store.select { it.blurBackdrop }
    val bgStyle by app.store.select { it.bgStyle }
    val swipeStyle by app.store.select { it.swipeStyle }
    val glassLevel by app.store.select { it.glassLevel }
    val fav by app.store.select(track?.path) { track != null && track.path in it.favorites }
    var tab by remember { mutableIntStateOf(0) }
    val swipe = rememberCoverSwipe(holder)

    Box(Modifier.fillMaxSize().background(bg)) {
        if (blur) {
            PlayerBackdrop(track, artColor, pui.isPlaying, bgStyle, Modifier.fillMaxSize())
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(bg.copy(alpha = 0.15f), bg.copy(alpha = 0.40f - 0.2f * glassLevel), bg.copy(alpha = 0.75f - 0.2f * glassLevel))),
                ),
            )
        } else {
            AuroraBackground(artColor, Modifier.fillMaxSize())
        }
        Row(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 28.dp, vertical = 16.dp)) {
            // ---- left: cover and names
            Column(
                Modifier.weight(0.46f).fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Box(
                    Modifier
                        .weight(1f, fill = false)
                        .fillMaxWidth(0.94f)
                        .widthIn(max = 560.dp)
                        .aspectRatio(1f)
                        .swipeFx(swipe, swipeStyle)
                        .coverSwipeGestures(holder, swipe, { track?.let { app.store.toggleFavorite(it.path) } }, onClose),
                    contentAlignment = Alignment.Center,
                ) {
                    PulsingGlow(artColor, pui.isPlaying, Modifier.fillMaxSize().graphicsLayer { scaleX = 1.2f; scaleY = 1.2f })
                    var lastIdx by remember { mutableIntStateOf(pui.index) }
                    val dir = if (pui.index >= lastIdx) 1 else -1
                    SideEffect { lastIdx = pui.index }
                    AnimatedContent(
                        targetState = track,
                        transitionSpec = {
                            if (swipe.busy) {
                                EnterTransition.None togetherWith ExitTransition.None
                            } else {
                                (fadeIn(tween(320)) + slideInHorizontally(tween(380)) { it * dir / 3 } + scaleIn(initialScale = 0.88f, animationSpec = tween(380)))
                                    .togetherWith(fadeOut(tween(200)) + slideOutHorizontally(tween(300)) { -it * dir / 4 })
                            }
                        },
                        modifier = Modifier.fillMaxSize().graphicsLayer {
                            val s = if (pui.isPlaying) 1f else 0.9f
                            scaleX = s
                            scaleY = s
                        },
                        label = "tabletCover",
                    ) { tr -> Cover(tr, Modifier.fillMaxSize(), 560.dp, RoundedCornerShape(28.dp)) }
                }
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(0.94f).widthIn(max = 560.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        AnimatedContent(
                            targetState = track?.title ?: "Nothing playing",
                            transitionSpec = { (fadeIn(tween(240)) + slideInHorizontally(tween(260)) { it / 6 }).togetherWith(fadeOut(tween(120))) },
                            label = "tabletTitle",
                        ) { title ->
                            Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        Text(
                            if (track == null) "Pick a song from your library" else "${track.artist} · ${track.album}",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    AnimatedHeart(fav, onClick = { track?.let { app.store.toggleFavorite(it.path) } })
                    IconButton(onClick = { track?.let { ui.menuTrack = it } }) { Icon(Icons.Rounded.MoreVert, "More") }
                }
            }
            Spacer(Modifier.width(28.dp))
            // ---- right: lyrics or queue, then the controls
            Column(Modifier.weight(0.54f).fillMaxHeight()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    listOf("Lyrics", "Up next").forEachIndexed { i, label ->
                        FilterChip(
                            selected = tab == i,
                            onClick = { tab = i },
                            label = { Text(label) },
                            modifier = Modifier.padding(end = 8.dp),
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Close player") }
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = { fadeIn(tween(220)).togetherWith(fadeOut(tween(140))) },
                        label = "tabletTab",
                    ) { t ->
                        if (t == 0) LyricsTab(ui, pui, track) else QueueTab(ui, pui)
                    }
                }
                Column(Modifier.fillMaxWidth().glass().padding(horizontal = 16.dp, vertical = 10.dp)) {
                    SeekBar(ui, pui)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { holder.toggleShuffle() }) { Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (pui.shuffle) primary else dim) }
                        IconButton(onClick = { holder.previous() }, Modifier.size(60.dp)) { Icon(Icons.Rounded.SkipPrevious, "Previous", Modifier.size(38.dp)) }
                        Box(Modifier.size(76.dp), contentAlignment = Alignment.Center) {
                            PlayRing(pui.isPlaying, primary, 120.dp)
                            FilledIconButton(onClick = { holder.togglePlay() }, Modifier.size(76.dp)) { PlayPauseIcon(pui.isPlaying, Modifier.size(42.dp)) }
                        }
                        IconButton(onClick = { holder.next() }, Modifier.size(60.dp)) { Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(38.dp)) }
                        IconButton(onClick = { holder.cycleRepeat() }) {
                            Icon(if (pui.repeat == 2) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat, "Repeat", tint = if (pui.repeat != 0) primary else dim)
                        }
                    }
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(onClick = { ui.soundOpen = true }, label = { Text(if (pui.speed != 1f || pui.pitch != 1f) "Sound · ${fmtSpeed(pui.speed)}" else "Sound") })
                        if (pui.speed != 1f || pui.pitch != 1f) AssistChip(onClick = { holder.resetSpeedPitch() }, label = { Text("Reset") })
                        val sleepOn = pui.sleepEndsAt > 0L || pui.sleepAfterSong
                        AssistChip(onClick = { ui.sleepOpen = true }, label = { Text(if (sleepOn) "Sleep on" else "Sleep") })
                        AssistChip(onClick = { holder.setLoopA() }, label = { Text(if (pui.loopA >= 0L) "A ${fmtTime(pui.loopA)}" else "Set A") })
                        AssistChip(onClick = { holder.setLoopB() }, label = { Text(if (pui.loopB >= 0L) "B ${fmtTime(pui.loopB)}" else "Set B") })
                        if (pui.loopA >= 0L || pui.loopB >= 0L) AssistChip(onClick = { holder.clearLoop() }, label = { Text("Clear") })
                        AssistChip(onClick = { ui.bookmarksOpen = true }, label = { Text("Bookmarks") })
                        AssistChip(onClick = { ui.carMode = true }, label = { Text("Car mode") })
                        AssistChip(onClick = { track?.let { ui.nowPlayingOpen = false; ui.open(Dest(Kind.BEAT, it.path)) } }, label = { Text("Beat game") })
                        AssistChip(onClick = { track?.let { shareNowPlaying(ctx, it) } }, label = { Text("Share") })
                    }
                }
            }
        }
    }
}
