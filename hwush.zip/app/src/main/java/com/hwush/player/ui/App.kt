@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

fun hasAudioPermission(ctx: Context): Boolean {
    val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    return ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
}

private fun permissionsToAsk(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33) {
        arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
    } else {
        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

private data class Tab(val kind: Kind, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab(Kind.SONGS, "Songs", Icons.Rounded.MusicNote),
    Tab(Kind.ALBUMS, "Albums", Icons.Rounded.Album),
    Tab(Kind.ARTISTS, "Artists", Icons.Rounded.Person),
    Tab(Kind.FOLDERS, "Folders", Icons.Rounded.Folder),
    Tab(Kind.PLAYLISTS, "Playlists", Icons.Rounded.QueueMusic),
)

@Composable
fun HwushRoot(ui: UiController) {
    val app = ui.app
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasAudioPermission(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudioPermission(ctx)
        if (granted) app.library.refresh()
    }
    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(permissionsToAsk())
    }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (granted) {
            MainShell(ui)
        } else {
            Box(Modifier.fillMaxSize().systemBarsPadding()) {
                EmptyState(
                    title = "Hwush needs access to your music",
                    body = "Allow access to audio files so Hwush can find the songs on this device. Nothing leaves your device.",
                    action = {
                        Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                            Button(onClick = { launcher.launch(permissionsToAsk()) }) { Text("Allow access") }
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                        .setData(Uri.fromParts("package", ctx.packageName, null)),
                                )
                            }) { Text("Open app settings") }
                        }
                    },
                )
            }
        }
    }
}

@Composable
private fun MainShell(ui: UiController) {
    val app = ui.app
    val loaded by app.library.loaded.collectAsState()
    LaunchedEffect(loaded) {
        if (loaded) app.player.restore()
    }
    LaunchedEffect(Unit) {
        app.player.messages.collect { ui.say(it) }
    }
    val cfg = LocalConfiguration.current
    val tablet = cfg.smallestScreenWidthDp >= 600 && cfg.orientation == Configuration.ORIENTATION_LANDSCAPE

    BackHandler(enabled = ui.stack.size > 1) { ui.back() }
    BackHandler(enabled = ui.nowPlayingOpen && !tablet) { ui.nowPlayingOpen = false }

    if (tablet) TabletShell(ui, cfg.screenWidthDp) else PhoneShell(ui)
    Overlays(ui)
}

@Composable
fun ContentRouter(ui: UiController, modifier: Modifier = Modifier) {
    val d = ui.current
    Box(modifier) {
        when (d.kind) {
            Kind.SONGS -> SongsScreen(ui)
            Kind.ALBUMS -> AlbumsScreen(ui)
            Kind.ARTISTS -> ArtistsScreen(ui)
            Kind.FOLDERS -> FoldersScreen(ui)
            Kind.PLAYLISTS -> PlaylistsScreen(ui)
            Kind.SETTINGS -> SettingsScreen(ui)
            Kind.ALBUM -> AlbumDetail(ui, d.arg)
            Kind.ARTIST -> ArtistDetail(ui, d.arg)
            Kind.FOLDER -> FolderDetail(ui, d.arg)
            Kind.PLAYLIST -> PlaylistDetail(ui, d.arg)
        }
    }
}

@Composable
private fun PhoneShell(ui: UiController) {
    Box(Modifier.fillMaxSize()) {
        Scaffold(
            snackbarHost = { SnackbarHost(ui.snack) },
            bottomBar = {
                Column {
                    MiniPlayer(ui)
                    NavigationBar {
                        tabs.forEach { t ->
                            NavigationBarItem(
                                selected = ui.root == t.kind,
                                onClick = { ui.go(t.kind) },
                                icon = { Icon(t.icon, t.label) },
                                label = { Text(t.label, maxLines = 1) },
                            )
                        }
                    }
                }
            },
        ) { pad ->
            ContentRouter(ui, Modifier.padding(pad).fillMaxSize())
        }
        if (ui.nowPlayingOpen) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                PlayerPane(ui, Modifier.systemBarsPadding(), onClose = { ui.nowPlayingOpen = false })
            }
        }
    }
}

/** Tablet landscape: navigation rail, the library in the middle and the player always visible on the right. */
@Composable
private fun TabletShell(ui: UiController, widthDp: Int) {
    Scaffold(snackbarHost = { SnackbarHost(ui.snack) }) { pad ->
        Row(Modifier.padding(pad).fillMaxSize()) {
            NavigationRail(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                Spacer(Modifier.height(8.dp))
                tabs.forEach { t ->
                    NavigationRailItem(
                        selected = ui.root == t.kind && ui.current.kind != Kind.SETTINGS,
                        onClick = { ui.go(t.kind) },
                        icon = { Icon(t.icon, t.label) },
                        label = { Text(t.label, maxLines = 1) },
                        alwaysShowLabel = true,
                    )
                }
                Spacer(Modifier.weight(1f))
                NavigationRailItem(
                    selected = ui.current.kind == Kind.SETTINGS,
                    onClick = { if (ui.current.kind != Kind.SETTINGS) ui.open(Dest(Kind.SETTINGS)) },
                    icon = { Icon(Icons.Rounded.Settings, "Settings") },
                    label = { Text("Settings", maxLines = 1) },
                    alwaysShowLabel = true,
                )
                Spacer(Modifier.height(8.dp))
            }
            ContentRouter(ui, Modifier.weight(1f).fillMaxHeight())
            VerticalDivider()
            PlayerPane(ui, Modifier.width(if (widthDp >= 1100) 460.dp else 390.dp).fillMaxHeight())
        }
    }
}
