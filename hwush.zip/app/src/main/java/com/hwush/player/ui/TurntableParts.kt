package com.hwush.player.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.changedToUp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.hwush.player.dj.DjEngine
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

internal val HotColors = listOf(
    Color(0xFFFF5C7A), Color(0xFFFF9F43), Color(0xFFFFD84D), Color(0xFF5CE08A),
    Color(0xFF3DD9D0), Color(0xFF5B9BFF), Color(0xFFA77BFF), Color(0xFFFF7BE0),
)

/** A rounded card for one section of the turntable. It is slightly see-through so the app background shows. */
@Composable
internal fun TtPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(22.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.62f))
            .padding(horizontal = 12.dp, vertical = 10.dp),
        content = content,
    )
}

@Composable
internal fun TtLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text,
        modifier = modifier,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
    )
}

/** Text that follows the sound, redrawn on its own every frame without redrawing the rest of the screen. */
@Composable
internal fun LiveText(frame: State<Int>, style: TextStyle, color: Color, modifier: Modifier = Modifier, f: () -> String) {
    @Suppress("UNUSED_VARIABLE") val t = frame.value
    Text(f(), modifier = modifier, style = style, color = color, maxLines = 1)
}

/** A small rounded button that can be switched on. */
@Composable
internal fun Pill(text: String, on: Boolean, accent: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (on) accent else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = if (on) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
        )
    }
}

/** A button that is active only while the finger is on it. */
@Composable
internal fun HoldPill(text: String, accent: Color, modifier: Modifier = Modifier, onDown: () -> Unit, onUp: () -> Unit) {
    var down by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    val d by rememberUpdatedState(onDown)
    val u by rememberUpdatedState(onUp)
    Box(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (down) accent else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    down = true
                    d()
                    tryAwaitRelease()
                    down = false
                    u()
                })
            }
            .padding(horizontal = 11.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = if (down) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
        )
    }
}

/** A knob you turn by dragging up or down. A double tap puts it back to [reset]. */
@Composable
internal fun Knob(
    value: Float,
    onChange: (Float) -> Unit,
    label: String,
    accent: Color,
    modifier: Modifier = Modifier,
    min: Float = -1f,
    max: Float = 1f,
    reset: Float = 0f,
    size: Dp = 44.dp,
) {
    val cur by rememberUpdatedState(value)
    val onC by rememberUpdatedState(onChange)
    val track = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.16f)
    val body = MaterialTheme.colorScheme.surfaceContainerHighest
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(
            Modifier
                .size(size)
                .pointerInput(Unit) {
                    detectVerticalDragGestures { change, dy ->
                        change.consume()
                        onC((cur - dy / 280f * (max - min)).coerceIn(min, max))
                    }
                }
                .pointerInput(Unit) { detectTapGestures(onDoubleTap = { onC(reset) }) },
        ) {
            val r = this.size.minDimension / 2f
            val c = Offset(this.size.width / 2f, this.size.height / 2f)
            drawCircle(body, r * 0.78f, c)
            val frac = ((cur - min) / (max - min)).coerceIn(0f, 1f)
            val stroke = Stroke(width = r * 0.14f, cap = StrokeCap.Round)
            val arcTl = Offset(c.x - r * 0.92f, c.y - r * 0.92f)
            val arcSz = Size(r * 1.84f, r * 1.84f)
            drawArc(track, 135f, 270f, false, arcTl, arcSz, style = stroke)
            val resetFrac = ((reset - min) / (max - min)).coerceIn(0f, 1f)
            val from = 135f + 270f * kotlin.math.min(frac, resetFrac)
            val sweep = 270f * abs(frac - resetFrac)
            if (sweep > 0.5f) drawArc(accent, from, sweep, false, arcTl, arcSz, style = stroke)
            val a = (135f + 270f * frac) * PI.toFloat() / 180f
            drawLine(
                Color.White.copy(alpha = 0.92f),
                Offset(c.x + cos(a) * r * 0.25f, c.y + sin(a) * r * 0.25f),
                Offset(c.x + cos(a) * r * 0.68f, c.y + sin(a) * r * 0.68f),
                strokeWidth = r * 0.12f,
                cap = StrokeCap.Round,
            )
        }
        TtLabel(label)
    }
}

/** A vertical fader. Touch anywhere on it to put the cap there. [detent] makes a spot the cap clicks onto. */
@Composable
internal fun VFader(
    value: Float,
    onChange: (Float) -> Unit,
    accent: Color,
    modifier: Modifier = Modifier,
    min: Float = 0f,
    max: Float = 1f,
    detent: Float? = null,
) {
    val cur by rememberUpdatedState(value)
    val onC by rememberUpdatedState(onChange)
    val slot = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.18f)
    val capColor = MaterialTheme.colorScheme.surfaceContainerHighest
    Canvas(
        modifier.pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                fun set(y: Float) {
                    val f = 1f - (y / size.height).coerceIn(0f, 1f)
                    var v = min + f * (max - min)
                    if (detent != null && abs(v - detent) < (max - min) * 0.035f) v = detent
                    onC(v)
                }
                set(down.position.y)
                down.consume()
                while (true) {
                    val ev = awaitPointerEvent()
                    val ch = ev.changes.firstOrNull() ?: break
                    if (!ch.pressed) break
                    set(ch.position.y)
                    ch.consume()
                }
            }
        },
    ) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        drawRoundRect(slot, Offset(cx - 2.5f, 6f), Size(5f, h - 12f), CornerRadius(3f, 3f))
        // tick marks
        for (i in 0..10) {
            val y = 6f + (h - 12f) * i / 10f
            val len = if (i == 5) w * 0.42f else w * 0.24f
            drawLine(slot, Offset(cx - len, y), Offset(cx - 8f, y), strokeWidth = if (i == 5) 2.5f else 1.5f)
            drawLine(slot, Offset(cx + 8f, y), Offset(cx + len, y), strokeWidth = if (i == 5) 2.5f else 1.5f)
        }
        val f = ((cur - min) / (max - min)).coerceIn(0f, 1f)
        val y = 6f + (h - 12f) * (1f - f)
        val capW = kotlin.math.min(w * 0.9f, 46f)
        drawRoundRect(capColor, Offset(cx - capW / 2f, y - 13f), Size(capW, 26f), CornerRadius(8f, 8f))
        drawRoundRect(accent, Offset(cx - capW / 2f + 5f, y - 2f), Size(capW - 10f, 4f), CornerRadius(2f, 2f))
    }
}

/** A row of lights that rises with the sound. */
@Composable
internal fun VuMeter(frame: State<Int>, level: () -> Float, accent: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        @Suppress("UNUSED_VARIABLE") val t = frame.value
        val v = level().coerceIn(0f, 1.2f)
        val n = 14
        val gap = 3f
        val h = (size.height - gap * (n - 1)) / n
        val lit = (v * n).toInt()
        for (i in 0 until n) {
            val on = i < lit
            val col = when {
                i >= n - 2 -> Color(0xFFFF4D4D)
                i >= n - 5 -> Color(0xFFFFC94D)
                else -> accent
            }
            drawRoundRect(
                if (on) col else col.copy(alpha = 0.12f),
                Offset(0f, size.height - (i + 1) * h - i * gap),
                Size(size.width, h),
                CornerRadius(2f, 2f),
            )
        }
    }
}

/**
 * The record. Grooves, a label, a strobe ring that turns with the speed, a tonearm that tracks across the record
 * as the song plays, and a surface you can grab to scratch.
 */
@Composable
internal fun Vinyl(engine: DjEngine, deck: Int, accent: Color, frame: State<Int>, modifier: Modifier) {
    val plate = MaterialTheme.colorScheme.surfaceContainerHighest
    Canvas(
        modifier.pointerInput(deck) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val c = Offset(size.width / 2f, size.height / 2f)
                var last = atan2(down.position.y - c.y, down.position.x - c.x)
                var lastT = down.uptimeMillis
                engine.touch(deck, 0f)
                down.consume()
                while (true) {
                    val ev = awaitPointerEvent(PointerEventPass.Main)
                    val ch = ev.changes.firstOrNull() ?: break
                    if (ch.changedToUp() || !ch.pressed) break
                    if (ch.positionChanged()) {
                        val a = atan2(ch.position.y - c.y, ch.position.x - c.x)
                        var da = a - last
                        if (da > PI.toFloat()) da -= 2f * PI.toFloat()
                        if (da < -PI.toFloat()) da += 2f * PI.toFloat()
                        val dt = (ch.uptimeMillis - lastT).coerceAtLeast(1L) / 1000f
                        val degPerSec = (da * 180f / PI.toFloat()) / dt
                        engine.touch(deck, (degPerSec / 200f).coerceIn(-12f, 12f))
                        last = a
                        lastT = ch.uptimeMillis
                        ch.consume()
                    }
                }
                engine.release(deck)
            }
        },
    ) {
        @Suppress("UNUSED_VARIABLE") val t = frame.value
        val d = engine.decks[deck]
        val angle = engine.angle(deck)
        val r = size.minDimension / 2f * 0.92f
        val c = Offset(size.width * 0.46f, size.height * 0.54f)
        val groove = Stroke(1.1f)

        // base plate and strobe ring
        drawCircle(plate, r * 1.07f, c)
        rotate(angle, c) {
            val dots = 60
            for (i in 0 until dots) {
                val a = (i.toFloat() / dots) * 2f * PI.toFloat()
                val big = i % 5 == 0
                drawCircle(
                    Color.White.copy(alpha = if (big) 0.65f else 0.28f),
                    if (big) 2.6f else 1.6f,
                    Offset(c.x + cos(a) * r * 1.035f, c.y + sin(a) * r * 1.035f),
                )
            }
        }
        // slipmat and record
        drawCircle(Color(0xFF16161B), r, c)
        drawCircle(Color(0xFF08080B), r * 0.985f, c)
        rotate(angle, c) {
            var g = r * 0.95f
            var k = 0
            while (g > r * 0.38f) {
                drawCircle(Color.White.copy(alpha = if (k % 7 == 0) 0.11f else 0.045f), g, c, style = groove)
                g -= r * 0.021f
                k++
            }
            // the gaps between tracks
            drawCircle(Color.White.copy(alpha = 0.16f), r * 0.62f, c, style = Stroke(2.2f))
            drawCircle(Color.White.copy(alpha = 0.16f), r * 0.78f, c, style = Stroke(2.2f))
            // label
            drawCircle(accent, r * 0.3f, c)
            drawCircle(Color.Black.copy(alpha = 0.14f), r * 0.3f, c, style = Stroke(r * 0.05f))
            drawCircle(Color.Black.copy(alpha = 0.22f), r * 0.2f, c, style = Stroke(1.5f))
            drawCircle(Color(0xFF08080B), r * 0.035f, c)
            // a mark so the turning can be seen
            drawLine(Color.White.copy(alpha = 0.85f), Offset(c.x, c.y - r * 0.3f), Offset(c.x, c.y - r * 0.9f), strokeWidth = 3.5f)
        }
        // light on the vinyl (does not turn)
        drawArc(Color.White.copy(alpha = 0.07f), -62f, 36f, true, Offset(c.x - r, c.y - r), Size(r * 2f, r * 2f))
        drawArc(Color.White.copy(alpha = 0.05f), 118f, 36f, true, Offset(c.x - r, c.y - r), Size(r * 2f, r * 2f))

        // tonearm
        val len = d.clip?.frames?.toFloat() ?: 0f
        val prog = if (len > 0f) (d.pos.toFloat() / len).coerceIn(0f, 1f) else 0f
        val pivot = Offset(c.x + r * 1.06f, c.y - r * 0.9f)
        val rNeedle = if (d.clip == null) r * 1.12f else r * (0.93f - 0.57f * prog)
        val ang = -38f * PI.toFloat() / 180f
        val lifted = !d.playing && !d.touching
        var nx = c.x + cos(ang) * rNeedle
        var ny = c.y + sin(ang) * rNeedle
        if (d.clip == null) { nx = pivot.x - r * 0.18f; ny = pivot.y + r * 1.0f }
        val arm = Color(0xFFC9CCD6)
        val dark = Color(0xFF3B3D46)
        // shadow
        if (!lifted) drawLine(Color.Black.copy(alpha = 0.35f), Offset(pivot.x + 4f, pivot.y + 6f), Offset(nx + 4f, ny + 6f), strokeWidth = 7f, cap = StrokeCap.Round)
        val lift = if (lifted && d.clip != null) 7f else 0f
        val tip = Offset(nx - lift, ny - lift)
        drawLine(arm, Offset(pivot.x, pivot.y), tip, strokeWidth = 5.5f, cap = StrokeCap.Round)
        // headshell
        val dir = Offset(tip.x - pivot.x, tip.y - pivot.y)
        val dl = max(1f, kotlin.math.sqrt(dir.x * dir.x + dir.y * dir.y))
        val ux = dir.x / dl
        val uy = dir.y / dl
        val hs = Path().apply {
            moveTo(tip.x - uy * 6f, tip.y + ux * 6f)
            lineTo(tip.x + uy * 6f, tip.y - ux * 6f)
            lineTo(tip.x + uy * 6f + ux * 16f, tip.y - ux * 6f + uy * 16f)
            lineTo(tip.x - uy * 6f + ux * 16f, tip.y + ux * 6f + uy * 16f)
            close()
        }
        drawPath(hs, dark)
        drawCircle(accent, 3.2f, Offset(tip.x + ux * 14f, tip.y + uy * 14f))
        // pivot
        drawCircle(dark, 13f, pivot)
        drawCircle(arm, 7f, pivot)
        drawCircle(Color(0xFF1C1D22), 2.6f, pivot)
    }
}

/**
 * A picture of the whole piece. The played part is lit, hot cues are marked, loops are shaded and the beat grid is
 * drawn when the speed is known. Touch it to drop the needle somewhere else.
 */
@Composable
internal fun WaveStrip(engine: DjEngine, deck: Int, accent: Color, frame: State<Int>, modifier: Modifier) {
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.22f)
    Canvas(
        modifier.pointerInput(deck) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                engine.seek(deck, down.position.x / size.width)
                down.consume()
                while (true) {
                    val ev = awaitPointerEvent()
                    val ch = ev.changes.firstOrNull() ?: break
                    if (!ch.pressed) break
                    engine.seek(deck, ch.position.x / size.width)
                    ch.consume()
                }
            }
        },
    ) {
        @Suppress("UNUSED_VARIABLE") val t = frame.value
        val d = engine.decks[deck]
        val c = d.clip
        val w = size.width
        val h = size.height
        drawRoundRect(Color.Black.copy(alpha = 0.28f), Offset.Zero, Size(w, h), CornerRadius(10f, 10f))
        if (c == null) return@Canvas
        val frames = c.frames.toFloat()
        val prog = (d.pos.toFloat() / frames).coerceIn(0f, 1f)
        // loop
        if (d.loopIn >= 0.0 && d.loopOut > d.loopIn) {
            val a = (d.loopIn / frames).toFloat() * w
            val b = (d.loopOut / frames).toFloat() * w
            drawRect(Color(0xFF5CE08A).copy(alpha = if (d.loopOn) 0.32f else 0.12f), Offset(a, 0f), Size(b - a, h))
        }
        // beat grid
        if (d.bpm > 0f) {
            val beatFrames = 60f / d.bpm * c.sampleRate
            val px = beatFrames / frames * w
            if (px > 5f) {
                var x = d.gridOffset * c.sampleRate / frames * w
                var k = 0
                while (x < w) {
                    drawLine(Color.White.copy(alpha = if (k % 4 == 0) 0.2f else 0.08f), Offset(x, 0f), Offset(x, h), strokeWidth = 1f)
                    x += px
                    k++
                }
            }
        }
        // waveform
        val ov = d.overview
        if (ov.isNotEmpty()) {
            val bw = w / ov.size
            for (i in ov.indices) {
                val x = i * bw
                val amp = max(0.04f, ov[i]) * (h * 0.46f)
                drawLine(if (x / w <= prog) accent else dim, Offset(x + bw / 2f, h / 2f - amp), Offset(x + bw / 2f, h / 2f + amp), strokeWidth = max(1f, bw * 0.7f))
            }
        }
        // hot cues
        for (i in 0 until DjEngine.HOT) {
            val p = d.hot[i]
            if (p < 0.0) continue
            val x = (p / frames).toFloat() * w
            val col = HotColors[i]
            drawLine(col, Offset(x, 0f), Offset(x, h), strokeWidth = 2f)
            val tri = Path().apply {
                moveTo(x, 0f)
                lineTo(x + 9f, 0f)
                lineTo(x, 9f)
                close()
            }
            drawPath(tri, col)
        }
        // cue point and playhead
        val cx = (d.cue / frames).toFloat() * w
        drawLine(Color(0xFFFFB02E), Offset(cx, h * 0.55f), Offset(cx, h), strokeWidth = 2f)
        val px = prog * w
        drawLine(Color.White, Offset(px, 0f), Offset(px, h), strokeWidth = 2.5f)
    }
}
