package com.hwush.player.data

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.pow

/** The loudness of a song across its length, used to draw the waveform seek bar. Worked out once, then remembered. */
object Waveform {
    const val BARS = 96
    private const val MAX_MS = 40L * 60_000L
    private val memory = ConcurrentHashMap<String, FloatArray>()

    fun cached(path: String): FloatArray? = memory[path]

    suspend fun load(ctx: Context, t: Track): FloatArray? = withContext(Dispatchers.IO) {
        memory[t.path]?.let { return@withContext it }
        if (t.durationMs <= 0L || t.durationMs > MAX_MS) return@withContext null
        val dir = File(ctx.cacheDir, "wave").apply { mkdirs() }
        val file = File(dir, "${t.path.hashCode()}_${t.size}.bin")
        try {
            if (file.exists() && file.length() == BARS.toLong()) {
                val b = file.readBytes()
                val out = FloatArray(BARS) { (b[it].toInt() and 0xFF) / 255f }
                memory[t.path] = out
                return@withContext out
            }
        } catch (_: Exception) {
        }
        val peaks = decode(ctx, t) ?: return@withContext null
        memory[t.path] = peaks
        try {
            file.writeBytes(ByteArray(BARS) { (peaks[it].coerceIn(0f, 1f) * 255f).toInt().toByte() })
        } catch (_: Exception) {
        }
        peaks
    }

    private fun decode(ctx: Context, t: Track): FloatArray? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, t.uri, null)
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) {
                    idx = i
                    fmt = f
                    break
                }
            }
            if (idx < 0 || fmt == null) return null
            ex.selectTrack(idx)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return null
            val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else t.durationMs * 1000L
            if (durUs <= 0L) return null
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(fmt, null, null, 0)
            codec.start()
            val peaks = FloatArray(BARS)
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val deadline = System.nanoTime() + 30_000_000_000L
            while (!outputDone && System.nanoTime() < deadline) {
                if (!inputDone) {
                    val i = codec.dequeueInputBuffer(5_000L)
                    if (i >= 0) {
                        val buf = codec.getInputBuffer(i)
                        val n = if (buf != null) ex.readSampleData(buf, 0) else -1
                        if (n < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 5_000L)
                if (o >= 0) {
                    val out = codec.getOutputBuffer(o)
                    if (out != null && info.size > 0) {
                        val sb = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val bucket = ((info.presentationTimeUs.toDouble() / durUs) * BARS).toInt().coerceIn(0, BARS - 1)
                        var m = 0
                        var k = sb.position()
                        val end = sb.limit()
                        while (k < end) {
                            val v = abs(sb.get(k).toInt())
                            if (v > m) m = v
                            k += 6
                        }
                        val f = m / 32768f
                        if (f > peaks[bucket]) peaks[bucket] = f
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                }
            }
            var top = 0f
            for (p in peaks) if (p > top) top = p
            if (top <= 0.0001f) return null
            // Fill any empty gaps from the neighbour, then shape so quiet parts still show.
            for (i in 1 until BARS) if (peaks[i] == 0f) peaks[i] = peaks[i - 1]
            return FloatArray(BARS) { (peaks[it] / top).toDouble().pow(0.65).toFloat() }
        } catch (_: Exception) {
            return null
        } finally {
            try { codec?.stop() } catch (_: Exception) {}
            try { codec?.release() } catch (_: Exception) {}
            try { ex.release() } catch (_: Exception) {}
        }
    }
}
