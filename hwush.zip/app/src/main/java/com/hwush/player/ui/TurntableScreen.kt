package com.hwush.player.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Track
import com.hwush.player.dj.DjAnalyse
import com.hwush.player.dj.DjDecoder
import com.hwush.player.dj.DjEngine
import com.hwush.player.dj.DrumKit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

internal fun ttTime(s: Float): String {
    val t = s.toInt().coerceAtLeast(0)
    return "%d:%02d".format(t / 60, t % 60)
}

/**
 * Two turntables and a mixer you can play. Spin a record with a finger to scratch, tap the waveform to drop the needle,
 * set hot cues and loops, sync the beats, shape each channel with an EQ, add effects, tap pads for drums or for pieces
 * you cut out of the songs, and record the whole thing.
 */
@Composable
fun TurntableScreen(ui: UiController) {
    val app = ui.app
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { DjEngine() }
    val tracks by app.library.tracks.collectAsState()

    DisposableEffect(Unit) {
        try { app.player.player.pause() } catch (_: Exception) {}
        engine.start()
        onDispose { engine.release() }
    }

    // Only the parts that follow the sound read this, so the rest of the screen is not redrawn every frame.
    val frame = remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            androidx.compose.runtime.withFrameNanos { frame.intValue++ }
        }
    }
    // Bumped when a control changes, so the buttons show their new state.
    var ver by remember { mutableIntStateOf(0) }
    val bump: () -> Unit = { ver++ }

    var chooseFor by remember { mutableIntStateOf(-1) }
    var loading by remember { mutableStateOf("") }
    var chopSlot by remember { mutableIntStateOf(-1) }
    var recording by remember { mutableStateOf(false) }
    var chopped by remember { mutableIntStateOf(0) }

    var pendingFile by remember { mutableStateOf<File?>(null) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-wav")) { uri ->
        val f = pendingFile
        if (uri != null && f != null) {
            scope.launch {
                try {
                    withContext(Dispatchers.IO) {
                        ctx.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
                    }
                    Toast.makeText(ctx, "Saved your mix", Toast.LENGTH_SHORT).show()
                } catch (_: Exception) {
                    Toast.makeText(ctx, "Could not save the mix", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun toggleRecord() {
        if (!recording) {
            val f = File(ctx.cacheDir, "turntable-mix.wav")
            engine.startRecording(f)
            recording = engine.isRecording
        } else {
            val f = engine.stopRecording()
            recording = false
            if (f != null) {
                pendingFile = f
                saver.launch("hwush-mix-${System.currentTimeMillis() / 1000}.wav")
            }
        }
    }

    val primary = MaterialTheme.colorScheme.primary
    val tertiary = MaterialTheme.colorScheme.tertiary

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth > maxHeight

        @Composable
        fun header() {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { ui.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") }
                Column(Modifier.weight(1f)) {
                    Text("Turntables", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("Spin a record to scratch", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (recording) {
                    Text("● REC", color = Color(0xFFFF4D4D), fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 8.dp))
                }
                FilledTonalButton(onClick = { toggleRecord() }) { Text(if (recording) "Stop" else "Record") }
            }
        }

        val loadA = { chooseFor = 0 }
        val loadB = { chooseFor = 1 }

        if (wide) {
            Column(Modifier.fillMaxSize()) {
                header()
                Row(Modifier.fillMaxSize().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DeckPanel(engine, 0, primary, frame, ver, bump, loadA, Modifier.weight(1.15f).verticalScroll(rememberScrollState()))
                    Column(Modifier.weight(1.1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        MixerPanel(engine, primary, tertiary, frame, ver, bump, Modifier.fillMaxWidth())
                        FxPanel(engine, primary, ver, bump, Modifier.fillMaxWidth())
                        PadPanel(engine, primary, tertiary, chopped, { chopSlot = it }, Modifier.fillMaxWidth())
                        Spacer(Modifier.height(16.dp))
                    }
                    DeckPanel(engine, 1, tertiary, frame, ver, bump, loadB, Modifier.weight(1.15f).verticalScroll(rememberScrollState()))
                }
            }
        } else {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                header()
                DeckPanel(engine, 0, primary, frame, ver, bump, loadA, Modifier.fillMaxWidth())
                DeckPanel(engine, 1, tertiary, frame, ver, bump, loadB, Modifier.fillMaxWidth())
                MixerPanel(engine, primary, tertiary, frame, ver, bump, Modifier.fillMaxWidth())
                FxPanel(engine, primary, ver, bump, Modifier.fillMaxWidth())
                PadPanel(engine, primary, tertiary, chopped, { chopSlot = it }, Modifier.fillMaxWidth())
                Spacer(Modifier.height(24.dp))
            }
        }
    }

    if (chooseFor >= 0) {
        val deck = chooseFor
        ChooseSongDialog(
            tracks = tracks,
            onClose = { chooseFor = -1 },
            onPick = { t, startMs ->
                chooseFor = -1
                loading = "Loading ${t.title}"
                scope.launch {
                    val clip = DjDecoder.decode(ctx, t, startMs)
                    if (clip != null) {
                        loading = "Reading the beat of ${t.title}"
                        val info = withContext(Dispatchers.Default) { DjAnalyse.run(clip) }
                        engine.load(deck, clip, t.title, info)
                        bump()
                    } else {
                        Toast.makeText(ctx, "Could not read that song", Toast.LENGTH_SHORT).show()
                    }
                    loading = ""
                }
            },
        )
    }

    if (loading.isNotEmpty()) {
        AlertDialog(onDismissRequest = {}, confirmButton = {}, title = { Text("Loading") }, text = { Text(loading) })
    }

    if (chopSlot >= 0) {
        val slot = chopSlot
        var deck by remember { mutableIntStateOf(0) }
        var secs by remember { mutableFloatStateOf(1f) }
        AlertDialog(
            onDismissRequest = { chopSlot = -1 },
            title = { Text("Chop ${slot - DjEngine.BUILTIN + 1}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Cuts a piece from the deck, starting where it is now.", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = deck == 0, onClick = { deck = 0 }, label = { Text("Deck A") })
                        FilterChip(selected = deck == 1, onClick = { deck = 1 }, label = { Text("Deck B") })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (s in listOf(0.5f, 1f, 2f, 4f)) {
                            FilterChip(selected = secs == s, onClick = { secs = s }, label = { Text("${s}s") })
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val ok = engine.chop(deck, slot, secs)
                    chopped++
                    chopSlot = -1
                    if (!ok) Toast.makeText(ctx, "Load a song on that deck first", Toast.LENGTH_SHORT).show()
                }) { Text("Cut it") }
            },
            dismissButton = { TextButton(onClick = { chopSlot = -1 }) { Text("Cancel") } },
        )
    }
}

// ---------------------------------------------------------------- one deck

@Composable
private fun DeckPanel(
    engine: DjEngine,
    i: Int,
    accent: Color,
    frame: State<Int>,
    ver: Int,
    bump: () -> Unit,
    onLoad: () -> Unit,
    modifier: Modifier,
) {
    @Suppress("UNUSED_VARIABLE") val v = ver
    val ctx = LocalContext.current
    val d = engine.decks[i]
    var motor by remember { mutableStateOf(false) }
    val mut = MaterialTheme.colorScheme.onSurfaceVariant

    TtPanel(modifier) {
        // title, time and speed
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(28.dp).clip(CircleShape).background(accent), contentAlignment = Alignment.Center) {
                Text(if (i == 0) "A" else "B", color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (d.title.isBlank()) "Deck ${if (i == 0) "A" else "B"} is empty" else d.title,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.labelLarge, color = accent,
                )
                LiveText(frame, MaterialTheme.typography.labelSmall, mut) { "${ttTime(engine.seconds(i))} / ${ttTime(engine.length(i))}" }
            }
            Column(horizontalAlignment = Alignment.End) {
                LiveText(frame, MaterialTheme.typography.titleSmall, accent) {
                    if (d.bpm > 0f) "%.1f BPM".format(engine.effectiveBpm(i)) else "BPM unknown"
                }
                Canvas(Modifier.size(10.dp)) {
                    @Suppress("UNUSED_VARIABLE") val t = frame.value
                    val ph = engine.beatPhase(i)
                    drawCircle(if (d.playing && d.bpm > 0f && ph < 0.2f) accent else accent.copy(alpha = 0.16f))
                }
            }
        }
        Spacer(Modifier.height(6.dp))

        // record and pitch fader
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Vinyl(engine, i, accent, frame, Modifier.weight(1f).aspectRatio(1f))
            Column(Modifier.width(60.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                TtLabel("Pitch")
                VFader(
                    value = ((d.tempo - 1f) / d.range).coerceIn(-1f, 1f),
                    onChange = { d.tempo = 1f + it * d.range; bump() },
                    accent = accent,
                    modifier = Modifier.fillMaxWidth().height(210.dp),
                    min = -1f, max = 1f, detent = 0f,
                )
                Text(
                    "%+.1f%%".format((d.tempo - 1f) * 100f),
                    style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, color = accent,
                )
                Spacer(Modifier.height(4.dp))
                for (rg in listOf(0.08f, 0.16f, 0.5f)) {
                    Pill("±${(rg * 100).toInt()}", d.range == rg, accent, Modifier.padding(vertical = 2.dp)) {
                        val pos = ((d.tempo - 1f) / d.range).coerceIn(-1f, 1f)
                        d.range = rg
                        d.tempo = 1f + pos * rg
                        bump()
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        WaveStrip(engine, i, accent, frame, Modifier.fillMaxWidth().height(56.dp))
        Spacer(Modifier.height(8.dp))

        // transport
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pill("Load", false, accent, Modifier.weight(1f)) { onLoad() }
            Pill("Cue", false, accent, Modifier.weight(1f)) { engine.cue(i); bump() }
            Pill(if (d.playing) "Pause" else "Play", d.playing, accent, Modifier.weight(1.4f)) { engine.togglePlay(i); bump() }
            Pill("Brake", false, accent, Modifier.weight(1f)) { engine.powerOff(i, 1.6f); bump() }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((k, name) in listOf("33", "45", "78").withIndex()) {
                Pill(name, d.rpm == k, accent) { d.rpm = k; bump() }
            }
            Pill("Reverse", d.reversed, accent) { d.reversed = !d.reversed; bump() }
            Pill("Key lock", d.keyLock, accent) { d.keyLock = !d.keyLock; bump() }
            Pill("Sync", false, accent) {
                val o = engine.decks[1 - i]
                if (d.bpm <= 0f || o.bpm <= 0f) {
                    Toast.makeText(ctx, "Both decks need a song with a known speed", Toast.LENGTH_SHORT).show()
                } else if (!engine.sync(i)) {
                    Toast.makeText(ctx, "Out of reach of this pitch range. Try a wider range.", Toast.LENGTH_SHORT).show()
                }
                bump()
            }
            HoldPill("Cut", accent, onDown = { d.killed = true }, onUp = { d.killed = false })
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HoldPill("◀ Nudge", accent, Modifier.weight(1f), onDown = { d.bend = -1f }, onUp = { d.bend = 0f })
            HoldPill("Nudge ▶", accent, Modifier.weight(1f), onDown = { d.bend = 1f }, onUp = { d.bend = 0f })
        }

        // hot cues
        Spacer(Modifier.height(10.dp))
        TtLabel("Hot cues · tap to set or jump · hold to clear")
        for (row in 0 until 2) {
            Row(Modifier.fillMaxWidth().padding(top = 5.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (col in 0 until 4) {
                    val k = row * 4 + col
                    val set = d.hot[k] >= 0.0
                    Box(
                        Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(12.dp))
                            .background(HotColors[k].copy(alpha = if (set) 0.9f else 0.17f))
                            .pointerInput(i, k) {
                                detectTapGestures(
                                    onTap = { engine.hotCue(i, k); bump() },
                                    onLongPress = { engine.clearHot(i, k); bump() },
                                )
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("${k + 1}", fontWeight = FontWeight.Bold, color = if (set) Color.Black.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }

        // loops
        Spacer(Modifier.height(10.dp))
        TtLabel("Loop")
        Row(Modifier.fillMaxWidth().padding(top = 5.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pill("In", false, accent) { engine.loopIn(i); bump() }
            Pill("Out", false, accent) { engine.loopOut(i); bump() }
            Pill("Reloop", d.loopOn, accent) { engine.reloop(i); bump() }
            Pill("½", false, accent) { engine.loopHalve(i); bump() }
            Pill("×2", false, accent) { engine.loopDouble(i); bump() }
            Pill("Exit", false, accent) { engine.loopExit(i); bump() }
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((label, beats) in listOf("¼" to 0.25f, "½ " to 0.5f, "1" to 1f, "2" to 2f, "4" to 4f, "8" to 8f, "16" to 16f)) {
                Pill("Auto $label", false, accent) {
                    if (!engine.autoLoop(i, beats)) Toast.makeText(ctx, "Needs a song with a known speed", Toast.LENGTH_SHORT).show()
                    bump()
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((label, beats) in listOf("¼" to 0.25f, "½ " to 0.5f, "1" to 1f)) {
                HoldPill("Roll $label", accent, onDown = { engine.roll(i, beats, true) }, onUp = { engine.roll(i, beats, false); bump() })
            }
            if (d.bpm > 0f) {
                Pill("Grid −", false, accent) { engine.gridShift(i, -0.01f); bump() }
                Pill("Grid +", false, accent) { engine.gridShift(i, 0.01f); bump() }
            }
            Pill("Motor", motor, accent) { motor = !motor }
        }
        if (motor) {
            TtLabel("Spin-up ${"%.2f".format(d.spinUp)} s", Modifier.padding(top = 6.dp))
            Slider(value = d.spinUp, onValueChange = { d.spinUp = it; bump() }, valueRange = 0.05f..2f)
            TtLabel("Brake ${"%.2f".format(d.brake)} s")
            Slider(value = d.brake, onValueChange = { d.brake = it; bump() }, valueRange = 0.05f..3f)
        }
    }
}

// ---------------------------------------------------------------- the mixer

@Composable
private fun Strip(engine: DjEngine, i: Int, accent: Color, frame: State<Int>, bump: () -> Unit, modifier: Modifier) {
    val d = engine.decks[i]
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(if (i == 0) "A" else "B", color = accent, fontWeight = FontWeight.Bold)
        Knob(d.trim, { d.trim = it; bump() }, "Trim", accent, min = 0f, max = 2f, reset = 1f, size = 38.dp)
        Knob(d.eqHigh, { d.eqHigh = it; bump() }, "High", accent, size = 42.dp)
        Pill("Kill", d.killHigh, accent) { d.killHigh = !d.killHigh; bump() }
        Knob(d.eqMid, { d.eqMid = it; bump() }, "Mid", accent, size = 42.dp)
        Pill("Kill", d.killMid, accent) { d.killMid = !d.killMid; bump() }
        Knob(d.eqLow, { d.eqLow = it; bump() }, "Low", accent, size = 42.dp)
        Pill("Kill", d.killLow, accent) { d.killLow = !d.killLow; bump() }
        Knob(d.filter, { d.filter = it; bump() }, "Filter", accent, size = 42.dp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            VFader(d.volume, { d.volume = it; bump() }, accent, Modifier.width(44.dp).height(150.dp), min = 0f, max = 1f)
            VuMeter(frame, { d.peak }, accent, Modifier.width(10.dp).height(150.dp))
        }
        Pill("Cue", d.cueOn, accent) { d.cueOn = !d.cueOn; bump() }
    }
}

@Composable
private fun MixerPanel(
    engine: DjEngine,
    accentA: Color,
    accentB: Color,
    frame: State<Int>,
    ver: Int,
    bump: () -> Unit,
    modifier: Modifier,
) {
    @Suppress("UNUSED_VARIABLE") val v = ver
    val accent = MaterialTheme.colorScheme.secondary
    TtPanel(modifier) {
        TtLabel("Mixer")
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            Strip(engine, 0, accentA, frame, bump, Modifier.weight(1f))
            Column(Modifier.weight(0.8f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Master", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Knob(engine.master, { engine.master = it; bump() }, "Level", accent, min = 0f, max = 1f, reset = 0.85f, size = 42.dp)
                Canvas(Modifier.size(12.dp)) {
                    @Suppress("UNUSED_VARIABLE") val t = frame.value
                    drawCircle(if (engine.limiting) Color(0xFFFF4D4D) else Color(0xFFFF4D4D).copy(alpha = 0.16f))
                }
                TtLabel("Limit")
                VuMeter(frame, { engine.masterPeak }, accent, Modifier.width(14.dp).height(190.dp))
                Pill("Limiter", engine.limiter, accent) { engine.limiter = !engine.limiter; bump() }
            }
            Strip(engine, 1, accentB, frame, bump, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Text("Crossfader", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Slider(value = engine.cross, onValueChange = { engine.cross = it; bump() }, valueRange = 0f..1f)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("A", color = accentA, fontWeight = FontWeight.Bold)
            Text("B", color = accentB, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for ((k, name) in listOf("Mix", "Cut", "Power").withIndex()) {
                Pill(name, engine.crossCurve == k, accent) { engine.crossCurve = k; bump() }
            }
            Pill("Reverse", engine.crossReverse, accent) { engine.crossReverse = !engine.crossReverse; bump() }
        }
    }
}

@Composable
private fun FxPanel(engine: DjEngine, accent: Color, ver: Int, bump: () -> Unit, modifier: Modifier) {
    @Suppress("UNUSED_VARIABLE") val v = ver
    TtPanel(modifier) {
        TtLabel("Effects")
        Row(Modifier.fillMaxWidth().padding(top = 6.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pill("Echo", engine.echo, accent) { engine.echo = !engine.echo; bump() }
            Pill("Reverb", engine.reverb, accent) { engine.reverb = !engine.reverb; bump() }
            Pill("Flanger", engine.flanger, accent) { engine.flanger = !engine.flanger; bump() }
            Pill("Crush", engine.crush, accent) { engine.crush = !engine.crush; bump() }
            Pill("Stutter", engine.stutter, accent) { engine.stutter = !engine.stutter; bump() }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            Knob(engine.fxAmount, { engine.fxAmount = it; bump() }, "Amount", accent, min = 0f, max = 1f, reset = 0.5f)
            Knob(engine.echoTime, { engine.echoTime = it; bump() }, "Echo time", accent, min = 0.08f, max = 0.6f, reset = 0.31f)
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Pill("Vinyl crackle", engine.crackle, accent) { engine.crackle = !engine.crackle; bump() }
            Pill("Quantize", engine.quantize, accent) { engine.quantize = !engine.quantize; bump() }
            Pill("Split cue (L cue, R master)", engine.split, accent) { engine.split = !engine.split; bump() }
        }
    }
}

// ---------------------------------------------------------------- pads

@Composable
private fun PadPanel(engine: DjEngine, primary: Color, tertiary: Color, chopped: Int, onChop: (Int) -> Unit, modifier: Modifier) {
    @Suppress("UNUSED_VARIABLE") val c = chopped
    var bank by remember { mutableIntStateOf(0) }
    TtPanel(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TtLabel("Pads · hold a chop pad to cut a piece from a deck", Modifier.weight(1f))
            Pill("Bank 1", bank == 0, primary) { bank = 0 }
            Spacer(Modifier.width(6.dp))
            Pill("Bank 2", bank == 1, primary) { bank = 1 }
        }
        Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            for (row in 0 until 4) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for (col in 0 until 4) {
                        val idx = bank * 16 + row * 4 + col
                        val isChop = idx >= DjEngine.BUILTIN
                        val has = engine.pads[idx] != null
                        var down by remember { mutableStateOf(false) }
                        val base = if (isChop) tertiary else primary
                        Box(
                            Modifier.weight(1f).height(54.dp).clip(RoundedCornerShape(12.dp))
                                .background(
                                    androidx.compose.ui.graphics.Brush.verticalGradient(
                                        listOf(
                                            base.copy(alpha = if (down) 0.95f else if (has) 0.45f else 0.14f),
                                            base.copy(alpha = if (down) 0.7f else if (has) 0.28f else 0.08f),
                                        ),
                                    ),
                                )
                                .pointerInput(idx) {
                                    detectTapGestures(
                                        onPress = {
                                            down = true
                                            engine.padOn(idx)
                                            tryAwaitRelease()
                                            down = false
                                        },
                                        onLongPress = { if (idx >= DjEngine.BUILTIN) onChop(idx) },
                                    )
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                if (isChop) (if (has) "Chop ${idx - DjEngine.BUILTIN + 1}" else "Chop ${idx - DjEngine.BUILTIN + 1}\nempty") else DrumKit.names[idx],
                                style = MaterialTheme.typography.labelSmall, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun ChooseSongDialog(tracks: List<Track>, onClose: () -> Unit, onPick: (Track, Long) -> Unit) {
    var q by remember { mutableStateOf("") }
    var picked by remember { mutableStateOf<Track?>(null) }
    var start by remember { mutableFloatStateOf(0f) }
    val p = picked
    if (p == null) {
        val list = remember(q, tracks) {
            val s = q.trim().lowercase()
            (if (s.isEmpty()) tracks else tracks.filter { it.title.lowercase().contains(s) || it.artist.lowercase().contains(s) }).take(80)
        }
        AlertDialog(
            onDismissRequest = onClose,
            title = { Text("Pick a song") },
            text = {
                Column {
                    OutlinedTextField(value = q, onValueChange = { q = it }, singleLine = true, label = { Text("Search") }, modifier = Modifier.fillMaxWidth())
                    LazyColumn(Modifier.fillMaxWidth().height(320.dp)) {
                        items(list, key = { it.path }) { t ->
                            Column(Modifier.fillMaxWidth().clickable { picked = t; start = 0f }.padding(vertical = 8.dp)) {
                                Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                                Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } },
        )
    } else {
        val total = (p.durationMs / 1000f).coerceAtLeast(10f)
        AlertDialog(
            onDismissRequest = onClose,
            title = { Text(p.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    Text("Start from ${ttTime(start)}. About two and a half minutes from there are loaded.", style = MaterialTheme.typography.bodySmall)
                    Slider(value = start, onValueChange = { start = it }, valueRange = 0f..(total - 5f).coerceAtLeast(1f))
                }
            },
            confirmButton = { TextButton(onClick = { onPick(p, (start * 1000f).toLong()) }) { Text("Load") } },
            dismissButton = { TextButton(onClick = { picked = null }) { Text("Back") } },
        )
    }
}
