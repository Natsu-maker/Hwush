package com.hwush.player.ui

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.changedToUp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Track
import com.hwush.player.dj.DjDecoder
import com.hwush.player.dj.DjEngine
import com.hwush.player.dj.DrumKit
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.PI
import kotlin.math.atan2

private fun ttTime(s: Float): String {
    val t = s.toInt().coerceAtLeast(0)
    return "%d:%02d".format(t / 60, t % 60)
}

/**
 * Two turntables and a mixer you can play. Spin a record with a finger to scratch, slide the crossfader, tap pads
 * for drums or for pieces you cut out of the songs, and record the whole thing.
 */
@Composable
fun TurntableScreen(ui: UiController) {
    val app = ui.app
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { DjEngine() }
    val tracks by app.library.tracks.collectAsState()

    DisposableEffect(Unit) {
        try { app.player.player.pause() } catch (_: Exception) {}
        engine.start()
        onDispose { engine.release() }
    }

    // Everything on screen that follows the sound is refreshed every frame.
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            androidx.compose.runtime.withFrameNanos { tick++ }
        }
    }

    var chooseFor by remember { mutableIntStateOf(-1) }
    var loading by remember { mutableStateOf("") }
    var chopSlot by remember { mutableIntStateOf(-1) }
    var recording by remember { mutableStateOf(false) }
    var cross by remember { mutableFloatStateOf(0.5f) }
    var echo by remember { mutableStateOf(false) }
    var stut by remember { mutableStateOf(false) }
    val vol = remember { mutableStateOf(floatArrayOf(1f, 1f)) }
    var volTick by remember { mutableIntStateOf(0) }
    val filt = remember { mutableStateOf(floatArrayOf(0f, 0f)) }
    var filtTick by remember { mutableIntStateOf(0) }
    var tempoTick by remember { mutableIntStateOf(0) }
    var revTick by remember { mutableIntStateOf(0) }
    var chopped by remember { mutableIntStateOf(0) }

    var pendingFile by remember { mutableStateOf<File?>(null) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-wav")) { uri ->
        val f = pendingFile
        if (uri != null && f != null) {
            scope.launch {
                try {
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        ctx.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
                    }
                    Toast.makeText(ctx, "Saved your mix", Toast.LENGTH_SHORT).show()
                } catch (_: Exception) {
                    Toast.makeText(ctx, "Could not save the mix", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    fun toggleRecord() {
        if (!recording) {
            val f = File(ctx.cacheDir, "turntable-mix.wav")
            engine.startRecording(f)
            recording = engine.isRecording
        } else {
            val f = engine.stopRecording()
            recording = false
            if (f != null) {
                pendingFile = f
                saver.launch("hwush-mix-${System.currentTimeMillis() / 1000}.wav")
            }
        }
    }

    val primary = MaterialTheme.colorScheme.primary
    val tertiary = MaterialTheme.colorScheme.tertiary

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide = maxWidth > maxHeight

        @Composable
        fun header() {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { ui.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") }
                Column(Modifier.weight(1f)) {
                    Text("Turntables", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("Spin a record to scratch", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (recording) {
                    Text("● REC", color = Color(0xFFFF4D4D), fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 8.dp))
                }
                FilledTonalButton(onClick = { toggleRecord() }) { Text(if (recording) "Stop" else "Record") }
            }
        }

        @Composable
        fun deckPanel(i: Int, mod: Modifier) {
            val d = engine.decks[i]
            val accent = if (i == 0) primary else tertiary
            @Suppress("UNUSED_VARIABLE") val t = tick
            @Suppress("UNUSED_VARIABLE") val rv = revTick
            @Suppress("UNUSED_VARIABLE") val tp = tempoTick
            Column(mod, horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    if (d.title.isBlank()) "Deck ${if (i == 0) "A" else "B"} is empty" else d.title,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.labelLarge, color = accent,
                )
                Text(
                    "${ttTime(engine.seconds(i))} / ${ttTime(engine.length(i))}",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Platter(engine, i, accent, tick, Modifier.fillMaxWidth().aspectRatio(1f).padding(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    FilledTonalButton(onClick = { chooseFor = i }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp)) { Text("Load") }
                    Button(onClick = { engine.togglePlay(i); revTick++ }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp)) {
                        Text(if (d.playing) "Pause" else "Play")
                    }
                    FilledTonalButton(onClick = { engine.cue(i) }, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp)) { Text("Cue") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(selected = d.reversed, onClick = { d.reversed = !d.reversed; revTick++ }, label = { Text("Reverse") })
                    Box(
                        Modifier.clip(RoundedCornerShape(10.dp))
                            .background(if (d.killed) accent else MaterialTheme.colorScheme.surfaceVariant)
                            .pointerInput(i) {
                                detectTapGestures(onPress = {
                                    d.killed = true
                                    revTick++
                                    tryAwaitRelease()
                                    d.killed = false
                                    revTick++
                                })
                            }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                    ) { Text("Cut", style = MaterialTheme.typography.labelLarge, color = if (d.killed) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface) }
                }
                Text("Tempo ${"%+.0f".format((d.tempo - 1f) * 100)}%", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Slider(value = d.tempo, onValueChange = { d.tempo = it; tempoTick++ }, valueRange = 0.84f..1.16f)
            }
        }

        @Composable
        fun mixer(mod: Modifier) {
            @Suppress("UNUSED_VARIABLE") val a = volTick
            @Suppress("UNUSED_VARIABLE") val b = filtTick
            Column(mod.padding(horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Crossfader", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Slider(value = cross, onValueChange = { cross = it; engine.cross = it }, valueRange = 0f..1f)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("A", color = primary, fontWeight = FontWeight.Bold)
                    Text("B", color = tertiary, fontWeight = FontWeight.Bold)
                }
                for (i in 0..1) {
                    Text("Deck ${if (i == 0) "A" else "B"} volume", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Slider(value = vol.value[i], onValueChange = { vol.value[i] = it; engine.decks[i].volume = it; volTick++ }, valueRange = 0f..1f)
                    val f = filt.value[i]
                    Text(
                        "Filter ${if (f < -0.02f) "low pass" else if (f > 0.02f) "high pass" else "off"}",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Slider(value = f, onValueChange = { filt.value[i] = it; engine.decks[i].filter = it; filtTick++ }, valueRange = -1f..1f)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = echo, onClick = { echo = !echo; engine.echo = echo }, label = { Text("Echo") })
                    FilterChip(selected = stut, onClick = { stut = !stut; engine.stutter = stut }, label = { Text("Stutter") })
                }
            }
        }

        @Composable
        fun padGrid(mod: Modifier) {
            @Suppress("UNUSED_VARIABLE") val c = chopped
            Column(mod, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Pads · hold a chop pad to cut a piece from a deck", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                for (row in 0 until 4) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (col in 0 until 4) {
                            val idx = row * 4 + col
                            val isChop = idx >= DjEngine.BUILTIN
                            val has = engine.pads[idx] != null
                            var down by remember { mutableStateOf(false) }
                            val base = if (isChop) tertiary else primary
                            Box(
                                Modifier.weight(1f).height(54.dp).clip(RoundedCornerShape(12.dp))
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(
                                                base.copy(alpha = if (down) 0.95f else if (has) 0.45f else 0.14f),
                                                base.copy(alpha = if (down) 0.7f else if (has) 0.28f else 0.08f),
                                            ),
                                        ),
                                    )
                                    .pointerInput(idx) {
                                        detectTapGestures(
                                            onPress = {
                                                down = true
                                                engine.padOn(idx)
                                                tryAwaitRelease()
                                                down = false
                                            },
                                            onLongPress = { if (idx >= DjEngine.BUILTIN) chopSlot = idx },
                                        )
                                    },
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    if (isChop) (if (has) "Chop ${idx - DjEngine.BUILTIN + 1}" else "Chop ${idx - DjEngine.BUILTIN + 1}\nempty") else DrumKit.names[idx],
                                    style = MaterialTheme.typography.labelSmall, maxLines = 2, overflow = TextOverflow.Ellipsis,
                                    color = MaterialTheme.colorScheme.onSurface,
                                )
                            }
                        }
                    }
                }
            }
        }

        if (wide) {
            Column(Modifier.fillMaxSize()) {
                header()
                Row(Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
                    deckPanel(0, Modifier.weight(1.1f).verticalScroll(rememberScrollState()))
                    Column(Modifier.weight(1.2f).verticalScroll(rememberScrollState())) {
                        mixer(Modifier.fillMaxWidth())
                        padGrid(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp))
                    }
                    deckPanel(1, Modifier.weight(1.1f).verticalScroll(rememberScrollState()))
                }
            }
        } else {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                header()
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                    deckPanel(0, Modifier.weight(1f))
                    deckPanel(1, Modifier.weight(1f))
                }
                mixer(Modifier.fillMaxWidth())
                padGrid(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp))
                Spacer(Modifier.height(24.dp))
            }
        }
    }

    if (chooseFor >= 0) {
        val deck = chooseFor
        ChooseSongDialog(
            tracks = tracks,
            onClose = { chooseFor = -1 },
            onPick = { t, startMs ->
                chooseFor = -1
                loading = "Loading ${t.title}"
                scope.launch {
                    val clip = DjDecoder.decode(ctx, t, startMs)
                    loading = ""
                    if (clip != null) engine.load(deck, clip, t.title)
                    else Toast.makeText(ctx, "Could not read that song", Toast.LENGTH_SHORT).show()
                }
            },
        )
    }

    if (loading.isNotEmpty()) {
        AlertDialog(onDismissRequest = {}, confirmButton = {}, title = { Text("Loading") }, text = { Text(loading) })
    }

    if (chopSlot >= 0) {
        val slot = chopSlot
        var deck by remember { mutableIntStateOf(0) }
        var secs by remember { mutableFloatStateOf(1f) }
        AlertDialog(
            onDismissRequest = { chopSlot = -1 },
            title = { Text("Chop ${slot - DjEngine.BUILTIN + 1}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Cuts a piece from the deck, starting where it is now.", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = deck == 0, onClick = { deck = 0 }, label = { Text("Deck A") })
                        FilterChip(selected = deck == 1, onClick = { deck = 1 }, label = { Text("Deck B") })
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for (s in listOf(0.5f, 1f, 2f, 4f)) {
                            FilterChip(selected = secs == s, onClick = { secs = s }, label = { Text("${s}s") })
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val ok = engine.chop(deck, slot, secs)
                    chopped++
                    chopSlot = -1
                    if (!ok) Toast.makeText(ctx, "Load a song on that deck first", Toast.LENGTH_SHORT).show()
                }) { Text("Cut it") }
            },
            dismissButton = { TextButton(onClick = { chopSlot = -1 }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Platter(engine: DjEngine, deck: Int, accent: Color, tick: Int, modifier: Modifier) {
    @Suppress("UNUSED_VARIABLE") val t = tick
    val angle = engine.angle(deck)
    Canvas(
        modifier.pointerInput(deck) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                val c = Offset(size.width / 2f, size.height / 2f)
                var last = atan2(down.position.y - c.y, down.position.x - c.x)
                var lastT = down.uptimeMillis
                engine.touch(deck, 0f)
                down.consume()
                while (true) {
                    val ev = awaitPointerEvent(PointerEventPass.Main)
                    val ch = ev.changes.firstOrNull() ?: break
                    if (ch.changedToUp() || !ch.pressed) break
                    if (ch.positionChanged()) {
                        val a = atan2(ch.position.y - c.y, ch.position.x - c.x)
                        var da = a - last
                        if (da > PI.toFloat()) da -= 2f * PI.toFloat()
                        if (da < -PI.toFloat()) da += 2f * PI.toFloat()
                        val dt = (ch.uptimeMillis - lastT).coerceAtLeast(1L) / 1000f
                        val degPerSec = (da * 180f / PI.toFloat()) / dt
                        engine.touch(deck, (degPerSec / 200f).coerceIn(-12f, 12f))
                        last = a
                        lastT = ch.uptimeMillis
                        ch.consume()
                    }
                }
                engine.release(deck)
            }
        },
    ) {
        val r = size.minDimension / 2f
        val c = Offset(size.width / 2f, size.height / 2f)
        drawCircle(Color(0xFF0B0B0F), r, c)
        rotate(angle, c) {
            var g = r * 0.96f
            while (g > r * 0.36f) {
                drawCircle(Color.White.copy(alpha = 0.06f), g, c, style = androidx.compose.ui.graphics.drawscope.Stroke(1.2f))
                g -= r * 0.045f
            }
            drawCircle(accent, r * 0.3f, c)
            drawCircle(Color(0xFF0B0B0F), r * 0.04f, c)
            // a mark so the turning can be seen
            drawLine(Color.White.copy(alpha = 0.85f), Offset(c.x, c.y - r * 0.3f), Offset(c.x, c.y - r * 0.92f), strokeWidth = 4f)
        }
        drawCircle(accent.copy(alpha = 0.5f), r, c, style = androidx.compose.ui.graphics.drawscope.Stroke(3f))
    }
}

@Composable
internal fun ChooseSongDialog(tracks: List<Track>, onClose: () -> Unit, onPick: (Track, Long) -> Unit) {
    var q by remember { mutableStateOf("") }
    var picked by remember { mutableStateOf<Track?>(null) }
    var start by remember { mutableFloatStateOf(0f) }
    val p = picked
    if (p == null) {
        val list = remember(q, tracks) {
            val s = q.trim().lowercase()
            (if (s.isEmpty()) tracks else tracks.filter { it.title.lowercase().contains(s) || it.artist.lowercase().contains(s) }).take(80)
        }
        AlertDialog(
            onDismissRequest = onClose,
            title = { Text("Pick a song") },
            text = {
                Column {
                    OutlinedTextField(value = q, onValueChange = { q = it }, singleLine = true, label = { Text("Search") }, modifier = Modifier.fillMaxWidth())
                    LazyColumn(Modifier.fillMaxWidth().height(320.dp)) {
                        items(list, key = { it.path }) { t ->
                            Column(Modifier.fillMaxWidth().clickable { picked = t; start = 0f }.padding(vertical = 8.dp)) {
                                Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                                Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } },
        )
    } else {
        val total = (p.durationMs / 1000f).coerceAtLeast(10f)
        AlertDialog(
            onDismissRequest = onClose,
            title = { Text(p.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    Text("Start from ${ttTime(start)}. About two and a half minutes from there are loaded.", style = MaterialTheme.typography.bodySmall)
                    Slider(value = start, onValueChange = { start = it }, valueRange = 0f..(total - 5f).coerceAtLeast(1f))
                }
            },
            confirmButton = { TextButton(onClick = { onPick(p, (start * 1000f).toLong()) }) { Text("Load") } },
            dismissButton = { TextButton(onClick = { picked = null }) { Text("Back") } },
        )
    }
}
