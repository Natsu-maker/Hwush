package com.hwush.player.player

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import com.hwush.player.HwushApp
import com.hwush.player.MainActivity
import com.hwush.player.data.Alarm
import java.util.Calendar

/** Sets and clears the wake-up alarms with the system alarm clock, which needs no special permission. */
object Alarms {
    const val ACTION_RING = "com.hwush.player.ALARM_RING"
    const val EXTRA_ID = "id"

    private fun code(id: Long): Int = (id % 1_000_000_007L).toInt()

    /** The next moment the alarm should ring, today if it is still ahead or on the next chosen day. */
    fun nextTime(a: Alarm, now: Long = System.currentTimeMillis()): Long {
        val base = Calendar.getInstance()
        base.timeInMillis = now
        base.set(Calendar.HOUR_OF_DAY, a.hour)
        base.set(Calendar.MINUTE, a.minute)
        base.set(Calendar.SECOND, 0)
        base.set(Calendar.MILLISECOND, 0)
        for (add in 0..7) {
            val c = base.clone() as Calendar
            c.add(Calendar.DAY_OF_YEAR, add)
            if (c.timeInMillis <= now) continue
            if (a.days == 0) return c.timeInMillis
            val dow = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Monday is 0, Sunday is 6
            if ((a.days shr dow) and 1 == 1) return c.timeInMillis
        }
        return base.timeInMillis + 86_400_000L
    }

    private fun ringIntent(ctx: Context, id: Long): PendingIntent = PendingIntent.getBroadcast(
        ctx,
        code(id),
        Intent(ctx, AlarmReceiver::class.java).setAction(ACTION_RING).putExtra(EXTRA_ID, id),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    fun cancel(ctx: Context, id: Long) {
        val mgr = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        mgr.cancel(ringIntent(ctx, id))
    }

    /** Schedules the alarm if it is switched on, otherwise makes sure nothing is waiting for it. */
    fun schedule(ctx: Context, a: Alarm) {
        cancel(ctx, a.id)
        if (!a.enabled) return
        val mgr = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            ctx,
            code(a.id),
            Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        try {
            mgr.setAlarmClock(AlarmManager.AlarmClockInfo(nextTime(a), show), ringIntent(ctx, a.id))
        } catch (_: Exception) {
        }
    }

    fun scheduleAll(ctx: Context) {
        val app = ctx.applicationContext as HwushApp
        for (a in app.store.data.value.alarms) schedule(ctx, a)
    }
}

/** Wakes up when an alarm is due, and again after a restart or an update so alarms are not lost. */
class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext as HwushApp
        if (intent.action != Alarms.ACTION_RING) {
            Alarms.scheduleAll(context)
            return
        }
        val id = intent.getLongExtra(Alarms.EXTRA_ID, 0L)
        val alarm = app.store.data.value.alarms.firstOrNull { it.id == id } ?: return
        if (alarm.days == 0) {
            app.store.saveAlarm(alarm.copy(enabled = false))
        } else {
            Alarms.schedule(context, alarm)
        }
        if (!app.library.loaded.value) app.library.refresh()
        val pending = goAsync()
        Thread {
            var waited = 0
            while (!app.library.loaded.value && waited < 15_000) {
                try {
                    Thread.sleep(250)
                } catch (_: InterruptedException) {
                }
                waited += 250
            }
            Handler(Looper.getMainLooper()).post {
                try {
                    app.player.startAlarm(alarm)
                } finally {
                    pending.finish()
                }
            }
        }.start()
    }
}
