package com.hwush.player.data

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import android.provider.MediaStore.Audio.Media as AudioMedia

/** Reads songs from the device (MediaStore) and groups them into albums, artists and folders. */
class Library(private val ctx: Context, store: Store) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val raw = MutableStateFlow<List<Track>>(emptyList())

    val loading = MutableStateFlow(false)
    val loaded = MutableStateFlow(false)

    @Volatile
    private var pathMap: Map<String, Track> = emptyMap()

    private data class Filters(
        val hidden: Set<String>,
        val minSeconds: Int,
        val excluded: Set<String>,
        val tags: Map<String, TagOverride>,
    )

    val tracks: StateFlow<List<Track>> = combine(
        raw,
        store.data.map { Filters(it.hidden, it.minSeconds, it.excludedFolders, it.tags) }.distinctUntilChanged(),
    ) { r, f ->
        r.asSequence()
            .filter { t ->
                t.path !in f.hidden &&
                    t.durationMs >= f.minSeconds * 1000L &&
                    f.excluded.none { ex -> t.folder.startsWith(ex) }
            }
            .map { t ->
                val o = f.tags[t.path]
                if (o == null) t else t.copy(
                    title = o.title ?: t.title,
                    artist = o.artist ?: t.artist,
                    album = o.album ?: t.album,
                )
            }
            .toList()
    }.onEach { list ->
        pathMap = list.associateBy { it.path }
    }.stateIn(scope, SharingStarted.Eagerly, emptyList())

    val albums: StateFlow<List<AlbumInfo>> = tracks.map { list ->
        list.groupBy { "${it.albumId}|${it.album}" }.map { (k, ts) ->
            val artists = ts.map { it.artist }.distinct()
            AlbumInfo(
                key = k,
                name = ts.first().album,
                artist = if (artists.size == 1) artists[0] else "Various artists",
                tracks = ts.sortedWith(compareBy({ it.trackNo }, { it.title.lowercase() })),
            )
        }.sortedBy { it.name.lowercase() }
    }.flowOn(Dispatchers.Default).stateIn(scope, SharingStarted.Eagerly, emptyList())

    val artists: StateFlow<List<ArtistInfo>> = tracks.map { list ->
        list.groupBy { it.artist }.map { (k, ts) -> ArtistInfo(k, ts) }.sortedBy { it.name.lowercase() }
    }.flowOn(Dispatchers.Default).stateIn(scope, SharingStarted.Eagerly, emptyList())

    val folders: StateFlow<List<FolderInfo>> = tracks.map { list ->
        list.groupBy { it.folder }.map { (k, ts) -> FolderInfo(k, ts) }.sortedBy { it.path.lowercase() }
    }.flowOn(Dispatchers.Default).stateIn(scope, SharingStarted.Eagerly, emptyList())

    fun find(path: String): Track? = pathMap[path]

    fun refresh() {
        scope.launch(Dispatchers.IO) {
            loading.value = true
            try {
                raw.value = query()
            } catch (_: Exception) {
            }
            loading.value = false
            loaded.value = true
        }
    }

    private fun query(): List<Track> {
        val base = if (Build.VERSION.SDK_INT >= 29) {
            AudioMedia.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            AudioMedia.EXTERNAL_CONTENT_URI
        }
        val proj = arrayOf(
            AudioMedia._ID, AudioMedia.TITLE, AudioMedia.ARTIST, AudioMedia.ALBUM, AudioMedia.ALBUM_ID,
            AudioMedia.DURATION, AudioMedia.DATA, AudioMedia.DATE_ADDED, AudioMedia.SIZE, AudioMedia.TRACK,
        )
        val sel = "${AudioMedia.IS_RINGTONE} = 0 AND ${AudioMedia.IS_ALARM} = 0 AND " +
            "${AudioMedia.IS_NOTIFICATION} = 0 AND ${AudioMedia.DURATION} > 0"
        val out = ArrayList<Track>()
        ctx.contentResolver.query(base, proj, sel, null, null)?.use { c ->
            val iId = c.getColumnIndexOrThrow(AudioMedia._ID)
            val iTitle = c.getColumnIndexOrThrow(AudioMedia.TITLE)
            val iArtist = c.getColumnIndexOrThrow(AudioMedia.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(AudioMedia.ALBUM)
            val iAlbumId = c.getColumnIndexOrThrow(AudioMedia.ALBUM_ID)
            val iDur = c.getColumnIndexOrThrow(AudioMedia.DURATION)
            val iData = c.getColumnIndexOrThrow(AudioMedia.DATA)
            val iAdded = c.getColumnIndexOrThrow(AudioMedia.DATE_ADDED)
            val iSize = c.getColumnIndexOrThrow(AudioMedia.SIZE)
            val iTrack = c.getColumnIndexOrThrow(AudioMedia.TRACK)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                val data = c.getString(iData) ?: ""
                val artist = c.getString(iArtist)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Unknown artist"
                val album = c.getString(iAlbum)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Unknown album"
                out.add(
                    Track(
                        id = id,
                        uri = ContentUris.withAppendedId(base, id),
                        path = if (data.isNotEmpty()) data else "id:$id",
                        title = c.getString(iTitle)?.takeIf { it.isNotBlank() } ?: "Untitled",
                        artist = artist,
                        album = album,
                        albumId = c.getLong(iAlbumId),
                        durationMs = c.getLong(iDur),
                        folder = if (data.isNotEmpty()) data.substringBeforeLast('/', "") else "",
                        dateAdded = c.getLong(iAdded),
                        size = c.getLong(iSize),
                        trackNo = c.getInt(iTrack) % 1000,
                    ),
                )
            }
        }
        return out
    }
}
