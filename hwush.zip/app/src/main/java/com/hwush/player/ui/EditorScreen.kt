package com.hwush.player.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hwush.player.data.TempoMath
import com.hwush.player.dj.DjDecoder
import com.hwush.player.editor.ED_RATE
import com.hwush.player.editor.ED_TRACKS
import com.hwush.player.editor.EdClip
import com.hwush.player.editor.EdSource
import com.hwush.player.editor.EdStems
import com.hwush.player.editor.EditorEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

private val trackColors = listOf(
    Color(0xFFFF8A2B), Color(0xFF5BC0EB), Color(0xFF9BE564), Color(0xFFE25DA8), Color(0xFFF2C94C), Color(0xFFA78BFA),
)

private fun clock(sec: Double): String {
    val t = max(0.0, sec)
    val m = (t / 60).toInt()
    val s = t - m * 60
    return "%d:%04.1f".format(m, s)
}

private class SourceInfo(val bpm: Int, val energy: Int, val peakDb: Float, val rmsDb: Float, val seconds: Float)

/**
 * A timeline audio editor. Songs and pieces of songs become clips on tracks that you move, cut, fade and layer.
 * It can read a clip's tempo and loudness, match one song's speed to another, split a clip into vocals,
 * instruments and bass, and render the whole mix to a wav file.
 */
@Composable
fun EditorScreen(ui: UiController) {
    val app = ui.app
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { EditorEngine() }
    val tracksAll by app.library.tracks.collectAsState()
    var rev by remember { mutableIntStateOf(0) }
    val frame = remember { mutableIntStateOf(0) }
    var zoom by remember { mutableFloatStateOf(36f) } // dp per second
    var selected by remember { mutableIntStateOf(-1) }
    var addOpen by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf("") }
    var progress by remember { mutableFloatStateOf(-1f) }
    var leaveAsk by remember { mutableStateOf(false) }
    var trackEdit by remember { mutableIntStateOf(-1) }
    var info by remember { mutableStateOf<Pair<String, SourceInfo>?>(null) }
    var stemAsk by remember { mutableStateOf(false) }
    var matchOpen by remember { mutableStateOf(false) }
    var exportAsk by remember { mutableStateOf(false) }
    val bpmCache = remember { HashMap<Int, SourceInfo>() }
    val scroll = rememberScrollState()

    fun touch() { rev++ }
    fun cleanup() { engine.sources.removeAll { s -> engine.clips.none { it.src === s } } }

    DisposableEffect(Unit) {
        try { app.player.player.pause() } catch (_: Exception) {}
        engine.start()
        onDispose { engine.release() }
    }
    LaunchedEffect(Unit) {
        while (true) {
            androidx.compose.runtime.withFrameNanos { }
            frame.intValue++
        }
    }
    fun leave() { if (engine.clips.isEmpty()) ui.back() else leaveAsk = true }
    BackHandler { leave() }

    var pending by remember { mutableStateOf<File?>(null) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-wav")) { uri ->
        val f = pending
        if (uri != null && f != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        ctx.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                        true
                    } catch (_: Exception) { false }
                }
                Toast.makeText(ctx, if (ok) "Saved your mix" else "Could not save", Toast.LENGTH_SHORT).show()
            }
        }
    }

    suspend fun infoFor(src: EdSource): SourceInfo = bpmCache[src.id] ?: withContext(Dispatchers.Default) {
        val hop = ED_RATE / 50
        val n = src.frames / hop
        val env = FloatArray(n)
        var peak = 0
        var sumSq = 0.0
        var cnt = 0L
        var mx = 0f
        for (b in 0 until n) {
            var s = 0.0
            for (i in b * hop until (b + 1) * hop) {
                val m = (src.data[i * 2] + src.data[i * 2 + 1]) / 2
                s += m.toDouble() * m
                val a = max(abs(src.data[i * 2].toInt()), abs(src.data[i * 2 + 1].toInt()))
                if (a > peak) peak = a
            }
            sumSq += s
            cnt += hop
            env[b] = sqrt(s / hop).toFloat()
            if (env[b] > mx) mx = env[b]
        }
        if (mx > 0f) for (b in 0 until n) env[b] /= mx
        val t = TempoMath.analyse(env)
        val rms = sqrt(sumSq / max(1L, cnt)).toFloat() / 32768f
        val r = SourceInfo(
            t.bpm, t.energy,
            20f * log10(max(peak, 1) / 32768f), 20f * log10(max(rms, 1e-6f)), src.seconds,
        )
        bpmCache[src.id] = r
        r
    }

    @Suppress("UNUSED_VARIABLE") val r = rev
    val clipSel = engine.clips.firstOrNull { it.id == selected }
    val text = rememberTextMeasurer()
    val primary = MaterialTheme.colorScheme.primary
    val onSurface = MaterialTheme.colorScheme.onSurface
    val dimText = MaterialTheme.colorScheme.onSurfaceVariant

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { leave() }) { Icon(Icons.Rounded.ArrowBack, "Back") }
            Column(Modifier.weight(1f)) {
                Text("Audio editor", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                Text("Layer, cut, fade, split and mix songs", style = MaterialTheme.typography.bodySmall, color = dimText)
            }
            FilledTonalButton(onClick = { if (engine.clips.isEmpty()) Toast.makeText(ctx, "Add a song first", Toast.LENGTH_SHORT).show() else exportAsk = true }) { Text("Export") }
        }
        // Transport
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(primary).clickable { engine.toggle() },
                contentAlignment = Alignment.Center,
            ) {
                @Suppress("UNUSED_VARIABLE") val f = frame.intValue
                Icon(if (engine.playing) Icons.Rounded.Stop else Icons.Rounded.PlayArrow, "Play or stop", tint = MaterialTheme.colorScheme.onPrimary)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                @Suppress("UNUSED_VARIABLE") val f = frame.intValue
                Text(clock(engine.positionSec), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Text("of ${clock(engine.duration())}", style = MaterialTheme.typography.labelSmall, color = dimText)
            }
            Spacer(Modifier.weight(1f))
            TextButton(onClick = { zoom = max(8f, zoom / 1.4f) }) { Text("−") }
            Text("Zoom", style = MaterialTheme.typography.labelSmall, color = dimText)
            TextButton(onClick = { zoom = min(240f, zoom * 1.4f) }) { Text("+") }
            Button(onClick = { addOpen = true }) { Text("Add song") }
        }

        // Timeline
        val rulerH = 26.dp
        val rowH = 58.dp
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp)) {
            Column(Modifier.width(54.dp)) {
                Spacer(Modifier.height(rulerH))
                for (t in 0 until ED_TRACKS) {
                    val tr = engine.tracks[t]
                    Box(
                        Modifier.height(rowH).fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(10.dp))
                            .background(trackColors[t].copy(alpha = if (tr.mute) 0.12f else 0.28f)).clickable { trackEdit = t },
                        contentAlignment = Alignment.Center,
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${t + 1}", fontWeight = FontWeight.Bold, color = trackColors[t])
                            Text(if (tr.mute) "muted" else if (tr.solo) "solo" else "", fontSize = 9.sp, color = dimText)
                        }
                    }
                }
            }
            BoxWithConstraints(Modifier.weight(1f)) {
                val vpPx = with(androidx.compose.ui.platform.LocalDensity.current) { maxWidth.toPx() }
                val total = max(engine.duration() + 20.0, 40.0)
                Box(Modifier.horizontalScroll(scroll)) {
                    Canvas(
                        Modifier.width((total * zoom).dp).height(rulerH + rowH * ED_TRACKS)
                            .pointerInput(zoom, rev) {
                                detectTapGestures { p ->
                                    val pps = zoom.dp.toPx()
                                    val ry = rulerH.toPx()
                                    val rh = rowH.toPx()
                                    if (p.y < ry) {
                                        engine.seek((p.x / pps).toDouble())
                                    } else {
                                        val tr = ((p.y - ry) / rh).toInt().coerceIn(0, ED_TRACKS - 1)
                                        val tt = p.x / pps
                                        val hit = engine.clips.lastOrNull { it.track == tr && tt >= it.start && tt <= it.end }
                                        if (hit != null) {
                                            selected = hit.id
                                        } else {
                                            selected = -1
                                            engine.seek(tt.toDouble())
                                        }
                                    }
                                    touch()
                                }
                            }
                            .pointerInput(zoom) {
                                var drag: EdClip? = null
                                var grabDx = 0.0
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { p ->
                                        val pps = zoom.dp.toPx()
                                        val ry = rulerH.toPx()
                                        val tr = ((p.y - ry) / rowH.toPx()).toInt().coerceIn(0, ED_TRACKS - 1)
                                        val tt = p.x / pps
                                        drag = engine.clips.lastOrNull { it.track == tr && tt >= it.start && tt <= it.end }
                                        drag?.let { selected = it.id; grabDx = tt - it.start }
                                    },
                                    onDrag = { ch, _ ->
                                        val c = drag
                                        if (c != null) {
                                            ch.consume()
                                            val pps = zoom.dp.toPx()
                                            var ns = ch.position.x / pps - grabDx
                                            // Snap to the playhead, zero, and the edges of other clips
                                            val snapDist = 8f / pps
                                            val marks = ArrayList<Double>()
                                            marks.add(0.0); marks.add(engine.positionSec)
                                            for (o in engine.clips) if (o !== c) { marks.add(o.start); marks.add(o.end) }
                                            for (m in marks) {
                                                if (abs(ns - m) < snapDist) ns = m
                                                else if (abs(ns + c.length - m) < snapDist) ns = m - c.length
                                            }
                                            c.start = max(0.0, ns)
                                            c.track = ((ch.position.y - rulerH.toPx()) / rowH.toPx()).toInt().coerceIn(0, ED_TRACKS - 1)
                                            touch()
                                        }
                                    },
                                    onDragEnd = { drag = null },
                                    onDragCancel = { drag = null },
                                )
                            },
                    ) {
                        val pps = zoom.dp.toPx()
                        val ry = rulerH.toPx()
                        val rh = rowH.toPx()
                        val scrollPx = scroll.value.toFloat()
                        val from = scrollPx
                        val to = scrollPx + vpPx
                        drawRect(onSurface.copy(alpha = 0.06f), Offset(0f, 0f), Size(size.width, ry))
                        // Seconds along the top
                        val step = if (zoom >= 90f) 1 else if (zoom >= 40f) 2 else if (zoom >= 18f) 5 else 10
                        var s = (from / pps).toInt() / step * step
                        while (s * pps < to + 60f) {
                            val x = s * pps
                            drawLine(onSurface.copy(alpha = 0.35f), Offset(x, ry * 0.55f), Offset(x, ry), 2f)
                            if (x >= from - 40f) {
                                drawText(text, "${s / 60}:${"%02d".format(s % 60)}", Offset(x + 3f, 0f), TextStyle(fontSize = 10.sp, color = dimText))
                            }
                            s += step
                        }
                        for (t in 0 until ED_TRACKS) {
                            drawRoundRect(
                                onSurface.copy(alpha = if (t % 2 == 0) 0.05f else 0.03f),
                                Offset(0f, ry + t * rh + 2f), Size(size.width, rh - 4f), CornerRadius(10.dp.toPx()),
                            )
                        }
                        for (c in engine.clips) {
                            val x0 = (c.start * pps).toFloat()
                            val w = (c.length * pps).toFloat()
                            if (x0 + w < from - 10f || x0 > to + 10f) continue
                            val y0 = ry + c.track * rh + 4f
                            val h = rh - 8f
                            val col = trackColors[c.track.coerceIn(0, ED_TRACKS - 1)]
                            val dim = c.mute || engine.tracks[c.track].mute
                            drawRoundRect(col.copy(alpha = if (dim) 0.18f else 0.38f), Offset(x0, y0), Size(w, h), CornerRadius(8.dp.toPx()))
                            // The wave inside
                            val peaks = c.src.peaks
                            val gain = Math.pow(10.0, c.gainDb / 20.0).toFloat()
                            var px = max(x0, from - 4f)
                            val endX = min(x0 + w, to + 4f)
                            val mid = y0 + h / 2f
                            while (px < endX) {
                                val tt = (px - x0) / pps
                                val st = c.inPoint + tt * c.rate
                                val idx = (st * 100).toInt()
                                if (idx in peaks.indices) {
                                    var amp = peaks[idx] * gain
                                    if (c.fadeIn > 0 && tt < c.fadeIn) amp *= (tt / c.fadeIn).toFloat()
                                    val rem = c.length - tt
                                    if (c.fadeOut > 0 && rem < c.fadeOut) amp *= (rem / c.fadeOut).toFloat()
                                    val a = min(1f, amp) * (h / 2f - 3f)
                                    drawLine(col.copy(alpha = if (dim) 0.4f else 0.95f), Offset(px, mid - a), Offset(px, mid + a), 2f)
                                }
                                px += 2f
                            }
                            if (c.id == selected) {
                                drawRoundRect(Color.White, Offset(x0, y0), Size(w, h), CornerRadius(8.dp.toPx()), style = Stroke(3f))
                            }
                            drawText(
                                text, c.src.title, Offset(max(x0, from) + 6f, y0 + 2f),
                                TextStyle(fontSize = 10.sp, color = onSurface, fontWeight = FontWeight.SemiBold),
                                overflow = TextOverflow.Ellipsis, maxLines = 1,
                                size = Size(max(10f, min(x0 + w, to) - max(x0, from) - 10f), 40f),
                            )
                        }
                        val px = (frame.intValue * 0 + engine.positionSec * pps).toFloat()
                        drawLine(primary, Offset(px, 0f), Offset(px, size.height), 3f)
                    }
                }
            }
        }
        // Keep the playhead in view while playing
        LaunchedEffect(Unit) {
            while (true) {
                delay(120)
                if (engine.playing) {
                    val x = (engine.positionSec * zoom * ctx.resources.displayMetrics.density).toInt()
                    val vp = (ctx.resources.displayMetrics.widthPixels * 0.7f).toInt()
                    if (x > scroll.value + vp || x < scroll.value) scroll.scrollTo(max(0, x - vp / 5))
                }
            }
        }
        Text("Tap the top to place the playhead. Tap a clip to pick it. Hold a clip, then drag, to move it. Tap a track number for volume, pan, mute and solo.", Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall, color = dimText)

        // The selected clip
        if (clipSel != null) {
            val c = clipSel
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp).clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.8f)).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                Text(c.src.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Track ${c.track + 1} · starts ${clock(c.start)} · ${"%.1f".format(c.length)} s", style = MaterialTheme.typography.bodySmall, color = dimText)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = {
                        val n = engine.split(c, engine.positionSec)
                        if (n == null) Toast.makeText(ctx, "Put the playhead inside the clip", Toast.LENGTH_SHORT).show() else selected = n.id
                        touch()
                    }) { Text("Split") }
                    OutlinedButton(onClick = { engine.trimStart(c, engine.positionSec); touch() }) { Text("Trim start") }
                    OutlinedButton(onClick = { engine.trimEnd(c, engine.positionSec); touch() }) { Text("Trim end") }
                    OutlinedButton(onClick = { selected = engine.duplicate(c).id; touch() }) { Text("Copy") }
                    OutlinedButton(onClick = { c.mute = !c.mute; touch() }) { Text(if (c.mute) "Unmute" else "Mute") }
                    OutlinedButton(onClick = { engine.clips.remove(c); selected = -1; cleanup(); touch() }) { Text("Delete") }
                }
                Text("Volume ${"%+.0f".format(c.gainDb)} dB", style = MaterialTheme.typography.labelMedium, color = dimText)
                Slider(value = c.gainDb, onValueChange = { c.gainDb = it; touch() }, valueRange = -24f..12f)
                Text("Fade in ${"%.1f".format(c.fadeIn)} s", style = MaterialTheme.typography.labelMedium, color = dimText)
                Slider(value = c.fadeIn, onValueChange = { c.fadeIn = min(it, (c.length / 2).toFloat()); touch() }, valueRange = 0f..8f)
                Text("Fade out ${"%.1f".format(c.fadeOut)} s", style = MaterialTheme.typography.labelMedium, color = dimText)
                Slider(value = c.fadeOut, onValueChange = { c.fadeOut = min(it, (c.length / 2).toFloat()); touch() }, valueRange = 0f..8f)
                Text("Speed ${"%.2f".format(c.rate)}x (pitch moves with speed)", style = MaterialTheme.typography.labelMedium, color = dimText)
                Slider(value = c.rate, onValueChange = { engine.setRate(c, (it * 20).toInt() / 20f); touch() }, valueRange = 0.7f..1.4f)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilledTonalButton(onClick = {
                        busy = "Reading the song"
                        progress = -1f
                        scope.launch { info = c.src.title to infoFor(c.src); busy = "" }
                    }) { Text("Analyse") }
                    FilledTonalButton(onClick = { matchOpen = true }) { Text("Match tempo") }
                    FilledTonalButton(onClick = { stemAsk = true }) { Text("Split vocals and instruments") }
                }
            }
        } else if (engine.clips.isEmpty()) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Start with a song", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "Add songs, layer them on different tracks, cut and fade them, match their tempo, and split a song into vocals, instruments and bass. Export the mix when it sounds right.",
                    style = MaterialTheme.typography.bodyMedium, color = dimText, textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
            }
        }
        Spacer(Modifier.height(32.dp))
    }

    // ---------------------------------------------------------------- dialogs
    if (addOpen) {
        ChooseSongDialog(
            tracks = tracksAll,
            onClose = { addOpen = false },
            onPick = { t, startMs ->
                addOpen = false
                busy = "Loading ${t.title}"
                progress = -1f
                scope.launch {
                    val clip = DjDecoder.decode(ctx, t, startMs, 150)
                    if (clip == null) {
                        busy = ""
                        Toast.makeText(ctx, "Could not read that song", Toast.LENGTH_SHORT).show()
                    } else if (engine.totalSeconds() + clip.frames.toFloat() / clip.sampleRate > 800f) {
                        busy = ""
                        Toast.makeText(ctx, "Too much audio loaded. Delete a clip first.", Toast.LENGTH_LONG).show()
                    } else {
                        val data = withContext(Dispatchers.Default) { resampleStereo(clip.data, clip.sampleRate) }
                        val src = engine.addSource(t.title, data)
                        val at = engine.positionSec
                        val c = engine.addClip(src, engine.freeTrack(at, src.seconds.toDouble()), at)
                        selected = c.id
                        busy = ""
                        touch()
                    }
                }
            },
        )
    }

    if (busy.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = {}, confirmButton = {}, title = { Text("Please wait") },
            text = {
                Column {
                    Text(busy)
                    Spacer(Modifier.height(10.dp))
                    if (progress in 0f..1f) LinearProgressIndicator(progress = { progress }, Modifier.fillMaxWidth())
                    else LinearProgressIndicator(Modifier.fillMaxWidth())
                }
            },
        )
    }

    if (leaveAsk) {
        AlertDialog(
            onDismissRequest = { leaveAsk = false },
            title = { Text("Leave the editor?") },
            text = { Text("Your edit is not saved. Export the mix first if you want to keep it.") },
            confirmButton = { TextButton(onClick = { leaveAsk = false; ui.back() }) { Text("Leave") } },
            dismissButton = { TextButton(onClick = { leaveAsk = false }) { Text("Stay") } },
        )
    }

    if (trackEdit >= 0) {
        val tr = engine.tracks[trackEdit]
        var local by remember { mutableIntStateOf(0) }
        @Suppress("UNUSED_VARIABLE") val l = local
        AlertDialog(
            onDismissRequest = { trackEdit = -1 },
            title = { Text("Track ${trackEdit + 1}", color = trackColors[trackEdit]) },
            text = {
                Column {
                    Text("Volume", style = MaterialTheme.typography.labelMedium)
                    Slider(value = tr.vol, onValueChange = { tr.vol = it; local++ }, valueRange = 0f..1.2f)
                    Text("Pan", style = MaterialTheme.typography.labelMedium)
                    Slider(value = tr.pan, onValueChange = { tr.pan = it; local++ }, valueRange = -1f..1f)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        androidx.compose.material3.FilterChip(selected = tr.mute, onClick = { tr.mute = !tr.mute; local++; touch() }, label = { Text("Mute") })
                        androidx.compose.material3.FilterChip(selected = tr.solo, onClick = { tr.solo = !tr.solo; local++; touch() }, label = { Text("Solo") })
                    }
                }
            },
            confirmButton = { TextButton(onClick = { trackEdit = -1; touch() }) { Text("Done") } },
        )
    }

    info?.let { (title, i) ->
        AlertDialog(
            onDismissRequest = { info = null },
            title = { Text("About this song") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text("Tempo about ${if (i.bpm > 0) i.bpm else "unknown"} BPM")
                    Text("Energy ${i.energy} out of 100")
                    Text("Loudest point ${"%.1f".format(i.peakDb)} dB")
                    Text("Average loudness ${"%.1f".format(i.rmsDb)} dB")
                    Text("Length of the loaded piece ${"%.0f".format(i.seconds)} s")
                    Text("The tempo is a guess from the loudness. Songs with changing speed or very soft beats can be off, sometimes by half or double.", style = MaterialTheme.typography.bodySmall, color = dimText)
                }
            },
            confirmButton = { TextButton(onClick = { info = null }) { Text("Close") } },
        )
    }

    if (matchOpen && clipSel != null) {
        val me = clipSel
        val others = engine.clips.filter { it.src !== me.src }.distinctBy { it.src.id }
        AlertDialog(
            onDismissRequest = { matchOpen = false },
            title = { Text("Match tempo to…") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (others.isEmpty()) Text("Add another song first, then speed this one up or slow it down to match.")
                    for (o in others) {
                        OutlinedButton(onClick = {
                            matchOpen = false
                            busy = "Finding both tempos"
                            progress = -1f
                            scope.launch {
                                val a = infoFor(me.src)
                                val b = infoFor(o.src)
                                busy = ""
                                if (a.bpm > 0 && b.bpm > 0) {
                                    var ratio = b.bpm.toFloat() / a.bpm
                                    // A half or double reading means the same beat, so fold it back near 1
                                    while (ratio > 1.45f) ratio /= 2f
                                    while (ratio < 0.7f) ratio *= 2f
                                    engine.setRate(me, ratio)
                                    Toast.makeText(ctx, "Speed set to ${"%.2f".format(me.rate)}x", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(ctx, "Could not find a clear beat", Toast.LENGTH_SHORT).show()
                                }
                                touch()
                            }
                        }, modifier = Modifier.fillMaxWidth()) { Text(o.src.title, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { matchOpen = false }) { Text("Cancel") } },
        )
    }

    if (stemAsk && clipSel != null) {
        val me = clipSel
        AlertDialog(
            onDismissRequest = { stemAsk = false },
            title = { Text("Split into parts") },
            text = {
                Text(
                    "Makes three new clips from this one: vocals, instruments and bass, each on its own track. " +
                        "It works from where sounds sit in the stereo picture and in pitch, so it is rougher than an AI service, " +
                        "and drums in the middle can leak into the vocals. It takes about ${(me.length / 8).toInt().coerceAtLeast(3)} to ${(me.length / 4).toInt().coerceAtLeast(6)} seconds.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    stemAsk = false
                    busy = "Splitting ${me.src.title}"
                    progress = 0f
                    scope.launch {
                        val stems = withContext(Dispatchers.Default) {
                            val seg = engine.cutOut(me)
                            EdStems.split(seg) { p -> progress = p }
                        }
                        val base = me.src.title
                        val dur = stems.vocals.size / 2.0 / ED_RATE
                        val items = listOf("Vocals" to stems.vocals, "Instruments" to stems.instrumental, "Bass" to stems.bass)
                        var last: EdClip? = null
                        for ((name, data) in items) {
                            val src = engine.addSource("$name · $base", data)
                            val tr = engine.freeTrack(me.start, dur)
                            val nc = EdClip(engine.newId(), src, tr, me.start, 0.0, dur)
                            nc.gainDb = me.gainDb
                            engine.clips.add(nc)
                            last = nc
                        }
                        me.mute = true
                        busy = ""
                        progress = -1f
                        selected = last?.id ?: selected
                        touch()
                    }
                }) { Text("Split") }
            },
            dismissButton = { TextButton(onClick = { stemAsk = false }) { Text("Cancel") } },
        )
    }

    if (exportAsk) {
        AlertDialog(
            onDismissRequest = { exportAsk = false },
            title = { Text("Export the mix") },
            text = { Text("Renders all tracks into one wav file, ${clock(engine.duration())} long.") },
            confirmButton = {
                TextButton(onClick = {
                    exportAsk = false
                    engine.playing = false
                    busy = "Rendering your mix"
                    progress = 0f
                    scope.launch {
                        val out = File(ctx.cacheDir, "editor-mix.wav")
                        val ok = withContext(Dispatchers.Default) { engine.export(out) { p -> progress = p } }
                        busy = ""
                        progress = -1f
                        if (ok) {
                            pending = out
                            saver.launch("hwush-mix-${System.currentTimeMillis() / 1000}.wav")
                        } else {
                            Toast.makeText(ctx, "Could not make the file", Toast.LENGTH_SHORT).show()
                        }
                    }
                }) { Text("Export") }
            },
            dismissButton = { TextButton(onClick = { exportAsk = false }) { Text("Cancel") } },
        )
    }
}

/** Turns stereo sound at any rate into stereo at 44100 Hz, the rate the editor works in. */
private fun resampleStereo(data: ShortArray, rate: Int): ShortArray {
    if (rate == ED_RATE) return data
    val frames = data.size / 2
    val ratio = rate.toDouble() / ED_RATE
    val n = (frames / ratio).toInt().coerceAtLeast(2)
    val out = ShortArray(n * 2)
    for (i in 0 until n) {
        val p = i * ratio
        val k = p.toInt().coerceAtMost(frames - 2)
        val f = (p - k).toFloat()
        out[i * 2] = (data[k * 2] + (data[(k + 1) * 2] - data[k * 2]) * f).toInt().toShort()
        out[i * 2 + 1] = (data[k * 2 + 1] + (data[(k + 1) * 2 + 1] - data[k * 2 + 1]) * f).toInt().toShort()
    }
    return out
}
