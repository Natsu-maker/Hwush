package com.hwush.player.dj

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tanh

private const val HOP = 1024
private val WIN = FloatArray(HOP) { (0.5 - 0.5 * cos(PI * it / HOP)).toFloat() }
private val RPM = floatArrayOf(1f, 1.35f, 2.34f) // 33 1/3, 45 and 78, as a speed compared with 33 1/3
private val A_LOW = (1.0 - exp(-2.0 * PI * 250.0 / DjEngine.RATE)).toFloat()
private val A_HIGH = (1.0 - exp(-2.0 * PI * 2500.0 / DjEngine.RATE)).toFloat()

/**
 * The sound of the turntable instrument. Two decks play pieces of songs held in memory, so the sound can be pushed
 * forward and backward by hand like a record. Each deck has speed (33, 45, 78), pitch with key lock, nudge, brake and
 * spin-up, eight hot cues, loops and loop rolls, a beat grid with sync, a three band EQ with kills, a filter, a trim
 * and level meters. The mixer has three crossfader curves, a reverse switch, effects (echo, reverb, flanger, crush,
 * stutter), a limiter, a split cue mode, a pad sampler with banks and a recorder.
 */
class DjEngine {
    companion object {
        const val RATE = 44100
        const val CHUNK = 256
        const val PADS = 32
        const val BUILTIN = 12
        const val HOT = 8
        private const val TURN = 200f // degrees per second of a record at 33 and a third rpm
    }

    class Deck {
        @Volatile var clip: DjClip? = null
        @Volatile var title: String = ""
        @Volatile var pos = 0.0 // frames of the clip
        @Volatile var playing = false
        @Volatile var reversed = false
        @Volatile var tempo = 1f // the pitch fader as a speed: 1 is normal
        @Volatile var rpm = 0 // 0 is 33, 1 is 45, 2 is 78
        @Volatile var range = 0.08f // how far the pitch fader reaches
        @Volatile var keyLock = false
        @Volatile var bend = 0f // nudge, -1 to 1
        @Volatile var spinUp = 0.08f // seconds to reach speed
        @Volatile var brake = 0.2f // seconds to stop
        @Volatile var volume = 1f
        @Volatile var trim = 1f
        @Volatile var filter = 0f // -1 low pass, 0 off, +1 high pass
        @Volatile var eqLow = 0f // -1 is all the way down, +1 is a boost
        @Volatile var eqMid = 0f
        @Volatile var eqHigh = 0f
        @Volatile var killLow = false
        @Volatile var killMid = false
        @Volatile var killHigh = false
        @Volatile var killed = false // held for transformer style cuts
        @Volatile var cueOn = false // sent to the cue side in split mode
        @Volatile var touching = false
        @Volatile var touchRate = 0f
        @Volatile var lastTouchNs = 0L
        @Volatile var cue = 0.0
        val hot = DoubleArray(HOT) { -1.0 }
        @Volatile var loopIn = -1.0
        @Volatile var loopOut = -1.0
        @Volatile var loopOn = false
        @Volatile var rolling = false
        @Volatile var shadow = 0.0
        @Volatile var bpm = 0f // 0 when the speed is not known
        @Volatile var gridOffset = 0f // seconds from the start of the piece to the first beat
        @Volatile var overview: FloatArray = FloatArray(0)
        @Volatile var peak = 0f // for the level meter
        var vel = 0f
        var gain = 0f
        // filter, EQ and key lock memory
        var fLowL = 0f
        var fLowR = 0f
        var e1l = 0f
        var e1r = 0f
        var e2l = 0f
        var e2r = 0f
        var h1l = 0f
        var h1r = 0f
        var klOn = false
        var kPh = 0
        var kNew = 0.0
        var kOld = 0.0
    }

    class Voice(val data: ShortArray, var pos: Int)

    val decks = arrayOf(Deck(), Deck())
    @Volatile var cross = 0.5f // 0 is all deck A, 1 is all deck B
    @Volatile var crossCurve = 0 // 0 smooth mix, 1 sharp cut for scratching, 2 constant power
    @Volatile var crossReverse = false // the hamster switch
    @Volatile var echo = false
    @Volatile var reverb = false
    @Volatile var flanger = false
    @Volatile var crush = false
    @Volatile var stutter = false
    @Volatile var fxAmount = 0.5f
    @Volatile var echoTime = 0.31f // seconds
    @Volatile var crackle = false
    @Volatile var quantize = false
    @Volatile var split = false // left side carries the cue, right side the master, for a splitter cable
    @Volatile var limiter = true
    @Volatile var master = 0.85f
    @Volatile var masterPeak = 0f
    @Volatile var limiting = false

    /** Sounds on the pads: 12 built in, then slots that hold pieces cut from the decks. */
    val pads = arrayOfNulls<ShortArray>(PADS)
    private val voices = ArrayList<Voice>()

    @Volatile private var running = false
    private var thread: Thread? = null
    private var track: AudioTrack? = null

    @Volatile private var recOut: BufferedOutputStream? = null
    @Volatile private var recBytes = 0L
    private var recFile: File? = null

    // Echo memory
    private val delayLen = (RATE * 0.62f).toInt()
    private val delayL = FloatArray(delayLen)
    private val delayR = FloatArray(delayLen)
    private var delayAt = 0
    private var echoSend = 0f
    // Reverb
    private val combLen = intArrayOf(1116, 1188, 1277, 1356)
    private val combBuf = Array(4) { FloatArray(combLen[it]) }
    private val combIdx = IntArray(4)
    private val combLp = FloatArray(4)
    private val apLen = intArrayOf(556, 441)
    private val apBuf = Array(2) { FloatArray(apLen[it]) }
    private val apIdx = IntArray(2)
    private var revSend = 0f
    // Flanger
    private val flL = FloatArray(2048)
    private val flR = FloatArray(2048)
    private var flAt = 0
    private var flPhase = 0.0
    private var flSend = 0f
    // Crush
    private var crushHoldL = 0f
    private var crushHoldR = 0f
    private var crushCount = 0
    private var crushSend = 0f
    // Stutter and limiter
    private var gate = 1f
    private var counter = 0L
    private var limG = 1f
    // Vinyl noise
    private var noiseSeed = 22222
    private var pop = 0f
    // Reading a piece
    private var rl = 0f
    private var rr = 0f

    init {
        val kit = DrumKit.build()
        for (i in kit.indices) pads[i] = kit[i]
    }

    // ---------------------------------------------------------------- control

    fun start() {
        if (thread != null) return
        val minBuf = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build(),
            )
            .setAudioFormat(
                AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build(),
            )
            .setBufferSizeInBytes(maxOf(minBuf, CHUNK * 4 * 3))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        track = t
        running = true
        t.play()
        thread = Thread({ loop(t) }, "hwush-dj").also {
            it.priority = Thread.MAX_PRIORITY
            it.start()
        }
    }

    fun release() {
        running = false
        try { thread?.join(600) } catch (_: Exception) {}
        thread = null
        stopRecording()
        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        track = null
        for (d in decks) { d.clip = null; d.playing = false }
    }

    fun load(deck: Int, clip: DjClip, title: String, info: DjInfo? = null) {
        val d = decks[deck]
        d.playing = false
        d.vel = 0f
        d.pos = 0.0
        d.cue = 0.0
        d.klOn = false
        d.loopOn = false
        d.loopIn = -1.0
        d.loopOut = -1.0
        d.rolling = false
        for (i in 0 until HOT) d.hot[i] = -1.0
        d.bpm = info?.bpm ?: 0f
        d.gridOffset = info?.offset ?: 0f
        d.overview = info?.overview ?: FloatArray(0)
        d.title = title
        d.clip = clip
    }

    fun togglePlay(deck: Int) {
        val d = decks[deck]
        if (d.clip == null) return
        d.playing = !d.playing
    }

    /** Stops the record with a long, slow brake, like turning the motor off. */
    fun powerOff(deck: Int, seconds: Float) {
        val d = decks[deck]
        if (d.clip == null) return
        val old = d.brake
        d.brake = seconds
        d.playing = false
        Thread {
            try { Thread.sleep((seconds * 1000f).toLong() + 200L) } catch (_: Exception) {}
            d.brake = old
        }.start()
    }

    private fun beatLen(d: Deck): Double {
        val c = d.clip ?: return 0.0
        return if (d.bpm > 0f) 60.0 / d.bpm * c.sampleRate else 0.0
    }

    /** Moves a position onto the nearest beat of the grid when quantize is on. */
    private fun snap(d: Deck, pos: Double): Double {
        val c = d.clip ?: return pos
        val b = beatLen(d)
        if (!quantize || b <= 0.0) return pos
        val off = d.gridOffset.toDouble() * c.sampleRate
        val k = Math.round((pos - off) / b)
        return max(0.0, off + k * b)
    }

    /** While playing, jumps back to the cue point. While stopped, sets the cue point here. */
    fun cue(deck: Int) {
        val d = decks[deck]
        if (d.clip == null) return
        if (d.playing) { d.pos = d.cue; d.klOn = false } else d.cue = snap(d, d.pos)
    }

    fun hotCue(deck: Int, i: Int) {
        val d = decks[deck]
        if (d.clip == null || i !in 0 until HOT) return
        if (d.hot[i] < 0.0) {
            d.hot[i] = snap(d, d.pos)
        } else {
            d.pos = d.hot[i]
            d.klOn = false
            if (!d.playing) d.playing = true
        }
    }

    fun clearHot(deck: Int, i: Int) {
        if (i in 0 until HOT) decks[deck].hot[i] = -1.0
    }

    fun seek(deck: Int, frac: Float) {
        val d = decks[deck]
        val c = d.clip ?: return
        d.pos = (frac.coerceIn(0f, 1f) * (c.frames - 2)).toDouble()
        d.klOn = false
    }

    // ----- loops

    fun loopIn(deck: Int) {
        val d = decks[deck]
        if (d.clip == null) return
        d.loopIn = snap(d, d.pos)
        if (d.loopOut <= d.loopIn) { d.loopOut = -1.0; d.loopOn = false }
    }

    fun loopOut(deck: Int) {
        val d = decks[deck]
        if (d.clip == null || d.loopIn < 0.0) return
        val p = snap(d, d.pos)
        if (p > d.loopIn + 200.0) { d.loopOut = p; d.loopOn = true }
    }

    fun reloop(deck: Int) {
        val d = decks[deck]
        if (d.loopIn < 0.0 || d.loopOut <= d.loopIn) return
        if (!d.loopOn && d.pos > d.loopOut) d.pos = d.loopIn
        d.loopOn = !d.loopOn
    }

    fun loopExit(deck: Int) {
        decks[deck].loopOn = false
    }

    /** A loop of [beats] beats from here. Needs the speed of the song to be known. */
    fun autoLoop(deck: Int, beats: Float): Boolean {
        val d = decks[deck]
        val c = d.clip ?: return false
        val b = beatLen(d)
        if (b <= 0.0) return false
        val a = snap(d, d.pos)
        val e = a + b * beats
        if (e >= c.frames - 2) return false
        d.loopIn = a
        d.loopOut = e
        d.loopOn = true
        return true
    }

    fun loopHalve(deck: Int) {
        val d = decks[deck]
        if (d.loopOut > d.loopIn && d.loopIn >= 0.0) d.loopOut = d.loopIn + (d.loopOut - d.loopIn) / 2.0
    }

    fun loopDouble(deck: Int) {
        val d = decks[deck]
        val c = d.clip ?: return
        if (d.loopOut > d.loopIn && d.loopIn >= 0.0) {
            val e = d.loopIn + (d.loopOut - d.loopIn) * 2.0
            if (e < c.frames - 2) d.loopOut = e
        }
    }

    /** Loop roll: loops while held, then the song carries on from where it would have been. */
    fun roll(deck: Int, beats: Float, on: Boolean) {
        val d = decks[deck]
        if (d.clip == null) return
        if (on) {
            if (d.rolling) return
            d.shadow = d.pos
            val savedQ = quantize
            quantize = false
            val ok = autoLoop(deck, beats)
            quantize = savedQ
            d.rolling = ok
        } else if (d.rolling) {
            d.loopOn = false
            d.pos = d.shadow
            d.klOn = false
            d.rolling = false
        }
    }

    // ----- speed, beat grid and sync

    /** The speed the deck is really playing at, in beats per minute. */
    fun effectiveBpm(deck: Int): Float {
        val d = decks[deck]
        return d.bpm * d.tempo * RPM[d.rpm.coerceIn(0, 2)]
    }

    /** Where in the beat the deck is, from 0 to 1. */
    fun beatPhase(deck: Int): Float {
        val d = decks[deck]
        val c = d.clip ?: return 0f
        val b = beatLen(d)
        if (b <= 0.0) return 0f
        val x = (d.pos - d.gridOffset * c.sampleRate) / b
        return (x - Math.floor(x)).toFloat()
    }

    fun gridShift(deck: Int, seconds: Float) {
        val d = decks[deck]
        d.gridOffset += seconds
    }

    /** Matches this deck's speed to the other deck, and lines up the beats when both are playing. */
    fun sync(deck: Int): Boolean {
        val d = decks[deck]
        val o = decks[1 - deck]
        if (d.clip == null || o.clip == null || d.bpm <= 0f || o.bpm <= 0f) return false
        val want = effectiveBpm(1 - deck) / (d.bpm * RPM[d.rpm.coerceIn(0, 2)])
        d.tempo = want.coerceIn(1f - d.range, 1f + d.range)
        if (d.playing && o.playing) {
            var delta = beatPhase(1 - deck) - beatPhase(deck)
            if (delta > 0.5f) delta -= 1f
            if (delta < -0.5f) delta += 1f
            d.pos = max(0.0, d.pos + delta * beatLen(d))
            d.klOn = false
        }
        return abs(want - d.tempo) < 0.005f
    }

    fun touch(deck: Int, rate: Float) {
        val d = decks[deck]
        d.touchRate = rate
        d.lastTouchNs = System.nanoTime()
        d.touching = true
    }

    fun release(deck: Int) {
        decks[deck].touching = false
    }

    /** Where the record is, in degrees, so the platter on screen turns with the sound. */
    fun angle(deck: Int): Float {
        val d = decks[deck]
        val c = d.clip ?: return 0f
        return ((d.pos / c.sampleRate) * TURN % 360.0).toFloat()
    }

    fun seconds(deck: Int): Float {
        val d = decks[deck]
        val c = d.clip ?: return 0f
        return (d.pos / c.sampleRate).toFloat()
    }

    fun length(deck: Int): Float {
        val c = decks[deck].clip ?: return 0f
        return c.frames.toFloat() / c.sampleRate
    }

    /** Cuts [seconds] out of the deck from where it is now and puts it on a pad slot. */
    fun chop(deck: Int, slot: Int, seconds: Float): Boolean {
        val d = decks[deck]
        val c = d.clip ?: return false
        if (slot < BUILTIN || slot >= PADS) return false
        val step = c.sampleRate.toDouble() / RATE
        val n = (seconds * RATE).toInt().coerceAtLeast(1)
        val out = ShortArray(n)
        var p = d.pos
        for (i in 0 until n) {
            val f = p.toInt()
            if (f >= c.frames) break
            out[i] = ((c.data[f * 2] + c.data[f * 2 + 1]) / 2).toShort()
            p += step
        }
        // A tiny fade at each end avoids clicks.
        val fade = minOf(220, n / 2)
        for (i in 0 until fade) {
            val g = i.toFloat() / fade
            out[i] = (out[i] * g).toInt().toShort()
            out[n - 1 - i] = (out[n - 1 - i] * g).toInt().toShort()
        }
        pads[slot] = out
        return true
    }

    fun padOn(i: Int): Boolean {
        val s = pads.getOrNull(i) ?: return false
        synchronized(voices) {
            if (voices.size >= 24) voices.removeAt(0)
            voices.add(Voice(s, 0))
        }
        return true
    }

    fun startRecording(file: File) {
        try {
            val out = BufferedOutputStream(FileOutputStream(file), 1 shl 16)
            out.write(ByteArray(44)) // the header is filled in when recording stops
            recFile = file
            recBytes = 0L
            recOut = out
        } catch (_: Exception) {
            recOut = null
        }
    }

    /** Stops recording and returns the finished .wav file, or null if nothing was recording. */
    fun stopRecording(): File? {
        val out = recOut ?: return null
        recOut = null
        val f = recFile
        try {
            out.flush()
            out.close()
            if (f != null) {
                RandomAccessFile(f, "rw").use { raf ->
                    val data = recBytes.toInt()
                    val h = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                    h.put("RIFF".toByteArray()).putInt(36 + data).put("WAVE".toByteArray())
                    h.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(2).putInt(RATE).putInt(RATE * 4).putShort(4).putShort(16)
                    h.put("data".toByteArray()).putInt(data)
                    raf.seek(0)
                    raf.write(h.array())
                }
            }
        } catch (_: Exception) {
            return null
        }
        return f
    }

    val isRecording: Boolean get() = recOut != null

    // ---------------------------------------------------------------- reading a deck

    private fun loopWrap(d: Deck, x: Double): Double {
        if (!d.loopOn) return x
        val a = d.loopIn
        val b = d.loopOut
        if (b <= a) return x
        return if (x >= b) a + ((x - a) % (b - a)) else x
    }

    private fun read(c: DjClip, p: Double) {
        val i = p.toInt()
        if (p < 0.0 || i >= c.frames - 1) {
            rl = 0f
            rr = 0f
            return
        }
        val fr = (p - i).toFloat()
        val a = i * 2
        rl = (c.data[a] + (c.data[a + 2] - c.data[a]) * fr) / 32768f
        rr = (c.data[a + 1] + (c.data[a + 3] - c.data[a + 1]) * fr) / 32768f
    }

    /** Moves one deck on by one output sample and leaves what it plays in [rl] and [rr]. */
    private fun deckSample(d: Deck, c: DjClip, now: Long, kUp: Float, kDown: Float) {
        val step = c.sampleRate.toDouble() / RATE
        val base = d.tempo * RPM[d.rpm.coerceIn(0, 2)] * (1f + d.bend * 0.06f)
        val target = when {
            d.touching -> if (now - d.lastTouchNs > 45_000_000L) 0f else d.touchRate
            d.playing -> if (d.reversed) -base else base
            else -> 0f
        }
        val k = if (d.touching) 0.02f else if (d.playing) kUp else kDown
        d.vel += (target - d.vel) * k
        if (!d.playing && !d.touching && abs(d.vel) < 0.0005f) d.vel = 0f

        val useKl = d.keyLock && !d.touching && d.playing && !d.reversed && d.vel > 0.05f && abs(base - 1f) > 0.002f
        if (useKl) {
            // Key lock: two overlapping short grains, read at normal pitch and moved on at the deck's speed.
            if (!d.klOn) {
                d.klOn = true
                d.kPh = 0
                d.kNew = d.pos
                d.kOld = d.pos
            }
            val ph = d.kPh
            val w1 = WIN[ph]
            val w0 = 1f - w1
            read(c, loopWrap(d, d.kNew + ph * step))
            val nl = rl
            val nr = rr
            read(c, loopWrap(d, d.kOld + (ph + HOP) * step))
            rl = nl * w1 + rl * w0
            rr = nr * w1 + rr * w0
            d.pos = loopWrap(d, d.kNew + ph * d.vel * step)
            d.kPh = ph + 1
            if (d.kPh >= HOP) {
                d.kPh = 0
                d.kOld = d.kNew
                d.kNew = loopWrap(d, d.kNew + d.vel * HOP * step)
            }
        } else {
            if (d.klOn) d.klOn = false
            read(c, d.pos)
            val prev = d.pos
            var p = prev + d.vel * step
            if (d.loopOn && d.loopOut > d.loopIn) {
                if (d.vel > 0f && p >= d.loopOut) {
                    p = d.loopIn + ((p - d.loopIn) % (d.loopOut - d.loopIn))
                } else if (d.vel < 0f && p < d.loopIn && prev >= d.loopIn) {
                    p = d.loopOut - ((d.loopIn - p) % (d.loopOut - d.loopIn))
                }
            }
            if (p < 0.0) { p = 0.0; d.vel = 0f }
            d.pos = p
        }
        if (d.rolling) d.shadow += d.vel * step
        if (d.pos >= c.frames - 1) {
            d.pos = (c.frames - 1).toDouble()
            d.vel = 0f
            d.playing = false
            d.klOn = false
        }
    }

    private fun eqGain(v: Float, kill: Boolean): Float = if (kill) 0f else if (v < 0f) 1f + v else 1f + v * 0.9f

    // ---------------------------------------------------------------- the mixing loop

    private fun loop(t: AudioTrack) {
        val out = ShortArray(CHUNK * 2)
        val rec = ShortArray(CHUNK * 2)
        val bytes = ByteArray(CHUNK * 4)
        val kUp = FloatArray(2)
        val kDown = FloatArray(2)
        while (running) {
            val now = System.nanoTime()
            for (di in 0..1) {
                val d = decks[di]
                kUp[di] = 1f - exp(-1f / (max(0.01f, d.spinUp) * RATE))
                kDown[di] = 1f - exp(-1f / (max(0.01f, d.brake) * RATE))
            }
            // Crossfader
            var x = cross
            if (crossReverse) x = 1f - x
            val xa: Float
            val xb: Float
            when (crossCurve) {
                1 -> { // sharp: both sides at full until the very ends
                    xa = if (x < 0.92f) 1f else max(0f, (1f - x) / 0.08f)
                    xb = if (x > 0.08f) 1f else max(0f, x / 0.08f)
                }
                2 -> { // constant power
                    xa = cos(x * PI.toFloat() / 2f)
                    xb = sin(x * PI.toFloat() / 2f)
                }
                else -> {
                    xa = min(1f, (1f - x) * 2f)
                    xb = min(1f, x * 2f)
                }
            }
            val amt = fxAmount
            val ed = (echoTime * RATE).toInt().coerceIn(2000, delayLen - 1)
            val nCrush = 1 + (amt * 7f).toInt()
            val levels = Math.pow(2.0, (12.0 - amt * 7.0)).toFloat()
            var peakM = 0f
            var limited = false

            for (n in 0 until CHUNK) {
                var l = 0f
                var r = 0f
                var cl = 0f
                var cr = 0f
                for (di in 0..1) {
                    val d = decks[di]
                    val c = d.clip ?: continue
                    deckSample(d, c, now, kUp[di], kDown[di])
                    var sl = rl * d.trim
                    var sr = rr * d.trim
                    // Three band EQ
                    d.e1l += A_LOW * (sl - d.e1l)
                    d.e1r += A_LOW * (sr - d.e1r)
                    d.e2l += A_LOW * (d.e1l - d.e2l)
                    d.e2r += A_LOW * (d.e1r - d.e2r)
                    d.h1l += A_HIGH * (sl - d.h1l)
                    d.h1r += A_HIGH * (sr - d.h1r)
                    val gLo = eqGain(d.eqLow, d.killLow)
                    val gMi = eqGain(d.eqMid, d.killMid)
                    val gHi = eqGain(d.eqHigh, d.killHigh)
                    val lowL = d.e2l
                    val lowR = d.e2r
                    sl = lowL * gLo + (d.h1l - lowL) * gMi + (sl - d.h1l) * gHi
                    sr = lowR * gLo + (d.h1r - lowR) * gMi + (sr - d.h1r) * gHi
                    // Filter
                    val f = d.filter
                    if (f < -0.02f) {
                        val fc = 200f + 17000f * (1f + f) * (1f + f)
                        val a = 1f - exp(-2f * Math.PI.toFloat() * fc / RATE)
                        d.fLowL += a * (sl - d.fLowL)
                        d.fLowR += a * (sr - d.fLowR)
                        sl = d.fLowL
                        sr = d.fLowR
                    } else if (f > 0.02f) {
                        val fc = 30f + 6000f * f * f
                        val a = 1f - exp(-2f * Math.PI.toFloat() * fc / RATE)
                        d.fLowL += a * (sl - d.fLowL)
                        d.fLowR += a * (sr - d.fLowR)
                        sl -= d.fLowL
                        sr -= d.fLowR
                    }
                    if (d.cueOn) {
                        cl += sl
                        cr += sr
                    }
                    val gt = d.volume * (if (di == 0) xa else xb) * (if (d.killed) 0f else 1f)
                    d.gain += (gt - d.gain) * 0.02f
                    val ol = sl * d.gain
                    val orr = sr * d.gain
                    val pk = max(abs(ol), abs(orr))
                    d.peak = if (pk > d.peak) pk else d.peak * 0.99985f
                    l += ol
                    r += orr
                }
                // Pads
                synchronized(voices) {
                    if (voices.isNotEmpty()) {
                        val it = voices.iterator()
                        while (it.hasNext()) {
                            val v = it.next()
                            if (v.pos >= v.data.size) {
                                it.remove()
                            } else {
                                val s = v.data[v.pos++] / 32768f * 0.9f
                                l += s
                                r += s
                            }
                        }
                    }
                }
                // Dust and crackle of an old record
                if (crackle) {
                    noiseSeed = noiseSeed xor (noiseSeed shl 13)
                    noiseSeed = noiseSeed xor (noiseSeed ushr 17)
                    noiseSeed = noiseSeed xor (noiseSeed shl 5)
                    val u = (noiseSeed and 0xffff) / 65535f
                    if ((noiseSeed ushr 16) % 7000 == 0) pop = (if (u > 0.5f) 1f else -1f) * (0.04f + 0.14f * u)
                    pop *= 0.82f
                    val hiss = (u - 0.5f) * 0.004f
                    l += pop + hiss
                    r += pop * 0.8f + hiss
                }
                // Flanger
                flSend += ((if (flanger) 1f else 0f) - flSend) * 0.002f
                flL[flAt] = l
                flR[flAt] = r
                if (flSend > 0.001f) {
                    flPhase += 2.0 * Math.PI * 0.27 / RATE
                    val dly = (3.2 + 2.4 * sin(flPhase)) * RATE / 1000.0
                    var rp = flAt - dly
                    while (rp < 0) rp += 2048.0
                    val i0 = rp.toInt() and 2047
                    val i1 = (i0 + 1) and 2047
                    val fr = (rp - Math.floor(rp)).toFloat()
                    val fdl = flL[i0] + (flL[i1] - flL[i0]) * fr
                    val fdr = flR[i0] + (flR[i1] - flR[i0]) * fr
                    flL[flAt] = l + fdl * 0.45f * amt
                    flR[flAt] = r + fdr * 0.45f * amt
                    l += fdl * flSend * (0.4f + 0.6f * amt)
                    r += fdr * flSend * (0.4f + 0.6f * amt)
                }
                flAt = (flAt + 1) and 2047
                // Bit crush
                crushSend += ((if (crush) 1f else 0f) - crushSend) * 0.004f
                if (crushSend > 0.001f) {
                    if (crushCount <= 0) {
                        crushHoldL = Math.round(l * levels) / levels
                        crushHoldR = Math.round(r * levels) / levels
                        crushCount = nCrush
                    }
                    crushCount--
                    l += (crushHoldL - l) * crushSend
                    r += (crushHoldR - r) * crushSend
                }
                // Reverb
                revSend += ((if (reverb) 1f else 0f) - revSend) * 0.002f
                if (revSend > 0.001f || reverb) {
                    val inp = (l + r) * 0.05f
                    var sum = 0f
                    for (i in 0..3) {
                        val b = combBuf[i]
                        val o = b[combIdx[i]]
                        combLp[i] = o * 0.75f + combLp[i] * 0.25f
                        b[combIdx[i]] = inp + combLp[i] * (0.8f + 0.15f * amt)
                        combIdx[i] = (combIdx[i] + 1) % combLen[i]
                        sum += o
                    }
                    var y = sum
                    for (j in 0..1) {
                        val b = apBuf[j]
                        val o = b[apIdx[j]]
                        val ii = y
                        y = -ii + o
                        b[apIdx[j]] = ii + o * 0.5f
                        apIdx[j] = (apIdx[j] + 1) % apLen[j]
                    }
                    l += y * revSend * (0.5f + amt)
                    r += y * revSend * (0.5f + amt)
                }
                // Echo
                echoSend += ((if (echo) 1f else 0f) - echoSend) * 0.002f
                var rd = delayAt - ed
                if (rd < 0) rd += delayLen
                val dl = delayL[rd]
                val dr = delayR[rd]
                delayL[delayAt] = l * echoSend + dl * (0.35f + 0.35f * amt)
                delayR[delayAt] = r * echoSend + dr * (0.35f + 0.35f * amt)
                delayAt = (delayAt + 1) % delayLen
                l += dl * 0.6f
                r += dr * 0.6f
                // Stutter gate, eight chops a second
                counter++
                val open = !(stutter && ((counter / 2756L) and 1L) == 1L)
                gate += ((if (open) 1f else 0f) - gate) * 0.01f
                l *= gate * master
                r *= gate * master
                // Limiter
                if (limiter) {
                    val ol = max(abs(l), abs(r))
                    val tg = if (ol > 0.92f) 0.92f / ol else 1f
                    if (tg < limG) { limG = tg; limited = true } else limG += (1f - limG) * 0.0006f
                    l *= limG
                    r *= limG
                }
                val pm = max(abs(l), abs(r))
                if (pm > peakM) peakM = pm
                val sL = toShort(l)
                val sR = toShort(r)
                rec[n * 2] = sL
                rec[n * 2 + 1] = sR
                if (split) {
                    out[n * 2] = toShort((cl + cr) * 0.5f)
                    val mono = (l + r) * 0.5f
                    out[n * 2 + 1] = toShort(mono)
                } else {
                    out[n * 2] = sL
                    out[n * 2 + 1] = sR
                }
            }
            masterPeak = if (peakM > masterPeak) peakM else masterPeak * 0.92f
            limiting = limited
            val recording = recOut
            if (recording != null) {
                try {
                    for (j in 0 until CHUNK * 2) {
                        val s = rec[j].toInt()
                        bytes[j * 2] = (s and 0xff).toByte()
                        bytes[j * 2 + 1] = ((s shr 8) and 0xff).toByte()
                    }
                    recording.write(bytes, 0, CHUNK * 4)
                    recBytes += CHUNK * 4
                } catch (_: Exception) {
                    recOut = null
                }
            }
            if (t.write(out, 0, out.size) < 0) break
        }
    }

    private fun toShort(v: Float): Short {
        val a = abs(v)
        val s = if (a < 0.8f) v else (if (v < 0f) -1f else 1f) * (0.8f + 0.2f * tanh((a - 0.8f) / 0.2f))
        return (s * 32767f).toInt().coerceIn(-32768, 32767).toShort()
    }
}
