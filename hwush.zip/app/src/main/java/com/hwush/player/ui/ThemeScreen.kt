@file:OptIn(ExperimentalLayoutApi::class)

package com.hwush.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.InputChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hwush.player.data.SavedTheme
import kotlin.math.roundToInt

/** Build your own look: colour, surfaces, light or dark, font and text size. Save it under a name to switch back later. */
@Composable
fun ThemeScreen(ui: UiController) {
    val app = ui.app
    val sd by app.store.data.collectAsState()
    var naming by remember { mutableStateOf(false) }
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(sd.accentColor, hsv)
    val hue = hsv[0]
    val sat = hsv[1]
    val bri = hsv[2]
    fun setColor(h: Float, s: Float, v: Float) {
        val argb = android.graphics.Color.HSVToColor(floatArrayOf(h.coerceIn(0f, 359.9f), s.coerceIn(0f, 1f), v.coerceIn(0.4f, 1f)))
        app.store.update { d -> d.copy(accentColor = argb, accentMode = 2) }
    }

    Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        ListHeader("Theme builder", "Colours and fonts", ui, emptyList(), back = ui.stack.size > 1)
        Surface(
            Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
        ) {
            Column(Modifier.padding(18.dp)) {
                Text("Hwush looks like this", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text("Songs, albums and everything else follow your choices.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    listOf(
                        MaterialTheme.colorScheme.primary,
                        MaterialTheme.colorScheme.primaryContainer,
                        MaterialTheme.colorScheme.secondary,
                        MaterialTheme.colorScheme.secondaryContainer,
                        MaterialTheme.colorScheme.surfaceContainer,
                    ).forEach { c -> Box(Modifier.size(34.dp).clip(CircleShape).background(c)) }
                }
            }
        }
        Heading2("Colour")
        Text("Shade", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.labelMedium)
        Slider(value = hue, onValueChange = { setColor(it, sat.coerceAtLeast(0.35f), bri.coerceAtLeast(0.7f)) }, valueRange = 0f..359f, modifier = Modifier.padding(horizontal = 16.dp))
        Text("Strength", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.labelMedium)
        Slider(value = sat.coerceAtLeast(0.2f), onValueChange = { setColor(hue, it, bri.coerceAtLeast(0.7f)) }, valueRange = 0.2f..1f, modifier = Modifier.padding(horizontal = 16.dp))
        Text("Brightness", Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.labelMedium)
        Slider(value = bri.coerceAtLeast(0.5f), onValueChange = { setColor(hue, sat.coerceAtLeast(0.35f), it) }, valueRange = 0.5f..1f, modifier = Modifier.padding(horizontal = 16.dp))
        Heading2("Mode")
        Choices(listOf("Match phone" to 0, "Light" to 1, "Dark" to 2), sd.themeMode) { v -> app.store.update { d -> d.copy(themeMode = v) } }
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Pure black for OLED screens", Modifier.weight(1f))
            Switch(checked = sd.amoled, onCheckedChange = { v -> app.store.update { d -> d.copy(amoled = v) } })
        }
        Heading2("Surfaces")
        Choices(listOf("Classic" to 0, "Rich" to 1, "Mono" to 2), sd.themeStyle) { v -> app.store.update { d -> d.copy(themeStyle = v) } }
        Heading2("Font")
        Choices(fontChoices.mapIndexed { i, n -> n to i }, sd.fontStyle) { v -> app.store.update { d -> d.copy(fontStyle = v) } }
        Heading2("Text size  ${sd.fontScale}%")
        Slider(
            value = sd.fontScale.toFloat(),
            onValueChange = { v -> app.store.update { d -> d.copy(fontScale = ((v / 5f).roundToInt() * 5).coerceIn(85, 130)) } },
            valueRange = 85f..130f,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        Heading2("Saved looks")
        if (sd.customThemes.isEmpty()) {
            Text(
                "Save what you built, then switch between looks in one tap.",
                Modifier.padding(horizontal = 16.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        FlowRow(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            sd.customThemes.forEach { t ->
                InputChip(
                    selected = false,
                    onClick = {
                        app.store.update { d ->
                            d.copy(accentColor = t.accent, accentMode = 2, themeStyle = t.style, amoled = t.amoled, themeMode = t.mode, fontStyle = t.font, fontScale = t.scale)
                        }
                    },
                    label = { Text(t.name) },
                    leadingIcon = { Box(Modifier.size(16.dp).clip(CircleShape).background(Color(t.accent))) },
                    trailingIcon = {
                        Icon(
                            Icons.Rounded.Close,
                            "Delete ${t.name}",
                            Modifier.size(16.dp).clickable { app.store.deleteTheme(t.name) },
                        )
                    },
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { naming = true }, modifier = Modifier.padding(horizontal = 16.dp)) { Text("Save this look") }
        TextButton(
            onClick = {
                app.store.update { d -> d.copy(accentMode = 3, themeStyle = 0, amoled = false, themeMode = 0, fontStyle = 0, fontScale = 100) }
            },
            modifier = Modifier.padding(horizontal = 8.dp),
        ) { Text("Back to the Hwush look") }
    }
    if (naming) {
        NameDialog("Name this look", "My look", "Save", { naming = false }) { name ->
            app.store.saveTheme(SavedTheme(name.trim(), sd.accentColor, sd.themeStyle, sd.amoled, sd.themeMode, sd.fontStyle, sd.fontScale))
            naming = false
            ui.say("Saved")
        }
    }
}

@Composable
private fun Heading2(text: String) {
    Text(
        text,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 6.dp),
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
    )
}
