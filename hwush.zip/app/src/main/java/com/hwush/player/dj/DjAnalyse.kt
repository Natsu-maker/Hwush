package com.hwush.player.dj

import com.hwush.player.data.TempoMath
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** What a deck knows about its record: the speed, where the beat falls, and a picture of the waveform. */
class DjInfo(val bpm: Float, val offset: Float, val overview: FloatArray)

object DjAnalyse {
    const val BARS = 480

    /** Reads a loaded piece once: the tempo, the first beat and the overview waveform. Run it off the main thread. */
    fun run(c: DjClip): DjInfo {
        val sr = c.sampleRate
        val frames = c.frames
        // Overview
        val over = FloatArray(BARS)
        val per = max(1, frames / BARS)
        for (b in 0 until BARS) {
            var peak = 0
            val s = b * per
            val e = minOf(frames, s + per)
            var i = s
            val stride = max(1, (e - s) / 64)
            while (i < e) {
                val v = abs(c.data[i * 2].toInt())
                if (v > peak) peak = v
                i += stride
            }
            over[b] = peak / 32768f
        }
        // Loudness every 20 ms
        val hop = max(1, sr / 50)
        val n = frames / hop
        if (n < 600) return DjInfo(0f, 0f, over)
        val env = FloatArray(n)
        var mx = 0f
        for (b in 0 until n) {
            var s = 0.0
            val st = b * hop
            var i = 0
            while (i < hop) {
                val v = (c.data[(st + i) * 2] + c.data[(st + i) * 2 + 1]) / 65536f
                s += v * v
                i += 2
            }
            env[b] = sqrt(s / (hop / 2)).toFloat()
            if (env[b] > mx) mx = env[b]
        }
        if (mx <= 0f) return DjInfo(0f, 0f, over)
        for (b in 0 until n) env[b] /= mx
        val bpm = TempoMath.analyse(env).bpm
        if (bpm <= 0) return DjInfo(0f, 0f, over)
        // Beat grid: the shift inside one beat where the loudness jumps most often.
        val period = 3000.0 / bpm
        val onset = FloatArray(n)
        for (i in 1 until n) onset[i] = max(0f, env[i] - env[i - 1])
        var bestShift = 0.0
        var bestScore = -1.0
        var sh = 0.0
        while (sh < period) {
            var score = 0.0
            var k = 0
            while (true) {
                val idx = (sh + k * period).roundToInt()
                if (idx >= n) break
                score += onset[idx]
                k++
            }
            if (score > bestScore) { bestScore = score; bestShift = sh }
            sh += 0.5
        }
        return DjInfo(bpm.toFloat(), (bestShift * 0.02).toFloat(), over)
    }
}
