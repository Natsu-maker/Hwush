package com.hwush.player.editor

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

const val ED_RATE = 44100
const val ED_TRACKS = 6

/** A piece of sound held in memory, stereo at 44100 Hz. Clips on the timeline point into it. */
class EdSource(val id: Int, val title: String, val data: ShortArray) {
    val frames: Int get() = data.size / 2
    val seconds: Float get() = frames.toFloat() / ED_RATE

    /** The loudest point in every 10 ms, from 0 to 1, for drawing the wave. */
    val peaks: FloatArray by lazy {
        val block = ED_RATE / 100
        val n = frames / block + 1
        val out = FloatArray(n)
        for (b in 0 until n) {
            var m = 0
            val from = b * block
            val to = min(frames, from + block)
            for (i in from until to) {
                val l = abs(data[i * 2].toInt())
                val r = abs(data[i * 2 + 1].toInt())
                if (l > m) m = l
                if (r > m) m = r
            }
            out[b] = m / 32768f
        }
        out
    }
}

/** A part of a source placed on a track. All times are in seconds. */
class EdClip(
    val id: Int,
    var src: EdSource,
    var track: Int,
    var start: Double,
    var inPoint: Double,
    var length: Double,
) {
    @Volatile var gainDb = 0f
    @Volatile var fadeIn = 0f
    @Volatile var fadeOut = 0f
    @Volatile var rate = 1f
    @Volatile var mute = false
    val end: Double get() = start + length
}

class EdTrack(var name: String) {
    @Volatile var vol = 0.9f
    @Volatile var pan = 0f
    @Volatile var mute = false
    @Volatile var solo = false
}

/**
 * Plays and renders a timeline of clips on a few tracks. The mixing function takes a start frame and makes the sound
 * from the clips alone, so playing live and exporting a file use exactly the same code.
 */
class EditorEngine {
    val sources = CopyOnWriteArrayList<EdSource>()
    val clips = CopyOnWriteArrayList<EdClip>()
    val tracks = Array(ED_TRACKS) { EdTrack("Track ${it + 1}") }
    private var nextId = 1

    @Volatile var master = 0.9f
    @Volatile var playing = false
    @Volatile var posFrames = 0L
    @Volatile private var running = false
    private var thread: Thread? = null
    private var track: AudioTrack? = null

    fun newId() = nextId++

    val positionSec: Double get() = posFrames.toDouble() / ED_RATE

    fun duration(): Double {
        var m = 0.0
        for (c in clips) m = max(m, c.end)
        return m
    }

    fun seek(sec: Double) { posFrames = (max(0.0, sec) * ED_RATE).toLong() }

    fun start() {
        if (thread != null) return
        val minBuf = AudioTrack.getMinBufferSize(ED_RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(ED_RATE).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
            .setBufferSizeInBytes(maxOf(minBuf, 1024 * 4 * 3))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track = t
        running = true
        t.play()
        thread = Thread({
            val n = 1024
            val buf = FloatArray(n * 2)
            val out = ShortArray(n * 2)
            while (running) {
                if (playing) {
                    renderAt(posFrames, n, buf)
                    for (i in buf.indices) out[i] = toShort(buf[i])
                    posFrames += n
                    if (posFrames > (duration() + 0.4) * ED_RATE) playing = false
                } else {
                    java.util.Arrays.fill(out, 0)
                }
                if (t.write(out, 0, out.size) < 0) break
            }
        }, "hwush-editor").also {
            it.priority = Thread.MAX_PRIORITY
            it.start()
        }
    }

    fun release() {
        running = false
        playing = false
        try { thread?.join(600) } catch (_: Exception) {}
        thread = null
        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        track = null
    }

    fun toggle() {
        if (playing) {
            playing = false
        } else {
            if (posFrames >= duration() * ED_RATE) posFrames = 0
            playing = true
        }
    }

    // -------------------------------------------------------------- editing

    fun addSource(title: String, data: ShortArray): EdSource {
        val s = EdSource(nextId++, title, data)
        sources.add(s)
        return s
    }

    fun totalSeconds(): Float = sources.sumOf { it.seconds.toDouble() }.toFloat()

    fun addClip(src: EdSource, track: Int, start: Double): EdClip {
        val c = EdClip(nextId++, src, track, start, 0.0, src.seconds.toDouble())
        clips.add(c)
        return c
    }

    fun freeTrack(from: Double, len: Double): Int {
        for (t in 0 until ED_TRACKS) {
            if (clips.none { it.track == t && it.start < from + len && from < it.end }) return t
        }
        return 0
    }

    /** Cuts a clip in two at [at] seconds on the timeline. Returns the new right hand clip. */
    fun split(c: EdClip, at: Double): EdClip? {
        if (at <= c.start + 0.05 || at >= c.end - 0.05) return null
        val left = at - c.start
        val right = EdClip(nextId++, c.src, c.track, at, c.inPoint + left * c.rate, c.length - left)
        right.gainDb = c.gainDb; right.rate = c.rate; right.mute = c.mute; right.fadeOut = c.fadeOut
        c.length = left
        c.fadeOut = 0f
        clips.add(right)
        return right
    }

    fun trimStart(c: EdClip, at: Double) {
        if (at <= c.start + 0.05 || at >= c.end - 0.05) return
        val d = at - c.start
        c.inPoint += d * c.rate
        c.start = at
        c.length -= d
    }

    fun trimEnd(c: EdClip, at: Double) {
        if (at <= c.start + 0.05 || at >= c.end) return
        c.length = at - c.start
    }

    fun duplicate(c: EdClip): EdClip {
        val d = EdClip(nextId++, c.src, c.track, c.end, c.inPoint, c.length)
        d.gainDb = c.gainDb; d.fadeIn = c.fadeIn; d.fadeOut = c.fadeOut; d.rate = c.rate; d.mute = c.mute
        clips.add(d)
        return d
    }

    /** Changes speed, keeping the clip's start. The length shrinks or grows to hold the same sound. */
    fun setRate(c: EdClip, rate: Float) {
        val r = rate.coerceIn(0.5f, 2f)
        val consumed = c.length * c.rate
        c.rate = r
        c.length = consumed / r
    }

    // -------------------------------------------------------------- mixing

    private fun smooth(x: Float): Float { val t = x.coerceIn(0f, 1f); return t * t * (3f - 2f * t) }

    fun renderAt(startFrame: Long, n: Int, buf: FloatArray) {
        java.util.Arrays.fill(buf, 0f, n * 2, 0f)
        val anySolo = tracks.any { it.solo }
        for (c in clips) {
            if (c.mute) continue
            val tr = tracks[c.track.coerceIn(0, ED_TRACKS - 1)]
            if (tr.mute || (anySolo && !tr.solo)) continue
            val cs = (c.start * ED_RATE).toLong()
            val ce = cs + (c.length * ED_RATE).toLong()
            if (startFrame + n <= cs || startFrame >= ce) continue
            val gain = 10f.pow(c.gainDb / 20f) * tr.vol
            val a = (tr.pan.coerceIn(-1f, 1f) + 1f) * (PI.toFloat() / 4f)
            val gl = gain * cos(a) * 1.41f
            val gr = gain * sin(a) * 1.41f
            val data = c.src.data
            val frames = c.src.frames
            val inF = c.inPoint * ED_RATE
            val fi = c.fadeIn * ED_RATE
            val fo = c.fadeOut * ED_RATE
            val rate = c.rate.toDouble()
            for (i in 0 until n) {
                val f = startFrame + i
                if (f < cs || f >= ce) continue
                val t = (f - cs).toDouble()
                val sp = inF + t * rate
                val idx = sp.toInt()
                if (idx < 0 || idx >= frames - 1) continue
                val fr = (sp - idx).toFloat()
                val p = idx * 2
                val l = (data[p] + (data[p + 2] - data[p]) * fr) / 32768f
                val r = (data[p + 1] + (data[p + 3] - data[p + 1]) * fr) / 32768f
                var g = 1f
                if (fi > 0 && t < fi) g *= smooth((t / fi).toFloat())
                val rem = (ce - f).toDouble()
                if (fo > 0 && rem < fo) g *= smooth((rem / fo).toFloat())
                buf[i * 2] += l * g * gl
                buf[i * 2 + 1] += r * g * gr
            }
        }
        val m = master
        for (i in 0 until n * 2) buf[i] *= m
    }

    private fun toShort(v: Float): Short {
        val a = abs(v)
        val s = if (a < 0.8f) v else (if (v < 0f) -1f else 1f) * (0.8f + 0.2f * tanh((a - 0.8f) / 0.2f))
        return (s * 32767f).toInt().coerceIn(-32768, 32767).toShort()
    }

    /** Renders the whole timeline into a wav file. Call off the main thread. */
    fun export(file: File, onProgress: (Float) -> Unit): Boolean {
        return try {
            val total = ((duration() + 1.0) * ED_RATE).toLong()
            val n = 4096
            val buf = FloatArray(n * 2)
            val bytes = ByteArray(n * 4)
            java.io.BufferedOutputStream(java.io.FileOutputStream(file), 1 shl 16).use { out ->
                out.write(ByteArray(44))
                var f = 0L
                while (f < total) {
                    renderAt(f, n, buf)
                    for (j in 0 until n * 2) {
                        val s = toShort(buf[j]).toInt()
                        bytes[j * 2] = (s and 0xff).toByte()
                        bytes[j * 2 + 1] = ((s shr 8) and 0xff).toByte()
                    }
                    out.write(bytes, 0, n * 4)
                    f += n
                    onProgress((f.toFloat() / total).coerceIn(0f, 1f))
                }
            }
            val written = ((total + n - 1) / n) * n
            RandomAccessFile(file, "rw").use { raf ->
                val data = (written * 4).toInt()
                val h = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                h.put("RIFF".toByteArray()).putInt(36 + data).put("WAVE".toByteArray())
                h.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(2).putInt(ED_RATE).putInt(ED_RATE * 4).putShort(4).putShort(16)
                h.put("data".toByteArray()).putInt(data)
                raf.seek(0)
                raf.write(h.array())
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    /** The audio under a clip as its own stereo piece, ready to be split into parts. */
    fun cutOut(c: EdClip): ShortArray {
        val frames = (c.length * ED_RATE).toInt().coerceAtLeast(2)
        val out = ShortArray(frames * 2)
        val data = c.src.data
        val sf = c.src.frames
        val inF = c.inPoint * ED_RATE
        for (i in 0 until frames) {
            val sp = inF + i * c.rate.toDouble()
            val idx = sp.toInt()
            if (idx < 0 || idx >= sf - 1) break
            val fr = (sp - idx).toFloat()
            val p = idx * 2
            out[i * 2] = (data[p] + (data[p + 2] - data[p]) * fr).toInt().toShort()
            out[i * 2 + 1] = (data[p + 1] + (data[p + 3] - data[p + 1]) * fr).toInt().toShort()
        }
        return out
    }
}
