package com.hwush.player.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object LrcParser {
    private val stamp = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")
    private val offsetTag = Regex("""^\[offset:\s*([+-]?\d+)]""", RegexOption.IGNORE_CASE)

    fun parse(text: String): Lyrics {
        val lines = ArrayList<LyricLine>()
        val plain = ArrayList<String>()
        var offset = 0L
        for (raw in text.lineSequence()) {
            val line = raw.trim().trimStart('﻿')
            if (line.isEmpty()) continue
            val off = offsetTag.find(line)
            if (off != null) {
                offset = off.groupValues[1].toLongOrNull() ?: 0L
                continue
            }
            val stamps = stamp.findAll(line).toList()
            if (stamps.isEmpty()) {
                if (!line.startsWith("[")) plain.add(line)
                continue
            }
            val body = line.substring(stamps.last().range.last + 1).trim()
            for (m in stamps) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = if (frac.isEmpty()) 0L else frac.padEnd(3, '0').take(3).toLong()
                lines.add(LyricLine((min * 60_000L + sec * 1000L + ms - offset).coerceAtLeast(0L), body))
            }
        }
        return if (lines.isNotEmpty()) {
            Lyrics(lines.sortedBy { it.timeMs }, true)
        } else {
            Lyrics(plain.map { LyricLine(-1L, it) }, false)
        }
    }
}

/** Finds a .lrc (or .txt) file next to the song, or inside the lyrics folder chosen in Settings. */
class LyricsFinder(private val ctx: Context, private val store: Store) {
    private var indexedTree: String? = null
    private var index: Map<String, Uri> = emptyMap()

    suspend fun find(t: Track): Lyrics? = withContext(Dispatchers.IO) {
        try {
            store.data.value.songLyrics[t.path]?.let { chosen ->
                try {
                    val text = ctx.contentResolver.openInputStream(Uri.parse(chosen))?.bufferedReader()?.use { it.readText() }
                    val l = text?.let { LrcParser.parse(it) }
                    if (l != null && l.lines.isNotEmpty()) return@withContext l
                } catch (_: Exception) {
                }
            }
            val base = t.path.substringBeforeLast('.', t.path)
            for (ext in listOf("lrc", "LRC", "txt")) {
                val f = File("$base.$ext")
                if (f.isFile && f.canRead()) {
                    val l = LrcParser.parse(f.readText())
                    if (l.lines.isNotEmpty()) return@withContext l
                }
            }
            val tree = store.data.value.lyricsTree ?: return@withContext null
            val idx = indexFor(tree)
            val name = File(base).name.lowercase()
            val uri = idx[name]
                ?: idx["${t.artist} - ${t.title}".lowercase()]
                ?: idx[t.title.lowercase()]
                ?: return@withContext null
            val text = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                ?: return@withContext null
            LrcParser.parse(text).takeIf { it.lines.isNotEmpty() }
        } catch (e: Exception) {
            null
        }
    }

    /** The raw text of the lyrics file for a song, for the editor. Null when there is none. */
    fun rawText(t: Track): String? {
        try {
            store.data.value.songLyrics[t.path]?.let { chosen ->
                try {
                    ctx.contentResolver.openInputStream(Uri.parse(chosen))?.bufferedReader()?.use { return it.readText() }
                } catch (_: Exception) {
                }
            }
            val base = t.path.substringBeforeLast('.', t.path)
            for (ext in listOf("lrc", "LRC", "txt")) {
                val f = File("$base.$ext")
                if (f.isFile && f.canRead()) return f.readText()
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun indexFor(tree: String): Map<String, Uri> {
        if (indexedTree == tree) return index
        val map = HashMap<String, Uri>()
        fun walk(dir: DocumentFile, depth: Int) {
            if (depth > 5) return
            for (f in dir.listFiles()) {
                val n = f.name ?: continue
                if (f.isDirectory) {
                    walk(f, depth + 1)
                } else {
                    val lower = n.lowercase()
                    if (lower.endsWith(".lrc")) map[lower.removeSuffix(".lrc")] = f.uri
                    else if (lower.endsWith(".txt")) map.putIfAbsent(lower.removeSuffix(".txt"), f.uri)
                }
            }
        }
        DocumentFile.fromTreeUri(ctx, Uri.parse(tree))?.let { walk(it, 0) }
        index = map
        indexedTree = tree
        return map
    }

    fun resetIndex() {
        indexedTree = null
    }
}
