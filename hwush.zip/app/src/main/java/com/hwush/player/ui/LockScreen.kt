package com.hwush.player.ui

import android.content.res.Configuration
import android.graphics.Bitmap
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Full screen player shown over the lock screen: clock, cover as backdrop, seek bar and controls. */
@Composable
fun LockScreen(ui: UiController, onAddToPlaylist: () -> Unit, onClose: () -> Unit) {
    val app = ui.app
    val holder = app.player
    val pui by app.player.ui.collectAsState()
    val track = pui.path?.let { app.library.find(it) }
    val fav by app.store.select(pui.path) { d -> pui.path?.let { it in d.favorites } ?: false }
    val bmp by produceState<Bitmap?>(null, track?.path) {
        value = if (track == null) null else app.art.load(track, 640)
    }
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(1000L)
        }
    }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val dragY = remember { Animatable(0f) }
    val breathe = rememberInfiniteTransition(label = "lockBreathe")
    val breatheScale by breathe.animateFloat(
        initialValue = 1f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(2800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "lockBreatheScale",
    )
    val drift by breathe.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(14000, easing = androidx.compose.animation.core.LinearEasing), RepeatMode.Reverse),
        label = "lockDrift",
    )
    val artColor = rememberArtColor(track, Color(0xFF6C63FF))
    // Synced lyrics: the line being sung, shown under the title.
    val rev = app.lyricsRev.intValue
    val lyrics by produceState<com.hwush.player.data.Lyrics?>(null, track?.path, rev) {
        value = try { track?.let { app.lyrics.find(it) } } catch (_: Exception) { null }
    }
    val lyricLine by produceState("", lyrics, pui.isPlaying) {
        val l = lyrics
        if (l == null || !l.synced || l.lines.isEmpty()) {
            value = ""
            return@produceState
        }
        while (true) {
            val p = app.player.position()
            var a = -1
            for (k in l.lines.indices) if (l.lines[k].timeMs <= p + 120L) a = k else break
            value = if (a >= 0) l.lines[a].text else ""
            delay(150L)
        }
    }
    fun skip(forward: Boolean) {
        scope.launch {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            dragY.animateTo(if (forward) 700f else -700f, tween(150))
            if (forward) holder.next() else holder.previous()
            dragY.snapTo(if (forward) -320f else 320f)
            dragY.animateTo(0f, spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow))
        }
    }
    val portrait = LocalConfiguration.current.orientation == Configuration.ORIENTATION_PORTRAIT
    val timeText = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(now)).lowercase()
    val dateText = SimpleDateFormat("MMM d, EEE", Locale.getDefault()).format(Date(now))

    CompositionLocalProvider(LocalContentColor provides Color.White) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onVerticalDrag = { change, amount ->
                            change.consume()
                            scope.launch { dragY.snapTo(dragY.value + amount * 0.7f) }
                        },
                        onDragEnd = {
                            val d = dragY.value
                            if (d > 150f) skip(true)
                            else if (d < -150f) skip(false)
                            else scope.launch { dragY.animateTo(0f, spring(dampingRatio = 0.6f, stiffness = 350f)) }
                        },
                        onDragCancel = { scope.launch { dragY.animateTo(0f) } },
                    )
                },
        ) {
            val b = bmp
            if (b != null) {
                Image(
                    b.asImageBitmap(),
                    null,
                    Modifier
                        .fillMaxSize()
                        .then(if (Build.VERSION.SDK_INT >= 31) Modifier.blur(36.dp) else Modifier),
                    contentScale = ContentScale.Crop,
                    alpha = 0.6f,
                )
            }
            androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                drawRect(
                    Brush.radialGradient(
                        listOf(artColor.copy(alpha = 0.40f), Color.Transparent),
                        center = androidx.compose.ui.geometry.Offset(w * (0.1f + 0.8f * drift), h * 0.25f),
                        radius = w * 0.95f,
                    ),
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(artColor.copy(alpha = 0.28f), Color.Transparent),
                        center = androidx.compose.ui.geometry.Offset(w * (0.9f - 0.8f * drift), h * 0.78f),
                        radius = w * 0.85f,
                    ),
                )
            }
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color(0x55000000), Color(0xCC000000))),
                ),
            )
            Column(
                Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(timeText, fontSize = 48.sp, fontWeight = FontWeight.Medium)
                Text(dateText, fontSize = 15.sp, color = Color(0xCCFFFFFF))
                Spacer(Modifier.weight(1f))
                if (portrait) {
                    Cover(
                        track,
                        Modifier
                            .size(240.dp)
                            .graphicsLayer {
                                val sc = if (pui.isPlaying) breatheScale else 1f
                                scaleX = sc
                                scaleY = sc
                                translationY = dragY.value * 0.6f
                                alpha = (1f - kotlin.math.abs(dragY.value) / 900f).coerceIn(0.15f, 1f)
                            },
                        240.dp,
                        RoundedCornerShape(20.dp),
                    )
                    Spacer(Modifier.height(20.dp))
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { holder.seekBy(-10_000L) }) { Icon(Icons.Rounded.FastRewind, "Back 10 seconds") }
                    AnimatedContent(
                        targetState = track,
                        modifier = Modifier.weight(1f),
                        transitionSpec = {
                            (slideInVertically(tween(320)) { it / 2 } + fadeIn(tween(320)))
                                .togetherWith(slideOutVertically(tween(220)) { -it / 2 } + fadeOut(tween(180)))
                        },
                        label = "lockTitle",
                    ) { tr ->
                        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            tr?.title ?: "Nothing playing",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            tr?.artist ?: "",
                            fontSize = 16.sp,
                            color = Color(0xE6FFFFFF),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            tr?.album ?: "",
                            fontSize = 14.sp,
                            color = Color(0xB3FFFFFF),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        }
                    }
                    IconButton(onClick = { holder.seekBy(10_000L) }) { Icon(Icons.Rounded.FastForward, "Forward 10 seconds") }
                }
                AnimatedContent(
                    targetState = lyricLine,
                    transitionSpec = {
                        (slideInVertically(tween(280)) { it / 2 } + fadeIn(tween(280)))
                            .togetherWith(slideOutVertically(tween(200)) { -it / 2 } + fadeOut(tween(160)))
                    },
                    label = "lockLyric",
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                ) { line ->
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Text(
                            line,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            color = Color(0xFFFFFFFF),
                        )
                    }
                }
                SeekBar(ui, pui)
                Row(
                    Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AnimatedHeart(fav, onClick = { pui.path?.let { app.store.toggleFavorite(it) } })
                    IconButton(onClick = { holder.previous() }, Modifier.size(52.dp)) {
                        Icon(Icons.Rounded.SkipPrevious, "Previous", Modifier.size(34.dp))
                    }
                    FilledIconButton(onClick = { holder.togglePlay() }, Modifier.size(72.dp)) {
                        PlayPauseIcon(pui.isPlaying, Modifier.size(40.dp))
                    }
                    IconButton(onClick = { holder.next() }, Modifier.size(52.dp)) {
                        Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(34.dp))
                    }
                    IconButton(onClick = onAddToPlaylist) { Icon(Icons.Rounded.PlaylistAdd, "Add to playlist") }
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Rounded.Lock, "Hide this screen") }
                    Text(
                        "Swipe down: next song  ·  Swipe up: previous",
                        fontSize = 12.sp,
                        color = Color(0x99FFFFFF),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.size(48.dp))
                }
            }
        }
    }
}
