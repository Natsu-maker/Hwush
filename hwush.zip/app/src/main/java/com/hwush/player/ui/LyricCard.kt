@file:OptIn(ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AColor
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.hwush.player.data.Track
import com.hwush.player.data.dominantColor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Pick a few lines of the lyrics and share them as a picture with the cover. */
@Composable
fun LyricCardSheet(ui: UiController, track: Track, onClose: () -> Unit) {
    val app = ui.app
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var lines by remember { mutableStateOf<List<String>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    val picked = remember { mutableStateListOf<Int>() }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(track.path) {
        lines = app.lyrics.find(track)?.lines?.map { it.text }?.filter { it.isNotBlank() } ?: emptyList()
        loaded = true
    }
    ModalBottomSheet(containerColor = sheetColor(), onDismissRequest = onClose) {
        Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 20.dp)) {
            Text("Share lyrics as a picture", style = MaterialTheme.typography.titleLarge)
            Text(
                "Tap up to 6 lines.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 8.dp),
            )
            if (loaded && lines.isEmpty()) {
                Text("This song has no lyrics yet. Add some in the Lyrics tab first.")
            } else {
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    itemsIndexed(lines) { i, line ->
                        Row(
                            Modifier.fillMaxWidth().clickable {
                                if (i in picked) picked.remove(i) else if (picked.size < 6) picked.add(i)
                            },
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(checked = i in picked, onCheckedChange = null, modifier = Modifier.padding(end = 8.dp))
                            Text(line, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                Button(
                    enabled = picked.isNotEmpty() && !busy,
                    onClick = {
                        busy = true
                        scope.launch {
                            val file = withContext(Dispatchers.IO) {
                                try {
                                    renderLyricCard(ctx, track, picked.sorted().map { lines[it] })
                                } catch (_: Exception) {
                                    null
                                }
                            }
                            busy = false
                            if (file == null) {
                                ui.say("Could not make the picture")
                            } else {
                                try {
                                    val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
                                    val send = Intent(Intent.ACTION_SEND).setType("image/png")
                                        .putExtra(Intent.EXTRA_STREAM, uri)
                                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    ctx.startActivity(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                    onClose()
                                } catch (_: Exception) {
                                    ui.say("Could not share the picture")
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                ) { Text(if (busy) "Making picture" else "Share picture") }
            }
        }
    }
}

private fun renderLyricCard(ctx: Context, t: Track, lines: List<String>): File {
    val w = 1080
    val h = 1350
    val app = ctx.applicationContext as com.hwush.player.HwushApp
    val cover = app.art.loadBlocking(t, 600)
    val base = if (cover != null) dominantColor(cover) else 0xFF5B8CFF.toInt()
    val hsv = FloatArray(3)
    AColor.colorToHSV(base, hsv)
    val top = AColor.HSVToColor(floatArrayOf(hsv[0], 0.55f, 0.55f))
    val bottom = AColor.HSVToColor(floatArrayOf(hsv[0], 0.6f, 0.13f))
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val bg = Paint().apply { shader = LinearGradient(0f, 0f, 0f, h.toFloat(), top, bottom, Shader.TileMode.CLAMP) }
    c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), bg)

    val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AColor.WHITE
        textSize = 68f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    val text = lines.joinToString("\n")
    val layout = StaticLayout.Builder.obtain(text, 0, text.length, tp, w - 200)
        .setAlignment(Layout.Alignment.ALIGN_CENTER)
        .setLineSpacing(0f, 1.18f)
        .build()
    val textTop = ((h - layout.height) / 2f).coerceAtLeast(120f) - 60f
    c.save()
    c.translate(100f, textTop)
    layout.draw(c)
    c.restore()

    val small = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AColor.argb(210, 255, 255, 255)
        textSize = 40f
        textAlign = Paint.Align.LEFT
    }
    if (cover != null) {
        val size = 150
        val scaled = Bitmap.createScaledBitmap(cover, size, size, true)
        c.drawBitmap(scaled, 100f, h - 250f, null)
    }
    val x = if (cover != null) 280f else 100f
    c.drawText(t.title.take(28), x, h - 190f, small.apply { typeface = Typeface.DEFAULT_BOLD })
    c.drawText(t.artist.take(32), x, h - 135f, small.apply { typeface = Typeface.DEFAULT; alpha = 170 })
    val brand = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AColor.argb(140, 255, 255, 255)
        textSize = 34f
        textAlign = Paint.Align.RIGHT
    }
    c.drawText("Hwush", w - 90f, 110f, brand)

    val dir = File(ctx.cacheDir, "cards").apply { mkdirs() }
    dir.listFiles()?.forEach { it.delete() }
    val f = File(dir, "lyrics.png")
    f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    return f
}
