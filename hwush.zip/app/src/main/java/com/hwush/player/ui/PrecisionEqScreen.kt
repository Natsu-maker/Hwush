package com.hwush.player.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.AssistChip
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hwush.player.player.PrecisionEq

private val peqPresets = listOf(
    "Flat" to listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Bass boost" to listOf(6f, 5f, 4f, 2f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Vocal" to listOf(-2f, -2f, -1f, 1f, 3f, 4f, 3f, 1f, 0f, -1f),
    "Treble" to listOf(0f, 0f, 0f, 0f, 0f, 1f, 3f, 5f, 6f, 6f),
    "V shape" to listOf(5f, 4f, 2f, 0f, -2f, -2f, 0f, 2f, 4f, 5f),
    "Warm" to listOf(3f, 3f, 2f, 1f, 0f, 0f, -1f, -2f, -3f, -4f),
    "Loudness" to listOf(5f, 4f, 1f, 0f, -1f, -1f, 0f, 1f, 4f, 5f),
)

/**
 * Ten band equalizer with its own filters. One set of levels for everything, or a set kept for the album or the
 * artist of the song playing, which switches on by itself whenever one of their songs plays.
 */
@Composable
fun PrecisionEqScreen(ui: UiController) {
    val app = ui.app
    val holder = app.player
    val sd by app.store.data.collectAsState()
    val pui by holder.ui.collectAsState()
    val track = pui.path?.let { app.library.find(it) }
    var target by remember { mutableIntStateOf(0) } // 0 everywhere, 1 album, 2 artist
    val key = when (target) {
        1 -> track?.let { "album:${it.album}" }
        2 -> track?.let { "artist:${it.artist}" }
        else -> null
    }
    val levels: List<Float> = if (key != null) sd.peqScoped[key] ?: sd.peqLevels else sd.peqLevels

    fun save(l: List<Float>) {
        if (key == null) {
            app.store.update { d -> d.copy(peqLevels = l) }
        } else {
            app.store.update { d -> d.copy(peqScoped = d.peqScoped + (key to l)) }
        }
        holder.refreshPeq()
    }

    val primary = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.18f)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 16.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { ui.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") }
            Column(Modifier.weight(1f)) {
                Text("Precision equalizer", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
                Text("Ten bands with its own filters", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = sd.peqOn, onCheckedChange = { v ->
                app.store.update { d -> d.copy(peqOn = v) }
                holder.refreshPeq()
            })
        }
        Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = target == 0, onClick = { target = 0 }, label = { Text("Everywhere") })
            if (track != null) {
                FilterChip(selected = target == 1, onClick = { target = 1 }, label = { Text("Album: ${track.album}".take(26)) })
                FilterChip(selected = target == 2, onClick = { target = 2 }, label = { Text("Artist: ${track.artist}".take(26)) })
            }
        }
        if (key != null) {
            val has = sd.peqScoped.containsKey(key)
            Text(
                if (has) "These levels play automatically for this ${if (target == 1) "album" else "artist"}." else "Change a band to save levels just for this ${if (target == 1) "album" else "artist"}.",
                Modifier.padding(horizontal = 16.dp),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (has) TextButton(onClick = {
                app.store.update { d -> d.copy(peqScoped = d.peqScoped - key) }
                holder.refreshPeq()
            }) { Text("Remove this preset") }
        }
        val on = sd.peqOn
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(220.dp)
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .pointerInput(key, levels.size) {
                    var band = 0
                    var live = levels.toMutableList()
                    detectDragGestures(
                        onDragStart = { p ->
                            live = levels.toMutableList()
                            while (live.size < PrecisionEq.BANDS) live.add(0f)
                            band = ((p.x / size.width) * PrecisionEq.BANDS).toInt().coerceIn(0, PrecisionEq.BANDS - 1)
                            live[band] = (12f - (p.y / size.height) * 24f).coerceIn(-12f, 12f)
                            save(live.toList())
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            live[band] = (12f - (change.position.y / size.height) * 24f).coerceIn(-12f, 12f)
                            save(live.toList())
                        },
                    )
                },
        ) {
            val n = PrecisionEq.BANDS
            val w = size.width
            val h = size.height
            for (g in listOf(-12f, -6f, 0f, 6f, 12f)) {
                val y = h * (12f - g) / 24f
                drawLine(if (g == 0f) primary.copy(alpha = 0.4f) else dim, Offset(0f, y), Offset(w, y), if (g == 0f) 2.dp.toPx() else 1.dp.toPx())
            }
            val pts = List(n) { i -> Offset(w * (i + 0.5f) / n, h * (12f - levels.getOrElse(i) { 0f }) / 24f) }
            val path = Path()
            pts.forEachIndexed { i, p ->
                if (i == 0) path.moveTo(p.x, p.y) else {
                    val q = pts[i - 1]
                    path.cubicTo((q.x + p.x) / 2f, q.y, (q.x + p.x) / 2f, p.y, p.x, p.y)
                }
            }
            val fill = Path().apply {
                addPath(path)
                lineTo(pts.last().x, h / 2f)
                lineTo(pts.first().x, h / 2f)
                close()
            }
            val a = if (on) 1f else 0.4f
            drawPath(fill, Brush.verticalGradient(listOf(primary.copy(alpha = 0.3f * a), Color.Transparent)))
            drawPath(path, primary.copy(alpha = a), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
            pts.forEach { p ->
                drawCircle(primary.copy(alpha = a), 7.dp.toPx(), p)
                drawCircle(Color.White.copy(alpha = a), 3.dp.toPx(), p)
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceAround) {
            PrecisionEq.FREQS.forEachIndexed { i, f ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (f >= 1000) "${f / 1000}k" else "$f", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("%+.0f".format(levels.getOrElse(i) { 0f }), style = MaterialTheme.typography.labelSmall, color = primary)
                }
            }
        }
        val boost = levels.maxOrNull()?.coerceAtLeast(0f) ?: 0f
        Text(
            if (boost > 0.5f) "Overall volume is lowered by %.0f dB to leave room for the boost, so loud songs stay clean.".format(boost) else "No boost, no volume change.",
            Modifier.padding(16.dp, 12.dp, 16.dp, 4.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text("Shapes", Modifier.padding(start = 16.dp, top = 8.dp), style = MaterialTheme.typography.titleSmall)
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            peqPresets.forEach { (name, l) -> AssistChip(onClick = { save(l) }, label = { Text(name) }) }
        }
        Text(
            "Works on normal 16-bit stereo files. It does not apply during the overlap blend between two songs.",
            Modifier.padding(16.dp),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(Modifier.height(24.dp))
    }
}
