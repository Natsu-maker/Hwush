package com.hwush.player

import android.app.Application
import android.content.Context
import androidx.compose.runtime.mutableIntStateOf
import com.hwush.player.data.Art
import com.hwush.player.data.Library
import com.hwush.player.data.LyricsFinder
import com.hwush.player.data.Store
import com.hwush.player.player.PlayerHolder

class HwushApp : Application() {
    lateinit var store: Store
    lateinit var library: Library
    lateinit var art: Art
    lateinit var lyrics: LyricsFinder
    lateinit var player: PlayerHolder

    /** Bumped when a cover is edited so images reload. */
    val coverRev = mutableIntStateOf(0)

    override fun onCreate() {
        super.onCreate()
        store = Store(this)
        library = Library(this, store)
        art = Art(this, store)
        lyrics = LyricsFinder(this, store)
        player = PlayerHolder(this, store, library, art)
    }
}

val Context.hwush: HwushApp get() = applicationContext as HwushApp
