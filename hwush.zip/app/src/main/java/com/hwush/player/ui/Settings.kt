@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hwush.player.player.PlaybackService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun SettingTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 8.dp),
    )
}

@Composable
private fun SettingLabel(text: String, hint: String? = null) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Text(text, style = MaterialTheme.typography.bodyLarge)
        if (hint != null) {
            Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingSwitch(title: String, hint: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (hint != null) {
                Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private val swatches = listOf(
    0xFF5B8CFF, 0xFFFF5252, 0xFFFF9F43, 0xFFFFD93D, 0xFF3DDC84,
    0xFF1DE9B6, 0xFF29B6F6, 0xFFB388FF, 0xFFFF6FB5, 0xFFE0E0E0,
)

@Composable
fun SettingsScreen(ui: UiController) {
    val app = ui.app
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val sd by app.store.data.collectAsState()

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        ctx.contentResolver.openOutputStream(uri)?.use { it.write(app.store.exportJson().toByteArray()) }
                        true
                    } catch (e: Exception) {
                        false
                    }
                }
                ui.say(if (ok) "Backup saved" else "Could not save the backup")
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val text = withContext(Dispatchers.IO) {
                    try {
                        ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    } catch (e: Exception) {
                        null
                    }
                }
                if (text != null && app.store.importJson(text)) {
                    app.player.reapplySettings()
                    ui.say("Backup restored")
                } else {
                    ui.say("That file is not a Hwush backup")
                }
            }
        }
    }
    val lyricsPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            app.lyrics.resetIndex()
            app.store.update { it.copy(lyricsTree = uri.toString()) }
            ui.say("Lyrics folder set")
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { ui.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") }
            Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {

            SettingTitle("Appearance")
            SettingLabel("Theme")
            Choices(listOf("Auto" to 0, "Light" to 1, "Dark" to 2), sd.themeMode) { v -> app.store.update { d -> d.copy(themeMode = v) } }
            SettingSwitch("Pure black", "True black background. Saves battery on OLED screens.", sd.amoled) { v ->
                app.store.update { d -> d.copy(amoled = v) }
            }
            SettingLabel(
                "Accent colour",
                if (Build.VERSION.SDK_INT < 27) "Wallpaper colours need Android 8.1 or newer. Hwush blue is used instead." else null,
            )
            Choices(
                listOf("Wallpaper" to 0, "Album art" to 1, "Custom" to 2, "Hwush blue" to 3),
                sd.accentMode,
            ) { v -> app.store.update { d -> d.copy(accentMode = v) } }
            if (sd.accentMode == 2) {
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    swatches.forEach { c ->
                        val argb = Color(c).toArgb()
                        val selected = sd.accentColor == argb
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(c))
                                .then(
                                    if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier,
                                )
                                .clickable { app.store.update { d -> d.copy(accentColor = argb) } },
                        )
                    }
                }
            }

            SettingTitle("Library")
            SettingLabel("Hide songs shorter than", "Keeps voice notes and short clips out of your music.")
            Choices(listOf("Off" to 0, "15 s" to 15, "30 s" to 30, "60 s" to 60), sd.minSeconds) { v ->
                app.store.update { d -> d.copy(minSeconds = v) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { app.library.refresh(); ui.say("Scanning your music") }) { Text("Scan again") }
                if (sd.hidden.isNotEmpty()) {
                    OutlinedButton(onClick = { app.store.unhideAll() }) { Text("Show ${sd.hidden.size} hidden") }
                }
                if (sd.excludedFolders.isNotEmpty()) {
                    OutlinedButton(onClick = { app.store.update { d -> d.copy(excludedFolders = emptySet()) } }) {
                        Text("Show ${sd.excludedFolders.size} folders")
                    }
                }
            }
            SettingLabel(
                "Lyrics folder",
                if (sd.lyricsTree == null) "Hwush also looks for a .lrc file next to each song."
                else Uri.decode(sd.lyricsTree.orEmpty()).substringAfterLast(':').ifEmpty { "Folder chosen" },
            )
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { lyricsPicker.launch(null) }) { Text("Choose folder") }
                if (sd.lyricsTree != null) {
                    OutlinedButton(onClick = {
                        app.lyrics.resetIndex()
                        app.store.update { d -> d.copy(lyricsTree = null) }
                    }) { Text("Clear") }
                }
            }

            SettingTitle("Playback")
            SettingLabel("Fade between songs", "Fades out at the end of a song and in at the start of the next.")
            Choices(listOf("Off" to 0, "2 s" to 2, "4 s" to 4, "6 s" to 6), sd.fadeSeconds) { v ->
                app.store.update { d -> d.copy(fadeSeconds = v) }
            }
            SettingSwitch("Skip silence", "Jumps over long silent parts.", sd.skipSilence) { v -> app.player.setSkipSilence(v) }
            SettingLabel(
                "Volume normalizing (ReplayGain)",
                "Evens out loud and quiet songs using the ReplayGain tags in MP3 and FLAC files. Songs without tags are left alone.",
            )
            Choices(listOf("Off" to 0, "Track" to 1, "Album" to 2), sd.replayGain) { v ->
                app.store.update { d -> d.copy(replayGain = v) }
                app.player.reapplySettings()
            }
            SettingSwitch(
                "Shake to skip",
                "Shake the phone firmly to jump to the next song while music is playing.",
                sd.shakeSkip,
            ) { v ->
                app.store.update { d -> d.copy(shakeSkip = v) }
                PlaybackService.instance?.updateShake()
            }
            SettingSwitch(
                "Resume when headphones reconnect",
                "If your headphones disconnect and music pauses, it continues when they connect again within 10 minutes.",
                sd.btResume,
            ) { v -> app.store.update { d -> d.copy(btResume = v) } }
            SettingLabel(
                "Headset buttons",
                "The button on your headphones plays and pauses. On most headsets a double press skips to the next song and a triple press goes back.",
            )
            SettingLabel("Remember position in long tracks", "Mixes and podcasts longer than this resume where you stopped.")
            Choices(listOf("Off" to 0, "5 min" to 5, "10 min" to 10, "20 min" to 20, "30 min" to 30), sd.rememberMinutes) { v ->
                app.store.update { d -> d.copy(rememberMinutes = v) }
            }

            SettingTitle("Player look")
            SettingSwitch(
                "Blurred cover background",
                "Fills the player with a soft blur of the cover. The blur itself needs Android 12 or newer; older phones get a dimmed cover.",
                sd.blurBackdrop,
            ) { v -> app.store.update { d -> d.copy(blurBackdrop = v) } }
            val vizPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
                app.store.update { d -> d.copy(visualizer = ok) }
                app.visualizer.configure(ok)
                app.visualizer.attach(app.player.player.audioSessionId)
                if (!ok) ui.say("Visualizer needs the microphone permission")
            }
            SettingSwitch(
                "Visualizer",
                "Dancing bars on the player. Android calls this the microphone permission, but Hwush only reads the song it is playing. Nothing is recorded.",
                sd.visualizer,
            ) { v ->
                if (!v) {
                    app.store.update { d -> d.copy(visualizer = false) }
                    app.visualizer.configure(false)
                } else if (app.visualizer.hasPermission()) {
                    app.store.update { d -> d.copy(visualizer = true) }
                    app.visualizer.configure(true)
                    app.visualizer.attach(app.player.player.audioSessionId)
                } else {
                    vizPerm.launch(android.Manifest.permission.RECORD_AUDIO)
                }
            }

            SettingTitle("Lock screen player")
            SettingSwitch(
                "Show player on the lock screen",
                "A full screen player with clock, cover and controls appears when you turn the screen off while music plays.",
                sd.lockPlayer,
            ) { v -> app.store.update { d -> d.copy(lockPlayer = v) } }
            if (android.os.Build.VERSION.SDK_INT >= 29 && !android.provider.Settings.canDrawOverlays(ctx)) {
                SettingLabel("Permission needed", "Android 10 and newer only lets Hwush appear over the lock screen if you allow \"Display over other apps\".")
                Row(Modifier.padding(horizontal = 16.dp)) {
                    OutlinedButton(onClick = {
                        try {
                            ctx.startActivity(
                                Intent(
                                    android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${ctx.packageName}"),
                                ),
                            )
                        } catch (e: Exception) {
                            ui.say("Open Settings, then Apps, then Hwush, then Display over other apps")
                        }
                    }) { Text("Allow display over other apps") }
                }
            }

            SettingTitle("Background playback")
            SettingLabel("If music stops when the screen is off", "Some phones close apps to save battery. Allow Hwush to run freely so the notification and lock screen player stay alive.")
            Row(Modifier.padding(horizontal = 16.dp)) {
                OutlinedButton(onClick = {
                    try {
                        ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    } catch (e: Exception) {
                        ui.say("Open your phone's battery settings and allow Hwush to run in the background")
                    }
                }) { Text("Battery settings") }
            }

            SettingTitle("Backup")
            SettingLabel("Playlists, favorites, play counts, edited song info and settings", "Saved as one small file you can keep anywhere.")
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { exportLauncher.launch("hwush-backup.json") }) { Text("Export backup") }
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) { Text("Restore backup") }
            }

            SettingTitle("About")
            val version = remember {
                try {
                    ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
                } catch (e: Exception) {
                    ""
                }
            }
            SettingLabel("Hwush $version", "A music player that works fully offline.")
        }
    }
}
