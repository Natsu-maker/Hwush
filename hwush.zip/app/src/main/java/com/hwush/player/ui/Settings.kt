@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hwush.player.player.PlaybackService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
private fun SettingTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 8.dp),
    )
}

@Composable
private fun SettingLabel(text: String, hint: String? = null) {
    Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
        Text(text, style = MaterialTheme.typography.bodyLarge)
        if (hint != null) {
            Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SettingSwitch(title: String, hint: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (hint != null) {
                Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private const val SUPPORT_URL = ""

@Composable
private fun SettingSwitchlessRow(title: String, hint: String, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
        Text(hint, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private val swatches = listOf(
    0xFF5B8CFF, 0xFFFF5252, 0xFFFF9F43, 0xFFFFD93D, 0xFF3DDC84,
    0xFF1DE9B6, 0xFF29B6F6, 0xFFB388FF, 0xFFFF6FB5, 0xFFE0E0E0,
    0xFFFF7043, 0xFF00BFA5, 0xFF7C4DFF, 0xFFC0CA33, 0xFFEC407A, 0xFF8D6E63,
)

/** Rows you can nudge up or down and switch off. Used for the Home sections and the bottom tabs. */
@Composable
private fun OrderEditor(
    labels: List<Pair<String, String>>,
    order: List<String>,
    hidden: Set<String>,
    locked: Set<String> = emptySet(),
    onChange: (List<String>, Set<String>) -> Unit,
) {
    val ids = labels.map { it.first }
    val ordered = order.filter { it in ids } + ids.filter { it !in order }
    ordered.forEachIndexed { i, id ->
        val label = labels.first { it.first == id }.second
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
            IconButton(enabled = i > 0, onClick = {
                val l = ordered.toMutableList()
                l.add(i - 1, l.removeAt(i))
                onChange(l, hidden)
            }) { Icon(Icons.Rounded.KeyboardArrowUp, "Move up") }
            IconButton(enabled = i < ordered.lastIndex, onClick = {
                val l = ordered.toMutableList()
                l.add(i + 1, l.removeAt(i))
                onChange(l, hidden)
            }) { Icon(Icons.Rounded.KeyboardArrowDown, "Move down") }
            Switch(
                checked = id !in hidden,
                enabled = id !in locked,
                onCheckedChange = { on -> onChange(ordered, if (on) hidden - id else hidden + id) },
            )
        }
    }
}

@Composable
fun SettingsScreen(ui: UiController) {
    val app = ui.app
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val sd by app.store.data.collectAsState()

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        ctx.contentResolver.openOutputStream(uri)?.use { it.write(app.history.withHistory(app.store.exportJson()).toByteArray()) }
                        true
                    } catch (e: Exception) {
                        false
                    }
                }
                ui.say(if (ok) "Backup saved" else "Could not save the backup")
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val text = withContext(Dispatchers.IO) {
                    try {
                        ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    } catch (e: Exception) {
                        null
                    }
                }
                if (text != null && app.store.importJson(text)) {
                    app.history.restore(text)
                    app.player.reapplySettings()
                    ui.say("Backup restored")
                } else {
                    ui.say("That file is not a Hwush backup")
                }
            }
        }
    }
    val lyricsPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            app.lyrics.resetIndex()
            app.store.update { it.copy(lyricsTree = uri.toString()) }
            ui.say("Lyrics folder set")
        }
    }

    // On a wide tablet screen the settings stay in a readable column in the middle.
    val sidePad = ((androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp - 900).coerceAtLeast(0) / 2).dp
    Column(Modifier.fillMaxSize().padding(horizontal = sidePad)) {
        Row(Modifier.fillMaxWidth().padding(start = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { ui.back() }) { Icon(Icons.Rounded.ArrowBack, "Back") }
            Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.SemiBold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 32.dp)) {

            Row(Modifier.padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                androidx.compose.material3.AssistChip(onClick = { ui.open(Dest(Kind.THEME)) }, label = { Text("Theme builder") })
                androidx.compose.material3.AssistChip(onClick = { ui.open(Dest(Kind.WIDGETS)) }, label = { Text("Widgets") })
                androidx.compose.material3.AssistChip(onClick = { ui.open(Dest(Kind.ALARMS)) }, label = { Text("Alarm clock") })
            }
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                androidx.compose.material3.AssistChip(onClick = { ui.open(Dest(Kind.HEALTH)) }, label = { Text("Recycle bin and health") })
            }

            SettingTitle("Appearance")
            SettingLabel("Theme")
            Choices(listOf("Auto" to 0, "Light" to 1, "Dark" to 2), sd.themeMode) { v -> app.store.update { d -> d.copy(themeMode = v) } }
            SettingLabel("Surface style", "Classic, Rich (more of your accent colour) or Mono (grey).")
            Choices(listOf("Classic" to 0, "Rich" to 1, "Mono" to 2), sd.themeStyle) { v -> app.store.update { d -> d.copy(themeStyle = v) } }
            SettingSwitch("Pure black", "True black background. Saves battery on OLED screens.", sd.amoled) { v ->
                app.store.update { d -> d.copy(amoled = v) }
            }
            SettingLabel(
                "Accent colour",
                if (Build.VERSION.SDK_INT < 27) "Wallpaper colours need Android 8.1 or newer. Hwush blue is used instead." else null,
            )
            Choices(
                listOf("Wallpaper" to 0, "Album art" to 1, "Custom" to 2, "Hwush blue" to 3),
                sd.accentMode,
            ) { v -> app.store.update { d -> d.copy(accentMode = v) } }
            if (sd.accentMode == 2) {
                Spacer(Modifier.height(10.dp))
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    swatches.forEach { c ->
                        val argb = Color(c).toArgb()
                        val selected = sd.accentColor == argb
                        Box(
                            Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(c))
                                .then(
                                    if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape) else Modifier,
                                )
                                .clickable { app.store.update { d -> d.copy(accentColor = argb) } },
                        )
                    }
                }
            }

            SettingTitle("Library")
            SettingLabel("Hide songs shorter than", "Keeps voice notes and short clips out of your music.")
            Choices(listOf("Off" to 0, "15 s" to 15, "30 s" to 30, "60 s" to 60), sd.minSeconds) { v ->
                app.store.update { d -> d.copy(minSeconds = v) }
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { app.library.refresh(); ui.say("Scanning your music") }) { Text("Scan again") }
                if (sd.hidden.isNotEmpty()) {
                    OutlinedButton(onClick = { app.store.unhideAll() }) { Text("Show ${sd.hidden.size} hidden") }
                }
                if (sd.excludedFolders.isNotEmpty()) {
                    OutlinedButton(onClick = { app.store.update { d -> d.copy(excludedFolders = emptySet()) } }) {
                        Text("Show ${sd.excludedFolders.size} folders")
                    }
                }
            }
            SettingLabel(
                "Lyrics folder",
                if (sd.lyricsTree == null) "Hwush also looks for a .lrc file next to each song."
                else Uri.decode(sd.lyricsTree.orEmpty()).substringAfterLast(':').ifEmpty { "Folder chosen" },
            )
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { lyricsPicker.launch(null) }) { Text("Choose folder") }
                if (sd.lyricsTree != null) {
                    OutlinedButton(onClick = {
                        app.lyrics.resetIndex()
                        app.store.update { d -> d.copy(lyricsTree = null) }
                    }) { Text("Clear") }
                }
            }

            SettingTitle("Playback")
            SettingLabel("Fade between songs", "Fades out at the end of a song and in at the start of the next.")
            Choices(listOf("Off" to 0, "2 s" to 2, "4 s" to 4, "6 s" to 6), sd.fadeSeconds) { v ->
                app.store.update { d -> d.copy(fadeSeconds = v) }
            }
            SettingSwitch(
                "Overlap songs (experimental)",
                "The next song fades in while the current one fades out. Needs \"Fade between songs\" above. If you hear glitches, switch it off.",
                sd.overlapFade,
            ) { v -> app.store.update { d -> d.copy(overlapFade = v) } }
            SettingSwitch("Skip silence", "Jumps over long silent parts.", sd.skipSilence) { v -> app.player.setSkipSilence(v) }
            SettingSwitch(
                "Reset speed for each new song",
                "A new song starts at normal speed and pitch, so one slowed or sped up song never carries over. Songs with their own sound settings, and long recordings, keep theirs.",
                sd.autoResetSpeed,
            ) { v -> app.store.update { d -> d.copy(autoResetSpeed = v) } }
            SettingSwitch(
                "Endless mode",
                "When the queue is about to end, Hwush adds songs that match what you are playing: same artist or genre, your favorites and often played songs.",
                sd.endless,
            ) { v -> app.store.update { d -> d.copy(endless = v) } }
            SettingLabel(
                "Volume normalizing (ReplayGain)",
                "Evens out loud and quiet songs using the ReplayGain tags in MP3 and FLAC files. Songs without tags are left alone.",
            )
            Choices(listOf("Off" to 0, "Track" to 1, "Album" to 2), sd.replayGain) { v ->
                app.store.update { d -> d.copy(replayGain = v) }
                app.player.reapplySettings()
            }
            SettingSwitch(
                "Shake to skip",
                "Shake the phone firmly to jump to the next song while music is playing.",
                sd.shakeSkip,
            ) { v ->
                app.store.update { d -> d.copy(shakeSkip = v) }
                PlaybackService.instance?.updateShake()
            }
            SettingSwitch(
                "Knock to skip (screen off)",
                "With the screen off, knock twice on the phone to skip and three times to go back. Android does not send touches to apps while the screen is off, so Hwush feels the knock with the motion sensor: tap the back, side or screen firmly. It works best with the phone on a table or in a hand.",
                sd.knockSkip,
            ) { v ->
                app.store.update { d -> d.copy(knockSkip = v) }
                PlaybackService.instance?.updateKnock()
            }
            SettingSwitch(
                "Find lyrics automatically",
                "When a song has no lyrics, Hwush looks it up on LRCLIB by title, artist and length and saves the best timed match. This is the only time Hwush goes online by itself, and only the song's title and artist are sent.",
                sd.autoLyrics,
            ) { v -> app.store.update { d -> d.copy(autoLyrics = v) } }
            val lyricStatus by com.hwush.player.data.AutoLyrics.status.collectAsState()
            SettingSwitchlessRow(
                "Find lyrics for all songs now",
                lyricStatus ?: "Goes through your whole library once and saves timed lyrics where it finds a match. Tap again while it runs to stop.",
            ) {
                if (lyricStatus != null && lyricStatus!!.startsWith("Looking")) com.hwush.player.data.AutoLyrics.stopAll()
                else com.hwush.player.data.AutoLyrics.runAll(app)
            }
            SettingSwitch(
                "Resume when headphones reconnect",
                "If your headphones disconnect and music pauses, it continues when they connect again within 10 minutes.",
                sd.btResume,
            ) { v -> app.store.update { d -> d.copy(btResume = v) } }
            SettingLabel(
                "Headset buttons",
                "The button on your headphones plays and pauses. On most headsets a double press skips to the next song and a triple press goes back.",
            )
            SettingLabel("Remember position in long tracks", "Mixes and podcasts longer than this resume where you stopped.")
            Choices(listOf("Off" to 0, "5 min" to 5, "10 min" to 10, "20 min" to 20, "30 min" to 30), sd.rememberMinutes) { v ->
                app.store.update { d -> d.copy(rememberMinutes = v) }
            }

            SettingTitle("Layout")
            SettingLabel("Home sections", "Move sections up or down, or switch them off.")
            OrderEditor(
                labels = listOf("recent" to "Jump back in", "top" to "Most played", "added" to "Recently added", "browse" to "Browse list"),
                order = sd.homeOrder,
                hidden = sd.homeHidden,
            ) { o, h -> app.store.update { d -> d.copy(homeOrder = o, homeHidden = h) } }
            SettingLabel("Bottom tabs", "Choose which tabs show and in what order. Home always stays.")
            OrderEditor(
                labels = tabs.map { it.kind.name to it.label },
                order = sd.tabOrder,
                hidden = sd.tabHidden,
                locked = setOf("HOME"),
            ) { o, h -> app.store.update { d -> d.copy(tabOrder = o, tabHidden = h) } }

            SettingTitle("Background")
            val wallPick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                if (uri != null) {
                    try {
                        val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, opts) }
                        var sample = 1
                        while (opts.outWidth / sample > 2000 || opts.outHeight / sample > 2000) sample *= 2
                        val o2 = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
                        val bmp = ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, o2) }
                        if (bmp != null) {
                            java.io.File(ctx.filesDir, "wallpaper.jpg").outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
                            app.store.update { d -> d.copy(wallStamp = System.currentTimeMillis(), wallMode = if (d.wallMode == 0) 2 else d.wallMode, fluidOn = true) }
                        } else {
                            ui.say("Could not read that picture")
                        }
                    } catch (_: Exception) {
                        ui.say("Could not read that picture")
                    }
                }
            }
            SettingLabel("Wallpaper", "Use your own picture behind the whole app, on its own or with the fluid colours moving over it.")
            Choices(listOf("Fluid" to 0, "Picture" to 1, "Picture and fluid" to 2), sd.wallMode) { v ->
                if (v != 0 && !java.io.File(ctx.filesDir, "wallpaper.jpg").exists()) wallPick.launch(arrayOf("image/*"))
                else app.store.update { d -> d.copy(wallMode = v, fluidOn = true) }
            }
            if (sd.wallMode != 0) {
                OutlinedButton(onClick = { wallPick.launch(arrayOf("image/*")) }, modifier = Modifier.padding(horizontal = 16.dp)) { Text("Choose a picture") }
                SettingLabel("Picture blur", "Softens the picture so text stays easy to read.")
                androidx.compose.material3.Slider(
                    value = sd.wallBlur,
                    onValueChange = { v -> app.store.update { d -> d.copy(wallBlur = v) } },
                    valueRange = 0f..1f,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                SettingLabel("Picture darkness", "Darkens the picture in a dark theme and lightens it in a light one.")
                androidx.compose.material3.Slider(
                    value = sd.wallDim,
                    onValueChange = { v -> app.store.update { d -> d.copy(wallDim = v) } },
                    valueRange = 0f..0.9f,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
            }
            SettingSwitch(
                "Lyrics behind the app",
                "While a song with timed lyrics plays, one line at a time fades in behind the app in a different spot each time.",
                sd.bgLyrics,
            ) { v -> app.store.update { d -> d.copy(bgLyrics = v) } }
            if (sd.bgLyrics) {
                SettingLabel("Lyrics size")
                androidx.compose.material3.Slider(
                    value = sd.bgLyricsSize,
                    onValueChange = { v -> app.store.update { d -> d.copy(bgLyricsSize = v) } },
                    valueRange = 0.6f..1.8f,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
            }
            SettingTitle("Fluid background")
            SettingSwitch(
                "Fluid background everywhere",
                "Colour from the cover of the playing song flows behind every screen.",
                sd.fluidOn,
            ) { v -> app.store.update { d -> d.copy(fluidOn = v) } }
            if (sd.fluidOn) {
                SettingLabel("Style", "Clouds, lava lamp or liquid marble.")
                Choices(listOf("Clouds" to 0, "Lava lamp" to 1, "Marble" to 2), sd.fluidStyle) { v -> app.store.update { d -> d.copy(fluidStyle = v) } }
                SettingLabel("Speed", "How fast it flows while music plays.")
                androidx.compose.material3.Slider(
                    value = sd.fluidSpeed,
                    onValueChange = { v -> app.store.update { d -> d.copy(fluidSpeed = v) } },
                    valueRange = 0.2f..2.5f,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                SettingLabel("Calm it down", "Darkens the fluid so text is easier to read.")
                androidx.compose.material3.Slider(
                    value = sd.fluidDim,
                    onValueChange = { v -> app.store.update { d -> d.copy(fluidDim = v) } },
                    valueRange = 0f..0.85f,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                SettingSwitch("Touch pushes it", "Drag a finger and the colour flows away and ripples.", sd.fluidTouch) { v -> app.store.update { d -> d.copy(fluidTouch = v) } }
                SettingSwitch("Glow orbs and light sweep", "Soft lights drift up and a sheen sweeps across.", sd.fluidOrbs) { v -> app.store.update { d -> d.copy(fluidOrbs = v) } }
                SettingSwitch("Sparkle", "Shooting stars, dust and aurora from the effects level in Settings.", sd.fluidFx) { v -> app.store.update { d -> d.copy(fluidFx = v) } }
                SettingLabel("Bar and mini player clarity", "How see-through the side bar, bottom bar and mini player are. Left is clearest.")
                androidx.compose.material3.Slider(
                    value = sd.barAlpha,
                    onValueChange = { v -> app.store.update { d -> d.copy(barAlpha = v) } },
                    valueRange = 0f..1f,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                SettingSwitch("Only while playing", "Fades to a plain background when music is paused, to save battery.", sd.fluidOnlyPlaying) { v -> app.store.update { d -> d.copy(fluidOnlyPlaying = v) } }
            }
            SettingTitle("Player look")
            SettingSwitch(
                "Animated background",
                "Fills the player with colours from the cover that keep moving while music plays.",
                sd.blurBackdrop,
            ) { v -> app.store.update { d -> d.copy(blurBackdrop = v) } }
            if (sd.blurBackdrop) {
                SettingLabel("Background style", "Apple fluid: soft colour clouds that swirl. Lava lamp: glowing blobs rise and melt together. Liquid marble: ribbons that stream and fold. Each song gets its own random movement.")
                Choices(listOf("Apple fluid" to 0, "Lava lamp" to 1, "Liquid marble" to 2), sd.bgStyle) { v -> app.store.update { d -> d.copy(bgStyle = v) } }
            }
            SettingTitle("Quick access")
            SettingLabel("Quick settings tile", "Pull down the quick settings panel, tap the pencil, and add the Hwush tile to play and pause from anywhere.")
            SettingTitle("Effects")
            SettingLabel("Effects level", "Off keeps everything still. Light is gentle and easy on the battery. Full turns on every sparkle.")
            Choices(listOf("Off" to 0, "Light" to 1, "Full" to 2), sd.fxLevel) { v -> app.store.update { d -> d.copy(fxLevel = v) } }
            if (sd.fxLevel > 0) {
                SettingSwitch("Shooting stars", "Streaks of light that cross the player now and then.", sd.fxStars) { v -> app.store.update { d -> d.copy(fxStars = v) } }
                SettingSwitch("Floating particles", "Soft glowing dust that drifts upward.", sd.fxParticles) { v -> app.store.update { d -> d.copy(fxParticles = v) } }
                SettingSwitch("Beat pulse", "The background glows on the hits of the music. Reads the song once, offline.", sd.fxPulse) { v -> app.store.update { d -> d.copy(fxPulse = v) } }
                SettingSwitch("Aurora and night sky", "Twinkling stars and slow colour ribbons at the top.", sd.fxAurora) { v -> app.store.update { d -> d.copy(fxAurora = v) } }
            }
            SettingLabel("Progress bar style", "Classic uses the waveform switch below. The others replace it.")
            Choices(listOf("Classic" to 0, "Wavy" to 1, "Comet" to 2, "Liquid" to 3), sd.barStyle) { v -> app.store.update { d -> d.copy(barStyle = v) } }
            SettingSwitch(
                "Waveform seek bar",
                "Draws the seek bar from the song's own loudness. Songs over 40 minutes keep the plain bar.",
                sd.waveSeek,
            ) { v -> app.store.update { d -> d.copy(waveSeek = v) } }
            SettingLabel("Swipe to change song", "How the cover moves and blurs when you swipe it.")
            Choices(listOf("Streak" to 0, "Whole slide" to 1, "Card stack" to 2), sd.swipeStyle) { v -> app.store.update { d -> d.copy(swipeStyle = v) } }
            SettingLabel("Glass strength", "How see-through and shiny the player panels are.")
            androidx.compose.material3.Slider(
                value = sd.glassLevel,
                onValueChange = { v -> app.store.update { d -> d.copy(glassLevel = v) } },
                valueRange = 0f..1f,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            SettingLabel("Cover style", "A square cover, or a round disc that spins while music plays.")
            Choices(listOf("Square" to 0, "Spinning disc" to 1), sd.coverStyle) { v -> app.store.update { d -> d.copy(coverStyle = v) } }
            val vizPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
                app.store.update { d -> d.copy(visualizer = ok) }
                app.visualizer.configure(ok)
                app.visualizer.attach(app.player.player.audioSessionId)
                if (!ok) ui.say("Visualizer needs the microphone permission")
            }
            SettingSwitch(
                "Visualizer",
                "Dancing bars on the player. Android calls this the microphone permission, but Hwush only reads the song it is playing. Nothing is recorded.",
                sd.visualizer,
            ) { v ->
                if (!v) {
                    app.store.update { d -> d.copy(visualizer = false) }
                    app.visualizer.configure(false)
                } else if (app.visualizer.hasPermission()) {
                    app.store.update { d -> d.copy(visualizer = true) }
                    app.visualizer.configure(true)
                    app.visualizer.attach(app.player.player.audioSessionId)
                } else {
                    vizPerm.launch(android.Manifest.permission.RECORD_AUDIO)
                }
            }

            SettingTitle("Lock screen player")
            SettingSwitch(
                "Show player on the lock screen",
                "A full screen player with clock, cover and controls appears when you turn the screen off while music plays.",
                sd.lockPlayer,
            ) { v -> app.store.update { d -> d.copy(lockPlayer = v) } }
            if (android.os.Build.VERSION.SDK_INT >= 29 && !android.provider.Settings.canDrawOverlays(ctx)) {
                SettingLabel("Permission needed", "Android 10 and newer only lets Hwush appear over the lock screen if you allow \"Display over other apps\".")
                Row(Modifier.padding(horizontal = 16.dp)) {
                    OutlinedButton(onClick = {
                        try {
                            ctx.startActivity(
                                Intent(
                                    android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${ctx.packageName}"),
                                ),
                            )
                        } catch (e: Exception) {
                            ui.say("Open Settings, then Apps, then Hwush, then Display over other apps")
                        }
                    }) { Text("Allow display over other apps") }
                }
            }

            SettingTitle("Background playback")
            SettingLabel("If music stops when the screen is off", "Some phones close apps to save battery. Allow Hwush to run freely so the notification and lock screen player stay alive.")
            Row(Modifier.padding(horizontal = 16.dp)) {
                OutlinedButton(onClick = {
                    try {
                        ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    } catch (e: Exception) {
                        ui.say("Open your phone's battery settings and allow Hwush to run in the background")
                    }
                }) { Text("Battery settings") }
            }

            SettingTitle("Backup")
            SettingLabel("Playlists, favorites, play counts, edited song info and settings", "Saved as one small file you can keep anywhere.")
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { exportLauncher.launch("hwush-backup.json") }) { Text("Export backup") }
                OutlinedButton(onClick = { importLauncher.launch(arrayOf("*/*")) }) { Text("Restore backup") }
            }
            LibraryTools(ui)

            SettingTitle("About")
            val version = remember {
                try {
                    ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
                } catch (e: Exception) {
                    ""
                }
            }
            SettingLabel("Hwush $version", "A music player that works fully offline.")
            if (SUPPORT_URL.isNotBlank()) {
                SettingSwitchlessRow("Support Hwush", "Hwush is free with no ads. If you like it, you can buy me a coffee.") {
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(SUPPORT_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (_: Exception) {
                        ui.say("Could not open the link")
                    }
                }
            }
        }
    }
}
