package com.hwush.player.editor

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin

/** A plain radix-2 Fourier transform. */
private class Fft(val n: Int) {
    private val levels = Integer.numberOfTrailingZeros(n)
    private val cosT = FloatArray(n / 2) { cos(2.0 * PI * it / n).toFloat() }
    private val sinT = FloatArray(n / 2) { sin(2.0 * PI * it / n).toFloat() }
    private val rev = IntArray(n) { Integer.reverse(it) ushr (32 - levels) }

    fun run(re: FloatArray, im: FloatArray, inverse: Boolean) {
        for (i in 0 until n) {
            val j = rev[i]
            if (j > i) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var size = 2
        while (size <= n) {
            val half = size / 2
            val step = n / size
            var i = 0
            while (i < n) {
                var k = 0
                for (j in i until i + half) {
                    val wr = cosT[k]
                    val wi = if (inverse) sinT[k] else -sinT[k]
                    val l = j + half
                    val tr = re[l] * wr - im[l] * wi
                    val ti = re[l] * wi + im[l] * wr
                    re[l] = re[j] - tr
                    im[l] = im[j] - ti
                    re[j] += tr
                    im[j] += ti
                    k += step
                }
                i += size
            }
            size *= 2
        }
    }
}

class Stems(val vocals: ShortArray, val instrumental: ShortArray, val bass: ShortArray)

/**
 * A rough, offline way of pulling a song apart. Voices, kick and bass sit in the middle of most mixes, so the part
 * of the sound that is the same on both sides, in the voice's frequencies, is kept as the vocals. Taking that away
 * leaves the instruments. The bass is just the low end. It is not as clean as a trained model, and drums that sit
 * in the middle can leak into the vocals.
 */
object EdStems {
    const val RATE = 44100

    fun split(seg: ShortArray, onProgress: (Float) -> Unit): Stems {
        val n = 2048
        val hop = 512
        val frames = seg.size / 2
        val fft = Fft(n)
        val win = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / n)).toFloat() }
        // Which pitches count as voice: nothing under 140 Hz, full from 250 to 5000, easing off by 9000
        val weight = FloatArray(n / 2 + 1) { k ->
            val f = k * RATE.toFloat() / n
            when {
                f < 140f -> 0f
                f < 250f -> (f - 140f) / 110f
                f < 5000f -> 1f
                f < 9000f -> 1f - 0.75f * (f - 5000f) / 4000f
                else -> 0.2f
            }
        }
        val voc = FloatArray(frames)
        val re = FloatArray(n)
        val im = FloatArray(n)
        val vr = FloatArray(n)
        val vi = FloatArray(n)
        var start = -(n - hop)
        var count = 0
        val total = (frames + n) / hop + 1
        while (start < frames) {
            for (j in 0 until n) {
                val p = start + j
                if (p in 0 until frames) {
                    re[j] = seg[p * 2] * win[j] / 32768f
                    im[j] = seg[p * 2 + 1] * win[j] / 32768f
                } else {
                    re[j] = 0f
                    im[j] = 0f
                }
            }
            fft.run(re, im, false)
            for (k in 0..n / 2) {
                val k2 = (n - k) % n
                val xr = re[k]; val xi = im[k]
                val yr = re[k2]; val yi = -im[k2]
                val lr = (xr + yr) * 0.5f
                val li = (xi + yi) * 0.5f
                val rr = (xi - yi) * 0.5f
                val ri = -(xr - yr) * 0.5f
                val pl = lr * lr + li * li
                val pr = rr * rr + ri * ri
                val dr = lr - rr
                val di = li - ri
                val pd = dr * dr + di * di
                var c = 1f - pd / (pl + pr + 1e-9f)
                if (c < 0f) c = 0f
                val g = c * c * weight[k]
                val mr = (lr + rr) * 0.5f * g
                val mi = (li + ri) * 0.5f * g
                vr[k] = mr
                vi[k] = mi
                if (k in 1 until n / 2) {
                    vr[n - k] = mr
                    vi[n - k] = -mi
                }
            }
            vi[0] = 0f
            vi[n / 2] = 0f
            fft.run(vr, vi, true)
            for (j in 0 until n) {
                val p = start + j
                if (p in 0 until frames) voc[p] += vr[j] / n * win[j] / 1.5f
            }
            start += hop
            count++
            if (count % 64 == 0) onProgress((count.toFloat() / total).coerceIn(0f, 1f))
        }
        val vocals = ShortArray(seg.size)
        val inst = ShortArray(seg.size)
        for (i in 0 until frames) {
            val v = (voc[i] * 32768f * 1.35f).toInt().coerceIn(-32768, 32767)
            vocals[i * 2] = v.toShort()
            vocals[i * 2 + 1] = v.toShort()
            inst[i * 2] = (seg[i * 2] - v).coerceIn(-32768, 32767).toShort()
            inst[i * 2 + 1] = (seg[i * 2 + 1] - v).coerceIn(-32768, 32767).toShort()
        }
        // Bass: three gentle low pass filters in a row
        val bass = ShortArray(seg.size)
        val a = 1f - exp(-2f * PI.toFloat() * 150f / RATE)
        for (ch in 0..1) {
            var s1 = 0f; var s2 = 0f; var s3 = 0f
            for (i in 0 until frames) {
                val x = seg[i * 2 + ch].toFloat()
                s1 += a * (x - s1)
                s2 += a * (s1 - s2)
                s3 += a * (s2 - s3)
                bass[i * 2 + ch] = (s3 * 1.4f).toInt().coerceIn(-32768, 32767).toShort()
            }
        }
        onProgress(1f)
        return Stems(vocals, inst, bass)
    }
}
