@file:OptIn(ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.hwush.player.data.Playlist

private class EditRow(val uid: Int, val path: String)

/**
 * The playlist while it is being rearranged: hold the handle and drag a song up or down, or swipe a song
 * sideways to take it out (with an undo). Every change is saved straight away.
 */
@Composable
fun PlaylistEditList(ui: UiController, playlist: Playlist, onDone: () -> Unit, header: @Composable () -> Unit) {
    val app = ui.app
    val rows = remember(playlist.id) {
        val l = mutableStateListOf<EditRow>()
        var n = 0
        for (p in playlist.paths) if (app.library.find(p) != null) l.add(EditRow(n++, p))
        l
    }
    val commit = {
        val missing = playlist.paths.filter { app.library.find(it) == null }
        app.store.setPlaylistPaths(playlist.id, rows.map { it.path } + missing)
    }
    val lazy = rememberLazyListState()
    var dragUid by remember { mutableIntStateOf(-1) }
    var pointer by remember { mutableFloatStateOf(0f) }

    LazyColumn(Modifier.fillMaxSize(), state = lazy, contentPadding = PaddingValues(bottom = 16.dp)) {
        item(key = "header") { header() }
        item(key = "hint") {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Drag the handle to reorder. Swipe a song sideways to remove it.",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                TextButton(onClick = onDone) { Text("Done") }
            }
        }
        itemsIndexed(rows, key = { _, r -> r.uid }) { _, r ->
            val track = app.library.find(r.path)
            if (track != null) {
                val state = rememberSwipeToDismissBoxState(
                    confirmValueChange = { v ->
                        if (v == SwipeToDismissBoxValue.Settled) {
                            false
                        } else {
                            val at = rows.indexOfFirst { it.uid == r.uid }
                            if (at >= 0) {
                                rows.removeAt(at)
                                commit()
                                ui.sayAction("Removed ${track.title}", "Undo") {
                                    rows.add(at.coerceAtMost(rows.size), r)
                                    commit()
                                }
                            }
                            true
                        }
                    },
                )
                val dragging = dragUid == r.uid
                SwipeToDismissBox(
                    state = state,
                    modifier = Modifier
                        .then(if (dragging) Modifier else Modifier.animateItem())
                        .zIndex(if (dragging) 1f else 0f)
                        .graphicsLayer {
                            if (dragging) {
                                val c = lazy.layoutInfo.visibleItemsInfo.firstOrNull { it.key == r.uid }
                                translationY = if (c != null) pointer - (c.offset + c.size / 2f) else 0f
                                shadowElevation = 12f
                            }
                        },
                    enableDismissFromStartToEnd = true,
                    enableDismissFromEndToStart = true,
                    backgroundContent = {
                        Box(
                            Modifier.fillMaxSize().background(MaterialTheme.colorScheme.errorContainer).padding(horizontal = 20.dp),
                            contentAlignment = Alignment.CenterEnd,
                        ) { Icon(Icons.Rounded.Delete, "Remove", tint = MaterialTheme.colorScheme.onErrorContainer) }
                    },
                ) {
                    ListItem(
                        modifier = Modifier.background(if (state.dismissDirection == androidx.compose.material3.SwipeToDismissBoxValue.Settled) Color.Transparent else MaterialTheme.colorScheme.background),
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        leadingContent = { Cover(track, Modifier.size(48.dp), 48.dp, RoundedCornerShape(8.dp)) },
                        headlineContent = { Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        supportingContent = { Text(track.artist, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        trailingContent = {
                            Icon(
                                Icons.Rounded.DragHandle,
                                "Drag to reorder",
                                Modifier
                                    .size(40.dp)
                                    .padding(8.dp)
                                    .pointerInput(r.uid) {
                                        detectDragGestures(
                                            onDragStart = {
                                                val c = lazy.layoutInfo.visibleItemsInfo.firstOrNull { it.key == r.uid }
                                                pointer = if (c != null) c.offset + c.size / 2f else 0f
                                                dragUid = r.uid
                                            },
                                            onDragEnd = { dragUid = -1; commit() },
                                            onDragCancel = { dragUid = -1; commit() },
                                            onDrag = { change, amount ->
                                                change.consume()
                                                pointer += amount.y
                                                val vis = lazy.layoutInfo.visibleItemsInfo
                                                // Only act when the screen has caught up with the last swap.
                                                val caughtUp = vis.all { info ->
                                                    val k = info.key
                                                    k !is Int || rows.getOrNull(info.index - 2)?.uid == k
                                                }
                                                if (caughtUp) {
                                                    val hit = vis.firstOrNull { info ->
                                                        val k = info.key
                                                        k is Int && k != r.uid && pointer >= info.offset && pointer <= info.offset + info.size
                                                    }
                                                    if (hit != null) {
                                                        val from = rows.indexOfFirst { it.uid == r.uid }
                                                        val to = rows.indexOfFirst { it.uid == hit.key }
                                                        if (from >= 0 && to >= 0) rows.add(to, rows.removeAt(from))
                                                    }
                                                }
                                            },
                                        )
                                    },
                            )
                        },
                    )
                }
            }
        }
    }
}
