package com.hwush.player.studio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.hwush.player.dj.DrumKit
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

const val ST_RATE = 44100
const val PPQ = 96 // ticks in a beat
const val STEP = 24 // ticks in a sixteenth
const val BAR = 384 // ticks in a bar of four beats
const val MAXPAT = 16
const val INSERTS = 9 // 0 is the master, 1 to 8 are mixer tracks

class Note(val start: Int, val len: Int, val pitch: Int, val vel: Float)

class Pattern(var name: String, var bars: Int, var color: Int)

/** One instrument in the channel rack: a drum sound, a synth or a piece of one of your songs. */
class Channel(val id: Int, var name: String, var type: Int, var kit: Int, var color: Int) {
    val notes = Array(MAXPAT) { CopyOnWriteArrayList<Note>() }
    @Volatile var wave = 2 // 0 sine, 1 square, 2 saw, 3 pluck
    @Volatile var cutoff = 0.6f
    @Volatile var attack = 0.1f
    @Volatile var release = 0.3f
    @Volatile var vol = 0.8f
    @Volatile var pan = 0f
    @Volatile var mute = false
    @Volatile var solo = false
    @Volatile var insert = 0
    @Volatile var defPitch = 60
    @Volatile var clip: ShortArray? = null
    @Volatile var title = ""
    @Volatile var path = ""
    @Volatile var startSec = 0f
}

/** A pattern placed on a playlist track, starting at a bar. */
class Clip(val track: Int, val bar: Int, val pattern: Int)

private class Reverb {
    private val cl = intArrayOf(1116, 1188, 1277, 1356)
    private val bl = Array(4) { FloatArray(cl[it]) }
    private val br = Array(4) { FloatArray(cl[it] + 23) }
    private val il = IntArray(4)
    private val ir = IntArray(4)
    private val sl = FloatArray(4)
    private val sr = FloatArray(4)
    private val al = arrayOf(FloatArray(556), FloatArray(441))
    private val ar = arrayOf(FloatArray(579), FloatArray(464))
    private val ail = IntArray(2)
    private val air = IntArray(2)
    var oL = 0f
    var oR = 0f

    fun run(l: Float, r: Float, room: Float, damp: Float) {
        val fb = 0.7f + 0.27f * room
        val d = damp * 0.7f
        val inp = (l + r) * 0.15f
        var a = 0f
        var b = 0f
        for (i in 0 until 4) {
            val yl = bl[i][il[i]]
            sl[i] = yl * (1f - d) + sl[i] * d
            bl[i][il[i]] = inp + sl[i] * fb
            il[i] = (il[i] + 1) % bl[i].size
            a += yl
            val yr = br[i][ir[i]]
            sr[i] = yr * (1f - d) + sr[i] * d
            br[i][ir[i]] = inp + sr[i] * fb
            ir[i] = (ir[i] + 1) % br[i].size
            b += yr
        }
        for (k in 0 until 2) {
            val x = al[k][ail[k]]
            al[k][ail[k]] = a + x * 0.5f
            a = -a + x
            ail[k] = (ail[k] + 1) % al[k].size
            val y = ar[k][air[k]]
            ar[k][air[k]] = b + y * 0.5f
            b = -b + y
            air[k] = (air[k] + 1) % ar[k].size
        }
        oL = a
        oR = b
    }
}

/** One effect in a mixer track. Types: 0 none, 1 filter, 2 delay, 3 reverb, 4 drive, 5 crush. */
class FxSlot {
    @Volatile var type = 0
    @Volatile var p1 = 0.5f
    @Volatile var p2 = 0.5f
    @Volatile var p3 = 0.35f
    var oL = 0f
    var oR = 0f
    private var a1 = 0f
    private var a2 = 0f
    private var b1 = 0f
    private var b2 = 0f
    private var dl: FloatArray? = null
    private var dr: FloatArray? = null
    private var di = 0
    private var rv: Reverb? = null
    private var hl = 0f
    private var hr = 0f
    private var hc = 0
    private var tl = 0f
    private var tr = 0f

    fun setType(t: Int) {
        if (t == 2 && dl == null) { dl = FloatArray(ST_RATE * 2); dr = FloatArray(ST_RATE * 2) }
        if (t == 3 && rv == null) rv = Reverb()
        when (t) {
            1 -> { p1 = 0.6f; p2 = 0.2f; p3 = 1f }
            2 -> { p1 = 0.45f; p2 = 0.45f; p3 = 0.35f }
            3 -> { p1 = 0.6f; p2 = 0.4f; p3 = 0.3f }
            4 -> { p1 = 0.4f; p2 = 0.6f; p3 = 0.6f }
            5 -> { p1 = 0.4f; p2 = 0.3f; p3 = 0.6f }
        }
        type = t
    }

    fun run(l: Float, r: Float, bpm: Int) {
        when (type) {
            1 -> {
                val fc = 30f * 2f.pow(p1 * 9.2f)
                val a = min(0.98f, 2f * PI.toFloat() * fc / ST_RATE)
                a1 += a * (l - a1); a2 += a * (a1 - a2)
                b1 += a * (r - b1); b2 += a * (b1 - b2)
                val hp = p2 > 0.5f
                val wl = if (hp) l - a2 else a2
                val wr = if (hp) r - b2 else b2
                oL = l + (wl - l) * p3
                oR = r + (wr - r) * p3
            }
            2 -> {
                val bl = dl; val brr = dr
                if (bl == null || brr == null) { oL = l; oR = r; return }
                val ds = (((p1 * 7f).toInt() + 1) * (ST_RATE * 60f / bpm / 4f)).toInt().coerceIn(200, bl.size - 1)
                val rd = (di - ds + bl.size) % bl.size
                val xl = bl[rd]
                val xr = brr[rd]
                bl[di] = l + xr * p2 * 0.9f
                brr[di] = r + xl * p2 * 0.9f
                di = (di + 1) % bl.size
                oL = l + xl * p3
                oR = r + xr * p3
            }
            3 -> {
                val v = rv
                if (v == null) { oL = l; oR = r; return }
                v.run(l, r, p1, p2)
                oL = l + v.oL * p3 * 1.4f
                oR = r + v.oR * p3 * 1.4f
            }
            4 -> {
                val g = 1f + p1 * 18f
                val a = 0.04f + p2 * p2 * 0.95f
                tl += a * (tanh(l * g) * 0.7f - tl)
                tr += a * (tanh(r * g) * 0.7f - tr)
                oL = l + (tl - l) * p3
                oR = r + (tr - r) * p3
            }
            5 -> {
                val bits = 16f - p1 * 12f
                val q = 2f.pow(bits - 1f)
                val ds = 1 + (p2 * 14f).toInt()
                if (hc <= 0) {
                    hl = (l * q).toInt() / q
                    hr = (r * q).toInt() / q
                    hc = ds
                }
                hc--
                oL = l + (hl - l) * p3
                oR = r + (hr - r) * p3
            }
            else -> { oL = l; oR = r }
        }
    }
}

class Insert(val name: String) {
    @Volatile var vol = 0.85f
    @Volatile var pan = 0f
    @Volatile var mute = false
    @Volatile var solo = false
    @Volatile var peak = 0f
    val slots = Array(3) { FxSlot() }
}

private class KV(val data: ShortArray, val rate: Float, val gl: Float, val gr: Float, val ins: Int) { var pos = 0f }
private class SV(
    val freq: Float, val wave: Int, val cutoff: Float, val atk: Float, val relCoef: Float,
    val gl: Float, val gr: Float, val ins: Int, var left: Int,
) {
    var ph = 0f
    var ph2 = 0.37f
    var env = 0f
    var rel = false
    var lp = 0f
    var age = 0
}

/**
 * The studio's engine, laid out like a loop based music maker: a rack of channels, patterns made of notes, a playlist
 * that arranges patterns along a timeline, and a mixer with effects. The same code makes the sound for the speaker
 * and for the exported file.
 */
class StudioEngine {
    val patterns = CopyOnWriteArrayList<Pattern>()
    val channels = CopyOnWriteArrayList<Channel>()
    val clips = CopyOnWriteArrayList<Clip>()
    val inserts = Array(INSERTS) { Insert(if (it == 0) "Master" else "Track $it") }
    private var nextId = 1

    @Volatile var bpm = 110
    @Volatile var songMode = false
    @Volatile var curPattern = 0
    @Volatile var playing = false
    @Volatile var tick = 0
    @Volatile var dirty = false

    private val kit: List<ShortArray> = DrumKit.build()
    val kitNames: List<String> get() = DrumKit.names
    private val lock = Any()
    private val kv = ArrayList<KV>()
    private val sv = ArrayList<SV>()
    private var pos = 0.0
    private var lastTick = -1
    private var loopLen = BAR
    private var wraps = 0
    private var exportLoops = 0
    @Volatile private var running = false
    private var thread: Thread? = null
    private var track: AudioTrack? = null
    private val busL = FloatArray(INSERTS)
    private val busR = FloatArray(INSERTS)

    private val colors = intArrayOf(0xFFFF8A2B.toInt(), 0xFF5BC0EB.toInt(), 0xFF9BE564.toInt(), 0xFFE25DA8.toInt(), 0xFFF2C94C.toInt(), 0xFFA78BFA.toInt(), 0xFF4ADEDE.toInt(), 0xFFFF6B6B.toInt())
    fun colorFor(i: Int): Int = colors[((i % colors.size) + colors.size) % colors.size]

    init { newProject() }

    fun newProject() {
        synchronized(lock) {
            playing = false
            kv.clear(); sv.clear()
            patterns.clear(); channels.clear(); clips.clear()
            patterns.add(Pattern("Pattern 1", 1, colorFor(0)))
            curPattern = 0
            bpm = 110
            songMode = false
            for (i in inserts.indices) {
                val n = inserts[i]
                n.vol = 0.85f; n.pan = 0f; n.mute = false; n.solo = false
                for (s in n.slots) s.type = 0
            }
            addChannelLocked("Kick", 0, 0, 1)
            addChannelLocked("Snare", 0, 1, 2)
            addChannelLocked("Clap", 0, 2, 2)
            addChannelLocked("Hat", 0, 3, 3)
            addChannelLocked("Open hat", 0, 4, 3)
            addChannelLocked("Lead", 1, 0, 4).also { it.wave = 2; it.vol = 0.55f }
            addChannelLocked("Bass", 1, 0, 5).also { it.defPitch = 36; it.wave = 1; it.cutoff = 0.35f; it.vol = 0.6f }
            val c = channels
            for (i in 0 until 4) c[0].notes[0].add(Note(i * 96, STEP, 60, 0.95f))
            c[1].notes[0].add(Note(96, STEP, 60, 0.9f)); c[1].notes[0].add(Note(288, STEP, 60, 0.9f))
            for (i in 0 until 8) c[3].notes[0].add(Note(i * 48, STEP, 60, if (i % 2 == 0) 0.9f else 0.6f))
            inserts[1].slots[0].setType(0)
            inserts[4].slots[0].setType(2)
            inserts[4].slots[0].p3 = 0.25f
            dirty = true
        }
    }

    private fun addChannelLocked(name: String, type: Int, kitIdx: Int, insert: Int): Channel {
        val ch = Channel(nextId++, name, type, kitIdx, colorFor(channels.size))
        ch.insert = insert
        channels.add(ch)
        return ch
    }

    fun addChannel(name: String, type: Int, kitIdx: Int): Channel = synchronized(lock) {
        val ch = addChannelLocked(name, type, kitIdx, 0)
        dirty = true
        ch
    }

    fun removeChannel(ch: Channel) { synchronized(lock) { channels.remove(ch); dirty = true } }

    fun addPattern(): Int = synchronized(lock) {
        if (patterns.size >= MAXPAT) return curPattern
        patterns.add(Pattern("Pattern ${patterns.size + 1}", 1, colorFor(patterns.size)))
        dirty = true
        patterns.size - 1
    }

    fun duplicatePattern(src: Int): Int = synchronized(lock) {
        if (patterns.size >= MAXPAT) return src
        val p = patterns[src]
        patterns.add(Pattern(p.name + " copy", p.bars, colorFor(patterns.size)))
        val dst = patterns.size - 1
        for (ch in channels) ch.notes[dst].addAll(ch.notes[src])
        dirty = true
        dst
    }

    fun clearPattern(i: Int) { for (ch in channels) ch.notes[i].clear(); dirty = true }

    fun kitSound(i: Int): ShortArray? = kit.getOrNull(i)

    // -------------------------------------------------------------- transport

    fun start() {
        if (thread != null) return
        val minBuf = AudioTrack.getMinBufferSize(ST_RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(ST_RATE).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
            .setBufferSizeInBytes(maxOf(minBuf, 512 * 4 * 3))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        track = t
        running = true
        t.play()
        thread = Thread({
            val buf = FloatArray(512 * 2)
            val out = ShortArray(512 * 2)
            while (running) {
                synchronized(lock) { render(buf, 512) }
                for (i in buf.indices) out[i] = toShort(buf[i])
                if (t.write(out, 0, out.size) < 0) break
            }
        }, "hwush-studio").also {
            it.priority = Thread.MAX_PRIORITY
            it.start()
        }
    }

    fun release() {
        running = false
        try { thread?.join(600) } catch (_: Exception) {}
        thread = null
        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        track = null
    }

    fun play() {
        synchronized(lock) {
            pos = 0.0
            lastTick = -1
            wraps = 0
            exportLoops = 0
            loopLen = computeLoop()
            playing = true
        }
    }

    fun stop() {
        synchronized(lock) { playing = false; tick = 0 }
    }

    fun songTicks(): Int {
        var m = 0
        for (c in clips) m = max(m, (c.bar + patterns.getOrNull(c.pattern)?.bars.let { it ?: 1 }) * BAR)
        return max(BAR, m)
    }

    private fun computeLoop(): Int = if (songMode) songTicks() else (patterns.getOrNull(curPattern)?.bars ?: 1) * BAR

    // -------------------------------------------------------------- sound making

    private fun panL(pan: Float) = cos((pan.coerceIn(-1f, 1f) + 1f) * (PI.toFloat() / 4f)) * 1.41f
    private fun panR(pan: Float) = sin((pan.coerceIn(-1f, 1f) + 1f) * (PI.toFloat() / 4f)) * 1.41f

    private fun fire(ch: Channel, n: Note, anySolo: Boolean, forced: Boolean = false) {
        if (!forced && (ch.mute || (anySolo && !ch.solo))) return
        val g = ch.vol * n.vel
        val gl = g * panL(ch.pan)
        val gr = g * panR(ch.pan)
        when (ch.type) {
            1 -> {
                if (sv.size >= 32) sv.removeAt(0)
                val f = 440f * 2f.pow((n.pitch - 69) / 12f)
                val tps = bpm * PPQ / 60f / ST_RATE
                val samples = (n.len / tps).toInt().coerceAtLeast(200)
                val relCoef = exp(-1f / (ST_RATE * (0.02f + ch.release * 1.2f) * 0.25f))
                val atk = 1f - exp(-1f / (ST_RATE * (0.002f + ch.attack * ch.attack * 0.5f)))
                sv.add(SV(f, ch.wave, ch.cutoff, atk, relCoef, gl * 0.5f, gr * 0.5f, ch.insert, samples))
            }
            else -> {
                val d = if (ch.type == 2) ch.clip else kit.getOrNull(ch.kit)
                if (d != null) {
                    if (kv.size >= 48) kv.removeAt(0)
                    kv.add(KV(d, 2f.pow((n.pitch - 60) / 12f), gl, gr, ch.insert))
                }
            }
        }
    }

    fun audition(ch: Channel, pitch: Int = 60, ticks: Int = 48) {
        synchronized(lock) { fire(ch, Note(0, ticks, pitch, 0.9f), false, true) }
    }

    private fun trigger(t: Int) {
        val anySolo = channels.any { it.solo }
        if (!songMode) {
            val p = curPattern
            val local = t
            for (ch in channels) for (n in ch.notes[p]) if (n.start == local) fire(ch, n, anySolo)
        } else {
            for (c in clips) {
                val pat = patterns.getOrNull(c.pattern) ?: continue
                val cs = c.bar * BAR
                if (t >= cs && t < cs + pat.bars * BAR) {
                    val local = t - cs
                    for (ch in channels) for (n in ch.notes[c.pattern]) if (n.start == local) fire(ch, n, anySolo)
                }
            }
        }
    }

    private fun wf(w: Int, p: Float): Float = when (w) {
        0 -> sin(2f * PI.toFloat() * p)
        1 -> if (p < 0.5f) 0.8f else -0.8f
        else -> 2f * p - 1f
    }

    /** Fills [buf] with [frames] stereo frames. Call with the lock held. */
    private fun render(buf: FloatArray, frames: Int) {
        val tps = bpm * PPQ / 60.0 / ST_RATE
        val anyIns = inserts.any { it.solo }
        for (n in 0 until frames) {
            if (playing) {
                val cur = pos.toInt()
                while (lastTick < cur) {
                    lastTick++
                    if (lastTick == 0) loopLen = computeLoop()
                    tick = lastTick
                    trigger(lastTick)
                }
                pos += tps
                if (pos >= loopLen) {
                    wraps++
                    if (exportLoops > 0 && wraps >= exportLoops) {
                        playing = false
                    } else {
                        pos -= loopLen
                        lastTick = -1
                    }
                }
            }
            java.util.Arrays.fill(busL, 0f)
            java.util.Arrays.fill(busR, 0f)
            var i = 0
            while (i < kv.size) {
                val v = kv[i]
                val p = v.pos.toInt()
                if (p >= v.data.size - 1) {
                    kv.removeAt(i)
                } else {
                    val f = v.pos - p
                    val s = (v.data[p] + (v.data[p + 1] - v.data[p]) * f) / 32768f
                    busL[v.ins] += s * v.gl
                    busR[v.ins] += s * v.gr
                    v.pos += v.rate
                    i++
                }
            }
            i = 0
            while (i < sv.size) {
                val v = sv[i]
                val inc = v.freq / ST_RATE
                v.ph += inc; if (v.ph >= 1f) v.ph -= 1f
                v.ph2 += inc * 1.005f; if (v.ph2 >= 1f) v.ph2 -= 1f
                val o = (wf(v.wave, v.ph) + wf(v.wave, v.ph2)) * 0.5f
                val cut = if (v.wave == 3) 250f + v.cutoff * 7000f * exp(-v.age / (ST_RATE * 0.16f)) else 150f + v.cutoff * v.cutoff * 11000f
                val a = min(0.95f, 2f * PI.toFloat() * cut / ST_RATE)
                v.lp += a * (o - v.lp)
                if (!v.rel) {
                    v.env += (1f - v.env) * v.atk
                    v.left--
                    if (v.left <= 0) v.rel = true
                } else {
                    v.env *= v.relCoef
                }
                v.age++
                val s = v.lp * v.env
                busL[v.ins] += s * v.gl
                busR[v.ins] += s * v.gr
                if (v.rel && v.env < 0.0008f) sv.removeAt(i) else i++
            }
            var ml = busL[0]
            var mr = busR[0]
            for (k in 1 until INSERTS) {
                val ins = inserts[k]
                var l = busL[k]
                var r = busR[k]
                for (s in ins.slots) if (s.type != 0) { s.run(l, r, bpm); l = s.oL; r = s.oR }
                l *= ins.vol * panL(ins.pan) * 0.71f
                r *= ins.vol * panR(ins.pan) * 0.71f
                val pk = max(abs(l), abs(r))
                ins.peak = if (pk > ins.peak) pk else ins.peak * 0.9996f
                if (!ins.mute && (!anyIns || ins.solo)) { ml += l; mr += r }
            }
            val m = inserts[0]
            for (s in m.slots) if (s.type != 0) { s.run(ml, mr, bpm); ml = s.oL; mr = s.oR }
            ml *= m.vol
            mr *= m.vol
            val pk = max(abs(ml), abs(mr))
            m.peak = if (pk > m.peak) pk else m.peak * 0.9996f
            buf[n * 2] = ml
            buf[n * 2 + 1] = mr
        }
    }

    private fun toShort(v: Float): Short {
        val a = abs(v)
        val s = if (a < 0.8f) v else (if (v < 0f) -1f else 1f) * (0.8f + 0.2f * tanh((a - 0.8f) / 0.2f))
        return (s * 32767f).toInt().coerceIn(-32768, 32767).toShort()
    }

    // -------------------------------------------------------------- export

    /** Plays the song (or the pattern) [loops] times into a wav file. Call off the main thread. */
    fun export(file: File, loops: Int): Boolean {
        try {
            synchronized(lock) {
                playing = false
                kv.clear(); sv.clear()
                pos = 0.0
                lastTick = -1
                wraps = 0
                loopLen = computeLoop()
                exportLoops = if (songMode) 1 else loops.coerceAtLeast(1)
                playing = true
                val buf = FloatArray(1024 * 2)
                val bytes = ByteArray(1024 * 4)
                var total = 0L
                var tail = 0
                java.io.BufferedOutputStream(java.io.FileOutputStream(file), 1 shl 16).use { out ->
                    out.write(ByteArray(44))
                    var guard = 0L
                    while (guard < ST_RATE.toLong() * 60 * 20) {
                        render(buf, 1024)
                        for (j in 0 until 2048) {
                            val s = toShort(buf[j]).toInt()
                            bytes[j * 2] = (s and 0xff).toByte()
                            bytes[j * 2 + 1] = ((s shr 8) and 0xff).toByte()
                        }
                        out.write(bytes, 0, 4096)
                        total += 1024
                        guard += 1024
                        if (!playing) {
                            tail += 1024
                            if (tail >= ST_RATE * 2) break
                        }
                    }
                }
                RandomAccessFile(file, "rw").use { raf ->
                    val data = (total * 4).toInt()
                    val h = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                    h.put("RIFF".toByteArray()).putInt(36 + data).put("WAVE".toByteArray())
                    h.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(2).putInt(ST_RATE).putInt(ST_RATE * 4).putShort(4).putShort(16)
                    h.put("data".toByteArray()).putInt(data)
                    raf.seek(0)
                    raf.write(h.array())
                }
                exportLoops = 0
                kv.clear(); sv.clear()
                playing = false
                tick = 0
            }
            return true
        } catch (_: Exception) {
            exportLoops = 0
            return false
        }
    }

    // -------------------------------------------------------------- saving

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("v", 2); o.put("bpm", bpm); o.put("song", songMode); o.put("cur", curPattern)
        val pa = JSONArray()
        for (p in patterns) pa.put(JSONObject().put("n", p.name).put("b", p.bars).put("c", p.color))
        o.put("patterns", pa)
        val ca = JSONArray()
        for (ch in channels) {
            val j = JSONObject()
            j.put("name", ch.name); j.put("type", ch.type); j.put("kit", ch.kit); j.put("color", ch.color)
            j.put("wave", ch.wave); j.put("cut", ch.cutoff.toDouble()); j.put("atk", ch.attack.toDouble()); j.put("rel", ch.release.toDouble())
            j.put("vol", ch.vol.toDouble()); j.put("pan", ch.pan.toDouble()); j.put("mute", ch.mute); j.put("ins", ch.insert); j.put("dp", ch.defPitch)
            j.put("path", ch.path); j.put("start", ch.startSec.toDouble()); j.put("title", ch.title)
            val pn = JSONArray()
            for (pi in 0 until patterns.size) {
                val na = JSONArray()
                for (n in ch.notes[pi]) na.put(JSONArray().put(n.start).put(n.len).put(n.pitch).put(n.vel.toDouble()))
                pn.put(na)
            }
            j.put("notes", pn)
            ca.put(j)
        }
        o.put("channels", ca)
        val ka = JSONArray()
        for (c in clips) ka.put(JSONArray().put(c.track).put(c.bar).put(c.pattern))
        o.put("clips", ka)
        val ia = JSONArray()
        for (n in inserts) {
            val j = JSONObject()
            j.put("vol", n.vol.toDouble()); j.put("pan", n.pan.toDouble()); j.put("mute", n.mute)
            val sa = JSONArray()
            for (s in n.slots) sa.put(JSONArray().put(s.type).put(s.p1.toDouble()).put(s.p2.toDouble()).put(s.p3.toDouble()))
            j.put("slots", sa)
            ia.put(j)
        }
        o.put("inserts", ia)
        return o
    }

    fun fromJson(o: JSONObject) {
        if (o.optInt("v", 1) < 2) return // an older, simpler project: keep the starting beat
        synchronized(lock) {
            playing = false
            kv.clear(); sv.clear()
            patterns.clear(); channels.clear(); clips.clear()
            bpm = o.optInt("bpm", 110).coerceIn(50, 220)
            songMode = o.optBoolean("song", false)
            val pa = o.optJSONArray("patterns")
            if (pa != null) for (i in 0 until min(pa.length(), MAXPAT)) {
                val j = pa.getJSONObject(i)
                patterns.add(Pattern(j.optString("n", "Pattern ${i + 1}"), j.optInt("b", 1).coerceIn(1, 4), j.optInt("c", colorFor(i))))
            }
            if (patterns.isEmpty()) patterns.add(Pattern("Pattern 1", 1, colorFor(0)))
            curPattern = o.optInt("cur", 0).coerceIn(0, patterns.size - 1)
            val ca = o.optJSONArray("channels")
            if (ca != null) for (i in 0 until ca.length()) {
                val j = ca.getJSONObject(i)
                val ch = Channel(nextId++, j.optString("name", "Channel"), j.optInt("type", 0), j.optInt("kit", 0), j.optInt("color", colorFor(i)))
                ch.wave = j.optInt("wave", 2); ch.cutoff = j.optDouble("cut", 0.6).toFloat(); ch.attack = j.optDouble("atk", 0.1).toFloat()
                ch.release = j.optDouble("rel", 0.3).toFloat(); ch.vol = j.optDouble("vol", 0.8).toFloat(); ch.pan = j.optDouble("pan", 0.0).toFloat()
                ch.defPitch = j.optInt("dp", 60); ch.mute = j.optBoolean("mute", false); ch.insert = j.optInt("ins", 0).coerceIn(0, INSERTS - 1)
                ch.path = j.optString("path", ""); ch.startSec = j.optDouble("start", 0.0).toFloat(); ch.title = j.optString("title", "")
                val pn = j.optJSONArray("notes")
                if (pn != null) for (pi in 0 until min(pn.length(), patterns.size)) {
                    val na = pn.getJSONArray(pi)
                    for (k in 0 until na.length()) {
                        val a = na.getJSONArray(k)
                        ch.notes[pi].add(Note(a.getInt(0), a.getInt(1), a.getInt(2), a.getDouble(3).toFloat()))
                    }
                }
                channels.add(ch)
            }
            val ka = o.optJSONArray("clips")
            if (ka != null) for (i in 0 until ka.length()) {
                val a = ka.getJSONArray(i)
                if (a.getInt(2) < patterns.size) clips.add(Clip(a.getInt(0), a.getInt(1), a.getInt(2)))
            }
            val ia = o.optJSONArray("inserts")
            if (ia != null) for (i in 0 until min(ia.length(), INSERTS)) {
                val j = ia.getJSONObject(i)
                val n = inserts[i]
                n.vol = j.optDouble("vol", 0.85).toFloat(); n.pan = j.optDouble("pan", 0.0).toFloat(); n.mute = j.optBoolean("mute", false)
                val sa = j.optJSONArray("slots")
                if (sa != null) for (k in 0 until min(sa.length(), 3)) {
                    val a = sa.getJSONArray(k)
                    n.slots[k].setType(a.getInt(0))
                    n.slots[k].p1 = a.getDouble(1).toFloat(); n.slots[k].p2 = a.getDouble(2).toFloat(); n.slots[k].p3 = a.getDouble(3).toFloat()
                }
            }
        }
    }

    fun setFx(slot: FxSlot, type: Int) { synchronized(lock) { slot.setType(type); dirty = true } }
}
