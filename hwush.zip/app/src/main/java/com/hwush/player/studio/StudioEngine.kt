package com.hwush.player.studio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.hwush.player.dj.DrumKit
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

const val ST_RATE = 44100
const val ST_MAXSTEPS = 64

class DrumLane(val name: String, val pad: Int) {
    val steps = BooleanArray(ST_MAXSTEPS)
    @Volatile var vol = 0.85f
    @Volatile var pan = 0f
    @Volatile var mute = false
    @Volatile var solo = false
}

class Note(val step: Int, val len: Int, val pitch: Int)

class SynthLane(val name: String, val low: Int) {
    val notes = CopyOnWriteArrayList<Note>()
    @Volatile var wave = 2 // 0 sine, 1 square, 2 saw, 3 pluck
    @Volatile var cutoff = 0.55f
    @Volatile var release = 0.25f
    @Volatile var vol = 0.6f
    @Volatile var pan = 0f
    @Volatile var mute = false
    @Volatile var solo = false
}

class SampleLane {
    val steps = BooleanArray(ST_MAXSTEPS)
    @Volatile var clip: ShortArray? = null
    @Volatile var title = ""
    @Volatile var path = ""
    @Volatile var startSec = 0f
    @Volatile var semis = 0
    @Volatile var vol = 0.8f
    @Volatile var pan = 0f
    @Volatile var mute = false
    @Volatile var solo = false
}

private class DVoice(val data: ShortArray, val gl: Float, val gr: Float) { var pos = 0 }
private class SVoice(val freq: Float, val wave: Int, val cutoff: Float, val relCoef: Float, val gl: Float, val gr: Float, var left: Int) {
    var ph = 0f
    var ph2 = 0.37f
    var env = 0f
    var rel = false
    var lp = 0f
    var age = 0
}
private class PVoice(val data: ShortArray, val rate: Float, val gl: Float, val gr: Float) { var pos = 0f }

/**
 * The sound of the beat studio. A project is a few drum lanes, two synth lanes and one sample lane that all play in
 * time over up to four bars of sixteenth steps. The same mixing code makes the sound for the speaker and for export.
 */
class StudioEngine {
    val drums = listOf(
        DrumLane("Kick", 0), DrumLane("Snare", 1), DrumLane("Clap", 2), DrumLane("Hat", 3),
        DrumLane("Open hat", 4), DrumLane("Tom", 5), DrumLane("Rim", 6), DrumLane("808", 7),
    )
    val synths = listOf(SynthLane("Lead", 60), SynthLane("Bass", 36))
    val sample = SampleLane()

    @Volatile var bpm = 100
    @Volatile var swing = 0f
    @Volatile var bars = 1
    @Volatile var master = 0.85f
    @Volatile var echoMix = 0f
    @Volatile var playing = false
    @Volatile var step = 0
    @Volatile var dirty = false

    private val kit: List<ShortArray> = DrumKit.build()
    private val lock = Any()
    private val dv = ArrayList<DVoice>()
    private val sv = ArrayList<SVoice>()
    private val pv = ArrayList<PVoice>()
    private var stepPos = 0
    private var curStep = 0
    private val dly = FloatArray(ST_RATE * 3 * 2)
    private var dlyAt = 0
    @Volatile private var running = false
    private var thread: Thread? = null
    private var track: AudioTrack? = null

    init {
        synths[1].wave = 1
        synths[1].cutoff = 0.35f
        // A starting beat so the screen is not silent and empty.
        for (i in 0 until 16 step 4) drums[0].steps[i] = true
        drums[1].steps[4] = true
        drums[1].steps[12] = true
        for (i in 0 until 16 step 2) drums[3].steps[i] = true
    }

    private fun stepSamples(s: Int): Int {
        val spp = ST_RATE * 60f / bpm / 4f
        val sw = swing * 0.33f
        return (if (s % 2 == 0) spp * (1f + sw) else spp * (1f - sw)).toInt().coerceAtLeast(64)
    }

    private fun audible(solo: Boolean, mute: Boolean, anySolo: Boolean) = !mute && (!anySolo || solo)

    private fun gains(vol: Float, pan: Float): FloatArray {
        val a = (pan.coerceIn(-1f, 1f) + 1f) * (PI.toFloat() / 4f)
        return floatArrayOf(vol * cos(a) * 1.41f, vol * sin(a) * 1.41f)
    }

    // -------------------------------------------------------------- control

    fun start() {
        if (thread != null) return
        val minBuf = AudioTrack.getMinBufferSize(ST_RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(ST_RATE).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
            .setBufferSizeInBytes(maxOf(minBuf, 512 * 4 * 3))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        track = t
        running = true
        t.play()
        thread = Thread({
            val buf = FloatArray(512 * 2)
            val out = ShortArray(512 * 2)
            while (running) {
                synchronized(lock) { render(buf, 512) }
                for (i in buf.indices) out[i] = toShort(buf[i])
                if (t.write(out, 0, out.size) < 0) break
            }
        }, "hwush-studio").also {
            it.priority = Thread.MAX_PRIORITY
            it.start()
        }
    }

    fun release() {
        running = false
        try { thread?.join(600) } catch (_: Exception) {}
        thread = null
        try { track?.stop() } catch (_: Exception) {}
        try { track?.release() } catch (_: Exception) {}
        track = null
    }

    fun play() {
        synchronized(lock) {
            stepPos = 0
            curStep = -1
            playing = true
            // Fire step 0 right away.
            stepPos = Int.MAX_VALUE / 2
        }
    }

    fun stop() {
        playing = false
        synchronized(lock) { step = 0 }
    }

    val totalSteps: Int get() = bars.coerceIn(1, 4) * 16

    fun audition(lane: Int) {
        val d = drums.getOrNull(lane) ?: return
        val g = gains(d.vol, d.pan)
        synchronized(lock) { dv.add(DVoice(kit[d.pad], g[0], g[1])) }
    }

    fun auditionNote(lane: Int, pitch: Int, steps: Int = 2) {
        val s = synths.getOrNull(lane) ?: return
        synchronized(lock) { addSynth(s, pitch, steps * stepSamples(0)) }
    }

    fun auditionSample() {
        val s = sample
        val c = s.clip ?: return
        val g = gains(s.vol, s.pan)
        synchronized(lock) { pv.add(PVoice(c, 2f.pow(s.semis / 12f), g[0], g[1])) }
    }

    fun clearAll() {
        for (d in drums) java.util.Arrays.fill(d.steps, false)
        for (s in synths) s.notes.clear()
        java.util.Arrays.fill(sample.steps, false)
        dirty = true
    }

    private fun addSynth(s: SynthLane, pitch: Int, samples: Int) {
        if (sv.size >= 24) sv.removeAt(0)
        val g = gains(s.vol, s.pan)
        val f = 440f * 2f.pow((pitch - 69) / 12f)
        val relCoef = exp(-1f / (ST_RATE * (0.02f + s.release * 0.9f) * 0.25f))
        sv.add(SVoice(f, s.wave, s.cutoff, relCoef, g[0] * 0.5f, g[1] * 0.5f, samples))
    }

    // -------------------------------------------------------------- mixing

    private fun fire(s: Int) {
        val anyDrumSolo = drums.any { it.solo } || synths.any { it.solo } || sample.solo
        for (d in drums) {
            if (d.steps[s] && audible(d.solo, d.mute, anyDrumSolo)) {
                val g = gains(d.vol, d.pan)
                if (dv.size >= 40) dv.removeAt(0)
                dv.add(DVoice(kit[d.pad], g[0], g[1]))
            }
        }
        for (l in synths) {
            if (!audible(l.solo, l.mute, anyDrumSolo)) continue
            for (n in l.notes) if (n.step == s) addSynth(l, n.pitch, n.len * stepSamples(s))
        }
        val sl = sample
        val clip = sl.clip
        if (clip != null && sl.steps[s] && audible(sl.solo, sl.mute, anyDrumSolo)) {
            val g = gains(sl.vol, sl.pan)
            if (pv.size >= 6) pv.removeAt(0)
            pv.add(PVoice(clip, 2f.pow(sl.semis / 12f), g[0], g[1]))
        }
    }

    /** Fills [buf] with [frames] stereo frames. Call with the lock held. */
    private fun render(buf: FloatArray, frames: Int) {
        val dlyLen = (ST_RATE * 60f / bpm / 4f * 3f).toInt().coerceIn(2000, ST_RATE * 3)
        val em = echoMix
        for (n in 0 until frames) {
            if (playing) {
                if (stepPos >= stepSamples(if (curStep < 0) 0 else curStep)) {
                    stepPos = 0
                    curStep = (curStep + 1) % totalSteps
                    step = curStep
                    fire(curStep)
                }
                stepPos++
            }
            var l = 0f
            var r = 0f
            var i = 0
            while (i < dv.size) {
                val v = dv[i]
                if (v.pos >= v.data.size) {
                    dv.removeAt(i)
                } else {
                    val s = v.data[v.pos++] / 32768f
                    l += s * v.gl
                    r += s * v.gr
                    i++
                }
            }
            i = 0
            while (i < pv.size) {
                val v = pv[i]
                val p = v.pos.toInt()
                if (p >= v.data.size - 1) {
                    pv.removeAt(i)
                } else {
                    val f = v.pos - p
                    val s = (v.data[p] + (v.data[p + 1] - v.data[p]) * f) / 32768f
                    l += s * v.gl
                    r += s * v.gr
                    v.pos += v.rate
                    i++
                }
            }
            i = 0
            while (i < sv.size) {
                val v = sv[i]
                val inc = v.freq / ST_RATE
                v.ph += inc
                if (v.ph >= 1f) v.ph -= 1f
                v.ph2 += inc * 1.005f
                if (v.ph2 >= 1f) v.ph2 -= 1f
                val o = (wf(v.wave, v.ph) + wf(v.wave, v.ph2)) * 0.5f
                val cut = if (v.wave == 3) 250f + v.cutoff * 7000f * exp(-v.age / (ST_RATE * 0.16f)) else 150f + v.cutoff * v.cutoff * 11000f
                val a = min(0.95f, 2f * PI.toFloat() * cut / ST_RATE)
                v.lp += a * (o - v.lp)
                if (!v.rel) {
                    v.env += (1f - v.env) * 0.012f
                    v.left--
                    if (v.left <= 0) v.rel = true
                } else {
                    v.env *= v.relCoef
                }
                v.age++
                val s = v.lp * v.env
                l += s * v.gl
                r += s * v.gr
                if (v.rel && v.env < 0.0008f) sv.removeAt(i) else i++
            }
            // Echo, a dotted eighth
            val rd = (dlyAt - dlyLen + dly.size / 2) % (dly.size / 2)
            val el = dly[rd * 2]
            val er = dly[rd * 2 + 1]
            dly[dlyAt * 2] = l * em + er * 0.42f
            dly[dlyAt * 2 + 1] = r * em + el * 0.42f
            dlyAt = (dlyAt + 1) % (dly.size / 2)
            l += el
            r += er
            buf[n * 2] = l * master
            buf[n * 2 + 1] = r * master
        }
    }

    private fun wf(w: Int, p: Float): Float = when (w) {
        0 -> sin(2f * PI.toFloat() * p)
        1 -> if (p < 0.5f) 0.8f else -0.8f
        else -> 2f * p - 1f
    }

    private fun toShort(v: Float): Short {
        val a = abs(v)
        val s = if (a < 0.8f) v else (if (v < 0f) -1f else 1f) * (0.8f + 0.2f * tanh((a - 0.8f) / 0.2f))
        return (s * 32767f).toInt().coerceIn(-32768, 32767).toShort()
    }

    // -------------------------------------------------------------- export

    /** Plays the pattern [loops] times into a wav file. Takes a few seconds; call off the main thread. */
    fun export(file: File, loops: Int): Boolean {
        try {
            synchronized(lock) {
                playing = false
                dv.clear(); sv.clear(); pv.clear()
                java.util.Arrays.fill(dly, 0f)
                val saveStep = step
                stepPos = Int.MAX_VALUE / 2
                curStep = -1
                playing = true
                var total = 0
                for (k in 0 until totalSteps * loops) total += stepSamples(k % totalSteps)
                total += ST_RATE * 2
                val buf = FloatArray(1024 * 2)
                val bytes = ByteArray(1024 * 4)
                java.io.BufferedOutputStream(java.io.FileOutputStream(file), 1 shl 16).use { out ->
                    out.write(ByteArray(44))
                    var left = total
                    var count = 0
                    while (left > 0) {
                        val n = min(1024, left)
                        render(buf, n)
                        for (j in 0 until n * 2) {
                            val s = toShort(buf[j]).toInt()
                            bytes[j * 2] = (s and 0xff).toByte()
                            bytes[j * 2 + 1] = ((s shr 8) and 0xff).toByte()
                        }
                        out.write(bytes, 0, n * 4)
                        left -= n
                        count += n
                        if (count >= total - ST_RATE * 2) playing = false
                    }
                }
                RandomAccessFile(file, "rw").use { raf ->
                    val data = total * 4
                    val h = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                    h.put("RIFF".toByteArray()).putInt(36 + data).put("WAVE".toByteArray())
                    h.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(2).putInt(ST_RATE).putInt(ST_RATE * 4).putShort(4).putShort(16)
                    h.put("data".toByteArray()).putInt(data)
                    raf.seek(0)
                    raf.write(h.array())
                }
                dv.clear(); sv.clear(); pv.clear()
                java.util.Arrays.fill(dly, 0f)
                curStep = 0
                stepPos = 0
                step = saveStep
                playing = false
            }
            return true
        } catch (_: Exception) {
            return false
        }
    }

    // -------------------------------------------------------------- saving

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("bpm", bpm); o.put("swing", swing.toDouble()); o.put("bars", bars)
        o.put("master", master.toDouble()); o.put("echo", echoMix.toDouble())
        val da = JSONArray()
        for (d in drums) {
            val j = JSONObject()
            val st = JSONArray(); for (i in 0 until ST_MAXSTEPS) st.put(if (d.steps[i]) 1 else 0)
            j.put("steps", st); j.put("vol", d.vol.toDouble()); j.put("pan", d.pan.toDouble()); j.put("mute", d.mute)
            da.put(j)
        }
        o.put("drums", da)
        val sa = JSONArray()
        for (s in synths) {
            val j = JSONObject()
            val ns = JSONArray()
            for (n in s.notes) ns.put(JSONArray().put(n.step).put(n.len).put(n.pitch))
            j.put("notes", ns); j.put("wave", s.wave); j.put("cutoff", s.cutoff.toDouble()); j.put("release", s.release.toDouble())
            j.put("vol", s.vol.toDouble()); j.put("pan", s.pan.toDouble()); j.put("mute", s.mute)
            sa.put(j)
        }
        o.put("synths", sa)
        val sm = JSONObject()
        val st = JSONArray(); for (i in 0 until ST_MAXSTEPS) st.put(if (sample.steps[i]) 1 else 0)
        sm.put("steps", st); sm.put("path", sample.path); sm.put("start", sample.startSec.toDouble()); sm.put("semis", sample.semis)
        sm.put("vol", sample.vol.toDouble()); sm.put("pan", sample.pan.toDouble()); sm.put("mute", sample.mute)
        o.put("sample", sm)
        return o
    }

    fun fromJson(o: JSONObject) {
        bpm = o.optInt("bpm", 100).coerceIn(50, 220)
        swing = o.optDouble("swing", 0.0).toFloat()
        bars = o.optInt("bars", 1).coerceIn(1, 4)
        master = o.optDouble("master", 0.85).toFloat()
        echoMix = o.optDouble("echo", 0.0).toFloat()
        val da = o.optJSONArray("drums")
        if (da != null) for (k in 0 until min(da.length(), drums.size)) {
            val j = da.getJSONObject(k); val d = drums[k]
            val st = j.optJSONArray("steps")
            for (i in 0 until ST_MAXSTEPS) d.steps[i] = st != null && i < st.length() && st.optInt(i) == 1
            d.vol = j.optDouble("vol", 0.85).toFloat(); d.pan = j.optDouble("pan", 0.0).toFloat(); d.mute = j.optBoolean("mute", false)
        }
        val sa = o.optJSONArray("synths")
        if (sa != null) for (k in 0 until min(sa.length(), synths.size)) {
            val j = sa.getJSONObject(k); val s = synths[k]
            s.notes.clear()
            val ns = j.optJSONArray("notes")
            if (ns != null) for (i in 0 until ns.length()) {
                val a = ns.getJSONArray(i)
                s.notes.add(Note(a.getInt(0), a.getInt(1), a.getInt(2)))
            }
            s.wave = j.optInt("wave", s.wave); s.cutoff = j.optDouble("cutoff", s.cutoff.toDouble()).toFloat()
            s.release = j.optDouble("release", s.release.toDouble()).toFloat()
            s.vol = j.optDouble("vol", s.vol.toDouble()).toFloat(); s.pan = j.optDouble("pan", 0.0).toFloat(); s.mute = j.optBoolean("mute", false)
        }
        val sm = o.optJSONObject("sample")
        if (sm != null) {
            val st = sm.optJSONArray("steps")
            for (i in 0 until ST_MAXSTEPS) sample.steps[i] = st != null && i < st.length() && st.optInt(i) == 1
            sample.path = sm.optString("path", ""); sample.startSec = sm.optDouble("start", 0.0).toFloat()
            sample.semis = sm.optInt("semis", 0); sample.vol = sm.optDouble("vol", 0.8).toFloat()
            sample.pan = sm.optDouble("pan", 0.0).toFloat(); sample.mute = sm.optBoolean("mute", false)
        }
    }
}
