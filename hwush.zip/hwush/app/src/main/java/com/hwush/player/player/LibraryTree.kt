@file:OptIn(UnstableApi::class)

package com.hwush.player.player

import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.LibraryResult
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaSession
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.hwush.player.HwushApp
import com.hwush.player.data.Track

/**
 * What a car or Bluetooth head unit sees when it browses Hwush: recent songs, favorites, playlists,
 * albums, artists and all songs. Choosing a song plays it through the normal player.
 */
class HwushLibraryCallback(private val app: HwushApp) : MediaLibraryService.MediaLibrarySession.Callback {

    private fun folder(id: String, title: String): MediaItem = MediaItem.Builder()
        .setMediaId(id)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setIsBrowsable(true)
                .setIsPlayable(false)
                .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_MIXED)
                .build(),
        )
        .build()

    private fun song(t: Track): MediaItem = MediaItem.Builder()
        .setMediaId(t.path)
        .setUri(t.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(t.title)
                .setArtist(t.artist)
                .setAlbumTitle(t.album)
                .setArtworkUri(PlayerHolder.artUri(t.path))
                .setIsBrowsable(false)
                .setIsPlayable(true)
                .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
                .build(),
        )
        .build()

    private fun children(parentId: String): List<MediaItem> {
        val lib = app.library
        val d = app.store.data.value
        val all = lib.tracks.value
        return when {
            parentId == ROOT -> listOf(
                folder("recent", "Recently played"),
                folder("fav", "Favorites"),
                folder("top", "Most played"),
                folder("pl", "Playlists"),
                folder("al", "Albums"),
                folder("ar", "Artists"),
                folder("songs", "All songs"),
            )
            parentId == "recent" -> all.filter { d.lastPlayed.containsKey(it.path) }
                .sortedByDescending { d.lastPlayed[it.path] ?: 0L }.take(60).map { song(it) }
            parentId == "fav" -> all.filter { it.path in d.favorites }.take(300).map { song(it) }
            parentId == "top" -> all.filter { (d.plays[it.path] ?: 0) > 0 }
                .sortedByDescending { d.plays[it.path] ?: 0 }.take(60).map { song(it) }
            parentId == "pl" -> d.playlists.map { folder("pl:${it.id}", it.name) }
            parentId.startsWith("pl:") -> {
                val id = parentId.removePrefix("pl:").toLongOrNull()
                d.playlists.firstOrNull { it.id == id }?.paths?.mapNotNull { lib.find(it) }?.take(500)?.map { song(it) } ?: emptyList()
            }
            parentId == "al" -> lib.albums.value.take(300).map { folder("al:${it.key}", it.name) }
            parentId.startsWith("al:") -> {
                val key = parentId.removePrefix("al:")
                lib.albums.value.firstOrNull { it.key == key }?.tracks?.map { song(it) } ?: emptyList()
            }
            parentId == "ar" -> lib.artists.value.take(300).map { folder("ar:${it.name}", it.name) }
            parentId.startsWith("ar:") -> {
                val name = parentId.removePrefix("ar:")
                lib.artists.value.firstOrNull { it.name == name }?.tracks?.take(300)?.map { song(it) } ?: emptyList()
            }
            parentId == "songs" -> all.sortedBy { it.title.lowercase() }.take(300).map { song(it) }
            else -> emptyList()
        }
    }

    override fun onGetLibraryRoot(
        session: MediaLibraryService.MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        params: MediaLibraryService.LibraryParams?,
    ): ListenableFuture<LibraryResult<MediaItem>> =
        Futures.immediateFuture(LibraryResult.ofItem(folder(ROOT, "Hwush"), params))

    override fun onGetChildren(
        session: MediaLibraryService.MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        parentId: String,
        page: Int,
        pageSize: Int,
        params: MediaLibraryService.LibraryParams?,
    ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> =
        Futures.immediateFuture(LibraryResult.ofItemList(ImmutableList.copyOf(children(parentId)), params))

    override fun onGetItem(
        session: MediaLibraryService.MediaLibrarySession,
        browser: MediaSession.ControllerInfo,
        mediaId: String,
    ): ListenableFuture<LibraryResult<MediaItem>> {
        val t = app.library.find(mediaId)
        val item = if (t != null) song(t) else folder(ROOT, "Hwush")
        return Futures.immediateFuture(LibraryResult.ofItem(item, null))
    }

    /** Turns the bare ids a car sends back into full songs the player can play. */
    override fun onAddMediaItems(
        mediaSession: MediaSession,
        controller: MediaSession.ControllerInfo,
        mediaItems: MutableList<MediaItem>,
    ): ListenableFuture<MutableList<MediaItem>> {
        val resolved = mediaItems.map { mi -> app.library.find(mi.mediaId)?.let { song(it) } ?: mi }.toMutableList()
        return Futures.immediateFuture(resolved)
    }

    companion object {
        const val ROOT = "root"
    }
}
