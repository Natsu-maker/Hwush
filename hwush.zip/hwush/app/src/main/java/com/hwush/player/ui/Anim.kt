package com.hwush.player.ui

import android.media.MediaPlayer
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Track
import com.hwush.player.hwush
import java.util.Calendar

// ------------------------------------------------------------------ small reusable animations

/** Cards pop in one after another: they grow from a little smaller, rise and fade in. */
@Composable
fun Modifier.popIn(index: Int): Modifier {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val delay = if (index in 0..7) index * 55 else 0
    val a by animateFloatAsState(
        if (shown) 1f else 0f,
        tween(420, delayMillis = delay, easing = FastOutSlowInEasing),
        label = "popIn",
    )
    return this.graphicsLayer {
        alpha = a
        val sc = 0.86f + 0.14f * a
        scaleX = sc
        scaleY = sc
        translationY = (1f - a) * 40f
    }
}

/** Soft rings spreading out from behind the play button while music plays. */
@Composable
fun PlayRing(active: Boolean, color: Color, size: Dp, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "ring")
    val p by t.animateFloat(
        0f,
        1f,
        infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart),
        label = "ringP",
    )
    val on by animateFloatAsState(if (active) 1f else 0f, tween(400), label = "ringOn")
    Canvas(modifier.requiredSize(size)) {
        if (on <= 0.01f) return@Canvas
        for (k in 0..1) {
            val q = (p + k * 0.5f) % 1f
            drawCircle(
                color = color.copy(alpha = (1f - q) * 0.35f * on),
                radius = this.size.minDimension / 2f * (0.55f + 0.45f * q) * 1.0f,
                style = Stroke(width = 2.dp.toPx()),
            )
        }
    }
}

/** A burst of rings, played once when [trigger] changes to true. */
@Composable
fun Modifier.burst(trigger: Boolean, color: Color): Modifier {
    val p = remember { Animatable(1f) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(trigger) {
        if (first) {
            first = false
        } else if (trigger) {
            p.snapTo(0f)
            p.animateTo(1f, tween(560, easing = FastOutSlowInEasing))
        }
    }
    return this.drawBehind {
        val v = p.value
        if (v < 1f) {
            drawCircle(color.copy(alpha = (1f - v) * 0.55f), radius = size.minDimension * (0.3f + 0.45f * v), style = Stroke(2.5.dp.toPx()))
            for (i in 0 until 6) {
                val a = Math.toRadians(i * 60.0 + 20.0)
                val d = size.minDimension * (0.25f + 0.5f * v)
                drawCircle(
                    color.copy(alpha = (1f - v) * 0.9f),
                    radius = 2.5.dp.toPx() * (1f - v),
                    center = Offset(center.x + (Math.cos(a) * d).toFloat(), center.y + (Math.sin(a) * d).toFloat()),
                )
            }
        }
    }
}

fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        h < 5 -> "Still up?"
        h < 12 -> "Good morning"
        h < 17 -> "Good afternoon"
        h < 22 -> "Good evening"
        else -> "Late night listening"
    }
}

// ------------------------------------------------------------------ hold a cover to hear a preview

class HoldPreview(private val app: com.hwush.player.HwushApp) {
    var active by mutableStateOf<String?>(null)
        private set
    private var mp: MediaPlayer? = null
    private var resume = false

    fun start(t: Track) {
        stop()
        active = t.path
        try {
            val p = app.player.player
            resume = p.isPlaying
            if (resume) p.pause()
            val m = MediaPlayer()
            mp = m
            m.setDataSource(app, t.uri)
            m.setAudioAttributes(
                android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build(),
            )
            m.setOnPreparedListener { x ->
                try {
                    if (x.duration > 40_000) x.seekTo((x.duration * 0.3f).toInt())
                    x.start()
                } catch (_: Exception) {
                }
            }
            m.prepareAsync()
        } catch (_: Exception) {
            stop()
        }
    }

    fun stop() {
        val had = active != null
        active = null
        try {
            mp?.release()
        } catch (_: Exception) {
        }
        mp = null
        if (had && resume) {
            resume = false
            app.player.player.play()
        }
    }
}

@Composable
fun rememberHoldPreview(): HoldPreview {
    val app = LocalContext.current.hwush
    val h = remember { HoldPreview(app) }
    DisposableEffect(Unit) { onDispose { h.stop() } }
    return h
}

/** A cover card for the home rows: pops in, presses down, and plays a preview while held. */
@Composable
fun HomeCard(t: Track, index: Int, preview: HoldPreview, playing: Boolean, onPlay: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val previewing = preview.active == t.path
    val lift by animateFloatAsState(
        if (previewing) 1.08f else 1f,
        spring(dampingRatio = 0.55f, stiffness = 350f),
        label = "lift",
    )
    var pressed by remember { mutableStateOf(false) }
    val press by animateFloatAsState(if (pressed && !previewing) 0.95f else 1f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "cardPress")
    val ringColor = MaterialTheme.colorScheme.primary
    Column(
        Modifier
            .width(120.dp)
            .popIn(index)
            .graphicsLayer {
                scaleX = lift * press
                scaleY = lift * press
            }
            .pointerInput(t.path) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                        preview.stop()
                    },
                    onTap = { onPlay() },
                    onLongPress = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        preview.start(t)
                    },
                )
            },
    ) {
        Box(
            Modifier.drawBehind {
                if (previewing || playing) {
                    drawRoundRect(
                        ringColor.copy(alpha = if (previewing) 0.9f else 0.55f),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(16.dp.toPx()),
                        style = Stroke(3.dp.toPx()),
                        topLeft = Offset(-3.dp.toPx(), -3.dp.toPx()),
                        size = androidx.compose.ui.geometry.Size(size.width + 6.dp.toPx(), size.height + 6.dp.toPx()),
                    )
                }
            },
        ) {
            Cover(t, Modifier.size(120.dp), 120.dp, RoundedCornerShape(14.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(
            if (previewing) "Preview…" else t.title,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (previewing) FontWeight.Bold else FontWeight.Normal,
        )
        Text(
            t.artist,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
