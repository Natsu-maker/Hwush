package com.hwush.player.ui

import android.graphics.Bitmap
import android.os.Build
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.hwush.player.HwushApp
import com.hwush.player.data.Track
import com.hwush.player.data.dominantColor
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.Alignment
import com.hwush.player.hwush

/** Heart that pops with a springy bounce when it is turned on. */
@Composable
fun AnimatedHeart(
    fav: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.primary,
    idleTint: Color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
) {
    val scale = remember { Animatable(1f) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(fav) {
        if (first) {
            first = false
        } else if (fav) {
            scale.snapTo(0.5f)
            scale.animateTo(1f, spring(dampingRatio = 0.3f, stiffness = 380f))
        } else {
            scale.snapTo(0.85f)
            scale.animateTo(1f, tween(160))
        }
    }
    val color by animateColorAsState(if (fav) tint else idleTint, tween(220), label = "heart")
    IconButton(onClick = onClick, modifier = modifier.burst(fav, tint)) {
        Icon(
            if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
            "Favorite",
            Modifier.graphicsLayer {
                scaleX = scale.value
                scaleY = scale.value
            },
            tint = color,
        )
    }
}

/** Play and pause icons that swap with a small zoom. */
@Composable
fun PlayPauseIcon(playing: Boolean, modifier: Modifier = Modifier) {
    AnimatedContent(
        targetState = playing,
        transitionSpec = {
            (fadeIn(animationSpec = tween(180)) + scaleIn(initialScale = 0.5f, animationSpec = tween(220))) togetherWith
                (fadeOut(animationSpec = tween(120)) + scaleOut(targetScale = 0.5f, animationSpec = tween(160)))
        },
        label = "playpause",
    ) { p ->
        Icon(if (p) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, if (p) "Pause" else "Play", modifier)
    }
}

/** List rows slide up and fade in, one after another. */
@Composable
fun Modifier.staggerIn(index: Int): Modifier {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val delay = if (index in 0..9) index * 30 else 0
    val a by animateFloatAsState(
        if (shown) 1f else 0f,
        tween(320, delayMillis = delay, easing = FastOutSlowInEasing),
        label = "stagger",
    )
    return this.graphicsLayer {
        alpha = a
        translationY = (1f - a) * 36f
    }
}

/** Shrinks a little while pressed, then springs back. */
@Composable
fun Modifier.pressScale(source: MutableInteractionSource): Modifier {
    val pressed by source.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.965f else 1f,
        spring(dampingRatio = 0.6f, stiffness = 500f),
        label = "press",
    )
    return this.graphicsLayer {
        scaleX = s
        scaleY = s
    }
}

/** A soft coloured glow that breathes while music plays. */
@Composable
fun PulsingGlow(color: Color, active: Boolean, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "glow")
    val pulse by t.animateFloat(
        initialValue = 0.28f,
        targetValue = 0.6f,
        animationSpec = infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "glowPulse",
    )
    val alpha by animateFloatAsState(if (active) pulse else 0.2f, tween(450), label = "glowAlpha")
    Box(modifier.background(Brush.radialGradient(listOf(color.copy(alpha = alpha), Color.Transparent))))
}

/** The main colour of the cover, eased from one song to the next. */
@Composable
fun rememberArtColor(track: Track?, fallback: Color): Color {
    val app = LocalContext.current.hwush
    val rev = app.coverRev.intValue
    val c by produceState<Int?>(null, track?.path, rev) {
        value = if (track == null) null else app.art.load(track, 96)?.let { dominantColor(it) }
    }
    val target = c?.let { Color(it) } ?: fallback
    val animated by animateColorAsState(target, tween(700), label = "artColor")
    return animated
}

/** The cover, blurred and dimmed, drawn behind the player. */
@Composable
fun BlurredBackdrop(track: Track?, modifier: Modifier = Modifier) {
    val app = LocalContext.current.hwush
    val rev = app.coverRev.intValue
    val bmp by produceState<Bitmap?>(null, track?.path, rev) {
        value = if (track == null) null else app.art.load(track, 160)?.let { b ->
            if (Build.VERSION.SDK_INT >= 31) b else Bitmap.createScaledBitmap(b, 24, 24, true)
        }
    }
    Crossfade(targetState = bmp, modifier = modifier, animationSpec = tween(800), label = "backdrop") { b ->
        if (b != null) {
            Image(
                b.asImageBitmap(),
                null,
                Modifier
                    .fillMaxSize()
                    .then(if (Build.VERSION.SDK_INT >= 31) Modifier.blur(44.dp) else Modifier),
                contentScale = ContentScale.Crop,
                alpha = 0.85f,
            )
        } else {
            Box(Modifier.fillMaxSize())
        }
    }
}

/** Bars that dance with the music. Needs the visualizer switched on in Settings. */
@Composable
fun VisualizerBars(app: HwushApp, color: Color, modifier: Modifier = Modifier) {
    val bands by app.visualizer.bands.collectAsState()
    Canvas(modifier) {
        val n = bands.size
        if (n == 0) return@Canvas
        val gap = 4.dp.toPx()
        val w = (size.width - gap * (n - 1)) / n
        for (i in 0 until n) {
            val v = bands[i].coerceIn(0f, 1f)
            val h = (v * size.height).coerceAtLeast(3.dp.toPx())
            drawRoundRect(
                color = color.copy(alpha = 0.5f + 0.5f * v),
                topLeft = Offset(i * (w + gap), size.height - h),
                size = Size(w, h),
                cornerRadius = CornerRadius(w / 2f, w / 2f),
            )
        }
    }
}


/** Frosted glass look: a faint tint with a bright edge. How strong it is comes from the glass slider in Settings. */
@Composable
fun Modifier.glass(shape: androidx.compose.ui.graphics.Shape = androidx.compose.foundation.shape.RoundedCornerShape(28.dp)): Modifier {
    val level by LocalContext.current.hwush.store.select { it.glassLevel }
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val k = level.coerceIn(0f, 1f)
    val top = (if (dark) 0.04f + 0.26f * k else 0.12f + 0.55f * k)
    val bottom = top * 0.35f
    val edge = 0.15f + 0.6f * k
    val sheen = androidx.compose.animation.core.rememberInfiniteTransition(label = "sheen")
    val x by sheen.animateFloat(
        initialValue = -0.6f,
        targetValue = 1.6f,
        animationSpec = infiniteRepeatable(tween(7000, easing = androidx.compose.animation.core.LinearEasing)),
        label = "sheenX",
    )
    return this
        .clip(shape)
        .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = top), Color.White.copy(alpha = bottom))))
        .drawWithContent {
            drawContent()
            val w = size.width
            drawRect(
                Brush.linearGradient(
                    listOf(Color.Transparent, Color.White.copy(alpha = 0.03f + 0.10f * k), Color.Transparent),
                    start = Offset(x * w - w * 0.3f, 0f),
                    end = Offset(x * w + w * 0.3f, size.height),
                ),
            )
        }
        .border(
            1.dp,
            Brush.linearGradient(listOf(Color.White.copy(alpha = edge), Color.White.copy(alpha = 0.04f), Color.White.copy(alpha = edge * 0.4f))),
            shape,
        )
}

/** The bottom of the cover mirrored under it and fading away, like a glossy surface. */
@Composable
fun CoverReflection(track: Track?, modifier: Modifier = Modifier) {
    androidx.compose.foundation.layout.BoxWithConstraints(modifier) {
        val h = maxWidth * 0.26f
        Box(Modifier.fillMaxWidth().height(h).clip(androidx.compose.foundation.shape.RoundedCornerShape(bottomStart = 26.dp, bottomEnd = 26.dp))) {
            Box(
                Modifier
                    .wrapContentHeight(Alignment.Top, unbounded = true)
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .graphicsLayer {
                        scaleY = -1f
                        compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.Offscreen
                    }
                    .drawWithContent {
                        drawContent()
                        drawRect(
                            Brush.verticalGradient(
                                0f to Color.Transparent,
                                0.72f to Color.Transparent,
                                1f to Color.Black.copy(alpha = 0.45f),
                            ),
                            blendMode = androidx.compose.ui.graphics.BlendMode.DstIn,
                        )
                    },
            ) {
                Cover(track, Modifier.fillMaxSize(), 160.dp, androidx.compose.foundation.shape.RoundedCornerShape(26.dp))
            }
        }
    }
}

/** Two slow soft blobs of the cover colour drifting behind the player. */
@Composable
fun AuroraBackground(color: Color, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "aurora")
    val p by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(16000, easing = androidx.compose.animation.core.LinearEasing),
            RepeatMode.Reverse,
        ),
        label = "auroraShift",
    )
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val c1 = Offset(w * (0.15f + 0.7f * p), h * 0.22f)
        val c2 = Offset(w * (0.85f - 0.7f * p), h * 0.7f)
        drawRect(Brush.radialGradient(listOf(color.copy(alpha = 0.32f), Color.Transparent), center = c1, radius = w * 0.9f))
        drawRect(Brush.radialGradient(listOf(color.copy(alpha = 0.24f), Color.Transparent), center = c2, radius = w * 0.8f))
    }
}
