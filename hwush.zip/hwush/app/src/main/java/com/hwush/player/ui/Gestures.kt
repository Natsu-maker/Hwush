package com.hwush.player.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import com.hwush.player.player.PlayerHolder
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Touch gestures for the big cover: swipe sideways to skip, up for favorite, down to close,
 * double tap the middle to play or pause and the edges to jump 10 seconds.
 * The cover follows the finger and springs back.
 */
@Composable
fun Modifier.coverGestures(holder: PlayerHolder, onFavorite: () -> Unit, onClose: (() -> Unit)?): Modifier {
    val scope = rememberCoroutineScope()
    val off = remember { Animatable(0f) }
    val favNow by rememberUpdatedState(onFavorite)
    val closeNow by rememberUpdatedState(onClose)
    return this
        .graphicsLayer {
            translationX = off.value
            rotationZ = off.value / 36f
        }
        .pointerInput(Unit) {
            detectTapGestures(onDoubleTap = { o ->
                val third = size.width / 3f
                when {
                    o.x < third -> holder.seekBy(-10_000L)
                    o.x > third * 2f -> holder.seekBy(10_000L)
                    else -> holder.togglePlay()
                }
            })
        }
        .pointerInput(Unit) {
            var dx = 0f
            var dy = 0f
            detectDragGestures(
                onDragStart = { dx = 0f; dy = 0f },
                onDrag = { change, amount ->
                    change.consume()
                    dx += amount.x
                    dy += amount.y
                    if (abs(dx) > abs(dy)) scope.launch { off.snapTo(dx * 0.6f) }
                },
                onDragEnd = {
                    if (abs(dx) > abs(dy)) {
                        if (dx < -150f) holder.next() else if (dx > 150f) holder.previous()
                    } else {
                        if (dy < -150f) favNow() else if (dy > 170f) closeNow?.invoke()
                    }
                    scope.launch { off.animateTo(0f, spring(dampingRatio = 0.55f, stiffness = 380f)) }
                },
                onDragCancel = { scope.launch { off.animateTo(0f) } },
            )
        }
}


/** Swipe the mini player left or right to skip. It follows the finger and springs back. */
@Composable
fun Modifier.swipeToSkip(holder: PlayerHolder): Modifier {
    val scope = rememberCoroutineScope()
    val off = remember { Animatable(0f) }
    return this
        .graphicsLayer { translationX = off.value }
        .pointerInput(Unit) {
            var dx = 0f
            detectHorizontalDragGestures(
                onDragStart = { dx = 0f },
                onHorizontalDrag = { change, amount ->
                    change.consume()
                    dx += amount
                    scope.launch { off.snapTo(dx * 0.5f) }
                },
                onDragEnd = {
                    if (dx < -160f) holder.next() else if (dx > 160f) holder.previous()
                    scope.launch { off.animateTo(0f, spring(dampingRatio = 0.6f, stiffness = 400f)) }
                },
                onDragCancel = { scope.launch { off.animateTo(0f) } },
            )
        }
}
