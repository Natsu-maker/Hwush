package com.hwush.player.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Track
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private sealed class HItem {
    data class Header(val label: String) : HItem()
    data class Play(val ts: Long, val track: Track) : HItem()
    data class Memory(val year: Int, val track: Track, val times: Int) : HItem()
}

/** Everything you played, newest first, with songs from this day in earlier years on top. */
@Composable
fun HistoryScreen(ui: UiController) {
    val app = ui.app
    val events by app.history.events.collectAsState()
    val tracks by app.library.tracks.collectAsState()
    val byPath = remember(tracks) { tracks.associateBy { it.path } }

    val rows = remember(events, byPath) {
        val out = ArrayList<HItem>()
        val now = System.currentTimeMillis()
        val dayFmt = SimpleDateFormat("yyyyMMdd", Locale.US)
        val todayKey = dayFmt.format(Date(now))
        val yesterdayKey = dayFmt.format(Date(now - 86_400_000L))
        val niceFmt = SimpleDateFormat("EEEE, d MMM yyyy", Locale.getDefault())

        // songs from this day in earlier years
        val cal = Calendar.getInstance()
        cal.timeInMillis = now
        val m = cal.get(Calendar.MONTH)
        val d = cal.get(Calendar.DAY_OF_MONTH)
        val y = cal.get(Calendar.YEAR)
        val mem = HashMap<Int, MutableList<String>>()
        for (e in events) {
            if (e.skipped) continue
            cal.timeInMillis = e.ts
            if (cal.get(Calendar.MONTH) == m && cal.get(Calendar.DAY_OF_MONTH) == d && cal.get(Calendar.YEAR) < y) {
                mem.getOrPut(cal.get(Calendar.YEAR)) { ArrayList() }.add(e.path)
            }
        }
        val memories = mem.entries.sortedByDescending { it.key }.mapNotNull { (year, paths) ->
            val top = paths.groupingBy { it }.eachCount().maxByOrNull { it.value } ?: return@mapNotNull null
            byPath[top.key]?.let { HItem.Memory(year, it, top.value) }
        }
        if (memories.isNotEmpty()) {
            out.add(HItem.Header("On this day"))
            out.addAll(memories)
        }

        var lastKey = ""
        var shown = 0
        for (i in events.indices.reversed()) {
            val e = events[i]
            if (e.skipped) continue
            val t = byPath[e.path] ?: continue
            val key = dayFmt.format(Date(e.ts))
            if (key != lastKey) {
                lastKey = key
                out.add(
                    HItem.Header(
                        when (key) {
                            todayKey -> "Today"
                            yesterdayKey -> "Yesterday"
                            else -> niceFmt.format(Date(e.ts))
                        },
                    ),
                )
            }
            out.add(HItem.Play(e.ts, t))
            if (++shown >= 800) break
        }
        out
    }
    val plays = remember(rows) { rows.filterIsInstance<HItem.Play>() }
    val timeFmt = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item(key = "header") {
            ListHeader("History", plural(plays.size, "play") + " remembered", ui, emptyList(), back = ui.stack.size > 1)
        }
        if (plays.isEmpty()) {
            item(key = "empty") {
                Text(
                    "Nothing here yet. Hwush started keeping a dated history in 1.7, so play a few songs and they will show up here.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp),
                )
            }
        } else {
            item(key = "play-all") {
                val todays = plays.take(30).map { it.track }
                Button(
                    onClick = { ui.play(todays, 0) },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                ) { Text("Play my latest ${todays.size}") }
            }
        }
        items(rows.size, key = { "h$it" }) { i ->
            when (val it = rows[i]) {
                is HItem.Header -> Text(
                    it.label,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 4.dp),
                )
                is HItem.Play -> HistoryRow(ui, it.track, timeFmt.format(Date(it.ts)))
                is HItem.Memory -> HistoryRow(ui, it.track, "${it.year}")
            }
        }
    }
}

@Composable
private fun HistoryRow(ui: UiController, t: Track, right: String) {
    Row(
        Modifier.fillMaxWidth().clickable { ui.play(listOf(t), 0) }.padding(start = 16.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Cover(t, Modifier.size(44.dp), 48.dp, RoundedCornerShape(8.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                t.artist,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Text(right, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        IconButton(onClick = { ui.menuTrack = t }) { Icon(Icons.Rounded.MoreVert, "More") }
    }
}
