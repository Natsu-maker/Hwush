package com.hwush.player.ui

import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Track
import kotlin.random.Random

private data class QuizQ(val answer: Track, val options: List<Track>)

private const val QUIZ_ROUNDS = 10

/** Guess the song from a short clip of your own library. */
@Composable
fun QuizScreen(ui: UiController) {
    val app = ui.app
    val ctx = LocalContext.current
    val tracks by app.library.tracks.collectAsState()
    val pool = remember(tracks) { tracks.filter { it.durationMs > 20_000L && it.title != "Untitled" } }

    var seed by remember { mutableIntStateOf(0) }
    var round by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    var picked by remember { mutableStateOf<Int?>(null) }
    var replay by remember { mutableIntStateOf(0) }

    val enough = pool.size >= 4
    val qs = remember(pool, seed) {
        if (!enough) {
            emptyList()
        } else {
            List(QUIZ_ROUNDS) {
                val ans = pool.random()
                val others = pool.filter { it.path != ans.path }.shuffled().take(3)
                QuizQ(ans, (others + ans).shuffled())
            }
        }
    }
    val done = round >= QUIZ_ROUNDS

    LaunchedEffect(Unit) { app.player.player.pause() }

    DisposableEffect(round, seed, replay, done, enough) {
        var mp: MediaPlayer? = null
        val h = Handler(Looper.getMainLooper())
        if (enough && !done && round < qs.size) {
            val t = qs[round].answer
            try {
                mp = MediaPlayer().apply {
                    setDataSource(ctx, t.uri)
                    setAudioAttributes(
                        android.media.AudioAttributes.Builder()
                            .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build(),
                    )
                    setOnPreparedListener { m ->
                        try {
                            val dur = m.duration
                            if (dur > 40_000) m.seekTo((dur * (0.15 + Random.nextDouble() * 0.45)).toInt())
                            m.start()
                            h.postDelayed({
                                try {
                                    m.pause()
                                } catch (_: Exception) {
                                }
                            }, 6_000L)
                        } catch (_: Exception) {
                        }
                    }
                    prepareAsync()
                }
            } catch (_: Exception) {
                try {
                    mp?.release()
                } catch (_: Exception) {
                }
                mp = null
            }
        }
        onDispose {
            h.removeCallbacksAndMessages(null)
            try {
                mp?.release()
            } catch (_: Exception) {
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        ListHeader(
            "Music quiz",
            if (!enough) null else if (done) "Finished" else "Question ${round + 1} of $QUIZ_ROUNDS · score $score",
            ui,
            emptyList(),
            back = ui.stack.size > 1,
        )
        if (!enough) {
            Text(
                "Add at least 4 songs to play the quiz.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(16.dp),
            )
        } else if (done) {
            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$score / $QUIZ_ROUNDS", style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold)
                Text(
                    when {
                        score >= 9 -> "You know your library by heart."
                        score >= 6 -> "Nicely done."
                        score >= 3 -> "Not bad. Some songs are still hiding."
                        else -> "Time to listen to more of your own music."
                    },
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 8.dp, bottom = 20.dp),
                )
                Button(onClick = {
                    seed++
                    round = 0
                    score = 0
                    picked = null
                }) { Text("Play again") }
            }
        } else {
            val q = qs[round]
            Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (picked == null) {
                    Text("Which song is this?", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    OutlinedButton(onClick = { replay++ }, modifier = Modifier.padding(top = 12.dp)) { Text("Hear it again") }
                } else {
                    Cover(q.answer, Modifier.size(140.dp), 140.dp, RoundedCornerShape(20.dp))
                    Text(
                        if (q.options[picked!!].path == q.answer.path) "Correct" else "It was ${q.answer.title}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 10.dp),
                    )
                }
            }
            q.options.forEachIndexed { i, t ->
                val isAnswer = t.path == q.answer.path
                val color = when {
                    picked == null -> MaterialTheme.colorScheme.surfaceContainerHigh
                    isAnswer -> Color(0xFF2E7D32).copy(alpha = 0.55f)
                    picked == i -> Color(0xFFC62828).copy(alpha = 0.55f)
                    else -> MaterialTheme.colorScheme.surfaceContainerHigh
                }
                Box(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(color)
                        .clickable(enabled = picked == null) {
                            picked = i
                            if (isAnswer) score++
                        }
                        .padding(16.dp),
                ) {
                    Column {
                        Text(t.title, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        Text(t.artist, style = MaterialTheme.typography.bodySmall, maxLines = 1)
                    }
                }
            }
            if (picked != null) {
                Button(
                    onClick = {
                        round++
                        picked = null
                    },
                    modifier = Modifier.padding(16.dp),
                ) { Text(if (round == QUIZ_ROUNDS - 1) "See my score" else "Next") }
            }
        }
    }
}
