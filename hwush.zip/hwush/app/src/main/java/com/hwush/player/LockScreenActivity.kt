package com.hwush.player

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.core.content.ContextCompat
import com.hwush.player.ui.HwushTheme
import com.hwush.player.ui.LockScreen
import com.hwush.player.ui.UiController

/** The full screen player that sits on top of the lock screen while music is playing. */
class LockScreenActivity : ComponentActivity() {
    private val unlocked = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        }
        enableEdgeToEdge()
        ContextCompat.registerReceiver(
            this,
            unlocked,
            IntentFilter(Intent.ACTION_USER_PRESENT),
            ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        val app = application as HwushApp
        setContent {
            val scope = rememberCoroutineScope()
            val ui = remember { UiController(app, scope) }
            HwushTheme(app) {
                LockScreen(ui, onAddToPlaylist = { unlockThenAddToPlaylist() }, onClose = { finish() })
            }
        }
    }

    private fun unlockThenAddToPlaylist() {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        km.requestDismissKeyguard(
            this,
            object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    startActivity(
                        Intent(this@LockScreenActivity, MainActivity::class.java)
                            .setAction(MainActivity.ACTION_ADD_PLAYLIST)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                    finish()
                }
            },
        )
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(unlocked)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }
}
