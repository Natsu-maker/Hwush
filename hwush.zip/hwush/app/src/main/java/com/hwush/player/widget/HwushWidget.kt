package com.hwush.player.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.hwush.player.HwushApp
import com.hwush.player.MainActivity
import com.hwush.player.R
import java.util.concurrent.Executors

/** Home screen widget with cover, title and previous / play / next. */
open class HwushWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        update(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        val player = (context.applicationContext as HwushApp).player
        when (intent.action) {
            ACT_PLAY -> player.togglePlay()
            ACT_NEXT -> player.next()
            ACT_PREV -> player.previous()
            else -> super.onReceive(context, intent)
        }
    }

    companion object {
        const val ACT_PLAY = "com.hwush.player.WIDGET_PLAY"
        const val ACT_NEXT = "com.hwush.player.WIDGET_NEXT"
        const val ACT_PREV = "com.hwush.player.WIDGET_PREV"

        private val exec = Executors.newSingleThreadExecutor()

        private fun action(ctx: Context, action: String, code: Int): PendingIntent = PendingIntent.getBroadcast(
            ctx,
            code,
            Intent(ctx, HwushWidget::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

        /** Call on the main thread. Reads the player state, then draws on a background thread. */
        fun update(ctx: Context) {
            val app = ctx.applicationContext as HwushApp
            val mgr = AppWidgetManager.getInstance(app)
            val barIds = mgr.getAppWidgetIds(ComponentName(app, HwushWidget::class.java))
            val bigIds = mgr.getAppWidgetIds(ComponentName(app, HwushWidgetBig::class.java))
            if (barIds.isEmpty() && bigIds.isEmpty()) return
            val ui = app.player.ui.value
            val track = ui.path?.let { app.library.find(it) }
            val playing = ui.isPlaying
            exec.execute {
                for ((ids, layout, px) in listOf(Triple(barIds, R.layout.widget, 192), Triple(bigIds, R.layout.widget_big, 400))) {
                    if (ids.isEmpty()) continue
                    try {
                        val rv = RemoteViews(app.packageName, layout)
                        rv.setTextViewText(R.id.w_title, track?.title ?: "Hwush")
                        rv.setTextViewText(R.id.w_artist, track?.artist ?: "Tap to open")
                        rv.setImageViewResource(R.id.w_play, if (playing) R.drawable.ic_pause else R.drawable.ic_play)
                        val bmp = track?.let { app.art.loadBlocking(it, px) }
                        if (bmp != null) rv.setImageViewBitmap(R.id.w_art, bmp)
                        else rv.setImageViewResource(R.id.w_art, R.drawable.ic_launcher_foreground)
                        rv.setOnClickPendingIntent(R.id.w_prev, action(app, ACT_PREV, 1))
                        rv.setOnClickPendingIntent(R.id.w_play, action(app, ACT_PLAY, 2))
                        rv.setOnClickPendingIntent(R.id.w_next, action(app, ACT_NEXT, 3))
                        rv.setOnClickPendingIntent(
                            R.id.w_root,
                            PendingIntent.getActivity(
                                app,
                                4,
                                Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
                            ),
                        )
                        mgr.updateAppWidget(ids, rv)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }
}

/** The large square version of the widget. It shares everything with the bar version. */
class HwushWidgetBig : HwushWidget()
