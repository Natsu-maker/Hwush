package com.hwush.player.ui

import android.content.res.Configuration
import android.graphics.Bitmap
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.FastForward
import androidx.compose.material.icons.rounded.FastRewind
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Full screen player shown over the lock screen: clock, cover as backdrop, seek bar and controls. */
@Composable
fun LockScreen(ui: UiController, onAddToPlaylist: () -> Unit, onClose: () -> Unit) {
    val app = ui.app
    val holder = app.player
    val pui by app.player.ui.collectAsState()
    val track = pui.path?.let { app.library.find(it) }
    val fav by app.store.select(pui.path) { d -> pui.path?.let { it in d.favorites } ?: false }
    val bmp by produceState<Bitmap?>(null, track?.path) {
        value = if (track == null) null else app.art.load(track, 640)
    }
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(1000L)
        }
    }
    val portrait = LocalConfiguration.current.orientation == Configuration.ORIENTATION_PORTRAIT
    val timeText = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(now)).lowercase()
    val dateText = SimpleDateFormat("MMM d, EEE", Locale.getDefault()).format(Date(now))

    CompositionLocalProvider(LocalContentColor provides Color.White) {
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            val b = bmp
            if (b != null) {
                Image(
                    b.asImageBitmap(),
                    null,
                    Modifier
                        .fillMaxSize()
                        .then(if (Build.VERSION.SDK_INT >= 31) Modifier.blur(36.dp) else Modifier),
                    contentScale = ContentScale.Crop,
                    alpha = 0.6f,
                )
            }
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(Color(0x55000000), Color(0xCC000000))),
                ),
            )
            Column(
                Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(timeText, fontSize = 48.sp, fontWeight = FontWeight.Medium)
                Text(dateText, fontSize = 15.sp, color = Color(0xCCFFFFFF))
                Spacer(Modifier.weight(1f))
                if (portrait) {
                    Cover(track, Modifier.size(240.dp), 240.dp, RoundedCornerShape(20.dp))
                    Spacer(Modifier.height(20.dp))
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { holder.seekBy(-10_000L) }) { Icon(Icons.Rounded.FastRewind, "Back 10 seconds") }
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            track?.title ?: "Nothing playing",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            track?.artist ?: "",
                            fontSize = 16.sp,
                            color = Color(0xE6FFFFFF),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            track?.album ?: "",
                            fontSize = 14.sp,
                            color = Color(0xB3FFFFFF),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    IconButton(onClick = { holder.seekBy(10_000L) }) { Icon(Icons.Rounded.FastForward, "Forward 10 seconds") }
                }
                SeekBar(ui, pui)
                Row(
                    Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    AnimatedHeart(fav, onClick = { pui.path?.let { app.store.toggleFavorite(it) } })
                    IconButton(onClick = { holder.previous() }, Modifier.size(52.dp)) {
                        Icon(Icons.Rounded.SkipPrevious, "Previous", Modifier.size(34.dp))
                    }
                    FilledIconButton(onClick = { holder.togglePlay() }, Modifier.size(72.dp)) {
                        PlayPauseIcon(pui.isPlaying, Modifier.size(40.dp))
                    }
                    IconButton(onClick = { holder.next() }, Modifier.size(52.dp)) {
                        Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(34.dp))
                    }
                    IconButton(onClick = onAddToPlaylist) { Icon(Icons.Rounded.PlaylistAdd, "Add to playlist") }
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    IconButton(onClick = onClose) { Icon(Icons.Rounded.Lock, "Hide this screen") }
                }
            }
        }
    }
}
