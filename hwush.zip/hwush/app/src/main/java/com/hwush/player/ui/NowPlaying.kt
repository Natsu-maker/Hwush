@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Bookmarks
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.unit.sp
import androidx.compose.animation.togetherWith
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.Lyrics
import com.hwush.player.data.Track
import com.hwush.player.player.PlayerUi
import kotlinx.coroutines.delay
import kotlin.math.max

fun fmtSpeed(v: Float): String = "%.2f×".format(v).replace(Regex("0+×$"), "×").replace(".×", "×")

// ---------------------------------------------------------------- mini player (phone)

@Composable
fun MiniPlayer(ui: UiController) {
    val app = ui.app
    val holder = app.player
    val pui by holder.ui.collectAsState()
    val track = pui.path?.let { app.library.find(it) }
    if (track != null) {
        val pos by produceState(0L, pui.path, pui.isPlaying) {
            while (true) {
                value = holder.position()
                delay(if (pui.isPlaying) 500L else 1500L)
            }
        }
        val dur = max(1L, holder.duration())
        Surface(
            onClick = { ui.nowPlayingOpen = true },
            modifier = Modifier.swipeToSkip(holder),
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
        ) {
            Column {
                LinearProgressIndicator(
                    progress = { (pos.toFloat() / dur).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(2.dp),
                )
                Row(
                    Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Cover(track, Modifier.size(44.dp), 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(track.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                        Text(
                            track.artist,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { holder.togglePlay() }) {
                        PlayPauseIcon(pui.isPlaying)
                    }
                    IconButton(onClick = { holder.next() }) { Icon(Icons.Rounded.SkipNext, "Next") }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- player pane (phone full screen and tablet side panel)

@Composable
fun PlayerPane(ui: UiController, modifier: Modifier = Modifier, onClose: (() -> Unit)? = null) {
    val app = ui.app
    val pui by app.player.ui.collectAsState()
    val track = pui.path?.let { app.library.find(it) }
    var tab by remember { mutableIntStateOf(0) }
    val blur by app.store.select { it.blurBackdrop }
    val bgStyle by app.store.select { it.bgStyle }
    val glassLevel by app.store.select { it.glassLevel }
    val artColor = rememberArtColor(track, MaterialTheme.colorScheme.primary)
    val bg = MaterialTheme.colorScheme.background
    Box(modifier.fillMaxSize()) {
    if (blur) {
        PlayerBackdrop(track, artColor, pui.isPlaying, bgStyle, Modifier.fillMaxSize())
        Box(
            Modifier.fillMaxSize().background(
                androidx.compose.ui.graphics.Brush.verticalGradient(
                    listOf(
                        bg.copy(alpha = 0.18f),
                        bg.copy(alpha = 0.42f - 0.2f * glassLevel),
                        bg.copy(alpha = 0.80f - 0.2f * glassLevel),
                    ),
                ),
            ),
        )
    } else {
        AuroraBackground(artColor, Modifier.fillMaxSize())
    }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            if (onClose != null) {
                IconButton(onClick = onClose) { Icon(Icons.Rounded.KeyboardArrowDown, "Close") }
            }
            Spacer(Modifier.weight(1f))
            listOf("Player", "Lyrics", "Up next").forEachIndexed { i, label ->
                FilterChip(
                    selected = tab == i,
                    onClick = { tab = i },
                    label = { Text(label) },
                    modifier = Modifier.padding(horizontal = 3.dp),
                )
            }
            Spacer(Modifier.weight(1f))
            if (onClose != null) Spacer(Modifier.width(48.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            androidx.compose.animation.AnimatedContent(
                targetState = tab,
                transitionSpec = {
                    androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(220)) togetherWith
                        androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(140))
                },
                label = "playerTab",
            ) { t ->
                when (t) {
                    0 -> NowTab(ui, pui, track, onClose)
                    1 -> LyricsTab(ui, pui, track)
                    else -> QueueTab(ui, pui)
                }
            }
        }
    }
    }
}

@Composable
private fun NowTab(ui: UiController, pui: PlayerUi, track: Track?, onClose: (() -> Unit)? = null) {
    val app = ui.app
    val holder = app.player
    val fav by app.store.select(track?.path) { track != null && track.path in it.favorites }
    val primary = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        val coverScale by androidx.compose.animation.core.animateFloatAsState(
            if (pui.isPlaying) 1f else 0.88f,
            androidx.compose.animation.core.spring(dampingRatio = 0.65f, stiffness = 200f),
            label = "coverScale",
        )
        val artColor = rememberArtColor(track, primary)
        val coverStyle by app.store.select { it.coverStyle }
        val disc = coverStyle == 1
        val angle = remember { androidx.compose.animation.core.Animatable(0f) }
        androidx.compose.runtime.LaunchedEffect(pui.isPlaying, disc) {
            if (disc && pui.isPlaying) {
                while (true) {
                    angle.animateTo(
                        angle.value + 360f,
                        androidx.compose.animation.core.tween(9000, easing = androidx.compose.animation.core.LinearEasing),
                    )
                }
            }
        }
        val bgColor = MaterialTheme.colorScheme.background
        Column(Modifier.fillMaxWidth(0.86f).widthIn(max = 380.dp)) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .coverGestures(holder, { track?.let { app.store.toggleFavorite(it.path) } }, onClose),
            contentAlignment = Alignment.Center,
        ) {
            PulsingGlow(artColor, pui.isPlaying, Modifier.fillMaxSize().graphicsLayer { scaleX = 1.25f; scaleY = 1.25f })
            // Next slides the cover in from the right, previous from the left.
            var lastIdx by remember { androidx.compose.runtime.mutableIntStateOf(pui.index) }
            val dir = if (pui.index >= lastIdx) 1 else -1
            androidx.compose.runtime.SideEffect { lastIdx = pui.index }
            androidx.compose.animation.AnimatedContent(
                targetState = track,
                transitionSpec = {
                    (androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(320)) +
                        androidx.compose.animation.slideInHorizontally(androidx.compose.animation.core.tween(380)) { it * dir / 3 } +
                        androidx.compose.animation.scaleIn(initialScale = 0.88f, animationSpec = androidx.compose.animation.core.tween(380)))
                        .togetherWith(
                            androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(200)) +
                                androidx.compose.animation.slideOutHorizontally(androidx.compose.animation.core.tween(300)) { -it * dir / 4 },
                        )
                },
                modifier = Modifier.fillMaxSize().graphicsLayer {
                    scaleX = coverScale
                    scaleY = coverScale
                    if (disc) rotationZ = angle.value % 360f
                },
                label = "coverSwap",
            ) { tr ->
                Cover(tr, Modifier.fillMaxSize(), 380.dp, if (disc) androidx.compose.foundation.shape.CircleShape else RoundedCornerShape(26.dp))
            }
            if (disc) {
                Box(
                    Modifier
                        .size(34.dp)
                        .background(bgColor, androidx.compose.foundation.shape.CircleShape),
                )
            }
        }
        if (disc) {
            Spacer(Modifier.height(8.dp))
        } else {
            CoverReflection(track, Modifier.fillMaxWidth().graphicsLayer { scaleX = coverScale; alpha = if (pui.isPlaying) 1f else 0.6f })
        }
        }
        Spacer(Modifier.height(12.dp))
        androidx.compose.animation.AnimatedContent(
            modifier = Modifier.staggerIn(1),
            targetState = track?.title ?: "Nothing playing",
            transitionSpec = {
                (androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(260)) +
                    androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(260)) { it / 3 })
                    .togetherWith(androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(120)))
            },
            label = "titleSwap",
        ) { title ->
            Text(
                title,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Text(
            if (track == null) "Pick a song from your library" else "${track.artist} · ${track.album}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        Spacer(Modifier.height(8.dp))
        Column(Modifier.fillMaxWidth().staggerIn(2).glass().padding(horizontal = 12.dp, vertical = 8.dp)) {
        SeekBar(ui, pui)
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { holder.toggleShuffle() }) {
                Icon(Icons.Rounded.Shuffle, "Shuffle", tint = if (pui.shuffle) primary else dim)
            }
            IconButton(onClick = { holder.previous() }, Modifier.size(56.dp)) {
                Icon(Icons.Rounded.SkipPrevious, "Previous", Modifier.size(34.dp))
            }
            Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
                PlayRing(pui.isPlaying, primary, 116.dp)
                FilledIconButton(onClick = { holder.togglePlay() }, Modifier.size(72.dp)) {
                    PlayPauseIcon(pui.isPlaying, Modifier.size(40.dp))
                }
            }
            IconButton(onClick = { holder.next() }, Modifier.size(56.dp)) {
                Icon(Icons.Rounded.SkipNext, "Next", Modifier.size(34.dp))
            }
            IconButton(onClick = { holder.cycleRepeat() }) {
                Icon(
                    if (pui.repeat == 2) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    "Repeat",
                    tint = if (pui.repeat != 0) primary else dim,
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AnimatedHeart(fav, onClick = { track?.let { app.store.toggleFavorite(it.path) } })
            val speedText = if (pui.speed != 1f || pui.pitch != 1f) "Sound · ${fmtSpeed(pui.speed)}" else "Sound"
            AssistChip(onClick = { ui.soundOpen = true }, label = { Text(speedText) })
            if (pui.speed != 1f || pui.pitch != 1f) {
                AssistChip(onClick = { holder.resetSpeedPitch() }, label = { Text("Reset") })
            }
            val sleepOn = pui.sleepEndsAt > 0L || pui.sleepAfterSong
            AssistChip(onClick = { ui.sleepOpen = true }, label = { Text(if (sleepOn) "Sleep on" else "Sleep") })
            IconButton(onClick = { track?.let { ui.menuTrack = it } }) { Icon(Icons.Rounded.MoreVert, "More") }
        }
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AssistChip(onClick = { holder.setLoopA() }, label = { Text(if (pui.loopA >= 0L) "A ${fmtTime(pui.loopA)}" else "Set A") })
            AssistChip(onClick = { holder.setLoopB() }, label = { Text(if (pui.loopB >= 0L) "B ${fmtTime(pui.loopB)}" else "Set B") })
            if (pui.loopA >= 0L || pui.loopB >= 0L) {
                AssistChip(onClick = { holder.clearLoop() }, label = { Text("Clear") })
            }
            IconButton(onClick = { ui.bookmarksOpen = true }) { Icon(Icons.Rounded.Bookmarks, "Bookmarks") }
        }
        val ctx = androidx.compose.ui.platform.LocalContext.current
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AssistChip(onClick = { ui.carMode = true }, label = { Text("Car mode") })
            AssistChip(onClick = { track?.let { shareNowPlaying(ctx, it) } }, label = { Text("Share") })
        }
        }
        val viz by app.store.select { it.visualizer }
        if (viz && app.visualizer.hasPermission()) {
            Spacer(Modifier.height(12.dp))
            VisualizerBars(app, primary, Modifier.fillMaxWidth().height(56.dp))
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun SeekBar(ui: UiController, pui: PlayerUi) {
    val holder = ui.app.player
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val pos by produceState(0L, pui.path, pui.isPlaying) {
        while (true) {
            value = holder.position()
            delay(if (pui.isPlaying) 250L else 700L)
        }
    }
    val dur = max(1L, holder.duration())
    val shown = if (dragging) dragValue else pos.toFloat().coerceIn(0f, dur.toFloat())
    Column(Modifier.fillMaxWidth()) {
        Slider(
            value = shown,
            onValueChange = { dragging = true; dragValue = it },
            onValueChangeFinished = { holder.seekTo(dragValue.toLong()); dragging = false },
            valueRange = 0f..dur.toFloat(),
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp)) {
            Text(fmtTime(shown.toLong()), style = MaterialTheme.typography.labelMedium, fontFamily = FontFamily.Monospace)
            Spacer(Modifier.weight(1f))
            Text(fmtTime(dur), style = MaterialTheme.typography.labelMedium, fontFamily = FontFamily.Monospace)
        }
    }
}

// ---------------------------------------------------------------- lyrics

@Composable
private fun LyricsTab(ui: UiController, pui: PlayerUi, track: Track?) {
    val app = ui.app
    val holder = app.player
    val tree by app.store.select { it.lyricsTree }
    val chosen by app.store.select(track?.path) { d -> track?.let { d.songLyrics[it.path] } }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var editing by remember { mutableStateOf(false) }
    val rev = app.lyricsRev.intValue
    if (editing && track != null) LyricsEditor(ui, track) { editing = false }
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null && track != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {
            }
            app.store.setSongLyrics(track.path, uri.toString())
        }
    }
    var lyrics by remember(track?.path) { mutableStateOf<Lyrics?>(null) }
    var loading by remember(track?.path) { mutableStateOf(true) }
    LaunchedEffect(track?.path, tree, chosen, rev) {
        loading = true
        lyrics = if (track == null) null else app.lyrics.find(track)
        loading = false
    }
    if (track == null) {
        EmptyState("Nothing playing", "Start a song to see its lyrics.")
        return
    }
    val l = lyrics
    if (l == null) {
        EmptyState(
            title = if (loading) "Looking for lyrics" else "No lyrics found",
            body = if (loading) "Checking next to the song and in your lyrics folder." else
                "Put a .lrc file with the same name next to the song, or pick a lyrics folder in Settings.",
            action = if (loading) null else ({
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Button(onClick = { editing = true }) { Text("Write lyrics") }
                    TextButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text("Choose .lrc file for this song") }
                    TextButton(onClick = { ui.nowPlayingOpen = false; ui.open(Dest(Kind.SETTINGS)) }) { Text("Pick a lyrics folder instead") }
                }
            }),
        )
        return
    }
    val pos by produceState(0L, pui.path, pui.isPlaying) {
        while (true) {
            value = holder.position()
            delay(if (pui.isPlaying) 50L else 600L)
        }
    }
    var active = -1
    if (l.synced) {
        for (k in l.lines.indices) {
            if (l.lines[k].timeMs <= pos + 120L) active = k else break
        }
    }
    val state = rememberLazyListState()
    LaunchedEffect(active) {
        if (active >= 0) {
            // The line being sung rests about a third of the way down, with the next lines below it.
            val top = state.layoutInfo.viewportSize.height / 3
            state.animateScrollToItem(active + 1, scrollOffset = -top)
        }
    }
    val bright = MaterialTheme.colorScheme.onSurface
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.34f)
    androidx.compose.foundation.lazy.LazyColumn(
        Modifier
            .fillMaxSize()
            .graphicsLayer { compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                drawRect(
                    androidx.compose.ui.graphics.Brush.verticalGradient(
                        0f to Color.Transparent,
                        0.06f to Color.Black,
                        0.86f to Color.Black,
                        1f to Color.Transparent,
                    ),
                    blendMode = androidx.compose.ui.graphics.BlendMode.DstIn,
                )
            },
        state = state,
        contentPadding = PaddingValues(start = 26.dp, end = 26.dp, top = 8.dp, bottom = 260.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { ui.lyricCard = track }) { Text("Picture") }
                TextButton(onClick = { editing = true }) { Text("Edit") }
                TextButton(onClick = { picker.launch(arrayOf("*/*")) }) { Text(if (chosen != null) "Change file" else "Use file") }
                if (chosen != null) TextButton(onClick = { app.store.setSongLyrics(track.path, null) }) { Text("Remove") }
            }
        }
        itemsIndexed(l.lines) { i, line ->
            val current = i == active
            val distance = if (active < 0 || !l.synced) 0 else kotlin.math.abs(i - active)
            val scale by androidx.compose.animation.core.animateFloatAsState(
                if (current || !l.synced) 1f else 0.9f,
                androidx.compose.animation.core.spring(dampingRatio = 0.72f, stiffness = 260f),
                label = "lyricScale",
            )
            val blurRadius by androidx.compose.animation.core.animateDpAsState(
                if (!l.synced || current) 0.dp else (distance.coerceAtMost(4) * 1.4f).dp,
                androidx.compose.animation.core.tween(380),
                label = "lyricBlur",
            )
            val fade by androidx.compose.animation.core.animateFloatAsState(
                if (!l.synced || current) 1f else (0.62f - 0.1f * distance.coerceAtMost(3)),
                androidx.compose.animation.core.tween(380),
                label = "lyricFade",
            )
            val next = l.lines.getOrNull(i + 1)?.timeMs ?: (line.timeMs + 4000L)
            val f = if (current) ((pos - line.timeMs).toFloat() / (next - line.timeMs).coerceAtLeast(1L)).coerceIn(0f, 1f) else 0f
            val rowMod = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
                    alpha = fade
                }
                .then(if (blurRadius > 0.dp) Modifier.blur(blurRadius) else Modifier)
                .then(if (l.synced) Modifier.clickable(
                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                    indication = null,
                ) { holder.seekTo(line.timeMs) } else Modifier)
                .padding(vertical = 9.dp)
            if (line.text.isBlank()) {
                Box(rowMod) { LyricDots(if (current) f else 0f, if (current) bright else dim) }
            } else {
                val base = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    lineHeight = 36.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Start,
                )
                val style = when {
                    !l.synced -> base.copy(color = bright, fontWeight = FontWeight.SemiBold)
                    current -> base.copy(
                        brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                            0f to bright,
                            f to bright,
                            (f + 0.06f).coerceAtMost(1f) to dim.copy(alpha = 0.55f),
                            1f to dim.copy(alpha = 0.55f),
                        ),
                    )
                    else -> base.copy(color = bright)
                }
                Text(line.text, style = style, modifier = rowMod)
            }
        }
    }
}

/** Three dots that fill in one by one during a gap in the singing. */
@Composable
private fun LyricDots(progress: Float, color: Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.padding(vertical = 8.dp)) {
        repeat(3) { i ->
            val p = (progress * 3f - i).coerceIn(0f, 1f)
            Box(
                Modifier
                    .size(13.dp)
                    .graphicsLayer {
                        val sc = 0.7f + 0.45f * p
                        scaleX = sc
                        scaleY = sc
                        alpha = 0.3f + 0.7f * p
                    }
                    .background(color, androidx.compose.foundation.shape.CircleShape),
            )
        }
    }
}

// ---------------------------------------------------------------- queue

@Composable
private fun QueueTab(ui: UiController, pui: PlayerUi) {
    val app = ui.app
    val holder = app.player
    val paths = pui.queue
    if (paths.isEmpty()) {
        EmptyState("Queue is empty", "Play a song, or add songs with Play next and Add to queue.")
        return
    }
    val state = rememberLazyListState()
    LaunchedEffect(Unit) { state.scrollToItem((pui.index - 1).coerceAtLeast(0)) }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "${plural(paths.size, "song")} in queue",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.weight(1f))
            TextButton(onClick = {
                val name = "Queue " + java.text.SimpleDateFormat("d MMM", java.util.Locale.getDefault()).format(java.util.Date())
                app.store.createPlaylist(name, paths.distinct())
                ui.say("Saved as \"$name\"")
            }) { Text("Save") }
            TextButton(onClick = {
                val removed = paths.drop(pui.index + 1).mapNotNull { app.library.find(it) }
                holder.clearUpcoming()
                if (removed.isNotEmpty()) ui.sayAction("Cleared ${plural(removed.size, "song")}", "Undo") { holder.enqueue(removed) }
            }) { Text("Clear upcoming") }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = state) {
            itemsIndexed(paths, key = { i, p -> "$i$p" }) { i, path ->
                val t = app.library.find(path)
                val current = i == pui.index
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { holder.skipTo(i) }
                        .padding(start = 16.dp, end = 0.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Cover(t, Modifier.size(40.dp), 48.dp, RoundedCornerShape(8.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            t?.title ?: lastSegment(path),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            fontWeight = if (current) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (current) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        )
                        Text(
                            t?.artist ?: "",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    IconButton(onClick = { holder.moveInQueue(i, i - 1) }, enabled = i > 0, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Rounded.KeyboardArrowUp, "Move up")
                    }
                    IconButton(onClick = { holder.moveInQueue(i, i + 1) }, enabled = i < paths.lastIndex, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Rounded.KeyboardArrowDown, "Move down")
                    }
                    IconButton(onClick = { holder.removeAt(i) }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Rounded.Close, "Remove")
                    }
                }
            }
        }
    }
}
