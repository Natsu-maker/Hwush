package com.hwush.player.ui

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.hwush.player.data.TagOverride
import com.hwush.player.data.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private data class FixRename(val track: Track, val newPath: String)

private val fixBad = Regex("[\\\\/:*?\"<>|]")
private val fixDigits = Regex("\\d{6,}")
private val fixLead = Regex("^\\d{1,3}[ .\\-]+")

private fun fixClean(s: String): String = s.replace(fixBad, "_").trim().trim('.').take(100)

private fun fixFullPath(dir: String, name: String, ext: String): String = "$dir/$name" + if (ext.isEmpty()) "" else ".$ext"

private fun fixPlan(tracks: List<Track>, onlyMessy: Boolean): List<FixRename> {
    val taken = HashSet<String>()
    for (t in tracks) taken.add(t.path.lowercase())
    val out = ArrayList<FixRename>()
    for (t in tracks) {
        if (!t.path.startsWith("/") || t.folder.isEmpty()) continue
        if (t.title == "Untitled") continue
        val file = File(t.path)
        val base = file.nameWithoutExtension
        val ext = file.extension
        val want = if (t.artist == "Unknown artist") fixClean(t.title) else fixClean("${t.artist} - ${t.title}")
        if (want.isBlank() || base.equals(want, ignoreCase = true)) continue
        if (onlyMessy && !fixDigits.containsMatchIn(base)) continue
        var name = want
        var n = 2
        while (fixFullPath(t.folder, name, ext).lowercase() in taken) {
            name = "$want ($n)"
            n++
        }
        val np = fixFullPath(t.folder, name, ext)
        taken.add(np.lowercase())
        out.add(FixRename(t, np))
    }
    return out
}

/** Reads "Artist - Title" out of a file name such as "01 Linkin Park - Numb.mp3". */
private fun fixParse(t: Track): Pair<String, String>? {
    if (!t.path.startsWith("/")) return null
    val base = File(t.path).nameWithoutExtension.replace('_', ' ').replace(fixLead, "")
    val i = base.indexOf(" - ")
    if (i < 1) return null
    val a = base.substring(0, i).trim()
    val ti = base.substring(i + 3).trim()
    if (a.isEmpty() || ti.isEmpty() || a.all { it.isDigit() }) return null
    return a to ti
}

private fun fixApply(ctx: Context, list: List<FixRename>): Map<String, String> {
    val ok = HashMap<String, String>()
    for (r in list) {
        try {
            val v = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, File(r.newPath).name) }
            if (ctx.contentResolver.update(r.track.uri, v, null, null) > 0) ok[r.track.path] = r.newPath
        } catch (_: Exception) {
        }
    }
    return ok
}

/** Tidies songs with messy names: fill missing info from the file name, and rename files from the song info. */
@Composable
fun FixFilesScreen(ui: UiController) {
    val app = ui.app
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val tracks by app.library.tracks.collectAsState()
    val tags by app.store.select { it.tags }
    var onlyMessy by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<List<FixRename>>(emptyList()) }

    val plan = remember(tracks, onlyMessy) { fixPlan(tracks, onlyMessy) }
    val fillable = remember(tracks, tags) {
        tracks.filter { (it.title == "Untitled" || it.artist == "Unknown artist") && it.path !in tags && fixParse(it) != null }
    }

    fun finish(ok: Map<String, String>, asked: Int) {
        app.store.migratePaths(ok)
        app.history.migrate(ok)
        app.library.refresh()
        busy = false
        ui.say(if (ok.size == asked) "Renamed ${plural(ok.size, "file")}" else "Renamed ${ok.size} of $asked files")
    }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val list = pending
            scope.launch {
                val ok = withContext(Dispatchers.IO) { fixApply(ctx, list) }
                finish(ok, list.size)
            }
        } else {
            busy = false
            ui.say("Nothing was renamed")
        }
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)) {
        item(key = "header") {
            ListHeader("Fix messy files", "Names like 19283728492.flac", ui, emptyList(), back = ui.stack.size > 1)
        }
        item(key = "fill") {
            Column(Modifier.padding(16.dp)) {
                Text("Fill missing info from file names", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "For songs with no title or artist, read \"Artist - Title\" from the file name. This only changes what Hwush shows. Your files are not touched.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = 8.dp),
                )
                Button(
                    enabled = fillable.isNotEmpty(),
                    onClick = {
                        val add = HashMap<String, TagOverride>()
                        for (t in fillable) {
                            val (a, ti) = fixParse(t) ?: continue
                            add[t.path] = TagOverride(
                                title = if (t.title == "Untitled") ti else null,
                                artist = if (t.artist == "Unknown artist") a else null,
                            )
                        }
                        app.store.update { d -> d.copy(tags = d.tags + add) }
                        ui.say("Filled in ${plural(add.size, "song")}")
                    },
                ) { Text(if (fillable.isEmpty()) "Nothing to fill" else "Fill ${plural(fillable.size, "song")}") }
            }
        }
        item(key = "rename") {
            Column(Modifier.padding(16.dp)) {
                Text("FixRename files from song info", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "Gives files the name \"Artist - Title\". Android asks you once to allow it. Your play counts, playlists and favorites follow the new names.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = 8.dp),
                )
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Only names made of numbers", Modifier.weight(1f))
                    Switch(checked = onlyMessy, onCheckedChange = { onlyMessy = it })
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        enabled = plan.isNotEmpty() && !busy,
                        onClick = {
                            val batch = plan.take(400)
                            pending = batch
                            busy = true
                            if (Build.VERSION.SDK_INT >= 30) {
                                try {
                                    val pi = MediaStore.createWriteRequest(ctx.contentResolver, batch.map { it.track.uri })
                                    launcher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                                } catch (e: Exception) {
                                    busy = false
                                    ui.say("Could not ask Android for permission")
                                }
                            } else {
                                scope.launch {
                                    val ok = withContext(Dispatchers.IO) { fixApply(ctx, batch) }
                                    finish(ok, batch.size)
                                }
                            }
                        },
                    ) { Text(if (busy) "Renaming" else if (plan.isEmpty()) "Nothing to rename" else "FixRename ${plural(plan.size.coerceAtMost(400), "file")}") }
                    if (plan.size > 400) OutlinedButton(onClick = {}, enabled = false) { Text("${plan.size} found") }
                }
            }
        }
        if (plan.isNotEmpty()) {
            item(key = "preview-title") {
                Text(
                    "Preview",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(start = 16.dp, top = 8.dp),
                )
            }
            items(plan.take(12).size, key = { "p$it" }) { i ->
                val r = plan[i]
                Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Text(File(r.track.path).name, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("→ " + File(r.newPath).name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}
