package com.hwush.player.player

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import com.hwush.player.HwushApp
import com.hwush.player.MainActivity
import com.hwush.player.R
import com.hwush.player.data.dominantColor

/**
 * Builds Hwush's own playback notification. It does not use the system media template, so the
 * collapsed and expanded views are drawn exactly as designed: cover, title, artist, album,
 * heart, previous, rewind, play, forward, next, add to playlist, and the upcoming songs.
 */
object HwushNotifications {
    const val CHANNEL = "hwush_playback"
    const val ID = 1101

    fun ensureChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "Now playing", NotificationManager.IMPORTANCE_LOW)
            ch.setShowBadge(false)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }
    }

    private fun broadcast(app: HwushApp, code: Int, action: String): PendingIntent = PendingIntent.getBroadcast(
        app,
        code,
        Intent(app, NotifActionReceiver::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun background(color: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        hsv[1] = hsv[1].coerceAtMost(0.7f)
        hsv[2] = hsv[2].coerceIn(0.28f, 0.5f)
        return Color.HSVToColor(hsv)
    }

    fun build(app: HwushApp, playing: Boolean): Notification {
        ensureChannel(app)
        val exo = app.player.player
        val track = app.player.currentTrack()
        val bmp = if (track != null) app.art.loadBlocking(track, 256) else null
        val bg = if (bmp != null) background(dominantColor(bmp)) else 0xFF2B3550.toInt()
        val title = track?.title ?: "Hwush"
        val artist = track?.artist ?: ""
        val fav = track != null && track.path in app.store.data.value.favorites

        val big = RemoteViews(app.packageName, R.layout.notification_big)
        big.setTextViewText(R.id.n_title, title)
        big.setTextViewText(R.id.n_artist, artist)
        big.setTextViewText(R.id.n_album, track?.album ?: "")
        if (bmp != null) big.setImageViewBitmap(R.id.n_art, bmp) else big.setImageViewResource(R.id.n_art, R.drawable.ic_stat_hwush)
        big.setInt(R.id.n_root, "setBackgroundColor", bg)
        big.setImageViewResource(R.id.n_fav, if (fav) R.drawable.ic_heart_filled else R.drawable.ic_heart)
        big.setImageViewResource(R.id.n_prev, R.drawable.ic_prev)
        big.setImageViewResource(R.id.n_rew, R.drawable.ic_rewind)
        big.setImageViewResource(R.id.n_play, if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        big.setImageViewResource(R.id.n_fwd, R.drawable.ic_forward)
        big.setImageViewResource(R.id.n_next, R.drawable.ic_next)
        big.setImageViewResource(R.id.n_add, R.drawable.ic_queue_add)
        big.setOnClickPendingIntent(R.id.n_fav, broadcast(app, 1, NotifActionReceiver.ACT_FAV))
        big.setOnClickPendingIntent(R.id.n_prev, broadcast(app, 2, NotifActionReceiver.ACT_PREV))
        big.setOnClickPendingIntent(R.id.n_rew, broadcast(app, 3, NotifActionReceiver.ACT_REW))
        big.setOnClickPendingIntent(R.id.n_play, broadcast(app, 4, NotifActionReceiver.ACT_PLAY))
        big.setOnClickPendingIntent(R.id.n_fwd, broadcast(app, 5, NotifActionReceiver.ACT_FWD))
        big.setOnClickPendingIntent(R.id.n_next, broadcast(app, 6, NotifActionReceiver.ACT_NEXT))
        big.setOnClickPendingIntent(
            R.id.n_add,
            PendingIntent.getActivity(
                app,
                7,
                Intent(app, MainActivity::class.java)
                    .setAction(MainActivity.ACTION_ADD_PLAYLIST)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            ),
        )
        val upcoming = ArrayList<String>()
        var i = exo.currentMediaItemIndex + 1
        while (i < exo.mediaItemCount && upcoming.size < 2) {
            val m = exo.getMediaItemAt(i).mediaMetadata
            upcoming.add("${m.title ?: ""} - ${m.artist ?: ""}")
            i++
        }
        if (upcoming.isEmpty()) {
            big.setTextViewText(R.id.n_up_label, "End of queue")
            big.setTextViewText(R.id.n_up1, "")
            big.setTextViewText(R.id.n_up2, "")
        } else {
            big.setTextViewText(R.id.n_up_label, "Upcoming songs")
            big.setTextViewText(R.id.n_up1, upcoming[0])
            big.setTextViewText(R.id.n_up2, upcoming.getOrElse(1) { "" })
        }

        val small = RemoteViews(app.packageName, R.layout.notification_small)
        small.setTextViewText(R.id.s_title, title)
        small.setTextViewText(R.id.s_artist, artist)
        if (bmp != null) small.setImageViewBitmap(R.id.s_art, bmp) else small.setImageViewResource(R.id.s_art, R.drawable.ic_stat_hwush)
        small.setInt(R.id.s_root, "setBackgroundColor", bg)
        small.setImageViewResource(R.id.s_prev, R.drawable.ic_prev)
        small.setImageViewResource(R.id.s_play, if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        small.setImageViewResource(R.id.s_next, R.drawable.ic_next)
        small.setOnClickPendingIntent(R.id.s_prev, broadcast(app, 2, NotifActionReceiver.ACT_PREV))
        small.setOnClickPendingIntent(R.id.s_play, broadcast(app, 4, NotifActionReceiver.ACT_PLAY))
        small.setOnClickPendingIntent(R.id.s_next, broadcast(app, 6, NotifActionReceiver.ACT_NEXT))

        val open = PendingIntent.getActivity(
            app,
            0,
            Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val b = NotificationCompat.Builder(app, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_hwush)
            .setContentTitle(title)
            .setContentText(artist)
            .setContentIntent(open)
            .setCustomContentView(small)
            .setCustomBigContentView(big)
            .setOnlyAlertOnce(true)
            .setOngoing(playing)
            .setShowWhen(false)
            .setCategory(NotificationCompat.CATEGORY_TRANSPORT)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setPriority(NotificationCompat.PRIORITY_LOW)
        if (bmp != null) b.setLargeIcon(bmp)
        return b.build()
    }
}
