package com.hwush.player.data

import java.io.File
import java.io.RandomAccessFile
import java.nio.charset.Charset

/** Reads lyrics stored inside the audio file itself: MP3 (USLT frame) and FLAC (LYRICS comment). */
object EmbeddedLyrics {
    fun read(path: String): String? {
        if (!path.startsWith("/")) return null
        val f = File(path)
        if (!f.isFile || !f.canRead()) return null
        val raw: String? = try {
            RandomAccessFile(f, "r").use { raf ->
                val head = ByteArray(4)
                raf.readFully(head)
                when {
                    head[0] == 'I'.code.toByte() && head[1] == 'D'.code.toByte() && head[2] == '3'.code.toByte() -> id3(raf)
                    head[0] == 'f'.code.toByte() && head[1] == 'L'.code.toByte() && head[2] == 'a'.code.toByte() && head[3] == 'C'.code.toByte() -> flac(raf)
                    else -> null
                }
            }
        } catch (_: Exception) {
            null
        }
        return raw?.trim()?.takeIf { it.isNotEmpty() }
    }

    private fun b(d: ByteArray, i: Int): Int = d[i].toInt() and 0xFF

    private fun syncsafe(d: ByteArray, i: Int): Int =
        ((b(d, i) and 0x7F) shl 21) or ((b(d, i + 1) and 0x7F) shl 14) or ((b(d, i + 2) and 0x7F) shl 7) or (b(d, i + 3) and 0x7F)

    private fun unsync(d: ByteArray): ByteArray {
        val out = java.io.ByteArrayOutputStream(d.size)
        for (i in d.indices) {
            if (d[i].toInt() == 0 && i > 0 && b(d, i - 1) == 0xFF) continue
            out.write(b(d, i))
        }
        return out.toByteArray()
    }

    private fun id3(raf: RandomAccessFile): String? {
        raf.seek(0)
        val h = ByteArray(10)
        raf.readFully(h)
        val ver = b(h, 3)
        val flags = b(h, 5)
        val size = syncsafe(h, 6)
        if (size <= 0 || size > 16 * 1024 * 1024) return null
        var d = ByteArray(size)
        raf.readFully(d)
        if ((flags and 0x80) != 0 && ver < 4) d = unsync(d)
        var p = 0
        if ((flags and 0x40) != 0 && d.size > 4) {
            val es = syncsafe(d, 0)
            p = if (ver == 4) es else es + 4
        }
        val idLen = if (ver == 2) 3 else 4
        val hLen = if (ver == 2) 6 else 10
        while (p + hLen <= d.size) {
            if (d[p].toInt() == 0) break
            val id = String(d, p, idLen, Charsets.ISO_8859_1)
            val fs = when (ver) {
                2 -> (b(d, p + 3) shl 16) or (b(d, p + 4) shl 8) or b(d, p + 5)
                4 -> syncsafe(d, p + 4)
                else -> (b(d, p + 4) shl 24) or (b(d, p + 5) shl 16) or (b(d, p + 6) shl 8) or b(d, p + 7)
            }
            val s = p + hLen
            val e = s + fs
            if (fs <= 0 || e > d.size || e < 0) break
            if (id == "USLT" || id == "ULT") {
                val text = usltText(d.copyOfRange(s, e))
                if (!text.isNullOrBlank()) return text
            }
            p = e
        }
        return null
    }

    private fun usltText(f: ByteArray): String? {
        if (f.size < 5) return null
        val enc = b(f, 0)
        var p = 4
        // skip the short description that comes before the lyrics
        if (enc == 1 || enc == 2) {
            while (p + 1 < f.size && !(f[p].toInt() == 0 && f[p + 1].toInt() == 0)) p += 2
            p += 2
        } else {
            while (p < f.size && f[p].toInt() != 0) p++
            p += 1
        }
        if (p >= f.size) return null
        val cs: Charset = when (enc) {
            1 -> Charsets.UTF_16
            2 -> Charsets.UTF_16BE
            3 -> Charsets.UTF_8
            else -> Charsets.ISO_8859_1
        }
        return String(f, p, f.size - p, cs)
    }

    private fun le32(d: ByteArray, i: Int): Int =
        b(d, i) or (b(d, i + 1) shl 8) or (b(d, i + 2) shl 16) or (b(d, i + 3) shl 24)

    private fun flac(raf: RandomAccessFile): String? {
        raf.seek(4)
        var guard = 0
        while (guard++ < 200) {
            val hd = ByteArray(4)
            raf.readFully(hd)
            val last = (b(hd, 0) and 0x80) != 0
            val type = b(hd, 0) and 0x7F
            val len = (b(hd, 1) shl 16) or (b(hd, 2) shl 8) or b(hd, 3)
            if (type == 4) {
                if (len <= 0 || len > 4 * 1024 * 1024) return null
                val d = ByteArray(len)
                raf.readFully(d)
                return vorbis(d)
            }
            raf.seek(raf.filePointer + len)
            if (last) break
        }
        return null
    }

    private fun vorbis(d: ByteArray): String? {
        var p = 0
        if (d.size < 8) return null
        p += 4 + le32(d, 0)
        if (p + 4 > d.size) return null
        val n = le32(d, p)
        p += 4
        for (i in 0 until n) {
            if (p + 4 > d.size) break
            val l = le32(d, p)
            p += 4
            if (l < 0 || p + l > d.size) break
            val s = String(d, p, l, Charsets.UTF_8)
            p += l
            val k = s.indexOf('=')
            if (k < 1) continue
            val key = s.substring(0, k).uppercase()
            if (key == "LYRICS" || key == "UNSYNCEDLYRICS" || key == "UNSYNCED LYRICS" || key == "SYNCEDLYRICS") {
                return s.substring(k + 1)
            }
        }
        return null
    }
}
