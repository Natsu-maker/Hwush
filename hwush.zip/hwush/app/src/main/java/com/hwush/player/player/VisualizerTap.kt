package com.hwush.player.player

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.sqrt

/** Listens to the sound Hwush is playing and turns it into bar heights (0 to 1) for the visualizer. */
class VisualizerTap(private val ctx: Context) {
    val bands = MutableStateFlow(FloatArray(BARS))

    private var viz: Visualizer? = null
    private var session = 0
    private var wanted = false
    private val level = FloatArray(BARS)

    fun configure(on: Boolean) {
        wanted = on
        rebuild()
    }

    fun attach(sessionId: Int) {
        session = sessionId
        rebuild()
    }

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun rebuild() {
        release()
        if (!wanted || session <= 0 || !hasPermission()) return
        try {
            val v = Visualizer(session)
            v.setEnabled(false)
            v.setCaptureSize(Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024))
            v.setDataCaptureListener(
                object : Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(visualizer: Visualizer?, waveform: ByteArray?, samplingRate: Int) {}

                    override fun onFftDataCapture(visualizer: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                        if (fft != null) process(fft)
                    }
                },
                Visualizer.getMaxCaptureRate() / 2,
                false,
                true,
            )
            v.setEnabled(true)
            viz = v
        } catch (e: Exception) {
            viz = null
        }
    }

    private fun release() {
        viz?.let {
            try {
                it.setEnabled(false)
                it.release()
            } catch (_: Exception) {
            }
        }
        viz = null
        java.util.Arrays.fill(level, 0f)
        bands.value = FloatArray(BARS)
    }

    private fun process(fft: ByteArray) {
        val half = fft.size / 2
        if (half < 8) return
        val maxBin = (half * 0.55f).toInt().coerceAtLeast(BARS + 1)
        for (b in 0 until BARS) {
            val from = 1 + ((maxBin - 1) * (b.toFloat() / BARS).pow(2f)).toInt()
            val to = (1 + ((maxBin - 1) * ((b + 1).toFloat() / BARS).pow(2f)).toInt()).coerceAtLeast(from + 1)
            var sum = 0f
            var n = 0
            for (k in from until to.coerceAtMost(half)) {
                val re = fft[2 * k].toFloat()
                val im = fft[2 * k + 1].toFloat()
                sum += sqrt(re * re + im * im)
                n++
            }
            val mag = if (n > 0) sum / n else 0f
            val v = (ln(1f + mag) / ln(1f + 90f)).coerceIn(0f, 1f)
            level[b] = if (v > level[b]) v else level[b] * 0.82f + v * 0.18f
        }
        bands.value = level.copyOf()
    }

    companion object {
        const val BARS = 28
    }
}
