package com.hwush.player.ui

import android.graphics.Bitmap
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import com.hwush.player.data.Track
import com.hwush.player.hwush
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ------------------------------------------------------------------ colours taken from the cover

/** Five colours from the cover: four corners and the middle, made a little richer so they glow. */
@Composable
fun rememberArtPalette(track: Track?, fallback: Color): List<Color> {
    val app = LocalContext.current.hwush
    val rev = app.coverRev.intValue
    val raw by produceState<List<Color>?>(null, track?.path, rev) {
        value = if (track == null) null else app.art.load(track, 64)?.let { bdPalette(it) }
    }
    val base = raw ?: List(5) { fallback }
    val a0 by animateColorAsState(base[0], tween(1100), label = "p0")
    val a1 by animateColorAsState(base[1], tween(1100), label = "p1")
    val a2 by animateColorAsState(base[2], tween(1100), label = "p2")
    val a3 by animateColorAsState(base[3], tween(1100), label = "p3")
    val a4 by animateColorAsState(base[4], tween(1100), label = "p4")
    return listOf(a0, a1, a2, a3, a4)
}

private fun bdPalette(src: Bitmap): List<Color> {
    val s = Bitmap.createScaledBitmap(src, 8, 8, true)
    val px = IntArray(64)
    s.getPixels(px, 0, 8, 0, 0, 8, 8)
    fun region(x0: Int, y0: Int, x1: Int, y1: Int): Color {
        var r = 0
        var g = 0
        var b = 0
        var n = 0
        for (y in y0 until y1) for (x in x0 until x1) {
            val c = px[y * 8 + x]
            r += (c shr 16) and 0xFF
            g += (c shr 8) and 0xFF
            b += c and 0xFF
            n++
        }
        if (n == 0) return Color.Gray
        return bdRich(r / n, g / n, b / n)
    }
    return listOf(region(0, 0, 4, 4), region(4, 0, 8, 4), region(0, 4, 4, 8), region(4, 4, 8, 8), region(2, 2, 6, 6))
}

private fun bdRich(r: Int, g: Int, b: Int): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.RGBToHSV(r, g, b, hsv)
    hsv[1] = min(1f, hsv[1] * 1.3f + 0.08f)
    hsv[2] = hsv[2].coerceIn(0.5f, 0.95f)
    return Color(android.graphics.Color.HSVToColor(hsv))
}

/** Blur a small picture properly (three box passes) so the result is smooth like frosted glass, not blocky. */
private fun bdBlur(src: Bitmap, radius: Int): Bitmap {
    val w = src.width
    val h = src.height
    val px = IntArray(w * h)
    src.getPixels(px, 0, w, 0, 0, w, h)
    val tmp = IntArray(w * h)
    fun pass(from: IntArray, to: IntArray, horizontal: Boolean) {
        val lines = if (horizontal) h else w
        val len = if (horizontal) w else h
        for (l in 0 until lines) {
            for (i in 0 until len) {
                var a = 0
                var r = 0
                var g = 0
                var b = 0
                var n = 0
                for (k in -radius..radius) {
                    val j = (i + k).coerceIn(0, len - 1)
                    val c = if (horizontal) from[l * w + j] else from[j * w + l]
                    a += (c ushr 24) and 0xFF
                    r += (c shr 16) and 0xFF
                    g += (c shr 8) and 0xFF
                    b += c and 0xFF
                    n++
                }
                val out = ((a / n) shl 24) or ((r / n) shl 16) or ((g / n) shl 8) or (b / n)
                if (horizontal) to[l * w + i] = out else to[i * w + l] = out
            }
        }
    }
    repeat(3) {
        pass(px, tmp, true)
        pass(tmp, px, false)
    }
    return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
}

// ------------------------------------------------------------------ the two player backgrounds

/**
 * What sits behind the player. Style 0 is flowing colour glass; style 1 is the cover as soft motion blur.
 * The movement eases to a crawl when the music pauses and speeds up again when it plays.
 */
@Composable
fun PlayerBackdrop(track: Track?, color: Color, playing: Boolean, style: Int, modifier: Modifier = Modifier) {
    var phase by remember { mutableFloatStateOf(0f) }
    var speed by remember { mutableFloatStateOf(0.2f) }
    LaunchedEffect(playing) {
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { n ->
                if (last != 0L) {
                    val dt = ((n - last) / 1_000_000_000f).coerceAtMost(0.05f)
                    val target = if (playing) 1f else 0.12f
                    speed += (target - speed) * min(1f, dt * 1.6f)
                    phase += dt * speed
                }
                last = n
            }
        }
    }
    Box(modifier) {
        if (style == 1) {
            MotionBlurArt(track, color, { phase }, Modifier.fillMaxSize())
        } else {
            FlowingGlass(track, color, { phase }, Modifier.fillMaxSize())
        }
    }
}

/** Soft blobs of the cover colours drifting over each other under a sheet of frosted glass. */
@Composable
private fun FlowingGlass(track: Track?, color: Color, phase: () -> Float, modifier: Modifier) {
    val pal = rememberArtPalette(track, color)
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val t = phase() * 0.55f
        val big = max(w, h)
        // Each blob follows its own slow looping path, so the mix of colours never repeats exactly.
        val blobs = listOf(
            Triple(pal[0], Offset(0.25f + 0.22f * sin(t * 1.0f), 0.2f + 0.14f * cos(t * 0.8f)), 0.85f),
            Triple(pal[1], Offset(0.78f + 0.2f * cos(t * 0.9f + 1f), 0.3f + 0.16f * sin(t * 1.1f)), 0.8f),
            Triple(pal[2], Offset(0.22f + 0.2f * cos(t * 0.7f + 2f), 0.75f + 0.14f * sin(t * 0.95f + 1f)), 0.85f),
            Triple(pal[3], Offset(0.8f + 0.18f * sin(t * 0.85f + 3f), 0.78f + 0.12f * cos(t * 1.2f)), 0.8f),
            Triple(pal[4], Offset(0.5f + 0.3f * sin(t * 0.6f + 4f), 0.5f + 0.22f * cos(t * 0.75f + 2f)), 0.7f),
        )
        for ((c, pos, rad) in blobs) {
            val centre = Offset(pos.x * w, pos.y * h)
            drawRect(
                Brush.radialGradient(
                    0f to c.copy(alpha = 0.78f),
                    0.55f to c.copy(alpha = 0.28f),
                    1f to Color.Transparent,
                    center = centre,
                    radius = big * rad * 0.75f,
                ),
            )
        }
        // A slow bright band of light sliding across, like light moving through a glass pane.
        val sweep = ((t * 0.18f) % 1.6f) - 0.3f
        drawRect(
            Brush.linearGradient(
                0f to Color.Transparent,
                0.5f to Color.White.copy(alpha = 0.07f),
                1f to Color.Transparent,
                start = Offset(w * (sweep - 0.35f), 0f),
                end = Offset(w * (sweep + 0.35f), h),
            ),
        )
        // Frosting: a faint white veil, brighter at the top edge.
        drawRect(
            Brush.verticalGradient(
                0f to Color.White.copy(alpha = 0.10f),
                0.35f to Color.White.copy(alpha = 0.02f),
                1f to Color.Black.copy(alpha = 0.10f),
            ),
        )
    }
}

/** The cover smeared along a slowly turning direction, like a photo taken while the camera drifts. */
@Composable
private fun MotionBlurArt(track: Track?, color: Color, phase: () -> Float, modifier: Modifier) {
    val app = LocalContext.current.hwush
    val rev = app.coverRev.intValue
    val img by produceState<ImageBitmap?>(null, track?.path, rev) {
        value = if (track == null) null else app.art.load(track, 96)?.let { b ->
            val small = Bitmap.createScaledBitmap(b, 64, 64, true)
            bdBlur(small, 5).asImageBitmap()
        }
    }
    Crossfade(targetState = img, modifier = modifier, animationSpec = tween(900), label = "motionBlur") { image ->
        if (image == null) {
            Box(Modifier.fillMaxSize())
        } else {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val t = phase() * 0.4f
                val side = max(w, h) * 1.45f
                val angle = (0.35f + 0.5f * sin(t * 0.7f)) // radians, sways back and forth
                val spread = max(w, h) * (0.07f + 0.035f * sin(t * 0.9f + 1f))
                val dx = cos(angle)
                val dy = sin(angle)
                val steps = 9
                val zoom = 1f + 0.05f * sin(t * 0.5f)
                for (i in 0 until steps) {
                    val k = (i - (steps - 1) / 2f) / ((steps - 1) / 2f) // -1..1
                    val a = if (i == steps / 2) 0.55f else 0.17f
                    withTransform({
                        translate(w / 2f - side / 2f + dx * spread * k, h / 2f - side / 2f + dy * spread * k)
                        scale(zoom, zoom, Offset(side / 2f, side / 2f))
                    }) {
                        drawImage(
                            image,
                            dstSize = IntSize(side.toInt(), side.toInt()),
                            alpha = a,
                            filterQuality = FilterQuality.High,
                        )
                    }
                }
                drawRect(color.copy(alpha = 0.10f))
            }
        }
    }
}
