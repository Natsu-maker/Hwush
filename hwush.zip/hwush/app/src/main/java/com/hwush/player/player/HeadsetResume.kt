package com.hwush.player.player

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import com.hwush.player.HwushApp

/** Continues the music when Bluetooth or wired headphones connect again, shortly after they were unplugged mid-song. */
class HeadsetResume(private val app: HwushApp) {
    private val handler = Handler(Looper.getMainLooper())
    private var armed = false

    fun register() {
        val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.registerAudioDeviceCallback(
            object : AudioDeviceCallback() {
                override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
                    if (!armed) return
                    if (!app.store.data.value.btResume) return
                    if (addedDevices.none { it.isSink && it.type in WANTED }) return
                    val holder = app.player
                    if (holder.player.isPlaying || holder.player.mediaItemCount == 0) return
                    if (System.currentTimeMillis() - holder.lastPausedAt > RESUME_WINDOW_MS) return
                    holder.togglePlay()
                }
            },
            handler,
        )
        // The system reports devices that are already connected right away; ignore those.
        handler.postDelayed({ armed = true }, 2000L)
    }

    companion object {
        private const val RESUME_WINDOW_MS = 10 * 60_000L
        private val WANTED = setOf(
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
            AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
            AudioDeviceInfo.TYPE_USB_HEADSET,
        )
    }
}
