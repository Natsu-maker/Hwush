@file:OptIn(ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.hwush.player.data.AudioCutter
import com.hwush.player.data.Track
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private const val MAX_CUT_MS = 40_000L

/** Pick a part of a song (up to 40 seconds), preview it and save it as a sound file. */
@Composable
fun RingtoneSheet(ui: UiController, track: Track, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val total = track.durationMs.coerceAtLeast(1000L)
    var range by remember(track.path) {
        mutableStateOf(0f..minOf(30_000L, total).toFloat())
    }
    var busy by remember { mutableStateOf(false) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-wav")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        busy = true
        scope.launch {
            val ok = withContext(Dispatchers.IO) {
                val tmp = File(ctx.cacheDir, "cut.wav")
                val done = tmp.outputStream().use { os ->
                    AudioCutter.cutToWav(ctx, track.uri, range.start.toLong(), range.endInclusive.toLong(), os)
                }
                if (done) {
                    try {
                        ctx.contentResolver.openOutputStream(uri)?.use { out -> tmp.inputStream().use { it.copyTo(out) } }
                    } catch (_: Exception) {
                        return@withContext false
                    }
                }
                tmp.delete()
                done
            }
            busy = false
            ui.say(if (ok) "Saved. Set it as your ringtone from sound settings." else "Could not cut this song")
            if (ok) onClose()
        }
    }
    ModalBottomSheet(onDismissRequest = {
        ui.app.player.clearLoop()
        onClose()
    }) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            Text("Make a ringtone", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text(track.title, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(16.dp))
            RangeSlider(
                value = range,
                onValueChange = { r ->
                    var s = r.start
                    var e = r.endInclusive
                    if (e - s > MAX_CUT_MS) {
                        if (s != range.start) e = s + MAX_CUT_MS else s = e - MAX_CUT_MS
                    }
                    range = s..e
                },
                valueRange = 0f..total.toFloat(),
            )
            Row(Modifier.fillMaxWidth()) {
                Text(fmtTime(range.start.toLong()), style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.weight(1f))
                Text("${((range.endInclusive - range.start) / 1000f).toInt()} s", style = MaterialTheme.typography.labelMedium)
                Spacer(Modifier.weight(1f))
                Text(fmtTime(range.endInclusive.toLong()), style = MaterialTheme.typography.labelMedium)
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FilledTonalButton(onClick = {
                    ui.app.player.previewRange(track, range.start.toLong(), range.endInclusive.toLong())
                }) { Text("Preview") }
                Button(enabled = !busy, onClick = { saver.launch("${track.title}-ringtone.wav") }) {
                    Text(if (busy) "Cutting" else "Save")
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "The clip is saved as a WAV file where you choose. Then open sound settings and pick it as your ringtone. Pick a Music or Ringtones folder if your phone does not list it.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = {
                try {
                    ctx.startActivity(Intent(Settings.ACTION_SOUND_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {
                }
            }) { Text("Open sound settings") }
        }
    }
}
