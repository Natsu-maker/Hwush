package com.hwush.player.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.min

/** Loads cover art: your custom cover, the tag inside the file, a cover.jpg in the folder, or the system thumbnail. */
class Art(private val ctx: Context, private val store: Store) {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val missing: MutableSet<String> = ConcurrentHashMap.newKeySet()

    private fun bucket(px: Int): Int = when {
        px <= 96 -> 96
        px <= 192 -> 192
        px <= 384 -> 384
        else -> 768
    }

    fun invalidate(path: String) {
        val prefix = "$path|"
        for (k in cache.snapshot().keys) if (k.startsWith(prefix)) cache.remove(k)
        missing.removeAll { it.startsWith(prefix) }
    }

    fun peek(t: Track, px: Int): Bitmap? = cache.get("${t.path}|${bucket(px)}")

    suspend fun load(t: Track, px: Int): Bitmap? = withContext(Dispatchers.IO) { loadBlocking(t, px) }

    fun loadBlocking(t: Track, px: Int): Bitmap? {
        val size = bucket(px)
        val key = "${t.path}|$size"
        cache.get(key)?.let { return it }
        if (key in missing) return null
        val bmp = fromOverride(t, size) ?: fromTag(t, size) ?: fromFolder(t, size) ?: fromProvider(t, size)
        if (bmp != null) cache.put(key, bmp) else missing.add(key)
        return bmp
    }

    private fun decode(b: ByteArray, size: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, 0, b.size, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var s = 1
        while (min(o.outWidth, o.outHeight) / (s * 2) >= size) s *= 2
        return BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun decodeFile(f: File, size: Int): Bitmap? {
        if (!f.isFile || !f.canRead()) return null
        return try {
            decode(f.readBytes(), size)
        } catch (e: Exception) {
            null
        }
    }

    private fun fromOverride(t: Track, size: Int): Bitmap? {
        val name = store.data.value.tags[t.path]?.cover ?: return null
        return decodeFile(File(File(ctx.filesDir, "covers"), name), size)
    }

    private fun fromTag(t: Track, size: Int): Bitmap? {
        val mmr = MediaMetadataRetriever()
        return try {
            mmr.setDataSource(ctx, t.uri)
            val b = mmr.embeddedPicture
            if (b != null) decode(b, size) else null
        } catch (e: Exception) {
            null
        } finally {
            try {
                mmr.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun fromFolder(t: Track, size: Int): Bitmap? {
        if (t.folder.isEmpty()) return null
        for (n in listOf("cover", "folder", "album", "front", "albumart")) {
            for (e in listOf("jpg", "jpeg", "png")) {
                val bmp = decodeFile(File(t.folder, "$n.$e"), size)
                if (bmp != null) return bmp
            }
        }
        return null
    }

    private fun fromProvider(t: Track, size: Int): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.loadThumbnail(t.uri, Size(size, size), null)
            } else {
                val u = Uri.parse("content://media/external/audio/albumart/${t.albumId}")
                ctx.contentResolver.openInputStream(u)?.use { decode(it.readBytes(), size) }
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Saves a picked image as a square cover inside the app and returns its file name. */
    fun saveCover(src: Uri): String? {
        try {
            val bytes = ctx.contentResolver.openInputStream(src)?.use { it.readBytes() } ?: return null
            val bmp = decode(bytes, 512) ?: return null
            val s = min(bmp.width, bmp.height)
            val square = Bitmap.createBitmap(bmp, (bmp.width - s) / 2, (bmp.height - s) / 2, s, s)
            val scaled = Bitmap.createScaledBitmap(square, 512, 512, true)
            val dir = File(ctx.filesDir, "covers")
            dir.mkdirs()
            val name = "c${System.currentTimeMillis()}.jpg"
            File(dir, name).outputStream().use { scaled.compress(Bitmap.CompressFormat.JPEG, 88, it) }
            return name
        } catch (e: Exception) {
            return null
        }
    }
}

/** Picks a lively colour from a cover for the "album art" accent mode. */
fun dominantColor(b: Bitmap): Int {
    val s = Bitmap.createScaledBitmap(b, 24, 24, true)
    val hsv = FloatArray(3)
    var best = 0xFF5B8CFF.toInt()
    var bestScore = -1f
    for (x in 0 until 24) {
        for (y in 0 until 24) {
            val c = s.getPixel(x, y)
            Color.colorToHSV(c, hsv)
            val score = hsv[1] * (1f - abs(hsv[2] - 0.62f))
            if (score > bestScore) {
                bestScore = score
                best = c or (0xFF shl 24)
            }
        }
    }
    return best
}
