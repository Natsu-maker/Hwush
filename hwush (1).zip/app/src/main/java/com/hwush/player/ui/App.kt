@file:OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)

package com.hwush.player.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Album
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.Surface
import androidx.compose.animation.togetherWith
import androidx.compose.material3.Text
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

fun hasAudioPermission(ctx: Context): Boolean {
    val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    return ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
}

private fun permissionsToAsk(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33) {
        arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
    } else {
        arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

internal data class Tab(val kind: Kind, val label: String, val icon: ImageVector)

internal val tabs = listOf(
    Tab(Kind.HOME, "Home", Icons.Rounded.Home),
    Tab(Kind.SONGS, "Songs", Icons.Rounded.MusicNote),
    Tab(Kind.ALBUMS, "Albums", Icons.Rounded.Album),
    Tab(Kind.ARTISTS, "Artists", Icons.Rounded.Person),
    Tab(Kind.PLAYLISTS, "Playlists", Icons.Rounded.QueueMusic),
)

/** The bottom bar tabs in the order the user chose, without the ones they hid. Home always stays. */
internal fun visibleTabs(order: List<String>, hidden: Set<String>): List<Tab> {
    val ordered = order.mapNotNull { n -> tabs.firstOrNull { it.kind.name == n } } +
        tabs.filter { t -> order.none { it == t.kind.name } }
    return ordered.filter { it.kind == Kind.HOME || it.kind.name !in hidden }
}

@Composable
fun HwushRoot(ui: UiController) {
    val app = ui.app
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasAudioPermission(ctx)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudioPermission(ctx)
        if (granted) app.library.refresh()
    }
    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(permissionsToAsk())
    }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (granted) {
            MainShell(ui)
        } else {
            Box(Modifier.fillMaxSize().systemBarsPadding()) {
                EmptyState(
                    title = "Hwush needs access to your music",
                    body = "Allow access to audio files so Hwush can find the songs on this device. Nothing leaves your device.",
                    action = {
                        Column(horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
                            Button(onClick = { launcher.launch(permissionsToAsk()) }) { Text("Allow access") }
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = {
                                ctx.startActivity(
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                        .setData(Uri.fromParts("package", ctx.packageName, null)),
                                )
                            }) { Text("Open app settings") }
                        }
                    },
                )
            }
        }
    }
}

@Composable
private fun MainShell(ui: UiController) {
    val app = ui.app
    val loaded by app.library.loaded.collectAsState()
    LaunchedEffect(loaded) {
        if (loaded) app.player.restore()
    }
    LaunchedEffect(Unit) {
        app.player.messages.collect { ui.say(it) }
    }
    val cfg = LocalConfiguration.current
    val tablet = cfg.smallestScreenWidthDp >= 600 && cfg.orientation == Configuration.ORIENTATION_LANDSCAPE

    BackHandler(enabled = ui.stack.size > 1) { ui.back() }
    BackHandler(enabled = ui.nowPlayingOpen) { ui.nowPlayingOpen = false }
    androidx.compose.runtime.SideEffect { ui.twoPane = tablet }

    BackHandler(enabled = ui.selection.isNotEmpty()) { ui.selection.clear() }
    val addRequest = app.addToPlaylistRequest.intValue
    LaunchedEffect(addRequest, loaded) {
        if (addRequest > 0 && loaded) {
            app.player.currentTrack()?.let { ui.pickPlaylistFor = listOf(it) }
        }
    }

    Box(Modifier.fillMaxSize()) {
        if (tablet) TabletShell(ui, cfg.screenWidthDp) else PhoneShell(ui)
        SelectionBar(ui, Modifier.align(androidx.compose.ui.Alignment.TopCenter))
    }
    Overlays(ui)
    if (loaded) WhatsNewPopup(ui)
    BackHandler(enabled = ui.carMode) { ui.carMode = false }
    androidx.compose.animation.AnimatedVisibility(
        visible = ui.carMode,
        enter = androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(250)),
        exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(200)),
    ) { CarMode(ui) }
}

@Composable
fun ContentRouter(ui: UiController, modifier: Modifier = Modifier, dest: Dest = ui.current) {
    androidx.compose.animation.AnimatedContent(
        targetState = dest,
        modifier = modifier,
        transitionSpec = {
            (androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(260, delayMillis = 70)) +
                androidx.compose.animation.scaleIn(androidx.compose.animation.core.tween(320, easing = androidx.compose.animation.core.FastOutSlowInEasing), initialScale = 0.94f) +
                androidx.compose.animation.slideInHorizontally(androidx.compose.animation.core.tween(320, easing = androidx.compose.animation.core.FastOutSlowInEasing)) { it / 10 })
                .togetherWith(
                    androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(140)) +
                        androidx.compose.animation.scaleOut(androidx.compose.animation.core.tween(180), targetScale = 1.04f),
                )
        },
        label = "route",
    ) { d ->
        Box(Modifier.fillMaxSize()) {
        when (d.kind) {
            Kind.DJ -> AutoDjScreen(ui)
            Kind.COMPOSERS -> ComposersScreen(ui)
            Kind.COMPOSER -> ComposerDetail(ui, d.arg)
            Kind.ALBUMARTISTS -> AlbumArtistsScreen(ui)
            Kind.ALBUMARTIST -> AlbumArtistDetail(ui, d.arg)
            Kind.PEQ -> PrecisionEqScreen(ui)
            Kind.NEWS -> WhatsNewScreen(ui)
            Kind.HEALTH -> HealthScreen(ui)
            Kind.THEME -> ThemeScreen(ui)
            Kind.WIDGETS -> WidgetsScreen(ui)
            Kind.ALARMS -> AlarmsScreen(ui)
            Kind.MIXES -> MixesScreen(ui)
            Kind.BADGES -> BadgesScreen(ui)
            Kind.GOALS -> GoalsScreen(ui)
            Kind.FILTER -> FilterScreen(ui)
            Kind.BOOKS -> BooksScreen(ui)
            Kind.SONGINFO -> SongInfoScreen(ui, d.arg)
            Kind.HISTORY -> HistoryScreen(ui)
            Kind.FIXFILES -> FixFilesScreen(ui)
            Kind.QUIZ -> QuizScreen(ui)
            Kind.STATS -> StatsScreen(ui)
            Kind.WRAPPED -> WrappedScreen(ui)
            Kind.HOME -> HomeScreen(ui)
            Kind.GENRES -> GenresScreen(ui)
            Kind.GENRE -> GenreDetail(ui, d.arg)
            Kind.YEARS -> YearsScreen(ui)
            Kind.YEAR -> YearDetail(ui, d.arg)
            Kind.DUPES -> DupesScreen(ui)
            Kind.SONGS -> SongsScreen(ui)
            Kind.ALBUMS -> AlbumsScreen(ui)
            Kind.ARTISTS -> ArtistsScreen(ui)
            Kind.FOLDERS -> FoldersScreen(ui)
            Kind.PLAYLISTS -> PlaylistsScreen(ui)
            Kind.SETTINGS -> SettingsScreen(ui)
            Kind.ALBUM -> AlbumDetail(ui, d.arg)
            Kind.ARTIST -> ArtistDetail(ui, d.arg)
            Kind.FOLDER -> FolderDetail(ui, d.arg)
            Kind.PLAYLIST -> PlaylistDetail(ui, d.arg)
        }
        }
    }
}

@Composable
private fun PhoneShell(ui: UiController) {
    val tabOrder by ui.app.store.select { it.tabOrder }
    val tabHidden by ui.app.store.select { it.tabHidden }
    val shownTabs = visibleTabs(tabOrder, tabHidden)
    val sideways = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    Box(Modifier.fillMaxSize()) {
        Scaffold(
            snackbarHost = { SnackbarHost(ui.snack) },
            bottomBar = if (sideways) ({ MiniPlayer(ui) }) else ({
                Column {
                    MiniPlayer(ui)
                    NavigationBar {
                        shownTabs.forEach { t ->
                            NavigationBarItem(
                                selected = ui.root == t.kind,
                                onClick = { ui.go(t.kind) },
                                icon = { Icon(t.icon, t.label) },
                                label = { Text(t.label, maxLines = 1) },
                            )
                        }
                    }
                }
            }),
        ) { pad ->
            if (sideways) {
                Row(Modifier.padding(pad).fillMaxSize()) {
                    NavigationRail(
                        modifier = Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState()),
                        containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    ) {
                        shownTabs.forEach { t ->
                            NavigationRailItem(
                                selected = ui.root == t.kind,
                                onClick = { ui.go(t.kind) },
                                icon = { Icon(t.icon, t.label) },
                                label = { Text(t.label, maxLines = 1) },
                                alwaysShowLabel = false,
                            )
                        }
                    }
                    ContentRouter(ui, Modifier.weight(1f).fillMaxHeight())
                }
            } else {
                ContentRouter(ui, Modifier.padding(pad).fillMaxSize())
            }
        }
        androidx.compose.animation.AnimatedVisibility(
            visible = ui.nowPlayingOpen,
            enter = androidx.compose.animation.slideInVertically(androidx.compose.animation.core.tween(340)) { it } +
                androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(200)),
            exit = androidx.compose.animation.slideOutVertically(androidx.compose.animation.core.tween(260)) { it } +
                androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(200)),
        ) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                if (androidx.compose.ui.platform.LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE) {
                    TabletPlayer(ui, onClose = { ui.nowPlayingOpen = false })
                } else {
                    PlayerPane(ui, Modifier.systemBarsPadding(), onClose = { ui.nowPlayingOpen = false })
                }
            }
        }
    }
}

/** Tablet landscape: navigation rail, the library in one or two panes, the mini player below and the full player on top. */
@Composable
private fun TabletShell(ui: UiController, widthDp: Int) {
    val tabOrder by ui.app.store.select { it.tabOrder }
    val tabHidden by ui.app.store.select { it.tabHidden }
    val shownTabs = visibleTabs(tabOrder, tabHidden)
    Box(Modifier.fillMaxSize()) {
        Scaffold(
            snackbarHost = { SnackbarHost(ui.snack) },
            bottomBar = { MiniPlayer(ui) },
        ) { pad ->
            Row(Modifier.padding(pad).fillMaxSize()) {
                NavigationRail(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                    Spacer(Modifier.height(8.dp))
                    shownTabs.forEach { t ->
                        NavigationRailItem(
                            selected = ui.root == t.kind && ui.current.kind != Kind.SETTINGS,
                            onClick = { ui.go(t.kind) },
                            icon = { Icon(t.icon, t.label) },
                            label = { Text(t.label, maxLines = 1) },
                            alwaysShowLabel = true,
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    NavigationRailItem(
                        selected = ui.current.kind == Kind.SETTINGS,
                        onClick = { if (ui.current.kind != Kind.SETTINGS) ui.open(Dest(Kind.SETTINGS)) },
                        icon = { Icon(Icons.Rounded.Settings, "Settings") },
                        label = { Text("Settings", maxLines = 1) },
                        alwaysShowLabel = true,
                    )
                    Spacer(Modifier.height(8.dp))
                }
                TabletContent(ui, Modifier.weight(1f).fillMaxHeight(), widthDp)
            }
        }
        androidx.compose.animation.AnimatedVisibility(
            visible = ui.nowPlayingOpen,
            enter = androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(260)) +
                androidx.compose.animation.scaleIn(androidx.compose.animation.core.tween(300), initialScale = 0.94f),
            exit = androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(200)) +
                androidx.compose.animation.scaleOut(androidx.compose.animation.core.tween(220), targetScale = 0.96f),
        ) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                TabletPlayer(ui, onClose = { ui.nowPlayingOpen = false })
            }
        }
    }
}

/** Songs, Albums, Artists and Playlists show the list on the left and whatever was opened on the right. */
@Composable
private fun TabletContent(ui: UiController, modifier: Modifier, widthDp: Int) {
    val first = ui.stack.first()
    val split = first.kind in UiController.TWO_PANE_ROOTS && ui.current.kind != Kind.SETTINGS
    if (!split) {
        ContentRouter(ui, modifier.fillMaxSize())
        return
    }
    Row(modifier.fillMaxSize()) {
        ContentRouter(ui, Modifier.weight(if (widthDp >= 1100) 0.40f else 0.46f).fillMaxHeight(), first)
        VerticalDivider()
        Box(Modifier.weight(if (widthDp >= 1100) 0.60f else 0.54f).fillMaxHeight()) {
            if (ui.stack.size > 1) {
                ContentRouter(ui, Modifier.fillMaxSize(), ui.current)
            } else {
                PanePlaceholder(first.kind)
            }
        }
    }
}

@Composable
private fun PanePlaceholder(kind: Kind) {
    val (icon, text) = when (kind) {
        Kind.ALBUMS -> Icons.Rounded.Album to "Pick an album to see its songs here"
        Kind.ARTISTS -> Icons.Rounded.Person to "Pick an artist to see their songs here"
        Kind.PLAYLISTS -> Icons.Rounded.QueueMusic to "Pick a playlist to open it here"
        else -> Icons.Rounded.MusicNote to "Song details, lyrics and tags open here"
    }
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
    ) {
        Icon(icon, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f))
        Spacer(Modifier.height(12.dp))
        Text(
            text,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
        )
    }
}
