@file:OptIn(UnstableApi::class)

package com.hwush.player.player

import android.content.Context
import android.content.Intent
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.hwush.player.data.Gains
import com.hwush.player.data.ReplayGainReader
import com.hwush.player.data.Art
import com.hwush.player.data.Library
import com.hwush.player.data.SongFx
import com.hwush.player.data.Store
import com.hwush.player.data.Track
import com.hwush.player.widget.HwushWidget
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

data class PlayerUi(
    val path: String? = null,
    val isPlaying: Boolean = false,
    val index: Int = 0,
    val queue: List<String> = emptyList(),
    val shuffle: Boolean = false,
    val repeat: Int = Player.REPEAT_MODE_OFF,
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val songScope: Boolean = false,
    val sleepEndsAt: Long = 0L,
    val sleepAfterSong: Boolean = false,
    val sleepSongs: Int = 0,
    val loopA: Long = -1L,
    val loopB: Long = -1L,
)

data class OutputInfo(val key: String, val label: String)

data class EqInfo(
    val bands: Int,
    val minMb: Int,
    val maxMb: Int,
    val freqsHz: List<Int>,
    val presets: List<String>,
)

/**
 * Owns the one ExoPlayer. Handles the queue, speed and pitch (independent, so no chipmunk effect),
 * equalizer, sleep timer, fades, remembered positions and play counts. Call everything on the main thread.
 */
class PlayerHolder(
    private val ctx: Context,
    private val store: Store,
    private val library: Library,
    @Suppress("unused") private val art: Art,
    private val history: com.hwush.player.data.History,
) {
    /** Balance and mono, applied inside the audio path of the main player. */
    private val balance = BalanceProcessor()

    val player: ExoPlayer = ExoPlayer.Builder(
        ctx,
        object : androidx.media3.exoplayer.DefaultRenderersFactory(ctx) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean,
            ): androidx.media3.exoplayer.audio.AudioSink =
                androidx.media3.exoplayer.audio.DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .setAudioProcessors(arrayOf(balance))
                    .build()
        }.setEnableDecoderFallback(true),
    )
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(),
            true,
        )
        .setHandleAudioBecomingNoisy(true)
        .setWakeMode(C.WAKE_MODE_LOCAL)
        .build()

    private val handler = Handler(Looper.getMainLooper())
    private val _ui = MutableStateFlow(PlayerUi())
    val ui: StateFlow<PlayerUi> = _ui

    val eqInfo = MutableStateFlow<EqInfo?>(null)
    val output = MutableStateFlow(OutputInfo("speaker", "Phone speaker"))

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages

    private var eq: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var loudness: LoudnessEnhancer? = null
    private var virtualizer: Virtualizer? = null

    private var queueCache: List<String> = emptyList()
    private var originalOrder: List<String> = emptyList()

    private var sleepEndsAt = 0L
    private var sleepAfterSong = false
    private var sleepSongs = 0
    private var shake: ShakeExtender? = null

    private var listenedMs = 0L
    private var counted = false
    private var lastPath: String? = null
    private var lastSaveAt = 0L
    private var errorStreak = 0
    private var ticking = false
    private var lastWidgetKey = "null|false"

    @Volatile
    var lastPausedAt = 0L

    /** Told whenever the audio session changes, so the visualizer can attach to it. */
    var onAudioSession: ((Int) -> Unit)? = null

    // The second player used for overlapping songs while one fades out and the next fades in.
    private var ghost: ExoPlayer? = null
    private var ghostIndex = -1
    private var swapping = false
    private var swapIdx = -1
    private var swapStartedAt = 0L
    private var swapSeekCount = 0
    private var swapLatency = 120L
    private var swapSeekAt = 0L
    private var fading = false

    private var loopA = -1L
    private var loopB = -1L
    private var loopTicking = false
    private var rgFactor = 1f
    private var alarmRampStart = 0L
    private var lastWidgetPush = 0L
    private var alarmRampMs = 0L
    private val gainCache = HashMap<String, Gains>()
    private val rgExec = java.util.concurrent.Executors.newSingleThreadExecutor()

    private val loopRunnable = object : Runnable {
        override fun run() {
            if (loopA >= 0L && loopB > loopA) {
                if (player.isPlaying && player.currentPosition >= loopB) player.seekTo(loopA)
                handler.postDelayed(this, 80L)
            } else {
                loopTicking = false
            }
        }
    }

    private val tickRunnable = object : Runnable {
        override fun run() {
            onTick()
            if (player.isPlaying || sleepEndsAt > 0L) {
                handler.postDelayed(this, TICK_MS)
            } else {
                ticking = false
            }
        }
    }

    private val listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            if (isPlaying) {
                errorStreak = 0
                ensureTick()
            } else {
                // Buffering during a hand off briefly reports "not playing"; the overlap carries on through it.
                if (ghost != null && !(swapping && player.playWhenReady)) {
                    stopGhost()
                    player.volume = rgFactor
                }
                saveState()
            }
            publish()
        }

        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            if (!playWhenReady && reason == Player.PLAY_WHEN_READY_CHANGE_REASON_AUDIO_BECOMING_NOISY) {
                lastPausedAt = System.currentTimeMillis()
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            publish()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            val fromSwap = swapping && mediaItem?.mediaId == swapPath()
            if (ghost != null && !fromSwap) {
                val g = ghost
                if (g != null && reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO && player.currentMediaItemIndex == ghostIndex) {
                    // The song ended before the hand off. Line the main player up with the second one.
                    val gp = try { g.currentPosition } catch (_: Exception) { 0L }
                    player.seekTo(gp)
                    player.volume = rgFactor
                    handler.postDelayed({ stopGhost() }, 120L)
                } else {
                    stopGhost()
                    swapping = false
                    player.volume = rgFactor
                }
            }
            // Leaving a song early by hand is a skip. Wrapped uses it for the most skipped and never skipped pages.
            val left = lastPath
            if (left != null && !counted && !fromSwap && listenedMs >= 1_500L && reason == Player.MEDIA_ITEM_TRANSITION_REASON_SEEK) {
                history.add(
                    com.hwush.player.data.PlayEvent(System.currentTimeMillis(), left, library.find(left)?.durationMs ?: 0L, true),
                )
            }
            lastPath = mediaItem?.mediaId
            listenedMs = 0L
            counted = false
            if (reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT) {
                loopA = -1L
                loopB = -1L
            }
            val path = mediaItem?.mediaId
            if (path != null && reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT && !fromSwap) {
                val d = store.data.value
                val t = library.find(path)
                val saved = d.positions[path] ?: 0L
                if (t != null && isBook(t)) {
                    // A book always resumes, a few seconds early so you hear the sentence you left in.
                    if (saved > 10_000L && saved < t.durationMs - 20_000L) player.seekTo((saved - 3_000L).coerceAtLeast(0L))
                } else if (t != null && saved > 10_000L && d.rememberMinutes > 0 &&
                    t.durationMs >= d.rememberMinutes * 60_000L && saved < t.durationMs - 10_000L
                ) {
                    player.seekTo(saved)
                }
            }
            val songEnded = reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO ||
                reason == Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT || fromSwap
            if (sleepSongs > 0 && songEnded) {
                sleepSongs--
                if (sleepSongs == 0) {
                    sleepAfterSong = false
                    player.pause()
                    player.volume = rgFactor
                }
            }
            if (path != null && reason != Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT && !fromSwap) autoResetSound(path)
            applyForCurrent()
            maybeEndless()
            updateReplayGain()
            publish()
        }

        override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) {
            queueCache = List(player.mediaItemCount) { player.getMediaItemAt(it).mediaId }
            saveQueue()
            publish()
        }

        override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
            publish()
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            publish()
        }

        override fun onAudioSessionIdChanged(audioSessionId: Int) {
            setupEffects(audioSessionId)
            onAudioSession?.invoke(audioSessionId)
        }

        override fun onPlayerError(error: PlaybackException) {
            errorStreak++
            _messages.tryEmit("Could not play that file")
            if (errorStreak <= 5 && player.hasNextMediaItem()) {
                player.seekToNextMediaItem()
                player.prepare()
                player.play()
            } else {
                player.pause()
            }
        }
    }

    init {
        val d = store.data.value
        player.addListener(listener)
        player.skipSilenceEnabled = d.skipSilence
        player.repeatMode = repeatToExo(d.repeat)
        setupEffects(player.audioSessionId)
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager
            am?.registerAudioDeviceCallback(
                object : android.media.AudioDeviceCallback() {
                    override fun onAudioDevicesAdded(addedDevices: Array<out android.media.AudioDeviceInfo>?) = scanOutput()
                    override fun onAudioDevicesRemoved(removedDevices: Array<out android.media.AudioDeviceInfo>?) = scanOutput()
                },
                handler,
            )
        } catch (_: Exception) {
        }
        scanOutput()
        publish()
    }

    /** Finds what the sound is going to (Bluetooth, wired, USB or the speaker) and switches to its saved equalizer profile. */
    private fun scanOutput() {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager ?: return
        var found: OutputInfo? = null
        try {
            for (dev in am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
                val name = dev.productName?.toString().orEmpty()
                when (dev.type) {
                    android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> found = OutputInfo("bt:$name", name.ifBlank { "Bluetooth" })
                    android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES, android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET ->
                        if (found == null) found = OutputInfo("wired", "Wired headphones")
                    android.media.AudioDeviceInfo.TYPE_USB_HEADSET, android.media.AudioDeviceInfo.TYPE_USB_DEVICE ->
                        if (found == null) found = OutputInfo("usb", name.ifBlank { "USB audio" })
                    else -> {}
                }
            }
        } catch (_: Exception) {
        }
        val info = found ?: OutputInfo("speaker", "Phone speaker")
        if (info == output.value) return
        output.value = info
        val d = store.data.value
        val profile = d.deviceProfiles[info.key]?.let { n -> d.eqProfiles.firstOrNull { it.name == n } }
        if (profile != null) {
            applyEqProfile(profile)
            _messages.tryEmit("Equalizer: ${profile.name}")
        }
    }

    /** Switches the equalizer, bass and loudness to a saved profile. */
    fun applyEqProfile(p: com.hwush.player.data.EqProfile) {
        store.update { it.copy(eqEnabled = true, eqLevels = p.levels, eqPreset = "Profile: ${p.name}", bass = p.bass, loudness = p.loudness) }
        applyFx()
        publish()
    }

    // ------------------------------------------------------------------ helpers

    private fun repeatToExo(r: Int) = when (r) {
        1 -> Player.REPEAT_MODE_ALL
        2 -> Player.REPEAT_MODE_ONE
        else -> Player.REPEAT_MODE_OFF
    }

    private fun item(t: Track): MediaItem = MediaItem.Builder()
        .setMediaId(t.path)
        .setUri(t.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(t.title)
                .setArtist(t.artist)
                .setAlbumTitle(t.album)
                .setArtworkUri(artUri(t.path))
                .build(),
        )
        .build()

    fun currentPath(): String? = player.currentMediaItem?.mediaId

    /** Audiobooks and podcasts: marked one by one, or by marking the whole folder. */
    fun isBook(t: Track?): Boolean {
        if (t == null) return false
        val d = store.data.value
        return t.path in d.books || t.folder in d.bookFolders
    }

    private fun bookKey(t: Track): String = if (t.folder in store.data.value.bookFolders) t.folder else t.path
    fun currentTrack(): Track? = currentPath()?.let { library.find(it) }
    fun position(): Long = player.currentPosition.coerceAtLeast(0L)
    fun duration(): Long {
        val d = player.duration
        if (d != C.TIME_UNSET && d > 0) return d
        return currentTrack()?.durationMs ?: 0L
    }

    private fun ensureService() {
        try {
            ctx.startService(Intent(ctx, PlaybackService::class.java))
        } catch (_: Exception) {
        }
    }

    private fun ensureTick() {
        if (!ticking) {
            ticking = true
            handler.post(tickRunnable)
        }
    }

    // ------------------------------------------------------------------ transport

    fun playList(tracks: List<Track>, index: Int) {
        if (tracks.isEmpty()) return
        val i = index.coerceIn(0, tracks.lastIndex)
        originalOrder = tracks.map { it.path }
        val shuffleOn = store.data.value.shuffle
        val ordered = if (shuffleOn) {
            listOf(tracks[i]) + tracks.filterIndexed { k, _ -> k != i }.shuffled()
        } else {
            tracks
        }
        player.setMediaItems(ordered.map { item(it) }, if (shuffleOn) 0 else i, 0L)
        player.prepare()
        player.play()
        ensureService()
    }

    fun playShuffled(tracks: List<Track>) {
        if (tracks.isEmpty()) return
        store.update { it.copy(shuffle = true) }
        playList(tracks, Random.nextInt(tracks.size))
    }

    fun togglePlay() {
        if (player.mediaItemCount == 0) return
        if (player.playbackState == Player.STATE_ENDED) {
            player.seekTo(0, 0L)
            player.play()
            ensureService()
            return
        }
        if (player.playWhenReady) {
            player.pause()
        } else {
            if (player.playbackState == Player.STATE_IDLE) player.prepare()
            player.play()
            ensureService()
        }
    }

    fun next() {
        if (player.mediaItemCount > 0) player.seekToNext()
    }

    fun previous() {
        if (player.mediaItemCount > 0) player.seekToPrevious()
    }

    fun seekTo(ms: Long) {
        player.seekTo(ms.coerceAtLeast(0L))
    }

    /** Jumps forward or back inside the current song, for example 10 seconds. */
    fun seekBy(deltaMs: Long) {
        if (player.mediaItemCount == 0) return
        val end = duration()
        val target = player.currentPosition + deltaMs
        player.seekTo(if (end > 0L) target.coerceIn(0L, end) else target.coerceAtLeast(0L))
    }

    fun skipTo(index: Int) {
        if (index !in 0 until player.mediaItemCount) return
        player.seekTo(index, 0L)
        player.play()
        ensureService()
    }

    fun cycleRepeat() {
        val n = (store.data.value.repeat + 1) % 3
        store.update { it.copy(repeat = n) }
        player.repeatMode = repeatToExo(n)
        publish()
    }

    fun toggleShuffle() {
        val on = !store.data.value.shuffle
        store.update { it.copy(shuffle = on) }
        val n = player.mediaItemCount
        if (n > 1) {
            val cur = player.currentMediaItemIndex
            val all = List(n) { player.getMediaItemAt(it) }
            if (on) {
                originalOrder = all.map { it.mediaId }
                val rest = all.filterIndexed { k, _ -> k != cur }.shuffled()
                player.removeMediaItems(cur + 1, n)
                player.removeMediaItems(0, cur)
                player.addMediaItems(rest)
            } else {
                val rank = HashMap<String, Int>()
                originalOrder.forEachIndexed { k, p -> rank.putIfAbsent(p, k) }
                val sorted = all.withIndex().sortedBy { rank[it.value.mediaId] ?: Int.MAX_VALUE }
                val pos = sorted.indexOfFirst { it.index == cur }
                val before = sorted.take(pos).map { it.value }
                val after = sorted.drop(pos + 1).map { it.value }
                player.removeMediaItems(cur + 1, n)
                player.removeMediaItems(0, cur)
                player.addMediaItems(0, before)
                player.addMediaItems(after)
            }
        }
        publish()
    }

    // ------------------------------------------------------------------ queue editing

    fun playNext(tracks: List<Track>) {
        if (tracks.isEmpty()) return
        if (player.mediaItemCount == 0) {
            playList(tracks, 0)
            return
        }
        val at = (player.currentMediaItemIndex + 1).coerceAtMost(player.mediaItemCount)
        player.addMediaItems(at, tracks.map { item(it) })
        _messages.tryEmit(if (tracks.size == 1) "Playing next" else "${tracks.size} songs play next")
    }

    fun enqueue(tracks: List<Track>) {
        if (tracks.isEmpty()) return
        if (player.mediaItemCount == 0) {
            playList(tracks, 0)
            return
        }
        player.addMediaItems(tracks.map { item(it) })
        _messages.tryEmit(if (tracks.size == 1) "Added to queue" else "${tracks.size} songs added to queue")
    }

    fun removeAt(index: Int) {
        if (index in 0 until player.mediaItemCount) player.removeMediaItem(index)
    }

    fun moveInQueue(from: Int, to: Int) {
        val n = player.mediaItemCount
        if (from in 0 until n && to in 0 until n && from != to) player.moveMediaItem(from, to)
    }

    fun clearUpcoming() {
        val n = player.mediaItemCount
        val cur = player.currentMediaItemIndex
        if (cur + 1 < n) player.removeMediaItems(cur + 1, n)
    }

    fun stopAndClear() {
        player.stop()
        player.clearMediaItems()
        store.update { it.copy(queue = emptyList(), queueIndex = 0, queuePos = 0L) }
        publish()
    }

    /** Puts the saved queue back on launch, paused, so lock screen and widget have something to show. */
    fun restore() {
        if (player.mediaItemCount > 0) return
        val d = store.data.value
        if (d.queue.isEmpty()) return
        val kept = d.queue.mapNotNull { library.find(it) }
        if (kept.isEmpty()) return
        val curPath = d.queue.getOrNull(d.queueIndex)
        val idx = kept.indexOfFirst { it.path == curPath }.takeIf { it >= 0 } ?: 0
        originalOrder = kept.map { it.path }
        player.setMediaItems(kept.map { item(it) }, idx, d.queuePos)
        player.prepare()
        player.pause()
    }

    // ------------------------------------------------------------------ speed and pitch

    fun semitonesToRatio(st: Float): Float = 2.0.pow(st / 12.0).toFloat()

    private fun songScoped(path: String? = currentPath()): Boolean =
        path != null && store.data.value.songFx.containsKey(path)

    private fun writeSpeedPitch(speed: Float, pitch: Float) {
        val s = speed.coerceIn(0.5f, 2.0f)
        val p = pitch.coerceIn(0.5f, 2.0f)
        val path = currentPath()
        if (path != null && songScoped(path)) {
            store.update { d ->
                val old = d.songFx[path]
                d.copy(songFx = d.songFx + (path to SongFx(s, p, old?.eq, old?.bass)))
            }
        } else if (isBook(currentTrack())) {
            val trk = currentTrack()
            if (trk != null) store.update { it.copy(bookSpeeds = it.bookSpeeds + (bookKey(trk) to s)) }
        } else {
            store.update { it.copy(speed = s, pitch = p) }
        }
        player.playbackParameters = PlaybackParameters(s, p)
        publish()
    }

    fun setSpeed(v: Float) {
        val link = store.data.value.linkSpeedPitch
        writeSpeedPitch(v, if (link) v else player.playbackParameters.pitch)
    }

    fun setPitch(ratio: Float) {
        if (store.data.value.linkSpeedPitch) return
        writeSpeedPitch(player.playbackParameters.speed, ratio)
    }

    /** Link on = pitch follows speed like a record. Off = speed changes keep the original pitch. */
    fun setLinkSpeedPitch(on: Boolean) {
        store.update { it.copy(linkSpeedPitch = on) }
        val s = player.playbackParameters.speed
        writeSpeedPitch(s, if (on) s else 1f)
    }

    fun resetSpeedPitch() = writeSpeedPitch(1f, 1f)

    /** Plays what an alarm asks for, starting very quiet and rising over the alarm's ramp time. */
    fun startAlarm(a: com.hwush.player.data.Alarm) {
        val d = store.data.value
        val all = library.tracks.value
        var picks: List<Track> = when (a.sourceKind) {
            1 -> d.playlists.firstOrNull { it.id.toString() == a.sourceArg }?.paths?.mapNotNull { library.find(it) } ?: emptyList()
            2 -> listOfNotNull(library.find(a.sourceArg))
            3 -> all.filter { it.path in d.favorites }
            else -> all
        }
        if (picks.isEmpty()) picks = all
        if (picks.isEmpty()) return
        val list = if (a.sourceKind == 2) picks else picks.shuffled()
        alarmRampMs = a.rampSeconds * 1000L
        alarmRampStart = System.currentTimeMillis()
        playList(list, 0)
        if (alarmRampMs > 0L) {
            player.volume = 0f
            ensureTick()
        }
    }

    /** On: this song keeps its own speed, pitch, equalizer and bass. Off: it follows the global sound. */
    fun setSongScope(on: Boolean) {
        val path = currentPath() ?: return
        if (on) {
            val ps = player.playbackParameters
            store.update { d ->
                d.copy(songFx = d.songFx + (path to SongFx(ps.speed, ps.pitch, d.eqLevels.takeIf { it.isNotEmpty() }, d.bass)))
            }
        } else {
            store.update { it.copy(songFx = it.songFx - path) }
        }
        applyForCurrent()
        publish()
    }

    // ------------------------------------------------------------------ equalizer and effects

    private fun setupEffects(session: Int) {
        releaseEffects()
        if (session == C.AUDIO_SESSION_ID_UNSET) return
        try {
            val e = Equalizer(0, session)
            val range = e.bandLevelRange
            val bands = e.numberOfBands.toInt()
            eqInfo.value = EqInfo(
                bands = bands,
                minMb = range[0].toInt(),
                maxMb = range[1].toInt(),
                freqsHz = List(bands) { e.getCenterFreq(it.toShort()) / 1000 },
                presets = List(e.numberOfPresets.toInt()) { e.getPresetName(it.toShort()) },
            )
            eq = e
        } catch (_: Exception) {
            eq = null
            eqInfo.value = null
        }
        try {
            bassBoost = BassBoost(0, session)
        } catch (_: Exception) {
            bassBoost = null
        }
        try {
            loudness = LoudnessEnhancer(session)
        } catch (_: Exception) {
            loudness = null
        }
        try {
            virtualizer = Virtualizer(0, session)
        } catch (_: Exception) {
            virtualizer = null
        }
        applyFx()
    }

    private fun releaseEffects() {
        try { eq?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        try { loudness?.release() } catch (_: Exception) {}
        try { virtualizer?.release() } catch (_: Exception) {}
        virtualizer = null
        eq = null
        bassBoost = null
        loudness = null
    }

    private fun applyFx() {
        val d = store.data.value
        val sf = currentPath()?.let { d.songFx[it] }
        val levels = sf?.eq ?: d.eqLevels
        val bass = sf?.bass ?: d.bass
        try {
            eq?.let { e ->
                e.setEnabled(d.eqEnabled)
                if (d.eqEnabled) {
                    val info = eqInfo.value
                    val lo = info?.minMb ?: -1500
                    val hi = info?.maxMb ?: 1500
                    for (i in 0 until e.numberOfBands.toInt()) {
                        e.setBandLevel(i.toShort(), levels.getOrElse(i) { 0 }.coerceIn(lo, hi).toShort())
                    }
                }
            }
        } catch (_: Exception) {
        }
        try {
            bassBoost?.let { b ->
                if (b.strengthSupported) {
                    b.setStrength(bass.coerceIn(0, 1000).toShort())
                    b.setEnabled(bass > 0)
                }
            }
        } catch (_: Exception) {
        }
        // A song marked louder gets its extra from the same booster, on top of the global one.
        val extra = (currentPath()?.let { d.songTrim[it] } ?: 0).coerceAtLeast(0) * 100
        try {
            loudness?.let { l ->
                val total = (d.loudness + extra).coerceIn(0, 1500)
                l.setTargetGain(total)
                l.setEnabled(total > 0)
            }
        } catch (_: Exception) {
        }
        try {
            virtualizer?.let { v ->
                if (v.strengthSupported) {
                    v.setStrength(d.spatial.coerceIn(0, 1000).toShort())
                    v.setEnabled(d.spatial > 0)
                }
            }
        } catch (_: Exception) {
        }
        balance.setBalance(d.balance)
        balance.mono = d.mono
    }

    /** How much to turn a song down. Only negative trims act here; positive ones use the loudness booster. */
    private fun trimScale(): Float {
        val db = currentPath()?.let { store.data.value.songTrim[it] } ?: 0
        return if (db < 0) 10.0.pow(db / 20.0).toFloat() else 1f
    }

    fun setBalanceValue(v: Int) {
        store.setBalance(v)
        applyFx()
    }

    fun setMonoValue(v: Boolean) {
        store.setMono(v)
        applyFx()
    }

    fun setSpatialValue(v: Int) {
        store.setSpatial(v)
        applyFx()
    }

    /** Sets the volume trim for the song that is playing, from -12 dB to +6 dB. */
    fun setTrimForCurrent(db: Int) {
        val path = currentPath() ?: return
        store.setSongTrim(path, db)
        updateReplayGain()
        applyFx()
        if (player.isPlaying && !swapping) player.volume = rgFactor
    }

    private fun swapPath(): String? =
        if (swapIdx in 0 until player.mediaItemCount) player.getMediaItemAt(swapIdx).mediaId else null

    /** A new song starts at normal speed, so one slowed song never leaves the next ones slowed. */
    private fun autoResetSound(path: String) {
        val d = store.data.value
        if (!d.autoResetSpeed || d.songFx.containsKey(path)) return
        if (abs(d.speed - 1f) < 0.001f && abs(d.pitch - 1f) < 0.001f) return
        val t = library.find(path)
        if (isBook(t)) return
        // Long recordings such as audiobooks and mixes keep the speed you chose.
        if (t != null && d.rememberMinutes > 0 && t.durationMs >= d.rememberMinutes * 60_000L) return
        store.update { it.copy(speed = 1f, pitch = 1f) }
        _messages.tryEmit("Speed and pitch back to normal")
    }

    /** Endless mode: when the queue is about to run out, add songs that fit what you play. */
    private fun maybeEndless() {
        val d = store.data.value
        if (!d.endless || player.repeatMode != Player.REPEAT_MODE_OFF || player.mediaItemCount == 0) return
        if (isBook(currentTrack())) return
        val remaining = player.mediaItemCount - player.currentMediaItemIndex - 1
        if (remaining >= 2) return
        val picks = endlessPicks(5)
        if (picks.isEmpty()) return
        player.addMediaItems(picks.map { item(it) })
        originalOrder = originalOrder + picks.map { it.path }
        _messages.tryEmit("Endless: added ${picks.size} songs")
    }

    private fun endlessPicks(n: Int): List<Track> {
        val d = store.data.value
        val cur = currentTrack()
        val inQueue = queueCache.toHashSet()
        val day = System.currentTimeMillis() - 24L * 3_600_000L
        return library.tracks.value.asSequence()
            .filter { it.path !in inQueue && it.durationMs >= 30_000L && it.path !in d.hidden }
            .map { t ->
                var sc = Random.nextFloat() * 2f
                if (cur != null) {
                    if (t.artist == cur.artist && t.artist.isNotBlank()) sc += 3f
                    if (t.genre.isNotBlank() && t.genre == cur.genre) sc += 2f
                    if (t.album == cur.album && t.album.isNotBlank()) sc += 1f
                    if (cur.year > 0 && t.year > 0 && abs(t.year - cur.year) <= 3) sc += 0.7f
                }
                if (t.path in d.favorites) sc += 1.5f
                sc += min(d.plays[t.path] ?: 0, 10) * 0.2f
                sc += (d.ratings[t.path] ?: 0) * 0.4f
                if ((d.lastPlayed[t.path] ?: 0L) > day) sc -= 2.5f
                t to sc
            }
            .sortedByDescending { it.second }
            .take(n)
            .map { it.first }
            .toList()
    }

    /** Called whenever the current song changes: loads its own sound or the global one. */
    private fun applyForCurrent() {
        val d = store.data.value
        val sf = currentPath()?.let { d.songFx[it] }
        val trk = currentTrack()
        val bookSpeed = if (sf == null && isBook(trk) && trk != null) d.bookSpeeds[bookKey(trk)] else null
        val s = sf?.speed ?: bookSpeed ?: (if (sf == null && isBook(trk)) 1f else d.speed)
        val p = sf?.pitch ?: (if (bookSpeed != null || (sf == null && isBook(trk))) 1f else d.pitch)
        val cur = player.playbackParameters
        if (abs(cur.speed - s) > 0.001f || abs(cur.pitch - p) > 0.001f) {
            player.playbackParameters = PlaybackParameters(s, p)
        }
        applyFx()
    }

    private fun writeEq(levels: List<Int>, preset: String) {
        val path = currentPath()
        if (path != null && songScoped(path)) {
            store.update { d ->
                val old = d.songFx[path]
                d.copy(
                    eqEnabled = true,
                    eqPreset = preset,
                    songFx = if (old != null) d.songFx + (path to old.copy(eq = levels)) else d.songFx,
                )
            }
        } else {
            store.update { it.copy(eqEnabled = true, eqLevels = levels, eqPreset = preset) }
        }
        applyFx()
        publish()
    }

    /** The levels the equalizer is using right now (this song's own, or the global ones). */
    fun currentEqLevels(): List<Int> {
        val d = store.data.value
        val sf = currentPath()?.let { d.songFx[it] }
        val bands = eqInfo.value?.bands ?: 0
        val base = sf?.eq ?: d.eqLevels
        return List(bands) { base.getOrElse(it) { 0 } }
    }

    fun currentBass(): Int {
        val d = store.data.value
        return currentPath()?.let { d.songFx[it]?.bass } ?: d.bass
    }

    fun setEqEnabled(on: Boolean) {
        store.update { it.copy(eqEnabled = on) }
        applyFx()
        publish()
    }

    fun setEqBand(index: Int, mb: Int) {
        val info = eqInfo.value ?: return
        val levels = currentEqLevels().toMutableList()
        if (index !in levels.indices) return
        levels[index] = mb.coerceIn(info.minMb, info.maxMb)
        writeEq(levels, "Custom")
    }

    fun usePreset(index: Int) {
        val e = eq ?: return
        try {
            e.usePreset(index.toShort())
            val levels = List(e.numberOfBands.toInt()) { e.getBandLevel(it.toShort()).toInt() }
            writeEq(levels, eqInfo.value?.presets?.getOrNull(index) ?: "Custom")
        } catch (_: Exception) {
        }
    }

    fun resetEq() {
        val bands = eqInfo.value?.bands ?: return
        writeEq(List(bands) { 0 }, "Flat")
    }

    fun setBass(strength: Int) {
        val path = currentPath()
        if (path != null && songScoped(path)) {
            store.update { d ->
                val old = d.songFx[path]
                d.copy(songFx = if (old != null) d.songFx + (path to old.copy(bass = strength)) else d.songFx)
            }
        } else {
            store.update { it.copy(bass = strength) }
        }
        applyFx()
        publish()
    }

    fun setLoudness(gainMb: Int) {
        store.update { it.copy(loudness = gainMb) }
        applyFx()
        publish()
    }

    fun setSkipSilence(on: Boolean) {
        store.update { it.copy(skipSilence = on) }
        player.skipSilenceEnabled = on
    }

    /** Re-reads every setting from the store, for example after a backup was restored. */
    fun reapplySettings() {
        val d = store.data.value
        player.skipSilenceEnabled = d.skipSilence
        player.repeatMode = repeatToExo(d.repeat)
        applyForCurrent()
        updateReplayGain()
        publish()
    }

    // ------------------------------------------------------------------ A-B loop

    fun setLoopA() {
        if (player.mediaItemCount == 0) return
        loopA = player.currentPosition.coerceAtLeast(0L)
        if (loopB <= loopA) loopB = -1L
        if (loopB > loopA) ensureLoopTick()
        publish()
    }

    fun setLoopB() {
        if (player.mediaItemCount == 0) return
        val pos = player.currentPosition
        if (loopA < 0L) loopA = 0L
        if (pos < loopA + 500L) {
            _messages.tryEmit("Set point B after point A")
            return
        }
        loopB = pos
        ensureLoopTick()
        publish()
    }

    /** Plays one part of a song on repeat, for example to preview a ringtone cut. */
    fun previewRange(t: Track, startMs: Long, endMs: Long) {
        val apply = {
            loopA = startMs
            loopB = endMs
            ensureLoopTick()
            player.seekTo(startMs)
            player.play()
            publish()
        }
        if (currentPath() == t.path) {
            apply()
        } else {
            playList(listOf(t), 0)
            handler.postDelayed({ apply() }, 300L)
        }
    }

    fun clearLoop() {
        loopA = -1L
        loopB = -1L
        publish()
    }

    private fun ensureLoopTick() {
        if (!loopTicking) {
            loopTicking = true
            handler.post(loopRunnable)
        }
    }

    // ------------------------------------------------------------------ volume normalizing (ReplayGain)

    private fun factorFor(g: Gains, mode: Int): Float {
        val db = if (mode == 2) (g.album ?: g.track) else (g.track ?: g.album)
        if (db == null) return 1f
        return 10.0.pow(db / 20.0).toFloat().coerceIn(0.05f, 1f)
    }

    private fun setRg(f: Float) {
        rgFactor = f * trimScale()
        if (!player.isPlaying && !swapping) player.volume = f
    }

    /** Turns loud songs down to match their ReplayGain tag. Songs without a tag are left alone. */
    private fun updateReplayGain() {
        val mode = store.data.value.replayGain
        val path = currentPath()
        if (mode == 0 || path == null) {
            setRg(1f)
            return
        }
        val cached = gainCache[path]
        if (cached != null) {
            setRg(factorFor(cached, mode))
            return
        }
        setRg(1f)
        rgExec.execute {
            val g = ReplayGainReader.read(path)
            handler.post {
                gainCache[path] = g
                if (currentPath() == path) setRg(factorFor(g, store.data.value.replayGain))
            }
        }
    }

    // ------------------------------------------------------------------ sleep timer

    fun setSleepMinutes(minutes: Int) {
        sleepAfterSong = false
        sleepSongs = 0
        sleepEndsAt = if (minutes <= 0) 0L else System.currentTimeMillis() + minutes * 60_000L
        if (sleepEndsAt > 0L) ensureTick()
        updateShake()
        publish()
    }

    fun sleepAfterThisSong() = sleepAfterSongs(1)

    /** Stops the music once this many songs have finished, counting the one playing now. */
    fun sleepAfterSongs(count: Int) {
        sleepEndsAt = 0L
        sleepSongs = count.coerceAtLeast(1)
        sleepAfterSong = true
        updateShake()
        publish()
    }

    fun cancelSleep() {
        sleepEndsAt = 0L
        sleepAfterSong = false
        sleepSongs = 0
        player.volume = rgFactor
        updateShake()
        publish()
    }

    /** Shaking the phone while the timer runs adds ten minutes. */
    private fun extendSleep() {
        if (sleepEndsAt <= 0L) return
        sleepEndsAt = maxOf(sleepEndsAt, System.currentTimeMillis()) + 10 * 60_000L
        _messages.tryEmit("Sleep timer extended by 10 minutes")
        publish()
    }

    private fun updateShake() {
        val want = store.data.value.shakeExtend && sleepEndsAt > 0L
        if (want && shake == null) {
            shake = ShakeExtender(ctx) { handler.post { extendSleep() } }.also { it.start() }
        } else if (!want) {
            shake?.stop()
            shake = null
        }
    }

    // ------------------------------------------------------------------ ticking: fades, sleep, counts, saving

    private fun startGhost(nextIdx: Int) {
        try {
            val g = ExoPlayer.Builder(ctx).build()
            g.setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(),
                false,
            )
            // Same audio session as the main player, so the equalizer and bass apply to both during the overlap.
            try { g.audioSessionId = player.audioSessionId } catch (_: Exception) {}
            g.setMediaItem(player.getMediaItemAt(nextIdx))
            g.playbackParameters = player.playbackParameters
            g.volume = 0f
            g.prepare()
            g.play()
            ghost = g
            ghostIndex = nextIdx
        } catch (_: Exception) {
            stopGhost()
        }
    }

    private fun stopGhost() {
        val g = ghost ?: return
        ghost = null
        ghostIndex = -1
        swapping = false
        swapIdx = -1
        try {
            g.stop()
            g.release()
        } catch (_: Exception) {
        }
    }

    /**
     * Moves the main player onto the next song at the spot the second player reached. The second player
     * keeps playing, and the main one stays silent, until the main one is ready and in time. Only then
     * does the second one stop, so there is no gap and no restart.
     */
    private fun handOff() {
        val g = ghost ?: return
        val idx = ghostIndex
        val pos = try { g.currentPosition } catch (_: Exception) { 0L }
        if (idx !in 0 until player.mediaItemCount) {
            stopGhost()
            return
        }
        swapping = true
        swapIdx = idx
        swapStartedAt = System.currentTimeMillis()
        swapSeekCount = 0
        fading = false
        player.volume = 0f
        g.volume = rgFactor
        swapSeekAt = System.currentTimeMillis()
        player.seekTo(idx, pos + swapLatency)
        handler.postDelayed({ pollSwap() }, 40L)
    }

    private fun pollSwap() {
        val g = ghost
        if (!swapping || g == null || fading) return
        val now = System.currentTimeMillis()
        val waited = now - swapStartedAt
        val ready = player.playbackState == Player.STATE_READY && player.currentMediaItemIndex == swapIdx
        if (ready && player.isPlaying) {
            val gp = try { g.currentPosition } catch (_: Exception) { -1L }
            val drift = if (gp >= 0L) gp - player.currentPosition else 0L
            if (abs(drift) > 50L && abs(drift) < 2_000L && swapSeekCount < 3) {
                // Not lined up yet. Learn how long a seek takes here and aim ahead by that much.
                swapSeekCount++
                swapLatency = (now - swapSeekAt).coerceIn(60L, 800L)
                swapSeekAt = now
                player.seekTo(gp + swapLatency)
                handler.postDelayed({ pollSwap() }, 30L)
                return
            }
            finishSwap()
            return
        }
        if (waited > 2_500L) {
            // The main player could not keep up. Let it carry on alone rather than stall.
            player.volume = rgFactor
            stopGhost()
            return
        }
        handler.postDelayed({ pollSwap() }, 30L)
    }

    /** The last step is a very short crossfade between the two players, so the switch cannot be heard as a cut. */
    private fun finishSwap() {
        fading = true
        val t0 = System.currentTimeMillis()
        val total = 180f
        val step = object : Runnable {
            override fun run() {
                val g = ghost
                val k = ((System.currentTimeMillis() - t0) / total).coerceIn(0f, 1f)
                val a = kotlin.math.sin(k * Math.PI.toFloat() / 2f)
                val b = kotlin.math.cos(k * Math.PI.toFloat() / 2f)
                player.volume = a * rgFactor
                if (g != null) {
                    try { g.volume = b * rgFactor } catch (_: Exception) {}
                }
                if (k >= 1f || g == null) {
                    player.volume = rgFactor
                    fading = false
                    stopGhost()
                } else {
                    handler.postDelayed(this, 16L)
                }
            }
        }
        handler.post(step)
    }

    private fun onTick() {
        val d = store.data.value
        val now = System.currentTimeMillis()
        if (player.isPlaying && now - lastWidgetPush > 15_000L) {
            // Keeps the progress bar on the home screen widgets moving.
            lastWidgetPush = now
            HwushWidget.update(ctx)
        }
        val dur = player.duration
        val pos = player.currentPosition
        var vol = 1f
        if (swapping) {
            // Hand off in progress: the volumes are managed by pollSwap.
            if (player.isPlaying) listenedMs += TICK_MS
            return
        }

        val fadeMs = d.fadeSeconds * 1000L
        val nextIdx = player.nextMediaItemIndex
        val canOverlap = d.overlapFade && fadeMs > 0L && player.repeatMode != Player.REPEAT_MODE_ONE &&
            nextIdx != C.INDEX_UNSET && dur != C.TIME_UNSET && dur > fadeMs * 2 && loopB < 0L && sleepSongs != 1
        if (canOverlap && player.isPlaying) {
            val toEnd = dur - pos
            if (toEnd <= fadeMs) {
                if (ghost == null) startGhost(nextIdx)
                val g = ghost
                if (g != null) {
                    val progress = (1f - toEnd.toFloat() / fadeMs).coerceIn(0f, 1f)
                    // Equal power curves keep the loudness steady through the middle of the blend.
                    vol = min(vol, kotlin.math.cos(progress * Math.PI.toFloat() / 2f))
                    try {
                        g.volume = kotlin.math.sin(progress * Math.PI.toFloat() / 2f) * rgFactor
                    } catch (_: Exception) {
                    }
                    if (toEnd <= TICK_MS + 120L) {
                        // The main player stays silent until it has caught up; the volumes are handled from here.
                        handOff()
                        if (player.isPlaying) listenedMs += TICK_MS
                        return
                    }
                }
            }
        } else if (ghost != null) {
            stopGhost()
        }
        if (!canOverlap && fadeMs > 0L && player.isPlaying && dur != C.TIME_UNSET && dur > fadeMs * 2) {
            val toEnd = dur - pos
            if (toEnd < fadeMs) vol = min(vol, (toEnd.toFloat() / fadeMs).coerceIn(0f, 1f))
            if (pos < fadeMs) vol = min(vol, (pos.toFloat() / fadeMs).coerceIn(0f, 1f))
        }

        if (sleepEndsAt > 0L) {
            val left = sleepEndsAt - now
            if (left <= 0L) {
                sleepEndsAt = 0L
                player.pause()
                player.volume = rgFactor
                updateShake()
                publish()
                return
            }
            val sleepFade = d.sleepFadeSeconds.coerceIn(3, 120) * 1000L
            if (left < sleepFade) vol = min(vol, left.toFloat() / sleepFade)
        }

        if (alarmRampMs > 0L) {
            // A wake-up alarm starts silent and rises slowly.
            val p = ((now - alarmRampStart).toFloat() / alarmRampMs).coerceIn(0f, 1f)
            vol = min(vol, 0.01f + 0.99f * p * p)
            if (p >= 1f) alarmRampMs = 0L
        }
        val target = vol * rgFactor
        if (abs(player.volume - target) > 0.02f) player.volume = target

        if (player.isPlaying) {
            listenedMs += TICK_MS
            val path = currentPath()
            if (!counted && path != null && dur != C.TIME_UNSET) {
                val need = min(30_000L, dur / 2)
                if (listenedMs >= need) {
                    counted = true
                    history.add(com.hwush.player.data.PlayEvent(now, path, dur, false))
                    store.update { s ->
                        s.copy(
                            plays = s.plays + (path to ((s.plays[path] ?: 0) + 1)),
                            lastPlayed = s.lastPlayed + (path to now),
                        )
                    }
                }
            }
            if (now - lastSaveAt > 5_000L) {
                lastSaveAt = now
                saveState()
            }
        }
    }

    private fun saveState() {
        if (player.mediaItemCount == 0) return
        val path = currentPath() ?: return
        val pos = player.currentPosition.coerceAtLeast(0L)
        val dur = player.duration
        val d = store.data.value
        val book = isBook(currentTrack())
        val long = book || (dur != C.TIME_UNSET && d.rememberMinutes > 0 && dur >= d.rememberMinutes * 60_000L)
        val finished = dur != C.TIME_UNSET && pos > dur - (if (book) 25_000L else 10_000L)
        store.update { s ->
            var positions = s.positions
            if (long) {
                positions = if (finished) positions - path else if (pos > 5_000L) positions + (path to pos) else positions
            }
            val done = if (book && finished) s.bookDone + path else s.bookDone
            s.copy(queueIndex = player.currentMediaItemIndex, queuePos = pos, positions = positions, bookDone = done)
        }
    }

    private fun saveQueue() {
        if (player.mediaItemCount == 0 && store.data.value.queue.isEmpty()) return
        val q = queueCache
        val idx = player.currentMediaItemIndex
        store.update { it.copy(queue = q, queueIndex = idx) }
    }

    // ------------------------------------------------------------------ ui state

    private fun publish() {
        val d = store.data.value
        val path = currentPath()
        val ps = player.playbackParameters
        val ui = PlayerUi(
            path = path,
            isPlaying = player.isPlaying,
            index = player.currentMediaItemIndex,
            queue = queueCache,
            shuffle = d.shuffle,
            repeat = when (player.repeatMode) {
                Player.REPEAT_MODE_ALL -> 1
                Player.REPEAT_MODE_ONE -> 2
                else -> 0
            },
            speed = ps.speed,
            pitch = ps.pitch,
            songScope = path != null && d.songFx.containsKey(path),
            sleepEndsAt = sleepEndsAt,
            sleepAfterSong = sleepAfterSong,
            sleepSongs = sleepSongs,
            loopA = loopA,
            loopB = loopB,
        )
        _ui.value = ui
        val key = "${ui.path}|${ui.isPlaying}"
        if (key != lastWidgetKey) {
            lastWidgetKey = key
            HwushWidget.update(ctx)
        }
    }

    companion object {
        private const val TICK_MS = 100L

        fun artUri(path: String): Uri =
            Uri.Builder().scheme("hwush-art").authority("t").appendQueryParameter("p", path).build()
    }
}


/** Watches the accelerometer for a firm shake while the sleep timer runs. */
private class ShakeExtender(ctx: Context, private val onShake: () -> Unit) : android.hardware.SensorEventListener {
    private val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as? android.hardware.SensorManager
    private var last = 0L

    fun start() {
        val sensor = sm?.getDefaultSensor(android.hardware.Sensor.TYPE_ACCELEROMETER) ?: return
        sm?.registerListener(this, sensor, android.hardware.SensorManager.SENSOR_DELAY_UI)
    }

    fun stop() {
        try { sm?.unregisterListener(this) } catch (_: Exception) {}
    }

    override fun onSensorChanged(e: android.hardware.SensorEvent) {
        val g = kotlin.math.sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) / 9.81f
        val now = System.currentTimeMillis()
        if (g > 2.6f && now - last > 1_200L) {
            last = now
            onShake()
        }
    }

    override fun onAccuracyChanged(sensor: android.hardware.Sensor?, accuracy: Int) {}
}
